package com.archivero

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Íconos de las 5 fichas de Inicio (Descargas, Música, Fotos, Vídeos, APKs) al estilo de carpetas de Windows XP:
 * carpeta crema con brillo, abierta, y un objeto de colores que asoma por detrás de la tapa.
 * Se dibujan en un lienzo de 100 × 84 y se escalan, así que se ven nítidos a cualquier tamaño y no dependen del tema.
 */
@Composable
fun FichaIcon(tab: HomeTab, w: Dp = 52.dp) {
    Canvas(Modifier.size(w, w * 0.84f)) {
        scale(size.width / 100f, Offset.Zero) {
            carpetaAtras()
            when (tab) {
                HomeTab.DOWNLOADS -> objetoDescarga()
                HomeTab.MUSIC -> objetoMusica()
                HomeTab.PHOTOS -> objetoFoto()
                HomeTab.VIDEOS -> objetoVideo()
                HomeTab.APKS -> objetoAndroid()
            }
            carpetaFrente()
        }
    }
}

private fun DrawScope.carpetaAtras() {
    val p = Path().apply {
        moveTo(4f, 16f); quadraticBezierTo(4f, 9f, 11f, 9f)
        lineTo(33f, 9f); quadraticBezierTo(37f, 9f, 39f, 13f)
        lineTo(41f, 16f); lineTo(89f, 16f); quadraticBezierTo(96f, 16f, 96f, 23f)
        lineTo(96f, 73f); quadraticBezierTo(96f, 80f, 89f, 80f)
        lineTo(11f, 80f); quadraticBezierTo(4f, 80f, 4f, 73f)
        close()
    }
    drawPath(p, Brush.verticalGradient(listOf(Color(0xFFE9C96C), Color(0xFFCFA43E)), startY = 9f, endY = 80f))
    drawPath(p, Color(0xFFB88A2A), style = Stroke(1.1f))
}

private fun DrawScope.carpetaFrente() {
    val p = Path().apply {
        moveTo(8f, 46f); quadraticBezierTo(9f, 40f, 16f, 39f)
        lineTo(92f, 34f); quadraticBezierTo(98f, 33.5f, 97f, 39f)
        lineTo(91f, 76f); quadraticBezierTo(90f, 81f, 84f, 81f)
        lineTo(9f, 81f); quadraticBezierTo(3f, 81f, 4f, 75f)
        close()
    }
    drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFF4BE), Color(0xFFF4D062)), startY = 34f, endY = 81f))
    drawPath(p, Color(0xFFC79A33), style = Stroke(1.2f))
    // Brillo en el borde de la tapa
    drawLine(Color(0xBBFFFFFF), Offset(18f, 41.5f), Offset(91f, 36.5f), strokeWidth = 1.6f, cap = StrokeCap.Round)
}

// ── Descargas: hoja con flecha azul hacia abajo ──
private fun DrawScope.objetoDescarga() {
    rotate(-4f, Offset(50f, 25f)) {
        val hoja = Path().apply {
            moveTo(30f, 7f); quadraticBezierTo(30f, 4f, 33f, 4f)
            lineTo(56f, 4f); lineTo(70f, 18f); lineTo(70f, 43f)
            quadraticBezierTo(70f, 46f, 67f, 46f); lineTo(33f, 46f)
            quadraticBezierTo(30f, 46f, 30f, 43f); close()
        }
        drawPath(hoja, Color.White)
        drawPath(hoja, Color(0xFFB4BFD0), style = Stroke(1f))
        val doblez = Path().apply { moveTo(56f, 4f); lineTo(70f, 18f); lineTo(56f, 18f); close() }
        drawPath(doblez, Color(0xFFD5E0F0))
        val flecha = Path().apply {
            moveTo(45f, 14f); lineTo(55f, 14f); lineTo(55f, 24f); lineTo(61f, 24f)
            lineTo(50f, 36f); lineTo(39f, 24f); lineTo(45f, 24f); close()
        }
        drawPath(flecha, Brush.verticalGradient(listOf(Color(0xFF63B2F7), Color(0xFF1F62B8)), startY = 14f, endY = 36f))
        drawPath(flecha, Color(0xFF184F95), style = Stroke(0.8f))
    }
}

// ── Música: nota musical azul-violeta ──
private fun DrawScope.objetoMusica() {
    val color = Brush.verticalGradient(listOf(Color(0xFF6877EE), Color(0xFF2A2E9C)), startY = 4f, endY = 42f)
    drawRoundRect(color, Offset(52f, 5f), Size(5.5f, 31f), CornerRadius(2f, 2f))
    val bandera = Path().apply {
        moveTo(57.5f, 5f); cubicTo(69f, 7f, 73f, 14f, 70.5f, 25f)
        cubicTo(69f, 18f, 64f, 14.5f, 57.5f, 13.5f); close()
    }
    drawPath(bandera, color)
    rotate(-20f, Offset(45f, 35.5f)) {
        drawOval(color, Offset(35f, 30f), Size(20f, 12f))
        drawOval(Color(0x66FFFFFF), Offset(38f, 31.5f), Size(8f, 3.5f))
    }
}

// ── Fotos: tarjeta con cielo, sol y montañas ──
private fun DrawScope.objetoFoto() {
    rotate(-7f, Offset(50f, 24f)) {
        drawRoundRect(Color.White, Offset(27f, 4f), Size(46f, 37f), CornerRadius(3f, 3f))
        drawRoundRect(Color(0xFFB9C4D6), Offset(27f, 4f), Size(46f, 37f), CornerRadius(3f, 3f), style = Stroke(1f))
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF93D2FF), Color(0xFF3E8BE0)), startY = 8f, endY = 36f),
            Offset(30.5f, 7.5f), Size(39f, 28f), CornerRadius(1.5f, 1.5f)
        )
        drawCircle(Color(0xFFFFF3A6), 3.6f, Offset(62f, 15f))
        val monte = Path().apply { moveTo(30.5f, 35.5f); lineTo(43f, 21f); lineTo(52f, 29f); lineTo(58f, 24f); lineTo(69.5f, 35.5f); close() }
        drawPath(monte, Brush.verticalGradient(listOf(Color(0xFF58BF63), Color(0xFF2E8A3F)), startY = 21f, endY = 36f))
    }
}

// ── Vídeos: cinta de película con triángulo de reproducir ──
private fun DrawScope.objetoVideo() {
    rotate(10f, Offset(50f, 24f)) {
        drawRoundRect(Color(0xFF1F1F24), Offset(23f, 5f), Size(54f, 34f), CornerRadius(3f, 3f))
        for (i in 0..7) {
            val x = 26f + i * 6.4f
            drawRoundRect(Color(0xE6EDEDED), Offset(x, 7f), Size(3.6f, 3f), CornerRadius(0.8f, 0.8f))
            drawRoundRect(Color(0xE6EDEDED), Offset(x, 34f), Size(3.6f, 3f), CornerRadius(0.8f, 0.8f))
        }
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF7C9CD8), Color(0xFF34508F)), startY = 12f, endY = 32f),
            Offset(27f, 12.5f), Size(46f, 20f), CornerRadius(1.5f, 1.5f)
        )
        val play = Path().apply { moveTo(46f, 17f); lineTo(46f, 28f); lineTo(57f, 22.5f); close() }
        drawPath(play, Color.White)
    }
}

// ── APKs: cabeza del robot de Android ──
private fun DrawScope.objetoAndroid() {
    rotate(-8f, Offset(50f, 26f)) {
        val verde = Brush.verticalGradient(listOf(Color(0xFF6FEFA8), Color(0xFF2FB86C)), startY = 12f, endY = 38f)
        drawLine(Color(0xFF2FB86C), Offset(37f, 6f), Offset(41.5f, 14.5f), strokeWidth = 2.4f, cap = StrokeCap.Round)
        drawLine(Color(0xFF2FB86C), Offset(63f, 6f), Offset(58.5f, 14.5f), strokeWidth = 2.4f, cap = StrokeCap.Round)
        val cabeza = Path().apply { moveTo(29f, 38f); quadraticBezierTo(29f, 13f, 50f, 13f); quadraticBezierTo(71f, 13f, 71f, 38f); close() }
        drawPath(cabeza, verde)
        drawPath(cabeza, Color(0xFF248F55), style = Stroke(0.9f))
        drawCircle(Color.White, 2.6f, Offset(41f, 26f))
        drawCircle(Color.White, 2.6f, Offset(59f, 26f))
    }
}
