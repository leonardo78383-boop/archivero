package com.archivero

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import androidx.core.graphics.PathParser
import kotlin.math.min

// Piezas visuales que usa el teclado propio (TecladoService): fondo con esquinas cortadas, íconos vectoriales y botón-ícono.

/** Mezcla un color con blanco (f = 0..1). */
private fun fMix(c: Int, f: Float): Int {
    val r = (c shr 16 and 0xFF); val g = (c shr 8 and 0xFF); val b = (c and 0xFF)
    val rr = (r + (255 - r) * f).toInt(); val gg = (g + (255 - g) * f).toInt(); val bb = (b + (255 - b) * f).toInt()
    return (c and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
}

/** Fondo con las esquinas superior izquierda e inferior derecha cortadas en diagonal, degradado suave y canto fino (el mismo estilo que la app). */
internal class CutBg(private val color: Int, private val stroke: Int, private val cut: Float, private val sw: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw }
    private val path = Path()
    private val grad = LinearGradient(0f, 0f, 0f, 1f, fMix(color, 0.08f), color, Shader.TileMode.CLAMP)
    private val gm = Matrix()
    init { fill.shader = grad }
    override fun onBoundsChange(b: Rect) {
        val i = sw / 2f
        val l = b.left + i; val t = b.top + i; val r = b.right - i; val bt = b.bottom - i
        val k = minOf(cut, (r - l) / 2f, (bt - t) / 2f).coerceAtLeast(0f)
        path.reset()
        path.moveTo(l + k, t); path.lineTo(r, t); path.lineTo(r, bt - k)
        path.lineTo(r - k, bt); path.lineTo(l, bt); path.lineTo(l, t + k); path.close()
        gm.setScale(1f, maxOf(1f, b.height().toFloat()))             // el mismo degradado, estirado: sin crear objetos al estirar el panel
        gm.postTranslate(0f, b.top.toFloat())
        grad.setLocalMatrix(gm)
        edge.color = stroke
    }
    override fun draw(c: Canvas) { c.drawPath(path, fill); c.drawPath(path, edge) }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Íconos vectoriales (trazos Material de 24×24): no dependen de emojis ni de fuentes, se ven igual en cualquier teléfono. */
internal object FIco {
    const val KEYBOARD = "M20 5H4c-1.1 0-1.99.9-1.99 2L2 17c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm-9 3h2v2h-2V8zm0 3h2v2h-2v-2zM8 8h2v2H8V8zm0 3h2v2H8v-2zm-1 2H5v-2h2v2zm0-3H5V8h2v2zm9 7H8v-2h8v2zm0-4h-2v-2h2v2zm0-3h-2V8h2v2zm3 3h-2v-2h2v2zm0-3h-2V8h2v2z"
    const val SHIFT = "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
    const val BACKSPACE = "M22 3H7c-.69 0-1.23.35-1.59.88L0 12l5.41 8.11c.36.53.9.89 1.59.89h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-3 12.59L17.59 17 14 13.41 10.41 17 9 15.59 12.59 12 9 8.41 10.41 7 14 10.59 17.59 7 19 8.41 15.41 12 19 15.59z"
    const val ENTER = "M19 7v4H5.83l3.58-3.59L8 6l-6 6 6 6 1.41-1.41L5.83 13H21V7z"

    private val cache = HashMap<String, Path>()
    private fun path(d: String): Path = cache.getOrPut(d) { PathParser.createPathFromPathData(d) }

    fun draw(c: Canvas, d: String, left: Float, top: Float, size: Float, paint: Paint) {
        val p = Path(path(d))
        val m = Matrix()
        m.setScale(size / 24f, size / 24f)
        m.postTranslate(left, top)
        p.transform(m)
        c.drawPath(p, paint)
    }
}

/** Botón-ícono: dibuja un trazo vectorial del color pedido. */
internal class FloatIconView(ctx: Context, private var d: String, private var tint: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun icon(newD: String, newTint: Int) {
        if (newD != d || newTint != tint) { d = newD; tint = newTint; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        paint.color = tint
        val s = min(width, height) * 0.56f
        FIco.draw(c, d, (width - s) / 2f, (height - s) / 2f, s, paint)
    }
}
