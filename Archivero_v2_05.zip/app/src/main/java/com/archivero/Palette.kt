package com.archivero

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Paleta de la app (v1.91, diseño elegante): fondo blanco, tinta negra y un solo acento carmesí.
 * Dos temas: claro (el de siempre, por defecto) y oscuro (negro con carmesí).
 * Los colores se leen de [light], que es un estado: al cambiarlo, toda la app se repinta sola.
 * Nombres heredados: en el tema claro, White = tinta del texto (negro) y Black = fondo (blanco); así todo lo que ya existía se adapta.
 */
object Pal {
    var light by mutableStateOf(true)

    // Acento: carmesí (#C30E53). Se mantiene el nombre Pink para no tocar el resto del código.
    val Pink: Color get() = Color(0xFFC30E53)
    val AccentHi: Color get() = Color(0xFFE23C72)                                  // parte alta del degradado del acento
    val Accent: Color get() = Pink
    /** Acento para TEXTO y trazos finos: en claro el carmesí tal cual; en oscuro, más claro para que se lea sobre negro. */
    val AccentText: Color get() = if (light) Color(0xFFC30E53) else Color(0xFFFF5C8E)
    /** Tinta que va ENCIMA del acento (botones, fichas encendidas): siempre blanca. */
    val AccentOn: Color get() = Color(0xFFFFFFFF)
    val Sel: Color get() = if (light) Color(0xFFFFE3EC) else Color(0xFF2E1018)       // fondo de lo seleccionado / casillas de ícono

    // Carpeta (los íconos de carpeta usan cartón manila propio; estos tonos quedan por compatibilidad).
    val FolderBack: Color get() = if (light) Color(0xFF6E747E) else Color(0xFFA9AEB8)
    val FolderBackDark: Color get() = if (light) Color(0xFF4C525B) else Color(0xFF787E88)
    val FolderFront: Color get() = if (light) Color(0xFFAEB4BE) else Color(0xFFF8F9FB)
    val FolderFrontDark: Color get() = if (light) Color(0xFF878E99) else Color(0xFFD3D8DF)
    val FolderEdge: Color get() = if (light) Color(0xFFD6DAE0) else Color(0xFFFFFFFF)
    val FolderPaper: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFFF4F6F8)
    val Black: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF0E0E0E)   // fondo
    val Ink: Color get() = if (light) Color(0xFFF5F5F2) else Color(0xFF161616)     // superficies
    val Card: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF1C1C1C)    // tarjetas / menús
    val Line: Color get() = if (light) Color(0xFFE8E8E3) else Color(0xFF2D2D2D)    // líneas finas
    val White: Color get() = if (light) Color(0xFF111111) else Color(0xFFF7F7F4)   // tinta del texto
    /** Resplandor suave (casi invisible en claro; un toque cálido en oscuro). */
    val Glow: Color get() = if (light) Color(0x14000000) else Color(0x1AC30E53)
    val Muted: Color get() = if (light) Color(0xFF6B6B66) else Color(0xFFA2A29B)   // texto secundario
}

/** Lee el tema guardado (al abrir la app). Por defecto: claro. */
fun cargarTema(ctx: Context) {
    Pal.light = ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).getBoolean("claro", true)
}

/** Cambia entre tema claro y oscuro y lo recuerda. */
fun cambiarTema(ctx: Context, claro: Boolean) {
    Pal.light = claro
    ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).edit().putBoolean("claro", claro).apply()
}
