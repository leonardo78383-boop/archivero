package com.archivero

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Las dos casillas nuevas del amigo flotante: «Optimizar» y «Caché».
 *
 * Android no deja que una app normal haga todo lo que hacen los limpiadores con permisos de sistema, así que cada una hace
 * lo que sí está permitido (y dice la verdad sobre cuánto logró):
 *  - Optimizar: cierra los procesos en segundo plano de las apps que tú instalaste (`killBackgroundProcesses`) y mide la RAM libre antes y después.
 *    No toca la app que estás usando, el lanzador, el teclado ni las apps del sistema; las apps con música o llamada (servicio en primer plano) no se cierran.
 *  - Caché: pide al sistema que libere la caché de las demás apps (`StorageManager.allocateBytes`, la vía oficial desde Android 8)
 *    y, además, borra la carpeta `cache` de las apps en la memoria externa cuando el teléfono deja entrar a `Android/data`.
 *    Solo toca cachés (se vuelven a crear solas): nunca datos, sesiones ni archivos de las apps.
 */
object Optimizador {

    class RamRes(val apps: Int, val antes: Long, val despues: Long) {
        val liberada: Long get() = (despues - antes).coerceAtLeast(0L)
    }

    class CacheRes(val liberado: Long, val apps: Int)

    private fun ramLibre(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem
    }

    private fun espacioLibre(dir: File): Long = try { StatFs(dir.path).availableBytes } catch (e: Exception) { 0L }

    /** Cierra lo que está en segundo plano y devuelve cuántas apps se tocaron y la RAM libre antes/después. */
    suspend fun optimizar(ctx: Context): RamRes = withContext(Dispatchers.Default) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = app.packageManager
        val antes = ramLibre(app)

        val saltar = HashSet<String>()
        saltar.add(app.packageName)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (ri in pm.queryIntentActivities(home, 0)) saltar.add(ri.activityInfo.packageName)
        } catch (e: Exception) { }
        try {
            val ime = Settings.Secure.getString(app.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            if (ime != null) saltar.add(ime.substringBefore('/'))
        } catch (e: Exception) { }

        var n = 0
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) {
                val ai = ri.activityInfo?.applicationInfo ?: continue
                val pkg = ai.packageName
                if (pkg in saltar) continue
                val delSistema = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (delSistema) continue
                try { am.killBackgroundProcesses(pkg); n++ } catch (e: Exception) { }
            }
        } catch (e: Exception) { }

        delay(1200)                       // el sistema tarda un momento en soltar la memoria
        RamRes(n, antes, ramLibre(app))
    }

    /** Libera la caché de las demás apps; devuelve cuánto espacio libre ganó el teléfono. */
    suspend fun borrarCache(ctx: Context): CacheRes = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        val sm = app.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val temporal = File(app.filesDir, ".espacio.tmp")
        try { temporal.delete() } catch (e: Exception) { }      // resto de una pasada anterior que se cortó
        val antes = espacioLibre(app.filesDir)
        var directo = 0L
        var apps = 0

        // 1) Cachés en la memoria externa (Android/data/<app>/cache), donde el teléfono lo permita.
        try {
            for (v in sm.storageVolumes) {
                if (v.state != Environment.MEDIA_MOUNTED) continue
                val raiz = v.directory ?: continue
                val paquetes = File(raiz, "Android/data").listFiles() ?: continue
                for (pk in paquetes) {
                    val cache = File(pk, "cache")
                    if (!cache.isDirectory) continue
                    var peso = 0L
                    cache.walkTopDown().forEach { if (it.isFile) peso += it.length() }
                    if (peso <= 0L) continue
                    var borro = false
                    cache.listFiles()?.forEach { if (it.deleteRecursively()) borro = true }
                    if (borro) { directo += peso; apps++ }
                }
            }
        } catch (e: Exception) { }

        // 2) La vía oficial: pedir al sistema más espacio del libre; para dárnoslo borra la caché de las demás apps.
        //    El archivo reservado se borra enseguida (y siempre, aunque falle).
        try {
            val uuid = sm.getUuidForPath(app.filesDir)
            val pedir = sm.getAllocatableBytes(uuid)
            if (pedir > 0L) {
                try {
                    FileOutputStream(temporal).use { out -> sm.allocateBytes(out.fd, pedir) }
                } finally {
                    try { temporal.delete() } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) { }

        delay(300)
        val despues = espacioLibre(app.filesDir)
        CacheRes(maxOf((despues - antes).coerceAtLeast(0L), directo), apps)
    }

    /** Plan B manual: la pantalla de Almacenamiento del sistema (en algunos teléfonos trae «Datos en caché» / «Limpiar»). */
    fun abrirAlmacenamiento(ctx: Context) {
        val app = ctx.applicationContext
        try {
            app.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try { app.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { }
        }
    }
}
