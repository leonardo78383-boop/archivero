package com.archivero

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Teclado propio de Archivero. Cuando está elegido como teclado del teléfono, sustituye al original en todas las apps.
 * Tiene el estilo del resto de la app (esquinas cortadas, plata sobre negro) y un botón «Corregir» que arregla ortografía y
 * gramática de todo el texto del campo (o solo de lo seleccionado), sin importar lo largo que sea.
 */
class TecladoService : InputMethodService() {

    private val ui = Handler(Looper.getMainLooper())
    private var modoSim = false                  // false = letras; true = números y símbolos
    private var shift = 0                        // 0 = minúsculas, 1 = una mayúscula, 2 = bloqueo de mayúsculas
    private var ultimoShift = 0L
    private var acento = 0                       // 0 = nada, 1 = la próxima vocal lleva tilde, 2 = lleva diéresis (ü)
    private var corrigiendo = false
    private var puedeCorregir = true
    private var antes: String? = null            // texto antes de la última corrección (para deshacer)
    private var despues: String? = null          // texto que dejó la última corrección

    private val teclasNum = ArrayList<TextView>()
    private val teclas1 = ArrayList<TextView>()
    private val teclas2 = ArrayList<TextView>()
    private val teclas3 = ArrayList<TextView>()
    private lateinit var teclaShift: View
    private lateinit var teclaSim: TextView
    private lateinit var teclaAcento: TextView
    private lateinit var botonCorregir: TextView
    private lateinit var estado: TextView
    private var restablecerEstado: Runnable? = null

    private val letras1 = "qwertyuiop".map { it.toString() }
    private val letras2 = "asdfghjklñ".map { it.toString() }
    private val letras3 = "zxcvbnm".map { it.toString() }
    private val sim1 = listOf("@", "#", "\$", "%", "&", "-", "+", "(", ")", "/")
    private val sim2 = listOf("*", "\"", "'", ":", ";", "!", "?", "¿", "¡", "_")
    private val sim3 = listOf("<", ">", "=", "~", "|", "€", "^")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onEvaluateFullscreenMode(): Boolean = false

    // ── Aspecto ──

    private fun fondo(base: Int, borde: Int, presionado: Int): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), CutBg(presionado, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dp(1).toFloat()))
        addState(intArrayOf(), CutBg(base, borde, dp(6).toFloat(), dp(1).toFloat()))
    }

    private fun params(peso: Float) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, peso).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }

    private fun tecla(texto: String, peso: Float = 1f, funcion: Boolean = false): TextView = TextView(this).apply {
        text = texto
        gravity = Gravity.CENTER
        setTextColor(0xFFFFFFFF.toInt())
        textSize = if (funcion) 13f else 18f
        typeface = if (funcion) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        isSingleLine = true
        background = if (funcion) fondo(0xFF23262C.toInt(), 0xFF3A3F47.toInt(), 0xFF4A4F58.toInt()) else fondo(0xFF1A1D22.toInt(), 0xFF2A2D33.toInt(), 0xFF3A3F47.toInt())
        layoutParams = params(peso)
    }

    private fun teclaIcono(d: String, peso: Float): FloatIconView = FloatIconView(this, d, 0xFFFFFFFF.toInt()).apply {
        background = fondo(0xFF23262C.toInt(), 0xFF3A3F47.toInt(), 0xFF4A4F58.toInt())
        layoutParams = params(peso)
    }

    /** La tecla actúa al tocar (sin esperar a soltar) y, si se pide, se repite al mantenerla. */
    @SuppressLint("ClickableViewAccessibility")
    private fun atar(v: View, repetir: Boolean = false, accion: () -> Unit) {
        var rep: Runnable? = null
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    accion()
                    if (repetir) {
                        val r = object : Runnable {
                            override fun run() { accion(); ui.postDelayed(this, 45L) }
                        }
                        rep = r
                        ui.postDelayed(r, 380L)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    rep?.let { ui.removeCallbacks(it) }
                    rep = null
                }
            }
            true
        }
    }

    private fun fila(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
    }

    override fun onCreateInputView(): View {
        teclasNum.clear(); teclas1.clear(); teclas2.clear(); teclas3.clear()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ColorDrawable(0xFF0B0C0E.toInt())
            setPadding(dp(3), dp(2), dp(3), dp(4))
        }

        // ── barra de arriba: Corregir, Deshacer, aviso y cambiar de teclado ──
        botonCorregir = TextView(this).apply {
            text = "CORREGIR"
            gravity = Gravity.CENTER
            setTextColor(0xFF0B0C0E.toInt())
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setPadding(dp(14), 0, dp(14), 0)
            background = fondo(0xFFD5D9E0.toInt(), 0xFFFFFFFF.toInt(), 0xFF9FA4AD.toInt())
        }
        atar(botonCorregir) { corregir() }
        val botonDeshacer = TextView(this).apply {
            text = "DESHACER"
            gravity = Gravity.CENTER
            setTextColor(0xFFD5D9E0.toInt())
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
            setPadding(dp(10), 0, dp(10), 0)
            background = fondo(0xFF16181C.toInt(), 0xFF2A2D33.toInt(), 0xFF3A3F47.toInt())
        }
        atar(botonDeshacer) { deshacer() }
        estado = TextView(this).apply {
            setTextColor(0xFF8D939C.toInt())
            textSize = 11f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(4), 0)
        }
        val botonCambiar = FloatIconView(this, FIco.KEYBOARD, 0xFFD5D9E0.toInt()).apply {
            background = fondo(0xFF16181C.toInt(), 0xFF2A2D33.toInt(), 0xFF3A3F47.toInt())
        }
        atar(botonCambiar) { cambiarTeclado() }
        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
            setPadding(dp(2), dp(3), dp(2), dp(3))
            addView(botonCorregir, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(botonDeshacer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { leftMargin = dp(6) })
            addView(estado, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            addView(botonCambiar, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        }
        raiz.addView(barra)

        // ── números ──
        val f0 = fila()
        for (c in "1234567890") {
            val t = tecla(c.toString())
            atar(t) { escribir(t.text.toString()) }
            teclasNum.add(t); f0.addView(t)
        }
        raiz.addView(f0)

        // ── letras / símbolos ──
        val f1 = fila()
        for (i in 0 until 10) {
            val t = tecla("")
            atar(t) { escribir(t.text.toString()) }
            teclas1.add(t); f1.addView(t)
        }
        raiz.addView(f1)

        val f2 = fila()
        for (i in 0 until 10) {
            val t = tecla("")
            atar(t) { escribir(t.text.toString()) }
            teclas2.add(t); f2.addView(t)
        }
        raiz.addView(f2)

        val f3 = fila()
        teclaShift = teclaIcono(FIco.SHIFT, 1.5f)
        atar(teclaShift) { tocarShift() }
        f3.addView(teclaShift)
        for (i in 0 until 7) {
            val t = tecla("")
            atar(t) { escribir(t.text.toString()) }
            teclas3.add(t); f3.addView(t)
        }
        val borrar = teclaIcono(FIco.BACKSPACE, 1.5f)
        atar(borrar, repetir = true) { borrarUno() }
        f3.addView(borrar)
        raiz.addView(f3)

        // ── fila de abajo ──
        val f4 = fila()
        teclaSim = tecla("?123", 1.5f, true)
        atar(teclaSim) { modoSim = !modoSim; acento = 0; pintar() }
        f4.addView(teclaSim)
        teclaAcento = tecla("´", 1f, true)
        atar(teclaAcento) { acento = (acento + 1) % 3; pintar() }
        f4.addView(teclaAcento)
        val coma = tecla(",")
        atar(coma) { escribir(",") }
        f4.addView(coma)
        val espacio = tecla("", 3.6f)
        atar(espacio) { escribir(" ") }
        f4.addView(espacio)
        val punto = tecla(".")
        atar(punto) { escribir(".") }
        f4.addView(punto)
        val intro = teclaIcono(FIco.ENTER, 1.5f)
        atar(intro) { pulsarIntro() }
        f4.addView(intro)
        raiz.addView(f4)

        pintar()
        return raiz
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val clase = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        modoSim = clase == InputType.TYPE_CLASS_NUMBER || clase == InputType.TYPE_CLASS_PHONE || clase == InputType.TYPE_CLASS_DATETIME
        puedeCorregir = campoPermitido(info)
        acento = 0
        shift = 0
        if (::botonCorregir.isInitialized) {
            botonCorregir.alpha = if (puedeCorregir) 1f else 0.35f
            aviso(if (puedeCorregir) "" else "Corregir no está disponible en este campo")
        }
        autoMayus()
        pintar()
    }

    /** Contraseñas, correos, direcciones web y números: ahí no se corrige ni se envía nada. */
    private fun campoPermitido(ei: EditorInfo?): Boolean {
        val t = ei?.inputType ?: return false
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        return when (t and InputType.TYPE_MASK_VARIATION) {
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_URI -> false
            else -> true
        }
    }

    // ── Teclas ──

    private fun pintar() {
        if (!::teclaShift.isInitialized) return
        val may = !modoSim && shift != 0
        val a = if (modoSim) sim1 else letras1
        val b = if (modoSim) sim2 else letras2
        val c = if (modoSim) sim3 else letras3
        for (i in teclas1.indices) teclas1[i].text = if (may) a[i].uppercase() else a[i]
        for (i in teclas2.indices) teclas2[i].text = if (may) b[i].uppercase() else b[i]
        for (i in teclas3.indices) teclas3[i].text = if (may) c[i].uppercase() else c[i]
        teclaSim.text = if (modoSim) "ABC" else "?123"
        teclaShift.visibility = if (modoSim) View.INVISIBLE else View.VISIBLE
        teclaShift.background = if (shift != 0) fondo(0xFFD5D9E0.toInt(), 0xFFFFFFFF.toInt(), 0xFF9FA4AD.toInt()) else fondo(0xFF23262C.toInt(), 0xFF3A3F47.toInt(), 0xFF4A4F58.toInt())
        (teclaShift as? FloatIconView)?.icon(FIco.SHIFT, if (shift != 0) 0xFF0B0C0E.toInt() else 0xFFFFFFFF.toInt())
        teclaAcento.text = if (acento == 2) "¨" else "´"
        teclaAcento.visibility = if (modoSim) View.INVISIBLE else View.VISIBLE
        teclaAcento.setTextColor(if (acento != 0) 0xFF0B0C0E.toInt() else 0xFFFFFFFF.toInt())
        teclaAcento.background = if (acento != 0) fondo(0xFFD5D9E0.toInt(), 0xFFFFFFFF.toInt(), 0xFF9FA4AD.toInt()) else fondo(0xFF23262C.toInt(), 0xFF3A3F47.toInt(), 0xFF4A4F58.toInt())
    }

    private fun tocarShift() {
        val ahora = System.currentTimeMillis()
        shift = when {
            shift == 2 -> 0
            ahora - ultimoShift < 350L -> 2
            shift == 1 -> 0
            else -> 1
        }
        ultimoShift = ahora
        pintar()
    }

    /** Pone la mayúscula sola al empezar una frase, como en cualquier teclado. */
    private fun autoMayus() {
        if (modoSim || shift == 2) return
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo ?: return
        val nuevo = if (ic.getCursorCapsMode(ei.inputType) != 0) 1 else 0
        if (nuevo != shift) { shift = nuevo; pintar() }
    }

    private fun conAcento(s: String): String {
        if (s.length != 1) return s
        val tabla = if (acento == 1) "aáeéiíoóuúAÁEÉIÍOÓUÚ" else "aäeëiïoöuüAÄEËIÏOÖUÜ"
        val i = tabla.indexOf(s[0])
        return if (i in 0 until tabla.length - 1 && i % 2 == 0) tabla[i + 1].toString() else s
    }

    private fun escribir(texto: String) {
        val ic = currentInputConnection ?: return
        var out = texto
        if (acento != 0) { out = conAcento(out); acento = 0 }
        ic.commitText(out, 1)
        if (shift == 1) shift = 0
        autoMayus()
        pintar()
    }

    private fun borrarUno() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        acento = 0
        autoMayus()
        pintar()
    }

    private fun pulsarIntro() {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection
        if (ei == null || ic == null) return
        val accion = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            accion == EditorInfo.IME_ACTION_NONE || accion == EditorInfo.IME_ACTION_UNSPECIFIED
        ) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        else ic.performEditorAction(accion)
        autoMayus()
    }

    private fun cambiarTeclado() {
        val ok = try { switchToPreviousInputMethod() } catch (e: Exception) { false }
        if (!ok) try { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } catch (e: Exception) { }
    }

    // ── Corregir ──

    private fun aviso(msg: String) {
        if (!::estado.isInitialized) return
        estado.text = msg
        restablecerEstado?.let { ui.removeCallbacks(it) }
        if (msg.isNotEmpty()) {
            val r = Runnable { estado.text = "" }
            restablecerEstado = r
            ui.postDelayed(r, 4000L)
        }
    }

    private fun pedido() = ExtractedTextRequest().apply { hintMaxChars = 200000; hintMaxLines = 20000 }

    /** Cambia el trozo [desde, hasta) del campo por [nuevo] y deja el cursor en [cursor] (posiciones absolutas). */
    private fun reemplazar(ic: InputConnection, desde: Int, hasta: Int, nuevo: String, cursor: Int) {
        ic.beginBatchEdit()
        ic.setSelection(desde, hasta)
        ic.commitText(nuevo, 1)
        ic.setSelection(cursor, cursor)
        ic.endBatchEdit()
    }

    private fun corregir() {
        if (corrigiendo) return
        if (!puedeCorregir) { aviso("Corregir no está disponible en este campo"); return }
        val ic = currentInputConnection ?: return
        val ex = ic.getExtractedText(pedido(), 0)
        val todo = ex?.text?.toString()
        if (ex == null || todo.isNullOrEmpty()) { aviso("No hay texto que corregir"); return }
        val s = minOf(ex.selectionStart, ex.selectionEnd).coerceIn(0, todo.length)
        val e = maxOf(ex.selectionStart, ex.selectionEnd).coerceIn(0, todo.length)
        val soloSeleccion = e > s                      // con texto seleccionado se corrige solo eso; si no, todo el campo
        val a = if (soloSeleccion) s else 0
        val b = if (soloSeleccion) e else todo.length
        val original = todo.substring(a, b)
        val cursorViejo = ex.selectionEnd.coerceIn(0, todo.length)
        corrigiendo = true
        botonCorregir.alpha = 0.55f
        aviso("Corrigiendo con LanguageTool…")
        Thread {
            var res: Corrector.Resultado? = null
            var error: String? = null
            try {
                res = Corrector.corregir(original)
            } catch (x: java.net.UnknownHostException) {
                error = "Sin internet"
            } catch (x: java.net.SocketTimeoutException) {
                error = "El servicio tardó demasiado"
            } catch (x: IOException) {
                error = if (x.message == "ocupado") "Servicio ocupado, prueba en un minuto" else "No se pudo conectar"
            } catch (x: Exception) {
                error = "No se pudo corregir"
            }
            val rr = res
            val ee = error
            ui.post {
                corrigiendo = false
                botonCorregir.alpha = if (puedeCorregir) 1f else 0.35f
                if (ee != null || rr == null) { aviso(ee ?: "No se pudo corregir"); return@post }
                if (rr.cambios == 0) { aviso("Sin errores"); return@post }
                val ic2 = currentInputConnection ?: return@post
                val ex2 = ic2.getExtractedText(pedido(), 0) ?: return@post
                val ahora = ex2.text?.toString()
                // Si mientras tanto se escribió algo, no se pisa el texto.
                if (ahora == null || ahora.length < b || ahora.substring(a, b) != original) {
                    aviso("El texto cambió, toca Corregir otra vez")
                    return@post
                }
                val base = ex2.startOffset
                val cursorNuevo = if (soloSeleccion) a + rr.texto.length
                else if (cursorViejo >= todo.length) rr.texto.length
                else (cursorViejo + (rr.texto.length - original.length)).coerceIn(0, rr.texto.length)
                reemplazar(ic2, base + a, base + b, rr.texto, base + cursorNuevo)
                antes = original
                despues = rr.texto
                aviso(if (rr.cambios == 1) "1 corrección" else "${rr.cambios} correcciones")
            }
        }.apply { isDaemon = true }.start()
    }

    private fun deshacer() {
        val d = despues
        val o = antes
        val ic = currentInputConnection
        if (d == null || o == null || ic == null) { aviso("Nada que deshacer"); return }
        val ex = ic.getExtractedText(pedido(), 0)
        val t = ex?.text?.toString()
        if (ex == null || t == null) return
        val i = t.indexOf(d)
        if (i < 0) { aviso("Ya no se puede deshacer"); return }
        val base = ex.startOffset
        reemplazar(ic, base + i, base + i + d.length, o, base + i + o.length)
        antes = null
        despues = null
        aviso("Corrección deshecha")
    }
}

/**
 * Corrector de ortografía y gramática. Manda el texto a la API pública de LanguageTool (necesita internet), en trozos para que
 * cualquier largo funcione, y aplica la primera sugerencia de cada error (se omiten las de estilo, que son opiniones).
 */
object Corrector {
    class Resultado(val texto: String, val cambios: Int)

    private const val URL_API = "https://api.languagetool.org/v2/check"
    private const val TROZO = 12000                   // la API pública acepta hasta 20 000 caracteres por pedido

    fun corregir(texto: String): Resultado {
        val sb = StringBuilder()
        var total = 0
        for (trozo in partir(texto)) {
            val (t, n) = corregirTrozo(trozo)
            sb.append(t)
            total += n
        }
        return Resultado(sb.toString(), total)
    }

    /** Parte el texto en trozos que terminan en salto de línea, fin de frase o espacio, para no cortar palabras. */
    private fun partir(t: String): List<String> {
        if (t.length <= TROZO) return listOf(t)
        val out = ArrayList<String>()
        var i = 0
        while (i < t.length) {
            var fin = minOf(t.length, i + TROZO)
            if (fin < t.length) {
                val mitad = i + TROZO / 2
                var corte = t.lastIndexOf('\n', fin - 1)
                if (corte <= mitad) {
                    val p = t.lastIndexOf(". ", fin - 1)
                    corte = if (p > mitad) p + 1 else -1
                }
                if (corte <= mitad) corte = t.lastIndexOf(' ', fin - 1)
                if (corte > i) fin = corte + 1
            }
            out.add(t.substring(i, fin))
            i = fin
        }
        return out
    }

    private class Cambio(val desde: Int, val largo: Int, val nuevo: String)

    private fun corregirTrozo(t: String): Pair<String, Int> {
        if (t.isBlank()) return Pair(t, 0)
        val con = URL(URL_API).openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 10000
            con.readTimeout = 30000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            con.setRequestProperty("Accept", "application/json")
            val cuerpo = "text=" + URLEncoder.encode(t, "UTF-8") +
                "&language=auto&preferredVariants=" + URLEncoder.encode("es,en-US", "UTF-8")
            con.outputStream.use { it.write(cuerpo.toByteArray(Charsets.UTF_8)) }
            val codigo = con.responseCode
            if (codigo == 429) throw IOException("ocupado")
            if (codigo !in 200..299) throw IOException("http $codigo")
            val json = con.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONObject(json).getJSONArray("matches")
            val cambios = ArrayList<Cambio>()
            for (k in 0 until arr.length()) {
                val m = arr.getJSONObject(k)
                val reps = m.optJSONArray("replacements") ?: continue
                if (reps.length() == 0) continue
                val tipo = m.optJSONObject("rule")?.optString("issueType") ?: ""
                if (tipo == "style") continue
                val nuevo = reps.getJSONObject(0).optString("value", "")
                cambios.add(Cambio(m.getInt("offset"), m.getInt("length"), nuevo))
            }
            cambios.sortBy { it.desde }
            val sb = StringBuilder()
            var pos = 0
            var n = 0
            for (c in cambios) {
                if (c.desde < pos || c.desde + c.largo > t.length) continue
                sb.append(t, pos, c.desde).append(c.nuevo)
                pos = c.desde + c.largo
                n++
            }
            sb.append(t, pos, t.length)
            return Pair(sb.toString(), n)
        } finally {
            con.disconnect()
        }
    }
}

/** Ayudas para la casilla «Teclado» del amigo flotante. */
object Teclado {
    fun habilitado(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList.any { it.packageName == ctx.packageName }
    } catch (e: Exception) { false }

    fun activo(ctx: Context): Boolean = try {
        (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "").startsWith(ctx.packageName + "/")
    } catch (e: Exception) { false }

    /** Lista de teclados del teléfono: ahí se enciende «Teclado Archivero». */
    fun abrirAjustes(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Selector de teclado del sistema (sirve para activar el de Archivero o para volver al de siempre). */
    fun elegir(ctx: Context) {
        ctx.startActivity(Intent(ctx, TecladoSelectorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Pantalla invisible: el selector de teclado del sistema solo se puede abrir desde una ventana con foco. */
class TecladoSelectorActivity : Activity() {
    private var mostrado = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !mostrado) {
            mostrado = true
            window.decorView.post {
                try { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } catch (e: Exception) { }
            }
        } else if (!hasFocus && mostrado) {
            finish()
        }
    }
}
