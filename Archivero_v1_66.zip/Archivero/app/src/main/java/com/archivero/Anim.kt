package com.archivero

import android.app.ActivityManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Animaciones adaptativas: un solo sitio decide cuánto duran.
 * - [reduced] (interruptor del panel lateral, se recuerda): sin animaciones de transición.
 * - Teléfono de poca RAM: duran un 35 % menos (menos cuadros que dibujar).
 * - La escala de animaciones del sistema (Opciones de desarrollador / Accesibilidad) ya la respeta Compose por su cuenta.
 */
object Anim {
    var reduced by mutableStateOf(false)
        private set
    private var lowEnd = false
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("archivero", Context.MODE_PRIVATE)
        reduced = prefs?.getBoolean("anim_reduced", false) ?: false
        lowEnd = try { app.getSystemService(ActivityManager::class.java)?.isLowRamDevice == true } catch (e: Exception) { false }
    }

    fun alternar() {
        reduced = !reduced
        prefs?.edit()?.putBoolean("anim_reduced", reduced)?.apply()
    }

    /** Duración final en ms de una animación que normalmente dura [base] ms. */
    fun ms(base: Int): Int = when {
        reduced -> 0
        lowEnd -> base * 65 / 100
        else -> base
    }
}
