package com.archivero

import android.content.Context

/**
 * El reproductor de música es de TODA la app, no de una pantalla: hay uno solo por proceso.
 * Así sobrevive si Android destruye la actividad en segundo plano, lo comparten la app y el mini reproductor del amigo
 * flotante (que ya no depende de que la actividad exista) y la música no se corta al volver a abrir la app.
 */
object Musica {
    @Volatile private var p: MusicPlayer? = null

    /** El reproductor (se crea la primera vez). */
    fun get(ctx: Context): MusicPlayer = p ?: synchronized(this) { p ?: MusicPlayer(ctx.applicationContext).also { p = it } }

    /** El reproductor si ya existe; null si todavía no se usó (para mirar sin crear nada). */
    fun actual(): MusicPlayer? = p

    /** Detiene la música y suelta el reproductor (cuando la app se cierra de verdad). */
    fun liberar() {
        synchronized(this) {
            try { p?.stop() } catch (e: Exception) { }
            p = null
        }
    }
}
