package com.archivero

import androidx.compose.foundation.background
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tonos del "vidrio" oscuro: de arriba (más claro) a abajo (más oscuro) para dar volumen. */
object Glass {
    val Top: Color get() = if (Pal.light) Color(0xFFFFFFFF) else Color(0xFF2E3138)
    val Mid: Color get() = if (Pal.light) Color(0xFFF5F5F8) else Color(0xFF1A1C20)
    val Bottom: Color get() = if (Pal.light) Color(0xFFE8E8EE) else Color(0xFF0E0F12)
    val Rim: Color get() = if (Pal.light) Color(0x33000000) else Color(0x55FFFFFF)
    val Rim2: Color get() = if (Pal.light) Color(0x14000000) else Color(0x14FFFFFF)
    val Rim3: Color get() = if (Pal.light) Color(0x0A000000) else Color(0x0AFFFFFF)
}

/** Fondo de Inicio: degradado grafito con un brillo plateado muy tenue en la esquina superior derecha. */
fun Modifier.fondoInicio(): Modifier = this
    .background(Brush.verticalGradient(if (Pal.light) listOf(Color(0xFFFFFFFF), Color(0xFFF3F3F7), Color(0xFFEAEAF0)) else listOf(Color(0xFF15171B), Color(0xFF08090B), Color(0xFF050506))))
    .drawBehind {
        drawRect(
            Brush.radialGradient(
                colors = listOf(Pal.Accent.copy(alpha = 0.10f), Color.Transparent),
                center = Offset(size.width * 0.95f, 0f),
                radius = size.width * 0.95f
            )
        )
    }

/** Superficie elevada de vidrio: sombra, degradado vertical, brillo en el borde superior y canto fino. */
fun Modifier.vidrio3D(shape: Shape, elevation: Dp = 10.dp, glow: Boolean = false): Modifier = this
    .shadow(elevation, shape, ambientColor = Color.Black, spotColor = if (glow) Pal.Accent else Color.Black)
    .background(Brush.verticalGradient(listOf(Glass.Top, Glass.Mid, Glass.Bottom)), shape)
    .drawBehind {
        val y = 1.5.dp.toPx()
        drawLine(
            Brush.horizontalGradient(listOf(Color.Transparent, if (Pal.light) Color(0x00000000) else Color(0x66FFFFFF), Color.Transparent)),
            Offset(size.width * 0.12f, y), Offset(size.width * 0.88f, y),
            strokeWidth = 1.dp.toPx()
        )
    }
    .border(1.dp, Brush.verticalGradient(listOf(Glass.Rim, Glass.Rim2, Glass.Rim3)), shape)

/** Esquinas de luz: pequeñas "L" brillantes en las esquinas (sin tocar la esquina cortada de arriba). */
fun Modifier.esquinasLuz(color: Color = Pal.Accent, largo: Dp = 12.dp, alpha: Float = 0.85f, topIzq: Boolean = true, topDer: Boolean = false): Modifier =
    this.drawWithContent {
        drawContent()
        val l = largo.toPx()
        val m = 1.dp.toPx()
        val w = size.width
        val h = size.height
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            for ((sw, al) in listOf(5.dp.toPx() to alpha * 0.18f, 1.6.dp.toPx() to alpha)) {
                val c = color.copy(alpha = al)
                drawLine(c, Offset(x, y), Offset(x + dx * l, y), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(c, Offset(x, y), Offset(x, y + dy * l), strokeWidth = sw, cap = StrokeCap.Round)
            }
        }
        if (topIzq) corner(m, m, 1f, 1f)
        if (topDer) corner(w - m, m, -1f, 1f)
        corner(m, h - m, 1f, -1f)
        corner(w - m, h - m, -1f, -1f)
    }

/** Título de sección: barrita de acento + texto pequeño en mayúsculas con letras espaciadas. */
@Composable
fun SectionTitle(text: String) {
    Row(Modifier.padding(start = 18.dp, top = 22.dp, end = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(14.dp).background(Pal.Accent))
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = Pal.Muted, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 2.sp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Pal.Line))
        Box(Modifier.width(18.dp).height(3.dp).background(Pal.Accent))
    }
}
