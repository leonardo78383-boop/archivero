package com.archivero

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Casilla «Optimizar» del amigo flotante.
 * Android no deja que una app normal haga todo lo que hacen los limpiadores con permisos de sistema, así que hace lo permitido
 * y dice la verdad sobre cuánto logró: cierra los procesos en segundo plano de las apps que tú instalaste (`killBackgroundProcesses`)
 * y mide la RAM libre antes y después. No toca la app que estás usando, el lanzador, el teclado ni las apps del sistema;
 * las apps con música o llamada (servicio en primer plano) no se cierran.
 */
object Optimizador {

    class RamRes(val apps: Int, val antes: Long, val despues: Long) {
        val liberada: Long get() = (despues - antes).coerceAtLeast(0L)
    }

    private fun ramLibre(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem
    }

    /** Cierra lo que está en segundo plano y devuelve cuántas apps se tocaron y la RAM libre antes/después. */
    suspend fun optimizar(ctx: Context): RamRes = withContext(Dispatchers.Default) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = app.packageManager
        val antes = ramLibre(app)

        val saltar = HashSet<String>()
        saltar.add(app.packageName)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (ri in pm.queryIntentActivities(home, 0)) saltar.add(ri.activityInfo.packageName)
        } catch (e: Exception) { }
        try {
            val ime = Settings.Secure.getString(app.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            if (ime != null) saltar.add(ime.substringBefore('/'))
        } catch (e: Exception) { }

        var n = 0
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) {
                val ai = ri.activityInfo?.applicationInfo ?: continue
                val pkg = ai.packageName
                if (pkg in saltar) continue
                val delSistema = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (delSistema) continue
                try { am.killBackgroundProcesses(pkg); n++ } catch (e: Exception) { }
            }
        } catch (e: Exception) { }

        delay(1200)                       // el sistema tarda un momento en soltar la memoria
        RamRes(n, antes, ramLibre(app))
    }
}
