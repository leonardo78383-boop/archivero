package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

enum class CleanPhase { IDLE, CLEANING, DONE }

private val MASCOT = 124.dp          // caja del robot (él mide ~108 dp de alto y pisa el borde de abajo)
/** Lleva un ángulo al rango -π..π (mismo aspecto, número pequeño). */
private fun wrapPi(a: Float): Float {
    val t = 6.2831855f
    return ((a + 3.1415927f) % t + t) % t - 3.1415927f
}

private val MASCOT_SKIN = 124.dp     // con una forma de foto se ve un poco más grande para que se reconozca

/** Burbujita de la estela del amigo (posición y velocidad en px; vida en segundos). */
class Bubble(var x: Float, var y: Float, val vx: Float, val vy: Float, val r: Float, val life: Float, val phase: Float, val pink: Boolean) {
    var age = 0f
}

/**
 * El amigo: una esfera de gelatina negra, medio transparente y en 3D, con ojitos. Borra los residuos de la propia app (se le toca):
 *  - archivos temporales en la caché (interna y externa) de Archivero,
 *  - miniaturas y carpetas leídas que la app guarda en memoria para ir más rápido.
 * NO toca tus archivos, ni la papelera, ni otras apps.
 * Vive en el mini panel de las 3 rayitas; se puede arrastrar fuera para que acompañe mientras navegas.
 */
class CleanerState(context: Context, private val store: Store) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("limpiador", Context.MODE_PRIVATE)

    /** true = anda suelto por la pantalla; false = guardado en el panel. */
    var out by mutableStateOf(prefs.getBoolean("out", false))
    /** Esquina superior izquierda (px) cuando anda suelto. */
    var pos by mutableStateOf(Offset(prefs.getFloat("x", 0f), prefs.getFloat("y", 0f)))
    var junk by mutableLongStateOf(-1L)           // -1 = midiendo
    var phase by mutableStateOf(CleanPhase.IDLE)
    var say by mutableStateOf<String?>(null)
    var sayId by mutableIntStateOf(0)
    var dragging by mutableStateOf(false)
    var pressed by mutableStateOf(false)          // dedo encima: se queda quieto para poder tocarlo/agarrarlo
    var look by mutableStateOf(Offset.Zero)       // hacia dónde mira (-1..1)
    // Giro 3D de la cara (radianes): yaw = izquierda/derecha (±π/2 de perfil, π de espaldas), pitch = arriba/abajo.
    // Lanzamiento: velocidad (px/s) al soltarlo y mientras vuela rebotando.
    var flyVel = Offset.Zero
    var dragVel = Offset.Zero
    var dragLastMs = 0L
    var yaw by mutableFloatStateOf(0f)
    var pitch by mutableFloatStateOf(0f)
    var roll by mutableFloatStateOf(0f)           // ladeo (de costado); como yaw y pitch, sin límite de giro
    var spinYaw = 0f                              // velocidades de giro libre (rad/s) al lanzarlo o tocarlo
    var spinPitch = 0f
    var spinRoll = 0f
    var spinning = false
    var settingsOpen by mutableStateOf(false)     // pantalla de Ajustes abierta
    var hint by mutableStateOf("")                // título de la pantalla actual (lo pone App)
    var sayMs = 2800L                             // cuánto dura el globito
    var sayTappable by mutableStateOf(false)      // true = tocar el globito abre el chat

    // Gelatina: se estira hacia donde va y rebota al parar (se actualiza en cada cuadro).
    var stretch by mutableFloatStateOf(0f)        // >0 estirada, <0 aplastada
    var moveAngle by mutableFloatStateOf(0f)      // grados: hacia dónde se mueve
    var stretchVel = 0f
    val bubbles = ArrayList<Bubble>()             // estela de burbujitas
    var tick by mutableIntStateOf(0)              // avisa al dibujo de que hay que repintar las burbujas

    // ── El robot 3D (Robot3D.kt): cuerpo completo, articulado, camina por el suelo ──
    internal val robot = Robot3D(ctx.resources.displayMetrics.density)
    var frame by mutableIntStateOf(0)             // se suma en cada cuadro: el dibujo del robot lo lee y se repinta solo él
    var poseOpen by mutableStateOf(false)         // modo "mover articulaciones"
    var poseTick by mutableIntStateOf(0)          // refresca los deslizadores

    /** Un golpecito: se aplasta y rebota. */
    fun poke() {
        robot.kick()
        stretchVel -= 5f
        spinYaw += if (Random.nextBoolean()) 9f else -9f      // un toque lo hace girar en el aire
        spinRoll += (Random.nextFloat() - 0.5f) * 4f
    }

    // ── Change shape: la forma de una foto de la galería ──
    var body by mutableStateOf(BodyType.SPHERE)        // SPHERE = la esfera de siempre
    var skin by mutableStateOf<ImageBitmap?>(null)     // la figura recortada
    var gait by mutableFloatStateOf(0f)                // 0 = parado, 1 = caminando a buen paso
    var walk by mutableFloatStateOf(0f)                // fase del paso (ciclos)
    var faceX by mutableFloatStateOf(1f)               // 1 = mira a la derecha, -1 = a la izquierda

    private val shapeFile get() = File(ctx.filesDir, "forma_amigo.png")

    /** Al abrir la app: vuelve a ponerse la última forma elegida. */
    suspend fun loadShape() {
        val t = BodyType.from(prefs.getString("body", null))
        if (t == BodyType.SPHERE) return
        val bmp = withContext(Dispatchers.IO) { shapeFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) } }
        if (bmp != null) { skin = bmp.asImageBitmap(); body = t }
    }

    /** Guarda la forma elegida y el amigo la toma. */
    suspend fun applyShape(bmp: Bitmap, type: BodyType) {
        withContext(Dispatchers.IO) {
            runCatching { shapeFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        }
        prefs.edit().putString("body", type.name).apply()
        gait = 0f
        faceX = 1f
        skin = bmp.asImageBitmap()
        body = type
    }

    /** Vuelve a ser la esfera de gelatina. */
    fun resetShape() {
        runCatching { shapeFile.delete() }
        prefs.edit().remove("body").apply()
        skin = null
        body = BodyType.SPHERE
        gait = 0f
        faceX = 1f
    }

    fun save() { prefs.edit().putBoolean("out", out).putFloat("x", pos.x).putFloat("y", pos.y).apply() }
    fun talk(msg: String?, ms: Long = 2800L, tappable: Boolean = false) { say = msg; sayMs = ms; sayTappable = tappable; sayId++ }

    private fun sizeOf(f: File?): Long =
        if (f == null || !f.exists()) 0L else if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun wipe(d: File?) {
        d?.listFiles()?.forEach { runCatching { if (it.isDirectory) it.deleteRecursively() else it.delete() } }
    }

    /** Residuos actuales en bytes: caché en disco + miniaturas en memoria. */
    suspend fun measure(): Long = withContext(Dispatchers.IO) {
        sizeOf(ctx.cacheDir) + sizeOf(ctx.externalCacheDir) + Thumbs.sizeBytes()
    }

    suspend fun refresh() { junk = measure() }

    suspend fun clean() {
        if (phase == CleanPhase.CLEANING) return
        phase = CleanPhase.CLEANING
        try {
            talk("Limpiando…")
            val before = measure()
            withContext(Dispatchers.IO) { wipe(ctx.cacheDir); wipe(ctx.externalCacheDir) }
            store.clearMemoryCaches()
            delay(900)                                   // para que se vea la animación
            val after = measure()
            junk = after
            val freed = (before - after).coerceAtLeast(0L)
            phase = CleanPhase.DONE
            talk(if (freed > 0) "¡Listo! ${fmtSize(freed)} liberados" else "Todo estaba limpio")
            delay(2200)
        } finally {
            phase = CleanPhase.IDLE      // si se cancela a mitad (sales de la pantalla), el amigo no queda «limpiando» para siempre
        }
    }
}

// ───────────── El robot ─────────────

/** El amigo dentro de la app: un robot 3D de cuerpo completo (Robot3D.kt). Sin texturas ni deformaciones: es una malla rígida articulada. */
@Composable
fun Mascot(c: CleanerState, boxSize: Dp) {
    val density = LocalDensity.current
    val unitPx = with(density) { (if (c.out) 36.dp else 24.dp).toPx() }
    // El lienzo es más grande que la caja del robot (queda centrado sobre ella): con los brazos arriba o abiertos
    // ninguna pieza toca el borde del lienzo, así que nada se ve cortado.
    val padDp = 64.dp
    val padPx = with(density) { padDp.toPx() }
    Canvas(Modifier.requiredSize(boxSize + padDp * 2)) {
        val f = c.frame               // leerlo repinta SOLO este lienzo en cada cuadro (sin recomponer nada)
        if (f >= 0) {
            val nc = drawContext.canvas.nativeCanvas
            nc.save()
            nc.translate(padPx, padPx)      // las coordenadas del robot (manos, hombros) siguen siendo las de la caja
            c.robot.draw(nc, size.width - 2f * padPx, size.height - 2f * padPx, unitPx)
            nc.restore()
        }
    }
}

// ───────────── Capa que flota sobre toda la app ─────────────

@Composable
fun CleanerLayer(c: CleanerState, store: Store, panelOpen: Boolean, onClosePanel: () -> Unit) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val mDp = if (c.skin != null && c.body != BodyType.SPHERE) MASCOT_SKIN else MASCOT
    val dPx = with(density) { mDp.toPx() }
    val dens = density.density
    var root by remember { mutableStateOf(IntSize.Zero) }
    var slot by remember { mutableStateOf(Rect.Zero) }
    val panelNow by rememberUpdatedState(panelOpen)
    LaunchedEffect(Unit) { c.resetShape() }      // Change shape ya no existe: el amigo vuelve a ser la esfera

    fun clamp(p: Offset) = Offset(
        p.x.coerceIn(0f, max(0f, root.width - dPx)),
        p.y.coerceIn(0f, max(0f, root.height - dPx))
    )
    val slotLift = dPx / 2f - (3f + 12f * Robot3D.HEIGHT_UNITS) * dens
    fun current(): Offset = if (c.out) clamp(c.pos) else slot.center - Offset(dPx / 2, dPx / 2 + slotLift)

    fun randomTarget(from: Offset): Offset {
        val margin = 8f * dens
        val maxX = max(margin, root.width - dPx - margin)
        val maxY = max(margin, root.height - dPx - margin)
        var best = Offset(margin, margin)
        for (i in 0 until 5) {
            val cand = Offset(margin + Random.nextFloat() * (maxX - margin), margin + Random.nextFloat() * (maxY - margin))
            best = cand
            if (kotlin.math.hypot(cand.x - from.x, cand.y - from.y) > 140f * dens) break
        }
        return best
    }

    LaunchedEffect(panelOpen) { c.refresh() }
    LaunchedEffect(c.sayId) {
        if (c.say != null) { delay(c.sayMs); c.say = null }
    }

    // Cada cuadro: el robot obedece a la gravedad, camina por el suelo (el borde de abajo), se da la vuelta, se agacha al caer
    // y cuelga cuando lo agarras. Nada flota: si lo sueltas en el aire, se cae.
    val visible = c.out || panelOpen
    LaunchedEffect(visible, dPx) {
        if (!visible) {
            c.frame = c.frame + 1
            return@LaunchedEffect
        }
        val r = c.robot
        val unitW = 36f * dens                    // px por unidad del modelo cuando está fuera
        var last = 0L
        var vel = Offset.Zero
        var grounded = false
        var wasDrag = false
        var wasOut = c.out
        var walkTo = -1f                          // x de destino (borde izquierdo de la caja); <0 = ninguno
        var idleUntil = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (last == 0L) { last = now; continue }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            last = now
            val nowMs = now / 1_000_000L
            r.manual = c.poseOpen
            val cleaning = c.phase == CleanPhase.CLEANING
            val done = c.phase == CleanPhase.DONE

            if (!c.out) {
                // En el mini panel: parado de frente, curioseando; limpia con los brazos arriba.
                r.mode = if (cleaning) Robot3D.MODE_CLEAN else if (done) Robot3D.MODE_HAPPY else Robot3D.MODE_STAND
                r.velX = 0f; r.velY = 0f
                wasOut = false
                grounded = false
                r.update(dt)
                c.frame = c.frame + 1
                continue
            }
            if (!wasOut) { wasOut = true; vel = Offset.Zero; walkTo = -1f }
            val maxX = max(0f, root.width - dPx)
            val floorY = max(0f, root.height - dPx)
            var pos = clamp(c.pos)

            if (c.dragging) {
                // Agarrado: cuelga del dedo (las piernas se balancean) y las manos se pueden mover aparte.
                wasDrag = true
                grounded = false
                vel = Offset.Zero
                walkTo = -1f
                r.mode = Robot3D.MODE_HELD
                r.velX = c.dragVel.x; r.velY = c.dragVel.y
                r.lookX = c.look.x.coerceIn(-1f, 1f)
            } else {
                if (wasDrag) {
                    wasDrag = false
                    vel = c.flyVel
                    c.flyVel = Offset.Zero
                    grounded = vel == Offset.Zero && pos.y >= floorY - 1f
                    if (kotlin.math.hypot(vel.x, vel.y) > 900f * dens) r.spin(vel.x)     // lanzado fuerte: sale dando una vuelta
                    idleUntil = nowMs + 1800L
                }
                if (!grounded && pos.y >= floorY - 1f && vel == Offset.Zero) grounded = true
                if (!grounded) {
                    // Cae: gravedad, rebota poco en las paredes y se agacha al tocar el suelo.
                    if (!c.pressed) {
                        var vx = vel.x
                        var vy = vel.y + 2700f * dens * dt
                        var nx = pos.x + vx * dt
                        var ny = pos.y + vy * dt
                        if (nx < 0f) { nx = 0f; vx = kotlin.math.abs(vx) * 0.45f }
                        else if (nx > maxX) { nx = maxX; vx = -kotlin.math.abs(vx) * 0.45f }
                        if (ny < 0f) { ny = 0f; vy = kotlin.math.abs(vy) * 0.3f }
                        if (ny >= floorY) {
                            val impact = vy
                            ny = floorY
                            if (impact > 260f * dens) r.land(impact)
                            vy = if (impact > 700f * dens) -impact * 0.16f else 0f
                            vx *= 0.4f
                            if (kotlin.math.abs(vy) < 40f * dens) {
                                vy = 0f; vx = 0f
                                grounded = true
                                idleUntil = nowMs + 900L
                                c.save()
                            }
                        }
                        vel = Offset(vx, vy)
                        pos = Offset(nx, ny)
                        c.pos = pos
                    }
                    r.mode = if (grounded) Robot3D.MODE_STAND else Robot3D.MODE_AIR
                    r.velX = vel.x; r.velY = vel.y
                    r.yawTarget = 0f
                } else {
                    // En el suelo: pegado al borde de abajo, pasea de un lado a otro y se da la vuelta al llegar.
                    if (pos.y != floorY) { pos = Offset(pos.x, floorY); c.pos = pos }
                    r.velX = 0f; r.velY = 0f
                    val canWalk = !c.pressed && !panelNow && !c.settingsOpen && !c.poseOpen && !cleaning && !done && root.width > 0
                    if (cleaning) r.mode = Robot3D.MODE_CLEAN
                    else if (done) r.mode = Robot3D.MODE_HAPPY
                    else if (!canWalk) { r.mode = Robot3D.MODE_STAND; walkTo = -1f }
                    else {
                        if (walkTo < 0f && nowMs >= idleUntil) {
                            val margin = 6f * dens
                            var tg = margin + Random.nextFloat() * max(1f, maxX - 2f * margin)
                            if (kotlin.math.abs(tg - pos.x) < 100f * dens) tg = if (pos.x > maxX / 2f) margin else maxX - margin
                            walkTo = tg
                        }
                        if (walkTo >= 0f) {
                            val dx = walkTo - pos.x
                            val dir = if (dx >= 0f) 1f else -1f
                            r.yawTarget = dir * 1.15f
                            r.lookX = dir * 0.5f
                            val aligned = kotlin.math.abs(wrapPi(r.yawTarget - r.yaw)) < 0.5f
                            if (kotlin.math.abs(dx) < 3f * dens) {
                                walkTo = -1f
                                idleUntil = nowMs + 1500L + Random.nextLong(4500)
                                r.mode = Robot3D.MODE_STAND
                                r.yawTarget = 0f
                                c.save()
                            } else if (aligned) {
                                // Los pasos avanzan con la distancia recorrida: el pie de apoyo no resbala.
                                r.mode = Robot3D.MODE_WALK
                                val step = min(kotlin.math.abs(dx), 52f * dens * dt)
                                pos = Offset(pos.x + dir * step, pos.y)
                                c.pos = pos
                                r.advance(step / unitW)
                            } else {
                                r.mode = Robot3D.MODE_STAND     // primero se gira, luego camina
                            }
                        } else {
                            r.mode = Robot3D.MODE_STAND
                        }
                    }
                }
            }
            r.update(dt)
            c.frame = c.frame + 1
        }
    }

    Box(Modifier.fillMaxSize().onSizeChanged { root = it }) {
        if (panelOpen) {
            CleanerPanel(
                c,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 66.dp, end = 8.dp),
                onSlot = { slot = it },
                onSettings = { c.settingsOpen = true; onClosePanel() },
                onPose = {
                    if (!c.out) { c.pos = current(); c.out = true }      // para posarlo tiene que estar fuera, en el suelo
                    c.poseOpen = true
                    onClosePanel()
                }
            )
        }
        // No dibujarlo hasta saber el tamaño de la pantalla (y dónde está el hueco del panel): antes aparecía un instante en la esquina de arriba a la izquierda.
        val placed = root.width > 0 && (c.out || slot != Rect.Zero)
        if ((c.out || panelOpen) && placed) {
            // La posición se lee dentro de los bloques de layout (no al componer): mientras el amigo se mueve no se recompone toda la capa.
            val onRight by remember(dPx) { derivedStateOf { current().x + dPx / 2 > root.width / 2f } }
            Box(
                Modifier
                    .offset { val q = current(); IntOffset(q.x.roundToInt(), q.y.roundToInt()) }
                    .size(mDp)
                    .pointerInput(dPx) {
                        var grabArm = -1          // 0/1 = moviendo una mano; -1 = llevando todo el robot
                        detectDragGestures(
                            onDragStart = { off ->
                                val hand = if (c.out && !c.dragging) c.robot.handAt(off.x, off.y) else -1
                                if (hand >= 0) {
                                    // Tocó una mano: el brazo sigue al dedo (las articulaciones se mueven libres).
                                    grabArm = hand
                                    c.robot.grabbing[hand] = true
                                    c.robot.grabX[hand] = off.x
                                    c.robot.grabY[hand] = off.y
                                } else {
                                    grabArm = -1
                                    if (!c.out) { c.pos = current(); c.out = true }   // sale del panel
                                    c.dragging = true
                                    c.flyVel = Offset.Zero
                                    c.dragVel = Offset.Zero
                                }
                            },
                            onDragEnd = {
                              if (grabArm >= 0) {
                                c.robot.grabbing[grabArm] = false
                                grabArm = -1
                              } else {
                                c.dragging = false
                                c.look = Offset.Zero
                                // Soltado sobre el hueco del panel (con el panel abierto): se guarda.
                                if (panelNow && slot.inflate(dPx * 0.15f).contains(clamp(c.pos) + Offset(dPx / 2, dPx / 2))) {
                                    c.out = false
                                    c.talk("Guardado")
                                }
                                // Si lo soltó en movimiento, sale lanzado (con tope de velocidad).
                                val sp = kotlin.math.hypot(c.dragVel.x, c.dragVel.y)
                                if (c.out && SystemClock.uptimeMillis() - c.dragLastMs < 90L && sp > 280f * dens) {
                                    val capK = (3400f * dens / sp).coerceAtMost(1f)
                                    c.flyVel = Offset(c.dragVel.x * capK, c.dragVel.y * capK)
                                }
                                c.dragVel = Offset.Zero
                                c.save()
                              }
                            },
                            onDragCancel = {
                                if (grabArm >= 0) { c.robot.grabbing[grabArm] = false; grabArm = -1 }
                                else { c.dragging = false; c.look = Offset.Zero; c.dragVel = Offset.Zero; c.save() }
                            },
                            onDrag = { change, amount ->
                              change.consume()
                              if (grabArm >= 0) {
                                c.robot.grabX[grabArm] = change.position.x
                                c.robot.grabY[grabArm] = change.position.y
                              } else {
                                val dtMs = (change.uptimeMillis - change.previousUptimeMillis).coerceAtLeast(1L)
                                c.dragVel = Offset(
                                    c.dragVel.x * 0.55f + amount.x * 1000f / dtMs * 0.45f,
                                    c.dragVel.y * 0.55f + amount.y * 1000f / dtMs * 0.45f
                                )
                                c.dragLastMs = change.uptimeMillis
                                c.pos = clamp(c.pos + amount)
                                val len = kotlin.math.hypot(amount.x, amount.y)
                                if (len > 0.5f) c.look = Offset(amount.x / len, amount.y / len)
                              }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                c.pressed = true
                                c.flyVel = Offset.Zero            // si iba volando, el dedo lo atrapa
                                try { tryAwaitRelease() } finally { c.pressed = false }
                            },
                            onTap = { c.poke(); scope.launch { c.clean() } }
                        )
                    }
            ) { Mascot(c, mDp) }

            // Globito de texto al lado.
            val msg = c.say
            if (msg != null) {
                val bw = with(density) { 170.dp.toPx() }
                val gap = with(density) { 8.dp.toPx() }
                Box(
                    Modifier.offset {
                        val q = current()
                        val bx = if (onRight) q.x - bw - gap else q.x + dPx + gap
                        val by = q.y + dPx / 2 - 18.dp.toPx()
                        IntOffset(bx.roundToInt(), by.roundToInt())
                    }.width(170.dp),
                    contentAlignment = if (onRight) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    val shape = ChamferShape(8.dp)
                    Text(
                        msg, color = Pal.White, fontSize = 12.sp,
                        modifier = Modifier.clip(shape).background(Pal.Ink).border(1.dp, if (c.sayTappable) Pal.Pink else Pal.Line, shape)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
        // Mover articulaciones: deslizadores de cada giro del esqueleto (arriba, para no tapar al robot que está abajo).
        if (c.poseOpen) PoseSheet(c, Modifier.align(Alignment.TopCenter).padding(top = 62.dp))
        // El "papel grande" de Ajustes, por encima de todo.
        if (c.settingsOpen) AjustesSheet(store) { c.settingsOpen = false }
    }
}

// ───────────── Mini panel ─────────────

@Composable
private fun CleanerPanel(c: CleanerState, modifier: Modifier, onSlot: (Rect) -> Unit, onSettings: () -> Unit, onPose: () -> Unit) {
    val shape = ChamferShape(14.dp)
    Column(
        modifier
            .width(224.dp)
            .vidrio3D(shape, 16.dp, glow = true)
            .esquinasLuz()
            .clip(shape)
            .pointerInput(Unit) { detectTapGestures { } }       // que los toques no pasen a lo de abajo
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(12.dp).background(Pal.Accent))
            Spacer(Modifier.width(8.dp))
            Text("TU AMIGO", color = Pal.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(10.dp))
        // Hueco donde vive la esfera. Aquí se suelta para guardarla.
        Box(
            Modifier
                .fillMaxWidth()
                .height(104.dp)
                .onGloballyPositioned { onSlot(it.boundsInRoot()) }
                .drawBehind {
                    drawRoundRect(Pal.Accent.copy(alpha = 0.05f), cornerRadius = CornerRadius(10.dp.toPx()))
                    drawRoundRect(
                        Pal.Accent.copy(alpha = 0.45f), cornerRadius = CornerRadius(10.dp.toPx()),
                        style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                    )
                },
            contentAlignment = Alignment.BottomCenter
        ) {
            Text(
                if (c.out) "Suéltalo aquí\npara guardarlo" else "Arrástralo para sacarlo",
                color = Pal.Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 6.dp).then(if (c.out) Modifier.align(Alignment.Center) else Modifier)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Residuos", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(if (c.junk < 0) "…" else fmtSize(c.junk), color = Pal.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(6.dp))
        SegBar((c.junk.coerceAtLeast(0L) / (30f * 1024 * 1024)).coerceIn(0f, 1f), Modifier.fillMaxWidth(), segments = 20, height = 3.dp)
        Spacer(Modifier.height(6.dp))
        Text("Tócalo y limpia los residuos", color = Pal.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        // Mover las articulaciones del robot a mano.
        Text(
            "Mover articulaciones", color = Pal.White, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(ChamferShape(6.dp)).clickable(onClick = onPose).padding(horizontal = 14.dp, vertical = 6.dp)
        )
        // Ajustes, como enlace debajo.
        Text(
            "Ajustes", color = Pal.Muted, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(ChamferShape(6.dp)).clickable(onClick = onSettings).padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}

// ───────────── Mover articulaciones ─────────────

@Composable
private fun PoseSheet(c: CleanerState, modifier: Modifier) {
    val r = c.robot
    val tick = c.poseTick          // leerlo refresca los valores al mover un deslizador
    val shape = ChamferShape(14.dp)
    val colors = androidx.compose.material3.SliderDefaults.colors(
        thumbColor = Pal.White, activeTrackColor = Pal.Pink, inactiveTrackColor = Pal.Line
    )
    Column(
        modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .heightIn(max = 330.dp)
            .vidrio3D(shape, 14.dp, glow = true)
            .clip(shape)
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MOVER ARTICULACIONES", color = Pal.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
            Text(
                "Reiniciar", color = Pal.Muted, fontSize = 12.sp,
                modifier = Modifier.clip(ChamferShape(6.dp)).clickable {
                    r.resetPose(); r.yawTarget = 0f; c.poseTick = c.poseTick + 1
                }.padding(horizontal = 10.dp, vertical = 6.dp)
            )
            Text(
                "Listo", color = Pal.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(ChamferShape(6.dp)).clickable { c.poseOpen = false }.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        Text("Tip: también puedes tocar una mano del robot y arrastrarla.", color = Pal.Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp))
        Column(Modifier.verticalScroll(rememberScrollState())) {
            if (tick >= 0) {
                Text("Girar el cuerpo (cualquier lado)", color = Pal.White, fontSize = 11.sp)
                androidx.compose.material3.Slider(
                    value = r.yawTarget.coerceIn(-3.1415927f, 3.1415927f),
                    onValueChange = { r.yawTarget = it; c.poseTick = c.poseTick + 1 },
                    valueRange = -3.1415927f..3.1415927f,
                    colors = colors
                )
                for (sl in Robot3D.sliders) {
                    Text(sl.label, color = Pal.White, fontSize = 11.sp)
                    androidx.compose.material3.Slider(
                        value = r.man[sl.joint].coerceIn(sl.min, sl.max),
                        onValueChange = { r.man[sl.joint] = it; c.poseTick = c.poseTick + 1 },
                        valueRange = sl.min..sl.max,
                        colors = colors
                    )
                }
            }
        }
    }
}
