package com.archivero

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/*
 * ROBOT 3D — cuerpo completo, articulado y con peso.
 *
 *  · Malla propia de caras planas (cajas biseladas: torso, cabeza y extremidades son cuadrados, nada redondo; solo las uniones llevan
 *    un cilindro bajo),
 *    dibujada con el Canvas de Android y orden de profundidad: sin texturas ni imágenes, no hay nada que se deforme.
 *  · Esqueleto de 19 articulaciones (torso, 2 brazos de 3 giros, 2 piernas de 4 giros). Cada cuadro: resortes → cinemática directa.
 *  · Las piernas se resuelven con cinemática inversa: el pie de apoyo queda clavado al suelo mientras avanza (no resbala)
 *    y el robot se apoya SIEMPRE en el pie más bajo: no flota ni se hunde (sin rebote de globo).
 *  · Gira hacia cualquier lado (yaw sin tope), camina, se agacha al caer, cuelga al agarrarlo y los brazos siguen al dedo.
 */

// materiales
private const val M_WHITE = 0
private const val M_ORANGE = 1
private const val M_BLACK = 2
private const val M_CYAN = 3
private const val M_VISOR = 4
private const val M_STEEL = 5

// tipos de cara
private const val K_HARD = 0      // pieza grande con contorno oscuro (líneas de panel)
private const val K_SMOOTH = 1    // superficie curva (sombreado suave, sin contorno)
private const val K_DECAL = 2     // calcomanía pegada a una superficie
private const val K_BEVEL = 3     // bisel, esquina o pieza chica (sin contorno)

private const val PI_F = 3.1415927f
private const val TAU_F = 6.2831855f

private val BASE_R = floatArrayOf(0.97f, 1.00f, 0.20f, 0.35f, 0.035f, 0.52f)
private val BASE_G = floatArrayOf(0.975f, 0.66f, 0.215f, 0.95f, 0.04f, 0.55f)
private val BASE_B = floatArrayOf(0.985f, 0.12f, 0.24f, 1.00f, 0.05f, 0.60f)

// marcos (sistemas de coordenadas) del esqueleto
private const val F_PELVIS = 0
private const val F_CHEST = 1
private const val F_SH0 = 2      // +1 = hombro del lado +x
private const val F_EL0 = 4
private const val F_HIP0 = 6
private const val F_KN0 = 8
private const val F_AN0 = 10
private const val F_PAD0 = 12     // hombrera: sigue al brazo cuando sube (así nunca lo atraviesa)
private const val NFR = 14

// cabeza (caja) en el marco del pecho
private const val HEAD_CY = 1.42f
private const val HEAD_HX = 0.40f
private const val HEAD_HY = 0.24f
private const val HEAD_HZ = 0.36f
private const val HEAD_EYE_Y = 1.43f

private class RFace(val idx: IntArray, val mat: Int, val kind: Int, val nx: Float, val ny: Float, val nz: Float, val parent: Int = -1)

/** Pieza lista para dibujar: vértices en su marco local y caras (polígonos convexos) con normal hacia afuera. */
internal class RPart(
    val frame: Int, val bias: Float,
    val vx: FloatArray, val vy: FloatArray, val vz: FloatArray,
    val fStart: IntArray, val fIdx: IntArray, val fMat: IntArray, val fKind: IntArray,
    val fnx: FloatArray, val fny: FloatArray, val fnz: FloatArray, val fParent: IntArray,
    val cx: Float, val cy: Float, val cz: Float
) {
    val nv get() = vx.size
    val nf get() = fMat.size
}

private class PartB(val frame: Int, val bias: Float = 0f) {
    val v = ArrayList<FloatArray>()
    val f = ArrayList<RFace>()

    fun addV(x: Float, y: Float, z: Float): Int { v.add(floatArrayOf(x, y, z)); return v.size - 1 }

    private fun normalOf(idx: IntArray, out: FloatArray) {
        var nx = 0f; var ny = 0f; var nz = 0f
        for (i in idx.indices) {
            val a = v[idx[i]]; val b = v[idx[(i + 1) % idx.size]]
            nx += (a[1] - b[1]) * (a[2] + b[2])
            ny += (a[2] - b[2]) * (a[0] + b[0])
            nz += (a[0] - b[0]) * (a[1] + b[1])
        }
        val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it < 1e-9f) 1f else it }
        out[0] = nx / l; out[1] = ny / l; out[2] = nz / l
    }

    /** Cara convexa: se invierte el orden de los vértices si la normal apunta hacia adentro (respecto del centro de la pieza). */
    fun convex(idx0: IntArray, mat: Int, kind: Int, cx: Float, cy: Float, cz: Float) {
        var idx = idx0
        val n = FloatArray(3)
        normalOf(idx, n)
        var mx = 0f; var my = 0f; var mz = 0f
        for (i in idx) { mx += v[i][0]; my += v[i][1]; mz += v[i][2] }
        mx /= idx.size; my /= idx.size; mz /= idx.size
        if (n[0] * (mx - cx) + n[1] * (my - cy) + n[2] * (mz - cz) < 0f) {
            idx = idx.reversedArray()
            n[0] = -n[0]; n[1] = -n[1]; n[2] = -n[2]
        }
        f.add(RFace(idx, mat, kind, n[0], n[1], n[2]))
    }

    /** Caja con aristas biseladas. c = 0 → caja simple de 6 caras. */
    fun chambox(cx: Float, cy: Float, cz: Float, hx: Float, hy: Float, hz: Float, c: Float, mat: Int, outline: Boolean = true) {
        val h = floatArrayOf(hx, hy, hz)
        val ctr = floatArrayOf(cx, cy, cz)
        val big = if (outline) K_HARD else K_BEVEL
        val ids = IntArray(8 * 3)         // [(sx,sy,sz) -> 0..7][eje]
        fun key(sx: Int, sy: Int, sz: Int) = ((sx + 1) / 2) * 4 + ((sy + 1) / 2) * 2 + ((sz + 1) / 2)
        val sg = intArrayOf(-1, 1)
        for (sx in sg) for (sy in sg) for (sz in sg) {
            val s = intArrayOf(sx, sy, sz)
            for (a in 0 until 3) {
                val p = FloatArray(3)
                for (b in 0 until 3) {
                    p[b] = ctr[b] + (if (b == a) s[b] * h[b] else s[b] * (h[b] - c))
                }
                ids[key(sx, sy, sz) * 3 + a] = addV(p[0], p[1], p[2])
            }
        }
        fun vid(s: IntArray, a: Int) = ids[key(s[0], s[1], s[2]) * 3 + a]
        // caras grandes
        for (a in 0 until 3) {
            val b = (a + 1) % 3; val cc = (a + 2) % 3
            for (sa in sg) {
                val q = IntArray(4)
                var k = 0
                for ((sb, sc) in listOf(-1 to -1, 1 to -1, 1 to 1, -1 to 1)) {
                    val s = IntArray(3); s[a] = sa; s[b] = sb; s[cc] = sc
                    q[k++] = vid(s, a)
                }
                convex(q, mat, big, cx, cy, cz)
            }
        }
        if (c <= 0f) return
        // biseles de arista
        for (a in 0 until 3) for (b in a + 1 until 3) {
            val cc = 3 - a - b
            for (sa in sg) for (sb in sg) {
                val q = IntArray(4)
                var k = 0
                for (sc in sg) { val s = IntArray(3); s[a] = sa; s[b] = sb; s[cc] = sc; q[k++] = vid(s, a) }
                for (sc in intArrayOf(1, -1)) { val s = IntArray(3); s[a] = sa; s[b] = sb; s[cc] = sc; q[k++] = vid(s, b) }
                convex(q, mat, K_BEVEL, cx, cy, cz)
            }
        }
        // esquinas
        for (sx in sg) for (sy in sg) for (sz in sg) {
            val s = intArrayOf(sx, sy, sz)
            convex(intArrayOf(vid(s, 0), vid(s, 1), vid(s, 2)), mat, K_BEVEL, cx, cy, cz)
        }
    }

    fun sphere(cx: Float, cy: Float, cz: Float, rx: Float, ry: Float, rz: Float, nl: Int, nt: Int, mat: Int) {
        val base = v.size
        for (i in 0..nt) {
            val th = PI_F * i / nt
            for (j in 0 until nl) {
                val ph = TAU_F * j / nl
                addV(cx + rx * sin(th) * sin(ph), cy + ry * cos(th), cz + rz * sin(th) * cos(ph))
            }
        }
        for (i in 0 until nt) for (j in 0 until nl) {
            val a = base + i * nl + j; val b = base + i * nl + (j + 1) % nl
            val c = base + (i + 1) * nl + j; val d = base + (i + 1) * nl + (j + 1) % nl
            val idx = if (i == 0) intArrayOf(a, c, d) else if (i == nt - 1) intArrayOf(a, c, b) else intArrayOf(a, c, d, b)
            convex(idx, mat, K_BEVEL, cx, cy, cz)
        }
    }

    /** Cilindro con eje en x (0), y (1) o z (2); h = media altura. */
    fun cylinder(cx: Float, cy: Float, cz: Float, r: Float, h: Float, axis: Int, ns: Int, mat: Int) {
        val o0 = if (axis == 0) 1 else 0
        val o1 = if (axis == 2) 1 else 2
        val ring = Array(2) { IntArray(ns) }
        for (k in 0 until 2) {
            val sgn = if (k == 0) -1f else 1f
            for (j in 0 until ns) {
                val a = TAU_F * j / ns
                val p = floatArrayOf(cx, cy, cz)
                p[axis] += sgn * h
                p[o0] += r * cos(a); p[o1] += r * sin(a)
                ring[k][j] = addV(p[0], p[1], p[2])
            }
        }
        for (j in 0 until ns) {
            convex(intArrayOf(ring[0][j], ring[0][(j + 1) % ns], ring[1][(j + 1) % ns], ring[1][j]), mat, K_BEVEL, cx, cy, cz)
        }
        convex(ring[0].copyOf(), mat, K_BEVEL, cx, cy, cz)
        convex(ring[1].copyOf(), mat, K_BEVEL, cx, cy, cz)
    }

    /** Polígono plano pegado a una cara: pts = (u, v, u, v…) en los otros dos ejes. sgn = hacia dónde mira. */
    fun decal(axis: Int, sgn: Int, off: Float, pts: FloatArray, mat: Int) {
        val o0 = if (axis == 0) 1 else 0
        val o1 = if (axis == 2) 1 else 2
        val n = pts.size / 2
        var idx = IntArray(n)
        for (i in 0 until n) {
            val p = FloatArray(3)
            p[axis] = off; p[o0] = pts[2 * i]; p[o1] = pts[2 * i + 1]
            idx[i] = addV(p[0], p[1], p[2])
        }
        val nn = FloatArray(3)
        normalOf(idx, nn)
        val want = FloatArray(3); want[axis] = sgn.toFloat()
        if (nn[0] * want[0] + nn[1] * want[1] + nn[2] * want[2] < 0f) idx = idx.reversedArray()
        // La calcomanía queda ligada a la cara donde está pegada: se dibuja SIEMPRE justo después de ella (no se hunde ni parpadea).
        var cu = 0f; var cv = 0f
        for (i in 0 until n) { cu += pts[2 * i]; cv += pts[2 * i + 1] }
        cu /= n; cv /= n
        var parent = -1
        var bestGap = 0.04f
        for (fi in f.indices) {
            val fc = f[fi]
            if (fc.kind == K_DECAL) continue
            if (fc.nx * want[0] + fc.ny * want[1] + fc.nz * want[2] < 0.995f) continue
            var d = 0f
            var u0 = 1e9f; var u1 = -1e9f; var w0 = 1e9f; var w1 = -1e9f
            for (id in fc.idx) {
                val q = v[id]
                d += q[axis]
                u0 = min(u0, q[o0]); u1 = max(u1, q[o0]); w0 = min(w0, q[o1]); w1 = max(w1, q[o1])
            }
            d /= fc.idx.size
            val gap = abs(d - off)
            if (gap < bestGap && cu >= u0 - 0.02f && cu <= u1 + 0.02f && cv >= w0 - 0.02f && cv <= w1 + 0.02f) { bestGap = gap; parent = fi }
        }
        f.add(RFace(idx, mat, K_DECAL, want[0], want[1], want[2], parent))
    }

    fun build(): RPart {
        val n = v.size
        val vx = FloatArray(n) { v[it][0] }
        val vy = FloatArray(n) { v[it][1] }
        val vz = FloatArray(n) { v[it][2] }
        val nf = f.size
        var total = 0
        for (fc in f) total += fc.idx.size
        val fStart = IntArray(nf + 1)
        val fIdx = IntArray(total)
        var k = 0
        for (i in 0 until nf) {
            fStart[i] = k
            for (id in f[i].idx) fIdx[k++] = id
        }
        fStart[nf] = k
        var sx = 0f; var sy = 0f; var sz = 0f
        for (i in 0 until n) { sx += vx[i]; sy += vy[i]; sz += vz[i] }
        return RPart(
            frame, bias, vx, vy, vz, fStart, fIdx,
            IntArray(nf) { f[it].mat }, IntArray(nf) { f[it].kind },
            FloatArray(nf) { f[it].nx }, FloatArray(nf) { f[it].ny }, FloatArray(nf) { f[it].nz }, IntArray(nf) { f[it].parent },
            sx / n, sy / n, sz / n
        )
    }
}

private fun fa(vararg v: Float) = v

/** Todas las piezas del robot (se construyen una sola vez). El orden importa: 0 torso, 1-2 hombreras, 3 pelvis, luego 5 piezas por lado, la cabeza al final. */
internal fun buildRobotParts(): Array<RPart> {
    val out = ArrayList<RPart>()
    // ── torso: cintura negra + abdomen gris + pecho blanco (todo cajas biseladas, cuerpo cerrado) ──
    run {
        val p = PartB(F_CHEST)
        p.chambox(0f, 0.02f, 0f, 0.34f, 0.14f, 0.28f, 0f, M_BLACK, false)          // cintura: tapa el hueco con la pelvis aunque se incline
        p.chambox(0f, 0.30f, 0f, 0.42f, 0.22f, 0.36f, 0.05f, M_STEEL)
        p.chambox(0f, 0.535f, 0f, 0.45f, 0.025f, 0.39f, 0f, M_BLACK, false)
        p.chambox(0f, 0.84f, 0f, 0.53f, 0.28f, 0.42f, 0.08f, M_WHITE)
        p.chambox(0f, 1.13f, 0f, 0.34f, 0.025f, 0.30f, 0f, M_BLACK, false)         // collar
        // frente del pecho: rombo, rayo, remaches
        p.decal(2, 1, 0.428f, fa(-0.27f, 1.00f, -0.15f, 0.86f, -0.27f, 0.72f, -0.39f, 0.86f), M_ORANGE)
        p.decal(2, 1, 0.428f, fa(0.31f, 1.02f, 0.15f, 0.83f, 0.25f, 0.83f, 0.19f, 0.68f, 0.37f, 0.87f, 0.27f, 0.87f), M_ORANGE)
        for (rx in floatArrayOf(-0.41f, 0.41f)) for (ry in floatArrayOf(0.70f, 0.99f))
            p.decal(2, 1, 0.428f, fa(rx - 0.03f, ry - 0.03f, rx + 0.03f, ry - 0.03f, rx + 0.03f, ry + 0.03f, rx - 0.03f, ry + 0.03f), M_STEEL)
        // costados del pecho
        for (sg in intArrayOf(1, -1)) {
            val sgf = sg.toFloat()
            p.decal(0, sg, sgf * 0.538f, fa(0.70f, -0.20f, 0.70f, 0.20f, 0.78f, 0.20f, 0.78f, -0.20f), M_ORANGE)
        }
        // abdomen: rejillas, luz e indicador
        for (vy in floatArrayOf(0.38f, 0.30f, 0.22f))
            p.decal(2, 1, 0.368f, fa(-0.20f, vy - 0.010f, 0.20f, vy - 0.010f, 0.20f, vy + 0.010f, -0.20f, vy + 0.010f), M_BLACK)
        p.decal(2, 1, 0.368f, fa(0.25f, 0.37f, 0.33f, 0.37f, 0.33f, 0.41f, 0.25f, 0.41f), M_CYAN)
        // espalda: panel oscuro con dos luces
        p.decal(2, -1, -0.428f, fa(-0.26f, 0.70f, 0.26f, 0.70f, 0.26f, 0.98f, -0.26f, 0.98f), M_BLACK)
        p.decal(2, -1, -0.436f, fa(-0.17f, 0.86f, 0.17f, 0.86f, 0.17f, 0.92f, -0.17f, 0.92f), M_CYAN)
        p.decal(2, -1, -0.436f, fa(-0.17f, 0.74f, 0.17f, 0.74f, 0.17f, 0.80f, -0.17f, 0.80f), M_CYAN)
        out.add(p.build())
    }
    // hombreras (marco propio: giran con el brazo al subirlo y nunca lo atraviesan)
    for (sg in intArrayOf(1, -1)) {
        val p = PartB(F_PAD0 + (if (sg == 1) 0 else 1))
        p.chambox(0f, 0.06f, -0.01f, 0.20f, 0.04f, 0.26f, 0f, M_BLACK, false)
        p.chambox(0f, 0.17f, -0.01f, 0.27f, 0.13f, 0.33f, 0.09f, M_WHITE)
        p.decal(1, 1, 0.304f, fa(-0.05f, -0.22f, 0.05f, -0.22f, 0.05f, 0.20f, -0.05f, 0.20f), M_ORANGE)
        p.decal(2, 1, 0.336f, fa(-0.04f, 0.13f, 0.04f, 0.13f, 0.04f, 0.21f, -0.04f, 0.21f), M_STEEL)
        out.add(p.build())
    }
    // pelvis
    run {
        val p = PartB(F_PELVIS)
        p.chambox(0f, 0.02f, 0f, 0.58f, 0.13f, 0.33f, 0.05f, M_BLACK, false)
        p.chambox(0f, -0.05f, 0f, 0.20f, 0.12f, 0.36f, 0.03f, M_STEEL, false)
        p.decal(2, 1, 0.338f, fa(-0.50f, 0.00f, -0.26f, 0.00f, -0.26f, 0.08f, -0.50f, 0.08f), M_ORANGE)
        p.decal(2, 1, 0.338f, fa(0.26f, 0.00f, 0.50f, 0.00f, 0.50f, 0.08f, 0.26f, 0.08f), M_ORANGE)
        out.add(p.build())
    }
    for (si in 0 until 2) {
        val sg = if (si == 0) 1 else -1
        val sgf = sg.toFloat()
        // brazo superior (marco: hombro). Rótula del hombro + barril del codo: nunca queda un hueco al doblar.
        var p = PartB(F_SH0 + si)
        p.sphere(0f, 0f, 0f, 0.21f, 0.21f, 0.21f, 8, 6, M_BLACK)
        p.cylinder(0f, -0.84f, 0f, 0.25f, 0.27f, 0, 8, M_BLACK)
        p.chambox(0f, -0.44f, 0f, 0.30f, 0.37f, 0.31f, 0.06f, M_WHITE)
        p.chambox(0f, -0.12f, 0f, 0.32f, 0.05f, 0.33f, 0f, M_BLACK, false)
        p.chambox(0f, -0.76f, 0f, 0.32f, 0.04f, 0.33f, 0f, M_BLACK, false)
        val o = sgf * 0.318f
        p.decal(0, sg, o, fa(-0.50f, -0.24f, -0.36f, 0.0f, -0.50f, 0.24f, -0.60f, 0.24f, -0.46f, 0.0f, -0.60f, -0.24f), M_ORANGE)
        p.decal(0, sg, o, fa(-0.30f, -0.12f, -0.24f, 0.0f, -0.30f, 0.12f, -0.34f, 0.12f, -0.28f, 0.0f, -0.34f, -0.12f), M_ORANGE)
        p.decal(2, 1, 0.318f, fa(-0.18f, -0.28f, 0.18f, -0.28f, 0.18f, -0.36f, -0.18f, -0.36f), M_ORANGE)
        p.decal(2, -1, -0.318f, fa(-0.18f, -0.28f, 0.18f, -0.28f, 0.18f, -0.36f, -0.18f, -0.36f), M_ORANGE)
        p.decal(0, sg, o, fa(-0.64f, -0.24f, -0.64f, -0.21f, -0.20f, -0.21f, -0.20f, -0.24f), M_BLACK)
        out.add(p.build())
        // antebrazo + puño (marco: codo)
        p = PartB(F_EL0 + si)
        p.cylinder(0f, 0f, 0f, 0.25f, 0.27f, 0, 8, M_BLACK)
        p.chambox(0f, -0.35f, 0.02f, 0.33f, 0.29f, 0.35f, 0.06f, M_WHITE)
        p.chambox(0f, -0.67f, 0.02f, 0.34f, 0.05f, 0.36f, 0f, M_BLACK, false)
        p.chambox(0f, -0.95f, 0.05f, 0.38f, 0.25f, 0.40f, 0.08f, M_WHITE)
        for (kx in floatArrayOf(-0.22f, 0f, 0.22f)) p.chambox(kx, -1.02f, 0.40f, 0.09f, 0.14f, 0.07f, 0f, M_BLACK, false)
        p.chambox(0f, -1.22f, 0.05f, 0.36f, 0.05f, 0.38f, 0f, M_BLACK, false)
        p.decal(0, sg, sgf * 0.338f, fa(-0.30f, -0.20f, -0.30f, 0.20f, -0.45f, 0.20f, -0.45f, -0.20f), M_ORANGE)
        p.decal(0, sg, sgf * 0.338f, fa(-0.52f, 0.10f, -0.52f, 0.16f, -0.62f, 0.16f, -0.62f, 0.10f), M_CYAN)
        p.decal(0, sg, sgf * 0.388f, fa(-0.82f, -0.18f, -0.78f, 0.05f, -0.90f, 0.05f, -0.94f, -0.18f), M_ORANGE)
        p.decal(2, 1, 0.372f, fa(-0.20f, -0.20f, 0.20f, -0.20f, 0.20f, -0.26f, -0.20f, -0.26f), M_STEEL)
        out.add(p.build())
        // muslo (marco: cadera). Barril de cadera + barril de rodilla.
        p = PartB(F_HIP0 + si)
        p.cylinder(0f, 0f, 0f, 0.20f, 0.20f, 0, 8, M_BLACK)
        p.cylinder(0f, -0.60f, 0.01f, 0.24f, 0.28f, 0, 8, M_BLACK)
        p.chambox(0f, -0.32f, 0f, 0.31f, 0.27f, 0.37f, 0.06f, M_WHITE)
        p.chambox(0f, -0.08f, 0f, 0.32f, 0.03f, 0.38f, 0f, M_BLACK, false)
        p.decal(2, 1, 0.376f, fa(-0.20f, -0.24f, 0.20f, -0.24f, 0.20f, -0.34f, -0.20f, -0.34f), M_ORANGE)
        p.decal(0, sg, sgf * 0.316f, fa(-0.20f, -0.26f, -0.20f, 0.26f, -0.24f, 0.26f, -0.24f, -0.26f), M_STEEL)
        out.add(p.build())
        // rodilla + espinilla (marco: rodilla). Barril de rodilla + barril de tobillo.
        p = PartB(F_KN0 + si)
        p.cylinder(0f, 0f, 0.02f, 0.24f, 0.28f, 0, 8, M_BLACK)
        p.cylinder(0f, -0.50f, 0.02f, 0.21f, 0.25f, 0, 8, M_BLACK)
        p.chambox(0f, -0.29f, 0.02f, 0.29f, 0.24f, 0.33f, 0.06f, M_WHITE)
        p.chambox(0f, -0.55f, 0.03f, 0.30f, 0.03f, 0.34f, 0f, M_BLACK, false)
        p.decal(2, 1, 0.352f, fa(-0.20f, -0.07f, 0.20f, -0.07f, 0.20f, -0.13f, -0.20f, -0.13f), M_STEEL)
        p.decal(2, 1, 0.352f, fa(-0.17f, -0.18f, -0.05f, -0.18f, -0.05f, -0.32f, -0.17f, -0.32f), M_CYAN)
        p.decal(2, 1, 0.352f, fa(0.05f, -0.18f, 0.17f, -0.18f, 0.17f, -0.32f, 0.05f, -0.32f), M_CYAN)
        p.decal(0, sg, sgf * 0.308f, fa(-0.40f, -0.20f, -0.38f, 0.20f, -0.50f, 0.20f, -0.52f, -0.20f), M_ORANGE)
        out.add(p.build())
        // pie (marco: tobillo)
        p = PartB(F_AN0 + si)
        p.chambox(0f, -0.07f, 0.14f, 0.33f, 0.09f, 0.46f, 0.05f, M_WHITE)
        p.chambox(0f, -0.175f, 0.14f, 0.345f, 0.035f, 0.47f, 0.02f, M_BLACK, false)
        p.decal(2, 1, 0.605f, fa(-0.18f, -0.04f, 0.18f, -0.04f, 0.18f, -0.10f, -0.18f, -0.10f), M_ORANGE)
        for (kx in floatArrayOf(-0.20f, 0f, 0.20f))
            p.decal(1, 1, 0.024f, fa(kx - 0.05f, 0.28f, kx + 0.05f, 0.28f, kx + 0.05f, 0.50f, kx - 0.05f, 0.50f), M_BLACK)
        out.add(p.build())
    }
    // ── cabeza: caja con visor (va al final para no mover los índices de los brazos) ──
    run {
        val p = PartB(F_CHEST)
        p.chambox(0f, 1.17f, 0f, 0.20f, 0.07f, 0.20f, 0f, M_BLACK, false)           // cuello
        p.chambox(0f, HEAD_CY, 0f, HEAD_HX, HEAD_HY, HEAD_HZ, 0.07f, M_WHITE)
        for (sg in floatArrayOf(-1f, 1f)) p.chambox(sg * 0.43f, HEAD_CY, 0f, 0.05f, 0.12f, 0.14f, 0.02f, M_BLACK, false)
        p.decal(1, 1, HEAD_CY + HEAD_HY + 0.004f, fa(-0.12f, -0.20f, 0.12f, -0.20f, 0.12f, 0.20f, -0.12f, 0.20f), M_ORANGE)
        p.decal(2, 1, HEAD_HZ + 0.004f, fa(-0.31f, 1.31f, 0.31f, 1.31f, 0.31f, 1.55f, -0.31f, 1.55f), M_STEEL)
        p.decal(2, 1, HEAD_HZ + 0.008f, fa(-0.28f, 1.34f, 0.28f, 1.34f, 0.28f, 1.52f, -0.28f, 1.52f), M_VISOR)
        p.decal(2, 1, HEAD_HZ + 0.004f, fa(-0.12f, 1.268f, 0.12f, 1.268f, 0.12f, 1.288f, -0.12f, 1.288f), M_BLACK)
        p.decal(2, -1, -(HEAD_HZ + 0.004f), fa(-0.16f, 1.34f, 0.16f, 1.34f, 0.16f, 1.50f, -0.16f, 1.50f), M_BLACK)
        p.decal(2, -1, -(HEAD_HZ + 0.010f), fa(-0.10f, 1.40f, 0.10f, 1.40f, 0.10f, 1.45f, -0.10f, 1.45f), M_CYAN)
        out.add(p.build())
    }
    return out.toTypedArray()
}

private fun wrapPiR(a: Float): Float = ((a + PI_F) % TAU_F + TAU_F) % TAU_F - PI_F

/** Un deslizador del modo "mover articulaciones". */
internal class PoseSlider(val label: String, val joint: Int, val min: Float, val max: Float)

// medidas del esqueleto (unidades del modelo)
private const val L1 = 0.60f        // cadera → rodilla
private const val L2 = 0.50f        // rodilla → tobillo
private const val STRIDE = 0.8f     // largo de paso (el pie de apoyo recorre esto)
private const val LIFT = 0.20f      // cuánto sube el pie al dar el paso
private const val CAM = 0.21f       // cámara mirando un poco desde arriba
private const val FOCAL = 9f

internal class Robot3D(private val dens: Float) {
    companion object {
        const val J_PYAW = 0
        const val J_PROLL = 1
        const val J_CYAW = 2
        const val J_CPITCH = 3
        const val J_CROLL = 4
        const val J_SHP0 = 5
        const val J_SHR0 = 6
        const val J_EL0 = 7
        const val J_SHP1 = 8
        const val J_SHR1 = 9
        const val J_EL1 = 10
        const val J_HIPP0 = 11
        const val J_HIPR0 = 12
        const val J_KN0 = 13
        const val J_AN0 = 14
        const val J_HIPP1 = 15
        const val J_HIPR1 = 16
        const val J_KN1 = 17
        const val J_AN1 = 18
        const val NJ = 19

        const val MODE_STAND = 0
        const val MODE_WALK = 1
        const val MODE_AIR = 2
        const val MODE_HELD = 3
        const val MODE_CLEAN = 4
        const val MODE_HAPPY = 5

        /** Alto total del modelo en unidades (para calcular el tamaño en pantalla). */
        const val HEIGHT_UNITS = 2.95f

        val parts: Array<RPart> by lazy { buildRobotParts() }

        val sliders: List<PoseSlider> = listOf(
            PoseSlider("Torso: girar", J_CYAW, -1.2f, 1.2f),
            PoseSlider("Torso: inclinar", J_CPITCH, -0.6f, 0.9f),
            PoseSlider("Torso: ladear", J_CROLL, -0.5f, 0.5f),
            PoseSlider("Hombro izq.: adelante/atrás", J_SHP0, -1.6f, 3.0f),
            PoseSlider("Brazo izq.: abrir", J_SHR0, -0.2f, 2.8f),
            PoseSlider("Codo izq.", J_EL0, 0f, 2.4f),
            PoseSlider("Hombro der.: adelante/atrás", J_SHP1, -1.6f, 3.0f),
            PoseSlider("Brazo der.: abrir", J_SHR1, -0.2f, 2.8f),
            PoseSlider("Codo der.", J_EL1, 0f, 2.4f),
            PoseSlider("Cadera izq.: adelante/atrás", J_HIPP0, -0.9f, 1.5f),
            PoseSlider("Cadera izq.: abrir", J_HIPR0, -0.2f, 0.8f),
            PoseSlider("Rodilla izq.", J_KN0, 0f, 2.1f),
            PoseSlider("Cadera der.: adelante/atrás", J_HIPP1, -0.9f, 1.5f),
            PoseSlider("Cadera der.: abrir", J_HIPR1, -0.2f, 0.8f),
            PoseSlider("Rodilla der.", J_KN1, 0f, 2.1f)
        )
    }

    // ───────── lo que decide el controlador (física / IA) ─────────
    var mode = MODE_STAND
    var yaw = 0f                     // hacia dónde mira el cuerpo (rad, sin tope: 0 = de frente a la cámara, + = a la derecha)
    var yawTarget = 0f
    var turnRate = 4.4f              // rad/s al girar
    var autoLook = true              // parado, mira a todos lados y a veces da una vuelta entera
    var velX = 0f                    // px/s (inclina el cuerpo / balancea las piernas al agarrarlo)
    var velY = 0f
    var lookX = 0f                   // -1..1: hacia dónde miran los ojos dentro del visor
    var lookY = 0f
    var manual = false               // modo "mover articulaciones": manda lo que pongan los deslizadores
    val man = FloatArray(NJ)
    val grabX = FloatArray(2)        // dedo sobre una mano (en px del cuadro del robot)
    val grabY = FloatArray(2)
    val grabbing = BooleanArray(2)

    // ───────── lo que se lee para dibujar y para tocar ─────────
    val handX = FloatArray(2)
    val handY = FloatArray(2)
    val cur = FloatArray(NJ)

    private val vel = FloatArray(NJ)
    private val tgt = FloatArray(NJ)
    private val gnd = FloatArray(NJ)
    private val airP = FloatArray(NJ)
    private val heldP = FloatArray(NJ)
    private val cleanP = FloatArray(NJ)
    private val happyP = FloatArray(NJ)
    private var time = 0f
    private var phase = 0f
    private var gaitW = 0f
    private var airW = 0f
    private var heldW = 0f
    private var cleanW = 0f
    private var happyW = 0f
    private var spinVel = 0f
    private var yawRate = 0f
    private var crouch = 0f
    private var crouchVel = 0f
    private var pend = 0f
    private var pendVel = 0f
    private var idleT = 2f
    private var blinkT = 3f
    private var surprise = 0f
    private var ikHip = 0f
    private var ikKnee = 0f
    private var trZ = 0f
    private var trH = 0f

    init { resetPose() }

    fun resetPose() {
        for (j in 0 until NJ) { cur[j] = 0f; vel[j] = 0f; man[j] = 0f }
        man[J_SHR0] = 0.07f; man[J_SHR1] = 0.07f; man[J_EL0] = 0.12f; man[J_EL1] = 0.12f
        cur[J_SHR0] = 0.07f; cur[J_SHR1] = 0.07f; cur[J_EL0] = 0.12f; cur[J_EL1] = 0.12f
    }

    /** Avanza la fase de la marcha según lo que se desplazó (en unidades del modelo). El pie de apoyo recorre STRIDE por cada 0.6 de fase. */
    fun advance(units: Float) {
        phase += units * 0.6f / STRIDE
        phase -= kotlin.math.floor(phase)
    }

    /** Da una vuelta entera hacia ese lado (sin tope de giro). */
    fun spin(dir: Float) { spinVel = 7.5f * (if (dir >= 0f) 1f else -1f) }

    /** Golpecito / susto: las articulaciones saltan y vuelven por sus resortes. */
    fun kick() {
        vel[J_CPITCH] -= 3.5f
        vel[J_SHR0] += 5f; vel[J_SHR1] += 5f
        vel[J_SHP0] += 3f; vel[J_SHP1] += 3f
        surprise = 0.9f
    }

    /** Aterrizaje: se agacha según la fuerza del golpe (px/s) y se levanta con un resorte. */
    fun land(impactPxS: Float) {
        crouchVel += (impactPxS / dens / 900f).coerceIn(0.3f, 3.2f)
        surprise = max(surprise, 0.4f)
    }

    private fun approach(a: Float, b: Float, rate: Float, dt: Float) = a + (b - a) * min(1f, rate * dt)

    private fun legIk(z: Float, v: Float) {
        var d = sqrt(z * z + v * v)
        val dmin = abs(L1 - L2) + 0.02f
        val dmax = L1 + L2 - 0.004f
        if (d < dmin) d = dmin
        if (d > dmax) d = dmax
        val ck = ((L1 * L1 + L2 * L2 - d * d) / (2f * L1 * L2)).coerceIn(-1f, 1f)
        ikKnee = PI_F - acos(ck)
        val cb = ((L1 * L1 + d * d - L2 * L2) / (2f * L1 * d)).coerceIn(-1f, 1f)
        ikHip = atan2(z, v) + acos(cb)
    }

    private fun smooth(u: Float) = u * u * (3f - 2f * u)

    private fun footTraj(g0: Float) {
        val g = g0 - kotlin.math.floor(g0)
        if (g < 0.6f) {
            trZ = STRIDE * (0.5f - g / 0.6f); trH = 0f
        } else {
            val u = (g - 0.6f) / 0.4f
            trZ = STRIDE * (-0.5f + smooth(u)); trH = LIFT * sin(PI_F * u)
        }
    }

    private fun pickIdle() {
        when (Random.nextInt(10)) {
            0, 1, 2 -> { yawTarget = (Random.nextFloat() * 2f - 1f) * 1.3f }
            3, 4 -> { yawTarget = 0f }
            5 -> { yawTarget = PI_F }
            6 -> { spin(if (Random.nextBoolean()) 1f else -1f); yawTarget = 0f }
            7, 8 -> { yawTarget = (if (Random.nextBoolean()) 1f else -1f) * (0.5f + Random.nextFloat() * 0.7f) }
            else -> { yawTarget = 0f; surprise = 0.6f }
        }
        lookX = Random.nextFloat() * 2f - 1f
        lookY = (Random.nextFloat() * 2f - 1f) * 0.8f
        idleT = 1.6f + Random.nextFloat() * 3.4f
    }

    fun update(dt0: Float) {
        val dt = dt0.coerceIn(0.001f, 0.034f)
        time += dt

        // ── giro del cuerpo (siempre por el camino corto; una vuelta entera es un giro libre) ──
        val oldYaw = yaw
        if (abs(spinVel) > 0.3f) {
            yaw += spinVel * dt
            spinVel *= (1f - 1.5f * dt).coerceAtLeast(0f)
        } else {
            spinVel = 0f
            val d = wrapPiR(yawTarget - yaw)
            val ms = turnRate * dt
            yaw += d.coerceIn(-ms, ms)
        }
        yaw = wrapPiR(yaw)
        yawRate = abs(wrapPiR(yaw - oldYaw)) / dt

        if (mode == MODE_STAND && autoLook && !manual && !grabbing[0] && !grabbing[1]) {
            idleT -= dt
            if (idleT <= 0f) pickIdle()
        }

        // ── pesos de cada comportamiento (se mezclan, no se cortan) ──
        gaitW = approach(gaitW, if (mode == MODE_WALK) 1f else 0f, 8f, dt)
        airW = approach(airW, if (mode == MODE_AIR) 1f else 0f, 14f, dt)
        heldW = approach(heldW, if (mode == MODE_HELD) 1f else 0f, 12f, dt)
        cleanW = approach(cleanW, if (mode == MODE_CLEAN) 1f else 0f, 10f, dt)
        happyW = approach(happyW, if (mode == MODE_HAPPY) 1f else 0f, 10f, dt)
        surprise = (surprise - dt * 1.6f).coerceAtLeast(0f)

        // agacharse al caer: resorte
        crouchVel += (-190f * crouch - 17f * crouchVel) * dt
        crouch = (crouch + crouchVel * dt).coerceIn(-0.1f, 1.0f)

        // colgado: péndulo que sigue el movimiento del dedo
        val pt = (-velX / dens / 650f).coerceIn(-0.8f, 0.8f)
        pendVel += ((pt - pend) * 55f - pendVel * 7f) * dt
        pend = (pend + pendVel * dt).coerceIn(-1.1f, 1.1f)

        // parpadeo
        blinkT -= dt
        if (blinkT < -0.14f) blinkT = 2.4f + Random.nextFloat() * 3.4f

        // pasitos mientras gira parado
        val turnW = if (mode == MODE_STAND) (yawRate / 2.6f).coerceIn(0f, 1f) * 0.55f else 0f
        if (mode == MODE_STAND && yawRate > 0.2f) { phase += yawRate * dt * 0.10f; phase -= kotlin.math.floor(phase) }
        val amp = max(gaitW, turnW)

        // ── objetivos con los pies en el suelo (cinemática inversa) ──
        for (j in 0 until NJ) gnd[j] = 0f
        val g = phase
        val breath = sin(time * 1.9f)
        val vmid = 1.03f + 0.045f * cos(2f * TAU_F * (g - 0.3f))
        val vst = 1.092f
        val vbase = vst + (vmid - vst) * amp - crouch * 0.30f
        val fs = FloatArray(2)
        for (si in 0 until 2) {
            footTraj(g + 0.5f * si)
            legIk(trZ * amp, vbase - trH * amp)
            gnd[J_HIPP0 + 4 * si] = ikHip
            gnd[J_KN0 + 4 * si] = ikKnee
            gnd[J_HIPR0 + 4 * si] = 0.02f * amp
            gnd[J_AN0 + 4 * si] = 0.30f * amp * (trH / LIFT).coerceIn(0f, 1f)
            fs[si] = trZ / (0.5f * STRIDE)
        }
        val dd = (fs[0] - fs[1]) * 0.5f
        for (si in 0 until 2) {
            gnd[J_SHP0 + 3 * si] = -0.36f * amp * fs[si] + 0.03f * breath + crouch * 0.35f
            gnd[J_SHR0 + 3 * si] = 0.07f + 0.012f * breath
            gnd[J_EL0 + 3 * si] = 0.12f + amp * (0.10f + 0.22f * max(0f, fs[si])) + crouch * 0.7f
        }
        gnd[J_PYAW] = 0.10f * dd * amp
        gnd[J_CYAW] = -0.12f * dd * amp + lookX * 0.28f * (1f - amp)
        gnd[J_CROLL] = 0.04f * sin(TAU_F * g) * amp
        gnd[J_PROLL] = -0.03f * sin(TAU_F * g) * amp
        gnd[J_CPITCH] = 0.02f * breath + 0.07f * amp + crouch * 0.28f - lookY * 0.10f * (1f - amp) - surprise * 0.25f

        // ── en el aire: piernas recogidas y brazos abiertos ──
        for (j in 0 until NJ) airP[j] = 0f
        airP[J_HIPP0] = 0.45f; airP[J_KN0] = 0.85f; airP[J_AN0] = 0.15f
        airP[J_HIPP1] = -0.15f; airP[J_KN1] = 0.55f
        airP[J_SHR0] = 1.25f + 0.10f * sin(time * 9f); airP[J_SHR1] = 1.25f - 0.10f * sin(time * 9f)
        airP[J_SHP0] = 0.2f; airP[J_SHP1] = 0.2f; airP[J_EL0] = 0.3f; airP[J_EL1] = 0.3f
        airP[J_CPITCH] = (velY / dens / 2500f).coerceIn(-0.3f, 0.3f)
        airP[J_CROLL] = (-velX / dens / 2200f).coerceIn(-0.35f, 0.35f)

        // ── colgado de un dedo: todo cuelga y se balancea ──
        for (j in 0 until NJ) heldP[j] = 0f
        heldP[J_HIPP0] = 0.10f; heldP[J_HIPP1] = 0.04f; heldP[J_KN0] = 0.18f; heldP[J_KN1] = 0.10f
        heldP[J_HIPR0] = pend * 0.8f; heldP[J_HIPR1] = -pend * 0.8f
        heldP[J_SHR0] = 0.35f + pend * 0.9f; heldP[J_SHR1] = 0.35f - pend * 0.9f
        heldP[J_SHP0] = 0.15f; heldP[J_SHP1] = 0.15f; heldP[J_EL0] = 0.25f; heldP[J_EL1] = 0.25f
        heldP[J_CROLL] = -pend * 0.35f
        heldP[J_CPITCH] = 0.05f

        // ── limpiando: brazos arriba bombeando, torso girando ──
        for (j in 0 until NJ) cleanP[j] = 0f
        cleanP[J_SHR0] = 2.3f; cleanP[J_SHR1] = 2.3f
        cleanP[J_SHP0] = 0.2f * sin(time * 14f); cleanP[J_SHP1] = -0.2f * sin(time * 14f)
        cleanP[J_EL0] = 0.45f + 0.35f * sin(time * 14f); cleanP[J_EL1] = 0.45f - 0.35f * sin(time * 14f)
        cleanP[J_CYAW] = 0.38f * sin(time * 7f)
        cleanP[J_CPITCH] = 0.10f + 0.06f * sin(time * 14f)
        cleanP[J_HIPP0] = 0.05f; cleanP[J_HIPP1] = 0.05f; cleanP[J_KN0] = 0.15f + 0.1f * sin(time * 14f); cleanP[J_KN1] = 0.15f - 0.1f * sin(time * 14f)

        // ── contento: saluda con una mano ──
        for (j in 0 until NJ) happyP[j] = 0f
        happyP[J_SHR0] = 2.35f + 0.18f * sin(time * 11f); happyP[J_EL0] = 0.55f + 0.5f * sin(time * 11f)
        happyP[J_SHR1] = 0.30f; happyP[J_EL1] = 0.3f
        happyP[J_CROLL] = 0.08f * sin(time * 5f); happyP[J_CYAW] = 0.18f * sin(time * 3f)
        happyP[J_CPITCH] = -0.06f
        happyP[J_HIPP0] = 0.03f; happyP[J_HIPP1] = 0.03f; happyP[J_KN0] = 0.1f; happyP[J_KN1] = 0.1f

        for (j in 0 until NJ) {
            var t = gnd[j]
            t += (airP[j] - t) * airW
            t += (heldP[j] - t) * heldW
            t += (cleanP[j] - t) * cleanW
            t += (happyP[j] - t) * happyW
            tgt[j] = if (manual) man[j] else t
        }
        if (!manual) {
            if (grabbing[0]) aimArm(0)
            if (grabbing[1]) aimArm(1)
        }

        // ── resortes de las articulaciones (piernas rígidas para que el pie no resbale; brazos y torso con más soltura) ──
        val sub = ceil(dt / 0.012f).toInt().coerceIn(1, 4)
        val h = dt / sub
        for (s in 0 until sub) for (j in 0 until NJ) {
            val leg = j >= J_HIPP0
            val k = if (leg) 1500f else 230f
            val c = 2f * sqrt(k) * (if (leg) 0.9f else 0.78f)
            vel[j] += ((tgt[j] - cur[j]) * k - vel[j] * c) * h
            cur[j] += vel[j] * h
        }
    }

    // ───────── brazos que siguen al dedo ─────────
    private val chestRv = FloatArray(9)
    private val shX = FloatArray(2)
    private val shY = FloatArray(2)
    private var lastUnit = 1f
    private var haveView = false

    private fun aimArm(si: Int) {
        if (!haveView) return
        val sg = if (si == 0) 1f else -1f
        val dx = (grabX[si] - shX[si]) / lastUnit
        val dy = -(grabY[si] - shY[si]) / lastUnit
        val dist = hypot(dx, dy)
        val reach = 1.75f
        val zf = sqrt(max(0f, reach * reach - dist * dist)) * 0.55f
        var vx = dx; var vy = dy; var vz = zf
        val l = sqrt(vx * vx + vy * vy + vz * vz).let { if (it < 1e-5f) 1f else it }
        vx /= l; vy /= l; vz /= l
        val m = chestRv
        val lx = m[0] * vx + m[3] * vy + m[6] * vz
        val ly = m[1] * vx + m[4] * vy + m[7] * vz
        val lz = m[2] * vx + m[5] * vy + m[8] * vz
        val th = asin(lx.coerceIn(-1f, 1f))
        val ph = atan2(-lz, -ly)
        tgt[J_SHP0 + 3 * si] = -ph
        tgt[J_SHR0 + 3 * si] = sg * th
        tgt[J_EL0 + 3 * si] = (1f - dist / reach).coerceIn(0f, 1f) * 1.9f
    }

    /** ¿Hay una mano cerca de este punto (px del cuadro)? Devuelve 0, 1 o -1. */
    fun handAt(x: Float, y: Float): Int {
        val r = 30f * dens
        var best = -1
        var bd = r * r
        for (si in 0 until 2) {
            val dx = x - handX[si]; val dy = y - handY[si]
            val d2 = dx * dx + dy * dy
            if (d2 < bd) { bd = d2; best = si }
        }
        return best
    }

    // ───────── dibujo ─────────
    private val fm = FloatArray(NFR * 12)
    private val vm = FloatArray(12)
    private val pm = FloatArray(parts.size * 12)
    private val vOff = IntArray(parts.size + 1)
    private val fOff = IntArray(parts.size + 1)
    private val tmp3 = FloatArray(3)
    init { for (i in parts.indices) { vOff[i + 1] = vOff[i] + parts[i].nv; fOff[i + 1] = fOff[i] + parts[i].nf } }
    private val totalV = vOff[parts.size]
    private val totalF = fOff[parts.size]
    private val tx = FloatArray(totalV)
    private val ty = FloatArray(totalV)
    private val tz = FloatArray(totalV)
    private val sxs = FloatArray(totalV)
    private val sys = FloatArray(totalV)
    private val faceOwner = IntArray(totalF)
    private val faceParent = IntArray(totalF)
    private val faceKey = FloatArray(totalF)
    private val sortBuf = LongArray(totalF)
    private var visorG = -1
    init {
        for (i in parts.indices) {
            val p = parts[i]
            for (f in 0 until p.nf) {
                val g = fOff[i] + f
                faceOwner[g] = i
                faceParent[g] = if (p.fParent[f] >= 0) fOff[i] + p.fParent[f] else -1
                if (i == parts.size - 1 && p.fMat[f] == M_VISOR) visorG = g
            }
        }
    }
    private val path = Path()
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE; strokeJoin = Paint.Join.ROUND; strokeWidth = max(0.8f, 0.4f * dens)
    }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeWidth = 0.55f * dens
    }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeWidth = 3.2f * dens
    }
    private val soleX = floatArrayOf(-0.34f, -0.34f, 0.34f, 0.34f)
    private val soleZ = floatArrayOf(-0.33f, 0.61f, -0.33f, 0.61f)

    private fun fkAll() {
        val pel = F_PELVIS * 12
        mIdent(fm, pel)
        mRy(fm, pel, cur[J_PYAW]); mRz(fm, pel, cur[J_PROLL])
        val ch = F_CHEST * 12
        System.arraycopy(fm, pel, fm, ch, 12)
        mTr(fm, ch, 0f, 0.04f, 0f)
        mRy(fm, ch, cur[J_CYAW]); mRx(fm, ch, -cur[J_CPITCH]); mRz(fm, ch, cur[J_CROLL])
        for (si in 0 until 2) {
            val sg = if (si == 0) 1f else -1f
            val sh = (F_SH0 + si) * 12
            System.arraycopy(fm, ch, fm, sh, 12)
            mTr(fm, sh, sg * 0.80f, 0.82f, 0f)
            mRx(fm, sh, -cur[J_SHP0 + 3 * si]); mRz(fm, sh, sg * cur[J_SHR0 + 3 * si])
            val pd = (F_PAD0 + si) * 12
            System.arraycopy(fm, ch, fm, pd, 12)
            mTr(fm, pd, sg * 0.80f, 0.82f, 0f)
            mRz(fm, pd, sg * max(0f, cur[J_SHR0 + 3 * si] - 0.9f))
            val el = (F_EL0 + si) * 12
            System.arraycopy(fm, sh, fm, el, 12)
            mTr(fm, el, 0f, -0.84f, 0f)
            mRx(fm, el, -cur[J_EL0 + 3 * si])
            val hp = (F_HIP0 + si) * 12
            System.arraycopy(fm, pel, fm, hp, 12)
            mTr(fm, hp, sg * 0.40f, -0.02f, 0f)
            val hipP = cur[J_HIPP0 + 4 * si]
            val kn = cur[J_KN0 + 4 * si]
            mRx(fm, hp, -hipP); mRz(fm, hp, sg * cur[J_HIPR0 + 4 * si])
            val k = (F_KN0 + si) * 12
            System.arraycopy(fm, hp, fm, k, 12)
            mTr(fm, k, 0f, -0.60f, 0f)
            mRx(fm, k, kn)
            val an = (F_AN0 + si) * 12
            System.arraycopy(fm, k, fm, an, 12)
            mTr(fm, an, 0f, -0.50f, 0f)
            mRx(fm, an, hipP - kn + cur[J_AN0 + 4 * si])
        }
    }

    /**
     * Dibuja el robot en un cuadro de w×h px. Los pies quedan en la parte de abajo del cuadro (el suelo);
     * [unit] = px por unidad del modelo (el alto total son HEIGHT_UNITS unidades).
     */
    fun draw(c: Canvas, w: Float, h: Float, unit: Float) {
        fkAll()
        // El robot se apoya siempre en su punto más bajo: ni flota ni se hunde.
        var low = 1e9f
        for (si in 0 until 2) {
            val o = (F_AN0 + si) * 12
            for (q in 0 until 4) {
                val y = fm[o + 4] * soleX[q] + fm[o + 5] * -0.21f + fm[o + 6] * (soleZ[q]) + fm[o + 7]
                if (y < low) low = y
            }
        }
        mIdent(vm, 0)
        mRx(vm, 0, CAM); mRy(vm, 0, yaw); mTr(vm, 0, 0f, -low, 0f)

        val cx = w / 2f
        val gy = h - 3f * dens
        val s = unit
        lastUnit = unit

        // aura de contacto (en AMOLED una sombra negra no se ve: el suelo se marca con luz suave)
        fillP.style = Paint.Style.FILL
        for (i in 0 until 3) {
            val k = 1f - i * 0.30f
            fillP.color = ((10 + i * 5) shl 24) or 0xFFFFFF
            c.drawOval(cx - s * 1.30f * k, gy - s * 0.20f * k, cx + s * 1.30f * k, gy + s * 0.20f * k, fillP)
        }
        fillP.style = Paint.Style.FILL_AND_STROKE

        val np = parts.size
        for (i in 0 until np) mMul(pm, i * 12, vm, 0, fm, parts[i].frame * 12)

        // 1) todos los vértices a espacio de vista y a pantalla
        for (i in 0 until np) {
            val p = parts[i]
            val o = i * 12
            val vo = vOff[i]
            for (k in 0 until p.nv) {
                val x = p.vx[k]; val y = p.vy[k]; val z = p.vz[k]
                val vx = pm[o] * x + pm[o + 1] * y + pm[o + 2] * z + pm[o + 3]
                val vy = pm[o + 4] * x + pm[o + 5] * y + pm[o + 6] * z + pm[o + 7]
                val vz = pm[o + 8] * x + pm[o + 9] * y + pm[o + 10] * z + pm[o + 11]
                tx[vo + k] = vx; ty[vo + k] = vy; tz[vo + k] = vz
                val kf = FOCAL / (FOCAL - vz)
                sxs[vo + k] = cx + vx * s * kf
                sys[vo + k] = gy - vy * s * kf
            }
        }

        // 2) profundidad de CADA cara (las cajas grandes ya no se tapan mal entre sí); una calcomanía hereda la de su cara + un pelito
        var cnt = 0
        for (i in 0 until np) {
            val p = parts[i]
            val o = i * 12
            val vo = vOff[i]
            for (f in 0 until p.nf) {
                val g = fOff[i] + f
                val s0 = p.fStart[f]
                val s1 = p.fStart[f + 1]
                var cxm = 0f; var cym = 0f; var czm = 0f
                for (k in s0 until s1) { val id = vo + p.fIdx[k]; cxm += tx[id]; cym += ty[id]; czm += tz[id] }
                val cn = (s1 - s0).toFloat()
                cxm /= cn; cym /= cn; czm /= cn
                val fnx = p.fnx[f]; val fny = p.fny[f]; val fnz = p.fnz[f]
                val nx = pm[o] * fnx + pm[o + 1] * fny + pm[o + 2] * fnz
                val ny = pm[o + 4] * fnx + pm[o + 5] * fny + pm[o + 6] * fnz
                val nz = pm[o + 8] * fnx + pm[o + 9] * fny + pm[o + 10] * fnz
                val par = faceParent[g]
                val key = if (par >= 0) faceKey[par] + 0.004f else czm
                faceKey[g] = key
                val facing = nx * (-cxm) + ny * (-cym) + nz * (FOCAL - czm)
                if (facing > 0f) {
                    sortBuf[cnt++] = (((key + 16f) * 65536f).toLong() shl 24) or g.toLong()
                }
            }
        }
        java.util.Arrays.sort(sortBuf, 0, cnt)

        // 3) de lejos a cerca
        for (q in 0 until cnt) {
            val g = (sortBuf[q] and 0xFFFFFFL).toInt()
            val i = faceOwner[g]
            val p = parts[i]
            val f = g - fOff[i]
            val o = i * 12
            val vo = vOff[i]
            val s0 = p.fStart[f]
            val s1 = p.fStart[f + 1]
            val fnx = p.fnx[f]; val fny = p.fny[f]; val fnz = p.fnz[f]
            val nx = pm[o] * fnx + pm[o + 1] * fny + pm[o + 2] * fnz
            val ny = pm[o + 4] * fnx + pm[o + 5] * fny + pm[o + 6] * fnz
            val nz = pm[o + 8] * fnx + pm[o + 9] * fny + pm[o + 10] * fnz
            val kind = p.fKind[f]
            val col = shade(p.fMat[f], kind, nx, ny, nz)
            path.reset()
            path.moveTo(sxs[vo + p.fIdx[s0]], sys[vo + p.fIdx[s0]])
            for (k in s0 + 1 until s1) path.lineTo(sxs[vo + p.fIdx[k]], sys[vo + p.fIdx[k]])
            path.close()
            fillP.color = col
            c.drawPath(path, fillP)
            if (kind == K_HARD) {
                edgeP.color = darken(col)
                c.drawPath(path, edgeP)
            }
            if (g == visorG) drawEyes(c, o, cx, gy, s)     // los ojos van pegados al visor
        }

        // posiciones en pantalla de hombros y manos (para agarrar los brazos y apuntarlos al dedo)
        for (si in 0 until 2) {
            val ou = (4 + 5 * si) * 12
            val k0 = FOCAL / (FOCAL - pm[ou + 11])
            shX[si] = cx + pm[ou + 3] * s * k0
            shY[si] = gy - pm[ou + 7] * s * k0
            val of = (5 + 5 * si) * 12
            val x = 0f; val y = -0.95f; val z = 0.05f
            val vx = pm[of] * x + pm[of + 1] * y + pm[of + 2] * z + pm[of + 3]
            val vy = pm[of + 4] * x + pm[of + 5] * y + pm[of + 6] * z + pm[of + 7]
            val vz = pm[of + 8] * x + pm[of + 9] * y + pm[of + 10] * z + pm[of + 11]
            val k1 = FOCAL / (FOCAL - vz)
            handX[si] = cx + vx * s * k1
            handY[si] = gy - vy * s * k1
        }
        for (r in 0 until 3) for (q in 0 until 3) chestRv[r * 3 + q] = pm[r * 4 + q]     // la pieza 0 es el torso (marco del pecho)
        haveView = true
    }

    // ojos: rayos cian dentro del visor (siguen la mirada, parpadean, se alegran, se asustan)

    private fun viewPt(o: Int, out: FloatArray) {
        val x = out[0]; val y = out[1]; val z = out[2]
        out[0] = pm[o] * x + pm[o + 1] * y + pm[o + 2] * z + pm[o + 3]
        out[1] = pm[o + 4] * x + pm[o + 5] * y + pm[o + 6] * z + pm[o + 7]
        out[2] = pm[o + 8] * x + pm[o + 9] * y + pm[o + 10] * z + pm[o + 11]
    }

    private fun addHeadPt(o: Int, x: Float, y: Float, first: Boolean, cx: Float, gy: Float, s: Float) {
        tmp3[0] = x; tmp3[1] = y; tmp3[2] = HEAD_HZ + 0.016f
        viewPt(o, tmp3)
        val k = FOCAL / (FOCAL - tmp3[2])
        val px = cx + tmp3[0] * s * k
        val py = gy - tmp3[1] * s * k
        if (first) path.moveTo(px, py) else path.lineTo(px, py)
    }

    private fun drawEyes(c: Canvas, o: Int, cx: Float, gy: Float, s: Float) {
        // la cara del visor es plana: se ve entera o no se ve
        tmp3[0] = 0f; tmp3[1] = HEAD_EYE_Y; tmp3[2] = HEAD_HZ
        viewPt(o, tmp3)
        val ex = -tmp3[0]; val ey = -tmp3[1]; val ez = FOCAL - tmp3[2]
        val len = sqrt(ex * ex + ey * ey + ez * ez)
        val facing = (pm[o + 2] * ex + pm[o + 6] * ey + pm[o + 10] * ez) / len
        val a = (facing / 0.12f).coerceIn(0f, 1f)
        if (a <= 0f) return
        val happy = mode == MODE_HAPPY
        val clean = mode == MODE_CLEAN
        val blink = if (blinkT < 0f && surprise <= 0f) 0.12f else 1f
        val sc = if (surprise > 0f) 1.25f else 1f
        val flick = if (clean) (0.65f + 0.35f * sin(time * 30f)) else 1f
        val rgb = if (clean) 0xFFB020 else 0x5BF2FF
        val al = (a * flick * 255f).toInt().coerceIn(0, 255)
        for (e in 0 until 2) {
            val ecx = (if (e == 0) -0.14f else 0.14f) + lookX * 0.05f
            val ecy = HEAD_EYE_Y + lookY * 0.035f
            path.reset()
            if (happy) {
                val w = 0.085f; val y = ecy + 0.02f
                addHeadPt(o, ecx - w, y - 0.040f, true, cx, gy, s)
                addHeadPt(o, ecx, y + 0.045f, false, cx, gy, s)
                addHeadPt(o, ecx + w, y - 0.040f, false, cx, gy, s)
                addHeadPt(o, ecx + w, y - 0.090f, false, cx, gy, s)
                addHeadPt(o, ecx, y - 0.010f, false, cx, gy, s)
                addHeadPt(o, ecx - w, y - 0.090f, false, cx, gy, s)
            } else {
                val hw = 0.085f * sc; val hh = 0.045f * sc * blink
                addHeadPt(o, ecx - hw, ecy - hh, true, cx, gy, s)
                addHeadPt(o, ecx + hw, ecy - hh, false, cx, gy, s)
                addHeadPt(o, ecx + hw, ecy + hh, false, cx, gy, s)
                addHeadPt(o, ecx - hw, ecy + hh, false, cx, gy, s)
            }
            path.close()
            glowP.color = ((al / 4) shl 24) or rgb
            c.drawPath(path, glowP)
            fillP.color = (al shl 24) or rgb
            c.drawPath(path, fillP)
        }
    }

    private fun darken(col: Int): Int {
        val r = ((col shr 16) and 0xFF) / 2
        val g = ((col shr 8) and 0xFF) / 2
        val b = (col and 0xFF) / 2
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun shade(mat: Int, kind: Int, nx: Float, ny: Float, nz: Float): Int {
        val br = BASE_R[mat]; val bg = BASE_G[mat]; val bb = BASE_B[mat]
        val ndl = LX * nx + LY * ny + LZ * nz
        if (mat == M_CYAN) {
            val k = 0.88f + 0.12f * ndl.coerceIn(0f, 1f)
            return pack(br * k + 0.08f, bg * k + 0.05f, bb * k)
        }
        val d = if (ndl > 0f) ndl else 0f
        val lit = if (kind == K_SMOOTH) 0.52f + 0.48f * d.pow(0.85f) else {
            val band = if (d < 0.16f) 0f else if (d < 0.52f) 0.5f else 1f
            0.52f + 0.48f * (0.55f * band + 0.45f * d)
        }
        val q = 1f - nz.coerceIn(0f, 1f)
        val rim = q * q * q
        val dark = mat == M_BLACK || mat == M_VISOR || mat == M_STEEL
        val rk = if (mat == M_VISOR) 0.10f else if (dark) 0.55f else 0.20f
        val sd = HX * nx + HY * ny + HZ * nz
        val s1 = if (sd > 0f) sd else 0f
        val s2 = s1 * s1; val s4 = s2 * s2; val s8 = s4 * s4; val s16 = s8 * s8; val s32 = s16 * s16
        val sp = s32 * s4 * (if (mat == M_WHITE) 0.30f else 0.25f)
        return pack(br * lit + 0.70f * rim * rk + sp, bg * lit + 0.88f * rim * rk + sp, bb * lit + rim * rk + sp)
    }

    private fun pack(r: Float, g: Float, b: Float): Int {
        val ri = (r * 255f).toInt().coerceIn(0, 255)
        val gi = (g * 255f).toInt().coerceIn(0, 255)
        val bi = (b * 255f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }
}

// luz fija respecto de la pantalla (arriba a la izquierda, de frente): al girar el robot se nota el volumen
private const val LX = -0.4336f
private const val LY = 0.6746f
private const val LZ = 0.5974f
private const val HX = -0.2426f
private const val HY = 0.3774f
private const val HZ = 0.8937f

// ───────── matrices 3×4 (3×3 de giro + traslación), sin crear objetos ─────────
private fun mIdent(m: FloatArray, o: Int) {
    m[o] = 1f; m[o + 1] = 0f; m[o + 2] = 0f; m[o + 3] = 0f
    m[o + 4] = 0f; m[o + 5] = 1f; m[o + 6] = 0f; m[o + 7] = 0f
    m[o + 8] = 0f; m[o + 9] = 0f; m[o + 10] = 1f; m[o + 11] = 0f
}

/** m = m · T(x, y, z) */
private fun mTr(m: FloatArray, o: Int, x: Float, y: Float, z: Float) {
    m[o + 3] += m[o] * x + m[o + 1] * y + m[o + 2] * z
    m[o + 7] += m[o + 4] * x + m[o + 5] * y + m[o + 6] * z
    m[o + 11] += m[o + 8] * x + m[o + 9] * y + m[o + 10] * z
}

/** m = m · Rx(a) */
private fun mRx(m: FloatArray, o: Int, a: Float) {
    val c = cos(a); val s = sin(a)
    for (r in 0 until 3) {
        val b = o + 4 * r
        val c1 = m[b + 1]; val c2 = m[b + 2]
        m[b + 1] = c * c1 + s * c2
        m[b + 2] = -s * c1 + c * c2
    }
}

/** m = m · Ry(a) */
private fun mRy(m: FloatArray, o: Int, a: Float) {
    val c = cos(a); val s = sin(a)
    for (r in 0 until 3) {
        val b = o + 4 * r
        val c0 = m[b]; val c2 = m[b + 2]
        m[b] = c * c0 - s * c2
        m[b + 2] = s * c0 + c * c2
    }
}

/** m = m · Rz(a) */
private fun mRz(m: FloatArray, o: Int, a: Float) {
    val c = cos(a); val s = sin(a)
    for (r in 0 until 3) {
        val b = o + 4 * r
        val c0 = m[b]; val c1 = m[b + 1]
        m[b] = c * c0 + s * c1
        m[b + 1] = -s * c0 + c * c1
    }
}

/** out = a · b  (out no puede ser a ni b) */
private fun mMul(out: FloatArray, oo: Int, a: FloatArray, ao: Int, b: FloatArray, bo: Int) {
    for (r in 0 until 3) {
        val a0 = a[ao + 4 * r]; val a1 = a[ao + 4 * r + 1]; val a2 = a[ao + 4 * r + 2]; val a3 = a[ao + 4 * r + 3]
        for (col in 0 until 4) {
            out[oo + 4 * r + col] = a0 * b[bo + col] + a1 * b[bo + 4 + col] + a2 * b[bo + 8 + col] + (if (col == 3) a3 else 0f)
        }
    }
}
