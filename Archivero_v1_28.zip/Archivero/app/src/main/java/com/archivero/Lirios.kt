package com.archivero

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Fondo de la pantalla de Inicio: lirios de araña (Lycoris radiata) en grises sobre negro.
 *
 * Igual que el amigo flotante, todo se DIBUJA con código (Canvas), sin imágenes: es vectorial, así que se ve nítido
 * a cualquier resolución y pesa casi nada. Cada pétalo es una cinta curva con borde ondulado, cada estambre una
 * curva fina con una puntita brillante, y cada flor se sostiene en un tallo que se dobla.
 *
 * Movimiento: una brisa suave recorre las flores de izquierda a derecha (cada una la siente un poco después).
 * Es una suma de ondas con frecuencias enteras sobre un ciclo de [LIRIO_CICLO_MS], así que el bucle es perfecto:
 * el último cuadro encaja exactamente con el primero y no se nota el salto. La animación solo se lee al dibujar
 * (no recompone nada), y existe únicamente mientras Inicio está en pantalla.
 *
 * La composición está hecha sobre la imagen de referencia de 736 x 1308 y anclada abajo; todo escala con el ancho.
 * Los números de [LIRIOS] salen de un prototipo que se comparó con la referencia (posición, tamaño, giro, luz).
 */
const val LIRIO_CICLO_MS = 10000

@Composable
fun LirioFondo(modifier: Modifier = Modifier) {
    val painter = remember { LirioPainter() }
    val t = rememberInfiniteTransition(label = "lirios")
    val u by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(LIRIO_CICLO_MS, easing = LinearEasing), RepeatMode.Restart),
        label = "brisa"
    )
    Canvas(modifier.fillMaxSize()) { painter.draw(this, u) }
}

// ───────────────────────── Datos ─────────────────────────

/**
 * Una flor. x, y = centro de la cabeza y p = tamaño base, en píxeles de la imagen de referencia (736 x 1308);
 * e = elevación de la cámara (grados); roll = inclinación (grados); lt = luz (1 = delante, menos = más al fondo);
 * bx = dónde nace el tallo abajo; order = orden de dibujo (de atrás hacia delante: 0..8 pétalos, 9.. estambres).
 * petals: 9 valores por pétalo (giro, ángulo inicial, ángulo final, largo, ancho, fase del borde, espiral, tono, interno).
 * stamens: 4 valores por estambre (giro, ángulo inicial, ángulo final, largo).
 */
private class Lirio(
    val x: Float, val y: Float, val p: Float, val e: Float, val roll: Float, val lt: Float, val bx: Float,
    val order: IntArray, val petals: FloatArray, val stamens: FloatArray
)

private val LIRIOS = arrayOf(
    Lirio(
        x = 625f, y = 1160f, p = 62f, e = 52f, roll = 8f, lt = 0.62f, bx = 622f,
        order = intArrayOf(18, 17, 6, 16, 8, 15, 7, 19, 5, 4, 14, 1, 9, 0, 10, 13, 2, 11, 3, 12),
        petals = floatArrayOf(
            0.1546f, 31.7932f, 66.2105f, 86.2037f, 8.06f, 3.1892f, 0.1922f, 0.9169f, 0f,
            0.8777f, 33.8965f, 59.6488f, 79.754f, 8.06f, 1.9054f, -0.9005f, 1.0419f, 0f,
            1.6518f, 30.2564f, 69.1097f, 67.763f, 6.2f, 4.1066f, 0.2542f, 0.9115f, 1f,
            2.0658f, 30.8514f, 22.9776f, 81.422f, 8.06f, 1.5194f, -1.0338f, 0.9728f, 0f,
            2.9421f, 40.2728f, 45.9562f, 89.2355f, 8.06f, 3.1386f, 0.3574f, 0.9715f, 0f,
            3.5723f, 58.9297f, 69.7846f, 66.2187f, 6.2f, 4.445f, -0.4064f, 0.9259f, 1f,
            4.275f, 17.1067f, 58.3144f, 85.0709f, 8.06f, 5.3165f, -0.2497f, 1.0716f, 0f,
            5.2069f, 15.0163f, 30.4859f, 93.9223f, 8.06f, 2.9515f, 1.0568f, 0.9595f, 0f,
            5.5807f, 47.8836f, 58.9255f, 59.1452f, 6.2f, 0.5473f, -0.3683f, 1.0728f, 1f
        ),
        stamens = floatArrayOf(
            0.2134f, 4.4837f, 71.3627f, 84.3589f,
            0.4434f, 30.2868f, 68.7518f, 101.4058f,
            1.204f, 7.246f, 89.812f, 85.472f,
            1.8711f, 4.4273f, 77.9887f, 88.5186f,
            2.2596f, 36.8953f, 92.5296f, 91.9142f,
            3.1313f, 8.007f, 76.9824f, 112.3828f,
            3.5838f, 3.8126f, 99.5935f, 88.5327f,
            3.9675f, 29.3622f, 74.5003f, 91.6233f,
            4.4484f, 3.4245f, 84.1439f, 89.6401f,
            5.2776f, 14.1248f, 79.2219f, 116.2798f,
            5.7913f, 21.8337f, 94.928f, 87.4012f
        )
    ),
    Lirio(
        x = 235f, y = 1238f, p = 52f, e = 54f, roll = -10f, lt = 0.66f, bx = 240f,
        order = intArrayOf(17, 7, 16, 6, 18, 5, 15, 19, 14, 4, 8, 0, 9, 3, 2, 1, 13, 10, 12, 11),
        petals = floatArrayOf(
            0.4257f, 34.7242f, 53.3205f, 67.5963f, 6.76f, 0.0682f, -0.2755f, 0.9348f, 0f,
            1.2645f, 35.7178f, 50.0729f, 73.6472f, 6.76f, 4.1531f, -0.7803f, 0.968f, 0f,
            1.6911f, 56.1792f, 22.9412f, 55.3157f, 5.2f, 0.4685f, 0.4113f, 0.9474f, 1f,
            2.4908f, 40.2721f, 20.9302f, 66.405f, 6.76f, 5.7464f, 0.0196f, 0.8982f, 0f,
            3.4329f, 43.4014f, 25.6264f, 71.6819f, 6.76f, 0.8482f, -0.4124f, 1.0043f, 0f,
            3.786f, 49.905f, 22.5677f, 48.5806f, 5.2f, 5.1226f, -0.2189f, 0.9638f, 1f,
            4.6653f, 29.303f, 39.2291f, 65.964f, 6.76f, 4.5613f, 1.0284f, 1.0753f, 0f,
            5.3918f, 25.6904f, 38.1564f, 75.5681f, 6.76f, 4.2313f, -0.8496f, 0.927f, 0f,
            5.9641f, 44.3405f, 60.5054f, 52.0001f, 5.2f, 0.1767f, 0.7096f, 0.966f, 1f
        ),
        stamens = floatArrayOf(
            0.2274f, 8.4424f, 78.2352f, 79.7133f,
            0.9222f, 3.8993f, 82.8989f, 73.1551f,
            1.4563f, 1.4002f, 72.5088f, 78.3384f,
            1.9987f, 1.9782f, 79.452f, 74.1144f,
            2.3964f, 18.098f, 98.4324f, 82.608f,
            3.297f, 6.3674f, 97.1215f, 78.9628f,
            3.4935f, 28.4441f, 96.6576f, 67.8082f,
            4.1033f, 29.2856f, 74.988f, 75.1375f,
            4.5476f, 1.5209f, 85.5249f, 98.295f,
            5.6026f, 19.1368f, 62.9086f, 77.6606f,
            6.0706f, 31.6143f, 86.2976f, 74.7608f
        )
    ),
    Lirio(
        x = 500f, y = 1262f, p = 56f, e = 49f, roll = 6f, lt = 0.7f, bx = 505f,
        order = intArrayOf(7, 18, 17, 16, 6, 8, 15, 0, 19, 5, 14, 4, 1, 9, 13, 2, 10, 11, 3, 12),
        petals = floatArrayOf(
            -0.0137f, 35.5577f, 54.2041f, 83.8776f, 7.28f, 1.1663f, -0.5928f, 0.9094f, 0f,
            0.6703f, 37.0207f, 26.5107f, 78.891f, 7.28f, 1.3433f, -0.4518f, 0.9663f, 0f,
            1.625f, 47.2521f, 20.7216f, 53.4894f, 5.6f, 0.9213f, 0.8168f, 1.0419f, 1f,
            2.3099f, 39.791f, 57.2375f, 85.4454f, 7.28f, 4.9849f, -0.5352f, 1.05f, 0f,
            2.8743f, 37.6501f, 48.2069f, 77.2958f, 7.28f, 2.2872f, -0.1544f, 0.9428f, 0f,
            3.4176f, 53.5893f, 59.9129f, 61.4396f, 5.6f, 4.339f, 0.1193f, 1.0297f, 1f,
            4.1231f, 35.3046f, 42.17f, 73.3296f, 7.28f, 1.2725f, 0.0499f, 0.9307f, 0f,
            4.9572f, 33.165f, 39.7879f, 72.6106f, 7.28f, 3.0826f, -0.582f, 0.9271f, 0f,
            5.5443f, 39.9932f, 23.6638f, 57.6938f, 5.6f, 5.989f, -0.2427f, 1.0238f, 1f
        ),
        stamens = floatArrayOf(
            0.2552f, 1.6419f, 67.3863f, 99.8848f,
            0.7801f, 24.2841f, 68.0708f, 86.6933f,
            1.366f, 33.6753f, 92.5205f, 79.6228f,
            1.9301f, 14.2407f, 89.2274f, 77.4035f,
            2.5588f, 22.933f, 89.4631f, 79.9136f,
            2.9569f, 22.0732f, 84.4665f, 84.8742f,
            3.5821f, 12.9707f, 73.2224f, 78.3266f,
            4.132f, 4.2659f, 70.5712f, 75.1232f,
            4.6834f, 21.1338f, 82.646f, 74.1046f,
            5.1549f, 13.0362f, 65.5212f, 72.8999f,
            5.9989f, 4.6176f, 73.4571f, 81.8365f
        )
    ),
    Lirio(
        x = 565f, y = 1288f, p = 44f, e = 48f, roll = -8f, lt = 0.62f, bx = 560f,
        order = intArrayOf(17, 18, 16, 6, 7, 4, 5, 15, 19, 8, 14, 0, 9, 2, 13, 3, 1, 12, 10, 11),
        petals = floatArrayOf(
            0.5334f, 36.0776f, 52.6021f, 67.0251f, 5.72f, 1.7026f, -0.5373f, 1.0268f, 0f,
            1.4626f, 24.0896f, 54.2117f, 60.327f, 5.72f, 4.8828f, -0.8395f, 0.9247f, 0f,
            2.2626f, 39.741f, 33.0201f, 46.6777f, 4.4f, 3.9668f, -0.7707f, 0.9903f, 1f,
            2.8612f, 19.9484f, 52.5849f, 56.9557f, 5.72f, 2.1168f, -0.9169f, 0.9209f, 0f,
            3.6909f, 27.1103f, 69.5216f, 60.8441f, 5.72f, 3.8153f, 0.8197f, 1.0174f, 0f,
            4.0261f, 46.6725f, 51.6865f, 41.1945f, 4.4f, 0.5945f, 0.8245f, 0.9828f, 1f,
            4.7587f, 28.578f, 30.9094f, 65.2743f, 5.72f, 3.143f, -0.8747f, 1.0436f, 0f,
            5.4131f, 23.4201f, 21.3999f, 64.561f, 5.72f, 0.7151f, 0.0567f, 0.8986f, 0f,
            6.275f, 49.5612f, 46.7425f, 43.6055f, 4.4f, 3.045f, -0.1385f, 0.9991f, 1f
        ),
        stamens = floatArrayOf(
            0.1511f, 18.0317f, 70.978f, 80.048f,
            1.1348f, 2.5251f, 67.4453f, 75.7716f,
            1.5264f, 0.726f, 88.786f, 82.1198f,
            2.0251f, 13.2046f, 83.6373f, 81.9932f,
            2.5183f, 11.4868f, 69.171f, 73.7902f,
            3.19f, 9.7308f, 76.74f, 58.1182f,
            3.6846f, 37.3504f, 84.2697f, 64.6602f,
            4.5606f, 13.6145f, 71.5583f, 58.1277f,
            4.7458f, 7.5635f, 70.7413f, 80.2467f,
            5.3748f, 9.4468f, 84.9492f, 81.4125f,
            5.9591f, 28.9403f, 76.012f, 72.0134f
        )
    ),
    Lirio(
        x = 398f, y = 1292f, p = 48f, e = 50f, roll = 4f, lt = 0.66f, bx = 398f,
        order = intArrayOf(17, 18, 16, 5, 4, 6, 8, 15, 7, 19, 0, 9, 14, 13, 2, 10, 3, 1, 11, 12),
        petals = floatArrayOf(
            0.4567f, 15.3496f, 56.7996f, 62.6037f, 6.24f, 6.1942f, -1.0629f, 1.0559f, 0f,
            1.0359f, 40.7203f, 69.9908f, 63.7018f, 6.24f, 2.1231f, 0.458f, 0.9361f, 0f,
            1.5589f, 35.8583f, 62.8919f, 51.5955f, 4.8f, 5.009f, -0.6085f, 1.065f, 1f,
            2.361f, 21.9416f, 42.7768f, 66.1231f, 6.24f, 0.4959f, 0.1423f, 0.952f, 0f,
            3.0835f, 42.9065f, 52.2786f, 65.9245f, 6.24f, 5.4232f, 1.0894f, 0.9781f, 0f,
            3.9389f, 29.5625f, 27.0159f, 44.8531f, 4.8f, 5.891f, 0.4191f, 1.0238f, 1f,
            4.3612f, 29.8496f, 64.3532f, 61.8223f, 6.24f, 0.7299f, -0.9957f, 0.9737f, 0f,
            5.2913f, 31.6497f, 40.073f, 67.2276f, 6.24f, 1.1254f, 0.9859f, 0.9508f, 0f,
            5.736f, 38.337f, 61.2466f, 46.2554f, 4.8f, 5.6822f, -0.3604f, 0.9683f, 1f
        ),
        stamens = floatArrayOf(
            -0.0772f, 34.4839f, 92.2538f, 76.0641f,
            0.5141f, 18.7144f, 76.2936f, 86.5921f,
            1.4824f, 28.162f, 72.9141f, 63.5917f,
            2.037f, 35.891f, 68.0182f, 76.7979f,
            2.4064f, 37.1043f, 63.6359f, 64.1771f,
            3.1549f, 21.6441f, 79.567f, 84.7992f,
            3.6037f, 26.3122f, 71.7138f, 64.846f,
            3.8893f, 12.658f, 86.643f, 73.3379f,
            4.6259f, 23.5051f, 88.7976f, 79.5491f,
            5.1797f, 31.2262f, 92.4268f, 88.1327f,
            6.0347f, 0.5714f, 87.4283f, 72.4249f
        )
    ),
    Lirio(
        x = 335f, y = 1218f, p = 62f, e = 48f, roll = -5f, lt = 0.86f, bx = 333f,
        order = intArrayOf(18, 17, 16, 7, 19, 6, 8, 15, 5, 9, 0, 14, 2, 10, 13, 4, 3, 1, 12, 11),
        petals = floatArrayOf(
            -0.058f, 29.4144f, 40.8476f, 85.8757f, 8.06f, 2.5718f, 0.347f, 0.9318f, 0f,
            0.7547f, 15.3039f, 35.1022f, 83.9367f, 8.06f, 0.8914f, 0.5355f, 0.942f, 0f,
            1.5174f, 57.6862f, 32.6753f, 66.8799f, 6.2f, 5.072f, 0.3683f, 0.8855f, 1f,
            2.0763f, 33.8025f, 34.8113f, 82.0145f, 8.06f, 1.9455f, -0.5319f, 1.0376f, 0f,
            2.7288f, 27.6937f, 52.1511f, 94.5839f, 8.06f, 1.8402f, -1.0032f, 1.0748f, 0f,
            3.63f, 52.7099f, 46.1686f, 58.7115f, 6.2f, 0.9703f, -0.4307f, 0.9722f, 1f,
            4.0069f, 35.9786f, 56.3941f, 78.3469f, 8.06f, 5.2905f, -0.0186f, 1.0638f, 0f,
            4.8765f, 38.8721f, 42.7133f, 88.7622f, 8.06f, 3.1352f, -1.0499f, 0.9088f, 0f,
            5.4729f, 41.1865f, 38.4624f, 62.4863f, 6.2f, 4.1408f, -0.22f, 0.9439f, 1f
        ),
        stamens = floatArrayOf(
            0.0054f, 36.2051f, 91.7473f, 104.981f,
            0.7261f, 8.6568f, 65.8344f, 84.0644f,
            0.9574f, 0.3473f, 85.7721f, 114.7776f,
            1.5248f, 26.0984f, 97.7419f, 109.0722f,
            2.1153f, 24.2574f, 71.7081f, 87.2271f,
            2.6171f, 19.9653f, 96.9214f, 84.47f,
            3.2548f, 14.7566f, 63.4662f, 97.8778f,
            4.1109f, 17.5086f, 63.4834f, 81.7282f,
            4.4221f, 25.3522f, 97.1475f, 99.3058f,
            4.9469f, 8.2051f, 77.8059f, 84.6266f,
            5.5243f, 16.4917f, 93.9398f, 89.4364f
        )
    ),
    Lirio(
        x = 185f, y = 1242f, p = 60f, e = 50f, roll = 5f, lt = 0.84f, bx = 215f,
        order = intArrayOf(17, 4, 16, 7, 6, 18, 19, 15, 8, 5, 14, 2, 9, 0, 3, 13, 12, 10, 11, 1),
        petals = floatArrayOf(
            0.5328f, 39.2007f, 68.0247f, 80.4657f, 7.8f, 4.8112f, 0.4493f, 1.0123f, 0f,
            1.0584f, 15.8081f, 39.2086f, 88.1394f, 7.8f, 1.585f, 0.0035f, 0.9435f, 0f,
            2.0649f, 57.3558f, 40.0795f, 65.9814f, 6f, 0.3906f, 0.6877f, 1.0551f, 1f,
            2.4718f, 36.1671f, 47.9446f, 91.6472f, 7.8f, 1.3189f, 0.0879f, 1.0565f, 0f,
            3.3743f, 24.276f, 24.0932f, 91.3882f, 7.8f, 2.9773f, 1.0919f, 0.9083f, 0f,
            4.145f, 53.4013f, 65.9988f, 54.214f, 6f, 2.3374f, -0.9863f, 1.0304f, 1f,
            4.6515f, 43.7852f, 38.7415f, 88.6095f, 7.8f, 5.4497f, -0.5743f, 0.9914f, 0f,
            5.6021f, 30.8075f, 37.9854f, 80.089f, 7.8f, 4.939f, -0.676f, 1.0008f, 0f,
            6.1319f, 45.6044f, 26.4743f, 61.9028f, 6f, 5.7558f, -0.3985f, 0.9464f, 1f
        ),
        stamens = floatArrayOf(
            0.4617f, 21.9771f, 72.358f, 78.3515f,
            0.9568f, 13.2242f, 79.752f, 87.8101f,
            1.4692f, 27.7014f, 73.7719f, 80.7011f,
            2.2133f, 34.5816f, 62.7851f, 98.3107f,
            2.6375f, 15.3145f, 89.8023f, 112.5534f,
            3.1618f, 14.8798f, 69.4346f, 87.0511f,
            3.5183f, 4.1955f, 70.0708f, 108.3129f,
            4.2783f, 30.5876f, 96.9671f, 107.1882f,
            4.6112f, 35.1864f, 65.5261f, 105.7548f,
            5.5682f, 24.9832f, 77.3399f, 80.7006f,
            5.7711f, 24.1871f, 71.1848f, 97.1622f
        )
    ),
    Lirio(
        x = 55f, y = 1190f, p = 70f, e = 48f, roll = -6f, lt = 0.9f, bx = 25f,
        order = intArrayOf(17, 6, 16, 18, 5, 19, 7, 4, 8, 15, 0, 14, 9, 2, 10, 3, 13, 11, 1, 12),
        petals = floatArrayOf(
            0.2156f, 34.8429f, 36.728f, 92.0796f, 9.1f, 3.0742f, -0.0131f, 0.976f, 0f,
            1.0297f, 22.9359f, 32.69f, 101.7608f, 9.1f, 2.0375f, 0.3846f, 1.0374f, 0f,
            1.8986f, 57.3209f, 31.7279f, 66.3236f, 7f, 4.6147f, 0.1662f, 0.9204f, 1f,
            2.5179f, 41.1975f, 61.7893f, 92.4355f, 9.1f, 1.8774f, -1.0853f, 1.0751f, 0f,
            3.0245f, 36.8131f, 46.8949f, 99.8319f, 9.1f, 3.3079f, 0.7162f, 1f, 0f,
            3.7573f, 32.4449f, 43.8702f, 75.9213f, 7f, 0.9119f, 0.4047f, 1.0062f, 1f,
            4.3955f, 21.2051f, 54.3123f, 96.765f, 9.1f, 2.556f, -0.0433f, 0.9002f, 0f,
            5.3217f, 32.6514f, 46.7106f, 94.8568f, 9.1f, 5.0968f, 0.7127f, 0.989f, 0f,
            5.7618f, 33.4374f, 27.6094f, 64.1038f, 7f, 4.0714f, 0.0957f, 0.9208f, 1f
        ),
        stamens = floatArrayOf(
            0.3751f, 23.9319f, 92.1022f, 125.3578f,
            0.8344f, 20.0175f, 99.4199f, 96.5817f,
            1.4094f, 33.6011f, 80.1788f, 125.3222f,
            1.7324f, 15.817f, 72.2936f, 107.672f,
            2.558f, 5.4541f, 74.8617f, 126.5348f,
            2.9335f, 4.7901f, 99.7856f, 113.729f,
            3.3662f, 21.7092f, 67.5492f, 97.8374f,
            4.2896f, 24.7831f, 78.2028f, 112.6056f,
            4.7728f, 17.4392f, 65.8459f, 123.2841f,
            5.4474f, 16.0359f, 77.3488f, 116.6389f,
            5.8728f, 15.7823f, 95.2935f, 129.0054f
        )
    ),
    Lirio(
        x = 670f, y = 1190f, p = 78f, e = 44f, roll = 6f, lt = 0.92f, bx = 688f,
        order = intArrayOf(6, 17, 16, 7, 18, 15, 4, 19, 8, 5, 14, 9, 1, 3, 10, 2, 11, 0, 13, 12),
        petals = floatArrayOf(
            0.2836f, 38.5473f, 46.0233f, 109.451f, 10.14f, 2.4714f, 1.093f, 0.9379f, 0f,
            0.7602f, 22.8324f, 33.0219f, 105.4297f, 10.14f, 1.6825f, -0.8632f, 0.9451f, 0f,
            1.5266f, 46.0772f, 30.0815f, 71.3043f, 7.8f, 1.272f, 0.0934f, 0.9577f, 1f,
            2.4016f, 39.0918f, 40.7219f, 100.45f, 10.14f, 4.5718f, 0.5625f, 0.9592f, 0f,
            3.0683f, 23.9715f, 65.7447f, 116.4903f, 10.14f, 4.9735f, 0.9986f, 0.9266f, 0f,
            3.7191f, 50.9413f, 60.0737f, 76.2884f, 7.8f, 0.8701f, 0.2779f, 0.9009f, 1f,
            4.4843f, 15.2086f, 42.725f, 108.7578f, 10.14f, 0.7523f, -0.0436f, 0.98f, 0f,
            5.0415f, 41.8882f, 63.3035f, 117.7293f, 10.14f, 1.5379f, -1.0431f, 0.9553f, 0f,
            5.6327f, 50.1569f, 33.1469f, 72.2028f, 7.8f, 1.7817f, -0.2125f, 1.0271f, 1f
        ),
        stamens = floatArrayOf(
            0.0857f, 11.4447f, 87.7401f, 103.5213f,
            0.5338f, 26.1239f, 90.5778f, 106.1413f,
            1.0353f, 19.2203f, 86.9451f, 102.1542f,
            1.7874f, 10.4424f, 65.234f, 109.4093f,
            2.2849f, 17.7475f, 66.2645f, 130.4321f,
            3.1458f, 25.9911f, 64.5831f, 131.7496f,
            3.5973f, 0.3332f, 76.6186f, 131.9393f,
            4.3231f, 35.3002f, 83.6422f, 128.9582f,
            4.8984f, 8.0038f, 81.3474f, 104.2802f,
            5.3797f, 24.8385f, 70.0022f, 110.6235f,
            5.8283f, 28.5647f, 67.1637f, 116.5353f
        )
    ),
    Lirio(
        x = 548f, y = 1035f, p = 108f, e = 44f, roll = -4f, lt = 1f, bx = 580f,
        order = intArrayOf(18, 17, 6, 16, 7, 19, 15, 5, 9, 8, 1, 0, 10, 14, 2, 3, 4, 11, 13, 12),
        petals = floatArrayOf(
            0.1699f, 35.5876f, 58.3255f, 163.4356f, 14.04f, 1.6317f, 0.2986f, 1.061f, 0f,
            0.854f, 32.1882f, 28.4689f, 148.5245f, 14.04f, 6.2413f, -0.8729f, 0.9438f, 0f,
            1.5848f, 42.482f, 30.4326f, 104.0451f, 10.8f, 5.7062f, -0.3617f, 0.9655f, 1f,
            2.1479f, 39.1676f, 44.6057f, 138.5435f, 14.04f, 3.5998f, -1.0228f, 0.8989f, 0f,
            2.6628f, 35.8031f, 34.1736f, 156.9532f, 14.04f, 1.0258f, -0.8411f, 0.8847f, 0f,
            3.5769f, 54.7734f, 30.9833f, 102.3315f, 10.8f, 0.0815f, 0.3187f, 0.9401f, 1f,
            4.0367f, 34.4062f, 49.9867f, 149.609f, 14.04f, 0.9609f, 0.3051f, 0.9911f, 0f,
            4.8588f, 19.9401f, 66.4417f, 162.1823f, 14.04f, 4.332f, 1.0912f, 0.9961f, 0f,
            5.52f, 32.4905f, 50.3843f, 108.4209f, 10.8f, 2.7408f, 1.0838f, 1.0479f, 1f
        ),
        stamens = floatArrayOf(
            -0.1882f, 33.6001f, 62.076f, 182.615f,
            0.481f, 27.7318f, 98.1964f, 174.7666f,
            1.2709f, 2.0657f, 87.3591f, 148.017f,
            1.6917f, 12.674f, 64.7779f, 188.8211f,
            2.086f, 9.7778f, 65.2649f, 183.3157f,
            2.7587f, 1.6842f, 63.0315f, 154.6324f,
            3.4304f, 0.4618f, 62.9038f, 183.5939f,
            4.0117f, 5.135f, 73.8595f, 148.5671f,
            4.4597f, 14.7455f, 70.2841f, 153.2003f,
            5.0071f, 11.4539f, 83.0908f, 197.8244f,
            5.7843f, 17.0437f, 62.1232f, 152.6188f
        )
    )
)

// ───────────────────────── Dibujo ─────────────────────────

private const val N = 14                    // tramos por pétalo / estambre (las curvas se suavizan al dibujar)
private const val NP = 9                    // pétalos por flor
private const val RUF = 0.55f               // cuánto se ondula el borde del pétalo
private val D2R = (PI / 180.0).toFloat()
private val TWO_PI = (2.0 * PI).toFloat()
private const val REF_W = 736f
private const val REF_H = 1308f

private fun gr(v: Float, a: Float = 1f): Color {
    val c = if (v < 0f) 0f else if (v > 1f) 1f else v
    return Color(c, c, c, a)
}

/** Brisa: tres ondas de frecuencia entera (ciclo exacto). Devuelve algo entre -1 y 1. */
private fun brisa(a: Float): Float = 0.6f * sin(a) + 0.25f * sin(2f * a + 1.3f) + 0.15f * sin(3f * a + 2.1f)

private class LirioPainter {
    // Memoria reutilizable: nada se crea en cada cuadro.
    private val g3 = FloatArray((N + 1) * 9)      // pétalo en 3D: centro, borde izquierdo, borde derecho
    private val s3 = FloatArray((N + 1) * 3)      // estambre en 3D
    private val cx = FloatArray(N + 1)
    private val cy = FloatArray(N + 1)
    private val lx = FloatArray(N + 1)
    private val ly = FloatArray(N + 1)
    private val rx = FloatArray(N + 1)
    private val ry = FloatArray(N + 1)
    private val px = FloatArray(2 * N + 2)
    private val py = FloatArray(2 * N + 2)
    private val path = Path()
    private val stem = Path()

    // Cámara de la flor actual.
    private var ce = 1f
    private var se = 0f
    private var cr = 1f
    private var sr = 0f
    private var hx = 0f
    private var hy = 0f
    private var k = 1f
    private var oy = 0f
    private var outX = 0f
    private var outY = 0f

    /** Pasa un punto 3D de la flor a la pantalla (vista desde arriba con elevación e, giro y posición de la cabeza). */
    private fun proj(x: Float, y: Float, z: Float) {
        val yd = -z * ce + y * se
        val xr = x * cr - yd * sr
        val yr = x * sr + yd * cr
        outX = (hx + xr) * k
        outY = oy + (hy + yr) * k
    }

    fun draw(ds: DrawScope, u: Float) {
        with(ds) {
            k = size.width / REF_W
            oy = size.height - REF_H * k            // anclado abajo
            val ph = TWO_PI * u
            for (fl in LIRIOS) drawLirio(fl, ph)
        }
    }

    private fun petalGeom(f: FloatArray, o: Int, a0: Float, aEnd: Float) {
        val phi0 = f[o]
        val ln = f[o + 3]
        val wmax = f[o + 4]
        val ph = f[o + 5]
        val tw = f[o + 6]
        var r = 0f
        var z = 0f
        val ds = ln / N
        for (i in 0..N) {
            val s = i.toFloat() / N
            val phi = phi0 + tw * s
            val cphi = cos(phi)
            val sphi = sin(phi)
            val al = (a0 + (aEnd - a0) * s.pow(1.3f)) * D2R
            val sa = sin(al)
            val ca = cos(al)
            if (i > 0) { r += ca * ds; z += sa * ds }
            val base = max(0f, sin(PI.toFloat() * s.pow(0.65f)))
            val w = wmax * (0.9f * base.pow(0.7f) + 0.1f * (1f - s))
            val nx = -sa * cphi
            val ny = -sa * sphi
            val nz = ca
            val rl = RUF * w * sin(s * 13f + ph) * (0.3f + s)
            val rr = RUF * w * sin(s * 13f + ph + 1.9f) * (0.3f + s)
            val ccx = r * cphi
            val ccy = r * sphi
            val tx = -sphi
            val ty = cphi
            val q = i * 9
            g3[q] = ccx; g3[q + 1] = ccy; g3[q + 2] = z
            g3[q + 3] = ccx + tx * w + nx * rl; g3[q + 4] = ccy + ty * w + ny * rl; g3[q + 5] = z + nz * rl
            g3[q + 6] = ccx - tx * w + nx * rr; g3[q + 7] = ccy - ty * w + ny * rr; g3[q + 8] = z + nz * rr
        }
    }

    private fun stamenGeom(f: FloatArray, o: Int, a1: Float) {
        val phi = f[o]
        val a0 = f[o + 1]
        val ln = f[o + 3]
        val cphi = cos(phi)
        val sphi = sin(phi)
        var r = 0f
        var z = 0f
        val ds = ln / N
        for (i in 0..N) {
            val s = i.toFloat() / N
            val al = (a0 + (a1 - a0) * s.pow(1.4f)) * D2R
            if (i > 0) { r += cos(al) * ds; z += sin(al) * ds }
            s3[i * 3] = r * cphi; s3[i * 3 + 1] = r * sphi; s3[i * 3 + 2] = z
        }
    }

    /** Curva suave por los puntos (curvas cuadráticas entre puntos medios). */
    private fun smooth(p: Path, xs: FloatArray, ys: FloatArray, m: Int, close: Boolean) {
        p.rewind()
        p.moveTo(xs[0], ys[0])
        for (i in 1 until m - 1) {
            p.quadraticBezierTo(xs[i], ys[i], (xs[i] + xs[i + 1]) * 0.5f, (ys[i] + ys[i + 1]) * 0.5f)
        }
        p.lineTo(xs[m - 1], ys[m - 1])
        if (close) p.close()
    }

    /** Cinta del pétalo: f = fracción del ancho, bias = desplazamiento hacia el lado izquierdo. */
    private fun ribbon(f: Float, bias: Float) {
        var m = 0
        for (i in 0..N) {
            px[m] = cx[i] + (lx[i] - cx[i]) * (f + bias)
            py[m] = cy[i] + (ly[i] - cy[i]) * (f + bias)
            m++
        }
        for (i in N - 1 downTo 0) {
            px[m] = cx[i] + (rx[i] - cx[i]) * f + (lx[i] - cx[i]) * bias
            py[m] = cy[i] + (ry[i] - cy[i]) * f + (ly[i] - cy[i]) * bias
            m++
        }
        smooth(path, px, py, m, true)
    }

    private fun DrawScope.drawLirio(fl: Lirio, ph: Float) {
        val lt = fl.lt
        val lag = fl.x / REF_W * 2.4f
        val wnd = brisa(ph - lag)                  // tronco y pétalos
        val wnd2 = brisa(ph - lag - 0.7f)          // los estambres, más livianos, llegan un poco después
        val sway = wnd * 3.2f * D2R

        // Tallo: nace abajo (fijo) y la cabeza gira alrededor de ese punto.
        val bx = fl.bx
        val by = REF_H + 30f
        val vx = fl.x - bx
        val vy = fl.y - by
        val c = cos(sway)
        val s = sin(sway)
        hx = bx + vx * c - vy * s
        hy = by + vx * s + vy * c
        stem.rewind()
        stem.moveTo(bx * k, oy + by * k)
        stem.quadraticBezierTo(((bx + hx) * 0.5f + wnd * 10f) * k, oy + ((by + hy) * 0.5f) * k, hx * k, oy + hy * k)
        drawPath(
            stem, gr(0.46f * lt * lt + 0.04f),
            style = Stroke(max(1f, 1.5f * k * (0.5f + fl.p / 110f * 0.5f)), cap = StrokeCap.Round)
        )

        val er = fl.e * D2R
        ce = cos(er)
        se = sin(er)
        val roll = fl.roll * D2R + sway
        cr = cos(roll)
        sr = sin(roll)
        val detail = lt >= 0.75f                   // las flores del fondo llevan menos capas (más fluido)
        val vein = max(1f, 0.9f * k)
        val fine = max(1f, 0.8f * k)

        for (idx in fl.order) {
            if (idx < NP) {
                val o = idx * 9
                val a0 = fl.petals[o + 1] + wnd * 3f
                val aEnd = fl.petals[o + 2] + wnd * 10f * sin(idx * 1.7f + 1f)
                petalGeom(fl.petals, o, a0, aEnd)
                for (i in 0..N) {
                    val q = i * 9
                    proj(g3[q], g3[q + 1], g3[q + 2]); cx[i] = outX; cy[i] = outY
                    proj(g3[q + 3], g3[q + 4], g3[q + 5]); lx[i] = outX; ly[i] = outY
                    proj(g3[q + 6], g3[q + 7], g3[q + 8]); rx[i] = outX; ry[i] = outY
                }
                val sh = fl.petals[o + 7]
                ribbon(1f, 0f)
                drawPath(path, gr(0.44f * lt * sh))
                if (detail) drawPath(
                    path, gr(0.86f * lt, 0.55f),
                    style = Stroke(fine, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                ribbon(0.70f, 0.06f)
                drawPath(path, gr(0.56f * lt * sh))
                if (detail) {
                    ribbon(0.25f, 0.28f)
                    drawPath(path, gr(0.80f * lt * sh, 0.5f))
                }
                // Nervadura central.
                smooth(path, cx, cy, N + 1, false)
                drawPath(path, gr(0.16f * lt, 0.8f), style = Stroke(vein, cap = StrokeCap.Round))
            } else {
                val j = idx - NP
                val o = j * 4
                stamenGeom(fl.stamens, o, fl.stamens[o + 2] + wnd2 * 14f * sin(j * 2.1f + 0.5f))
                for (i in 0..N) {
                    proj(s3[i * 3], s3[i * 3 + 1], s3[i * 3 + 2]); cx[i] = outX; cy[i] = outY
                }
                smooth(path, cx, cy, N + 1, false)
                drawPath(path, gr(0.78f * lt, 0.9f), style = Stroke(max(1f, 0.7f * k), cap = StrokeCap.Round))
                // Puntita brillante con un halo suave.
                val tip = Offset(cx[N], cy[N])
                val r0 = 0.95f * k
                drawCircle(Color(1f, 1f, 1f, 0.13f), r0 * 2.2f, tip)
                drawCircle(Color.White, r0, tip)
            }
        }
    }
}
