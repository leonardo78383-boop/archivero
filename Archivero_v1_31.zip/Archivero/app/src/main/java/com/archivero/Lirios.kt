package com.archivero

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Fondo de Inicio: lirios de araña (Lycoris radiata) en grises sobre negro, rehechos desde cero.
 *
 * Misma técnica que el amigo flotante: se DIBUJA con código en un Canvas (nada de imágenes ni GIF), así que cada
 * trazo se calcula a la resolución real de tu pantalla y queda nítido. Cada pétalo es una cinta curva con borde
 * ondulado y espiral, cada estambre una curva fina con una puntita de luz, y cada flor cuelga de un tallo que se dobla.
 *
 * Brisa: una suma de ondas de frecuencia entera sobre un ciclo de [LIRIO_CICLO_MS]. El último instante encaja con el
 * primero, así que el bucle es infinito y no se nota el corte. La brisa recorre las flores de izquierda a derecha;
 * cada una la siente un poco después, y los estambres (más livianos) un poco más tarde que los pétalos.
 *
 * Ligero a propósito (la 1.28 se sentía pesada): el lienzo es solo la franja de abajo donde están las flores, todos los
 * pétalos de una flor se pintan juntos en pocas llamadas (un relleno con degradado, un realce, los bordes, las
 * nervaduras), los estambres y sus puntitas van en un solo trazo, nada se crea en cada cuadro y el tiempo solo se lee
 * al dibujar (no recompone nada). Existe únicamente mientras Inicio está en pantalla.
 *
 * Composición: sobre la imagen de referencia de 736 x 1308, anclada abajo y escalada al ancho. Los números de
 * [LIRIOS] salen de un prototipo comparado con la referencia (posición, tamaño, giro, luz, forma de cada pétalo).
 */
const val LIRIO_CICLO_MS = 12000

private const val REF_W = 736f
private const val REF_H = 1308f
private const val REF_TOP = 830f              // el lienzo empieza en esta fila de la referencia (arriba de eso no hay flores)

@Composable
fun LirioFondo(modifier: Modifier = Modifier) {
    val painter = remember { LirioPainter() }
    val t = rememberInfiniteTransition(label = "lirios")
    val u by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(LIRIO_CICLO_MS, easing = LinearEasing), RepeatMode.Restart),
        label = "brisa"
    )
    Canvas(modifier.fillMaxWidth().aspectRatio(REF_W / (REF_H - REF_TOP))) { painter.draw(this, u) }
}

// ───────────────────────── Datos ─────────────────────────

/**
 * Una flor. x, y = centro de la cabeza y p = tamaño base (px de la referencia); e = elevación de la cámara (grados);
 * roll = inclinación (grados); lt = luz (1 = delante, menos = más al fondo); bx = dónde nace el tallo abajo.
 * petals: 8 valores por pétalo (giro, ángulo inicial, ángulo final, largo, ancho, fase del borde, espiral, interno).
 * stamens: 5 valores por estambre (giro, ángulo inicial, ángulo final, largo, 1 = va por delante de los pétalos).
 */
private class Lirio(
    val x: Float, val y: Float, val p: Float, val e: Float, val roll: Float, val lt: Float, val bx: Float,
    val petals: FloatArray, val stamens: FloatArray
)

private val LIRIOS = arrayOf(
    Lirio(
        x = 705.0f, y = 1130.0f, p = 44.0f, e = 50.0f, roll = 10.0f, lt = 0.5f, bx = 700.0f,
        petals = floatArrayOf(
            -0.0136f, 10.6976f, 66.6061f, 63.8652f, 5.72f, 0.871f, -1.3177f, 0.0f,
            0.579f, 26.1822f, 53.1071f, 64.5649f, 5.72f, 4.1584f, -1.2356f, 0.0f,
            1.198f, 30.746f, 67.6914f, 48.3678f, 4.4f, 0.5847f, -1.6308f, 1.0f,
            1.8486f, 17.6707f, 55.9174f, 59.5094f, 5.72f, 2.2915f, 1.5474f, 0.0f,
            2.143f, 13.2062f, 77.1696f, 62.1837f, 5.72f, 5.9895f, 1.1515f, 0.0f,
            2.7122f, 24.8926f, 91.0027f, 48.303f, 4.4f, 0.1907f, 0.7992f, 1.0f,
            3.3969f, 23.6276f, 57.0097f, 65.254f, 5.72f, 4.5833f, -1.041f, 0.0f,
            3.8491f, 13.2604f, 47.2777f, 59.5796f, 5.72f, 2.0997f, -0.353f, 0.0f,
            4.3745f, 40.0682f, 97.8728f, 48.1926f, 4.4f, 6.2392f, 0.9855f, 1.0f,
            4.7912f, 12.2312f, 79.3063f, 62.1645f, 5.72f, 4.236f, -1.382f, 0.0f,
            5.2791f, 30.1044f, 78.0764f, 64.0069f, 5.72f, 0.6007f, -0.3428f, 0.0f,
            6.028f, 35.5839f, 99.541f, 41.3327f, 4.4f, 2.8561f, 1.0219f, 1.0f
        ),
        stamens = floatArrayOf(
            0.0466f, 29.9787f, 83.3438f, 60.3162f, 1.0f,
            0.3851f, 37.3538f, 66.5341f, 62.3244f, 1.0f,
            0.9674f, 27.1115f, 94.4554f, 69.7581f, 1.0f,
            1.519f, 29.9606f, 72.5641f, 67.0314f, 1.0f,
            2.0503f, 24.1765f, 63.4469f, 60.1573f, 1.0f,
            2.3348f, 27.5549f, 88.331f, 82.8913f, 1.0f,
            3.0818f, 9.6807f, 91.089f, 83.2049f, 1.0f,
            3.3897f, 0.4251f, 76.2572f, 64.6585f, 0.0f,
            3.8007f, 1.7135f, 66.7444f, 80.041f, 0.0f,
            4.2312f, 23.3301f, 69.8473f, 62.3035f, 0.0f,
            5.0374f, 11.3516f, 68.9853f, 69.2081f, 0.0f,
            5.468f, 19.9266f, 94.6694f, 67.7969f, 0.0f,
            5.8797f, 27.2497f, 79.5386f, 76.129f, 0.0f
        )
    ),
    Lirio(
        x = 625.0f, y = 1160.0f, p = 62.0f, e = 52.0f, roll = 8.0f, lt = 0.6f, bx = 622.0f,
        petals = floatArrayOf(
            0.1596f, 21.4345f, 95.8316f, 86.2037f, 8.06f, 3.1892f, 0.2971f, 0.0f,
            0.5991f, 20.2858f, 79.6435f, 91.8861f, 8.06f, 0.5911f, -0.6684f, 0.0f,
            1.0931f, 39.4315f, 83.1391f, 56.3193f, 6.2f, 6.1682f, 1.5802f, 1.0f,
            1.7937f, 22.7735f, 53.6622f, 78.3804f, 8.06f, 3.3182f, -1.4975f, 0.0f,
            2.1716f, 13.8066f, 46.6545f, 86.1739f, 8.06f, 2.7665f, 1.1643f, 0.0f,
            2.7985f, 35.367f, 72.4875f, 64.0144f, 6.2f, 2.872f, -0.7542f, 1.0f,
            3.4725f, 31.8966f, 91.2119f, 90.4076f, 8.06f, 1.9799f, -0.9191f, 0.0f,
            3.7734f, 9.6854f, 87.1458f, 85.0709f, 8.06f, 5.3165f, -0.3859f, 0.0f,
            4.5072f, 40.3354f, 45.03f, 58.4005f, 6.2f, 5.7165f, -0.102f, 1.0f,
            5.0378f, 17.5382f, 49.0171f, 89.0473f, 8.06f, 4.889f, -0.7828f, 0.0f,
            5.2808f, 15.9821f, 98.0242f, 91.2796f, 8.06f, 0.741f, -0.8623f, 0.0f,
            5.8088f, 21.4374f, 88.8362f, 58.0032f, 6.2f, 3.5124f, -0.1788f, 1.0f
        ),
        stamens = floatArrayOf(
            -0.0423f, 27.812f, 66.9767f, 104.5462f, 0.0f,
            0.41f, 15.9887f, 70.0889f, 90.6364f, 1.0f,
            1.2512f, 30.5296f, 73.5575f, 113.517f, 1.0f,
            1.4161f, 14.9824f, 94.4663f, 104.4763f, 1.0f,
            1.8531f, 37.5935f, 70.1032f, 90.2079f, 1.0f,
            2.6181f, 12.5003f, 73.2603f, 83.3304f, 1.0f,
            2.8155f, 22.1439f, 71.2345f, 102.9678f, 1.0f,
            3.4168f, 17.2219f, 98.4471f, 98.5946f, 0.0f,
            3.9851f, 32.928f, 68.9475f, 86.3338f, 0.0f,
            4.6082f, 31.0765f, 71.4809f, 87.6606f, 0.0f,
            5.0208f, 35.7354f, 69.4704f, 115.9451f, 0.0f,
            5.5639f, 22.9343f, 78.0154f, 84.4628f, 0.0f,
            5.6939f, 36.5819f, 71.0595f, 106.8104f, 0.0f
        )
    ),
    Lirio(
        x = 235.0f, y = 1238.0f, p = 52.0f, e = 54.0f, roll = -10.0f, lt = 0.64f, bx = 240.0f,
        petals = floatArrayOf(
            0.4283f, 23.7793f, 81.6526f, 67.5963f, 6.76f, 0.0682f, -0.4258f, 0.0f,
            0.8889f, 27.4484f, 82.9826f, 74.2772f, 6.76f, 3.5054f, 0.5485f, 0.0f,
            1.3721f, 30.5613f, 53.9247f, 56.2221f, 5.2f, 0.3694f, 1.084f, 1.0f,
            1.8735f, 24.4867f, 63.535f, 71.4112f, 6.76f, 5.2903f, -1.6367f, 0.0f,
            2.3927f, 29.9608f, 72.9909f, 66.8446f, 6.76f, 6.1992f, 1.5188f, 0.0f,
            2.9326f, 30.157f, 52.4288f, 50.0504f, 5.2f, 3.9027f, -1.144f, 1.0f,
            3.6398f, 9.2325f, 54.4168f, 77.3966f, 6.76f, 2.5153f, -0.2759f, 0.0f,
            4.1317f, 19.4424f, 66.152f, 65.964f, 6.76f, 4.5613f, 1.5894f, 0.0f,
            4.7748f, 35.9263f, 64.599f, 50.5765f, 5.2f, 4.3339f, 0.5908f, 1.0f,
            5.0274f, 13.6393f, 64.9827f, 72.9653f, 6.76f, 5.0875f, 0.0f, 0.0f,
            5.5241f, 27.7416f, 68.6585f, 73.0766f, 6.76f, 1.3952f, -0.2474f, 0.0f,
            6.1608f, 38.526f, 50.6437f, 52.5197f, 5.2f, 1.1182f, 0.666f, 1.0f
        ),
        stamens = floatArrayOf(
            0.0242f, 10.5088f, 75.0788f, 87.4722f, 1.0f,
            0.5139f, 17.452f, 69.9342f, 76.3951f, 1.0f,
            1.1749f, 36.4324f, 80.2789f, 97.4238f, 1.0f,
            1.5289f, 35.1215f, 75.8393f, 73.504f, 1.0f,
            2.2556f, 34.6576f, 62.2536f, 75.9695f, 1.0f,
            2.7482f, 12.988f, 71.1803f, 67.8693f, 1.0f,
            2.9254f, 23.5249f, 99.385f, 98.753f, 1.0f,
            3.6029f, 0.9086f, 74.2533f, 92.1669f, 0.0f,
            4.2238f, 24.2976f, 70.7215f, 84.0498f, 0.0f,
            4.5586f, 23.8262f, 71.9818f, 97.1363f, 0.0f,
            5.2166f, 6.1616f, 73.0702f, 94.8429f, 0.0f,
            5.4418f, 35.8683f, 81.5765f, 89.3143f, 0.0f,
            6.1038f, 8.1346f, 72.8308f, 75.5542f, 0.0f
        )
    ),
    Lirio(
        x = 500.0f, y = 1262.0f, p = 56.0f, e = 49.0f, roll = 6.0f, lt = 0.68f, bx = 505.0f,
        petals = floatArrayOf(
            0.0116f, 24.4462f, 82.6245f, 83.8776f, 7.28f, 1.1663f, -0.9161f, 0.0f,
            0.5f, 13.4039f, 85.3713f, 72.6017f, 7.28f, 3.3367f, -0.9727f, 0.0f,
            1.07f, 30.3579f, 91.0711f, 57.2141f, 5.6f, 0.0906f, -0.7622f, 1.0f,
            1.5471f, 28.9108f, 89.5357f, 83.1988f, 7.28f, 5.1896f, 0.8322f, 0.0f,
            2.3228f, 27.0505f, 59.1189f, 83.887f, 7.28f, 3.057f, 0.867f, 0.0f,
            2.7254f, 30.3099f, 65.0311f, 55.214f, 5.6f, 1.9704f, -1.301f, 1.0f,
            3.3293f, 27.1582f, 99.2125f, 81.3937f, 7.28f, 3.4805f, 0.8446f, 0.0f,
            3.6377f, 24.2437f, 69.387f, 73.3296f, 7.28f, 1.2725f, 0.0772f, 0.0f,
            4.1986f, 31.027f, 78.3024f, 54.8325f, 5.6f, 0.8213f, -0.0311f, 1.0f,
            4.7165f, 13.6563f, 55.6958f, 76.3058f, 7.28f, 0.4602f, 0.5142f, 0.0f,
            5.4658f, 17.3525f, 84.5385f, 85.1891f, 7.28f, 0.2713f, -1.2181f, 0.0f,
            5.943f, 40.1155f, 80.1481f, 52.1893f, 5.6f, 2.5967f, 1.252f, 1.0f
        ),
        stamens = floatArrayOf(
            0.2054f, 30.5205f, 69.7162f, 101.4828f, 1.0f,
            0.4745f, 27.2274f, 67.2063f, 105.4358f, 1.0f,
            1.0536f, 27.4631f, 70.0452f, 93.5393f, 1.0f,
            1.5275f, 22.4665f, 75.6553f, 97.2505f, 1.0f,
            1.9105f, 11.2224f, 68.2504f, 95.7835f, 1.0f,
            2.2978f, 8.5712f, 64.6275f, 94.4225f, 1.0f,
            2.9671f, 20.646f, 63.4754f, 87.5702f, 1.0f,
            3.3611f, 3.5212f, 62.113f, 106.3299f, 0.0f,
            3.7517f, 11.4571f, 72.2199f, 92.8679f, 0.0f,
            4.2165f, 17.8558f, 75.9345f, 100.8393f, 0.0f,
            4.6698f, 12.7206f, 80.8692f, 105.3849f, 0.0f,
            5.3672f, 18.0204f, 87.4411f, 82.7643f, 0.0f,
            5.6474f, 19.0523f, 96.5953f, 97.6093f, 0.0f
        )
    ),
    Lirio(
        x = 565.0f, y = 1288.0f, p = 44.0f, e = 48.0f, roll = -8.0f, lt = 0.6f, bx = 560.0f,
        petals = floatArrayOf(
            0.5746f, 24.8621f, 80.8623f, 67.0251f, 5.72f, 1.7026f, -0.8304f, 0.0f,
            1.2953f, 23.8028f, 61.6643f, 63.8698f, 5.72f, 2.4911f, 0.9436f, 0.0f,
            1.6254f, 25.3584f, 94.5805f, 42.7507f, 4.4f, 1.6353f, 1.0346f, 1.0f,
            2.3103f, 11.5929f, 75.3233f, 63.6205f, 5.72f, 1.0359f, 0.5158f, 0.0f,
            2.6741f, 16.0896f, 49.5764f, 57.9585f, 5.72f, 6.1418f, -0.3275f, 0.0f,
            3.4702f, 30.5276f, 78.4142f, 47.2788f, 4.4f, 4.3136f, -1.3208f, 1.0f,
            3.8677f, 23.2095f, 54.9659f, 56.6064f, 5.72f, 5.4937f, 0.0469f, 0.0f,
            4.2671f, 18.8624f, 57.0003f, 65.2743f, 5.72f, 3.143f, -1.3517f, 0.0f,
            4.9869f, 22.1488f, 60.4368f, 39.8464f, 4.4f, 4.6493f, -1.3128f, 1.0f,
            5.4186f, 10.2316f, 71.4241f, 63.8838f, 5.72f, 3.3589f, -0.1524f, 0.0f,
            5.9294f, 18.489f, 77.7496f, 56.6086f, 5.72f, 2.98f, -0.8967f, 0.0f,
            6.5725f, 42.5365f, 48.6547f, 40.861f, 4.4f, 4.4178f, 0.2429f, 1.0f
        ),
        stamens = floatArrayOf(
            0.1476f, 26.786f, 97.8694f, 68.3701f, 1.0f,
            0.7685f, 21.6373f, 97.6872f, 64.1574f, 1.0f,
            1.2329f, 7.171f, 85.8799f, 69.5884f, 1.0f,
            1.6969f, 14.74f, 63.3216f, 65.4486f, 1.0f,
            2.4846f, 22.2697f, 72.7382f, 81.9138f, 1.0f,
            2.7063f, 9.5583f, 63.3353f, 61.0597f, 1.0f,
            3.1229f, 8.7413f, 95.1733f, 64.184f, 1.0f,
            3.627f, 22.9492f, 96.8513f, 64.8923f, 0.0f,
            4.3252f, 14.012f, 83.3223f, 72.9301f, 0.0f,
            4.8842f, 28.7758f, 81.3097f, 79.4129f, 0.0f,
            5.1264f, 14.5962f, 98.4791f, 71.6129f, 0.0f,
            5.7801f, 11.949f, 96.7811f, 73.3762f, 0.0f,
            6.0431f, 35.4782f, 79.8191f, 66.161f, 0.0f
        )
    ),
    Lirio(
        x = 398.0f, y = 1292.0f, p = 48.0f, e = 50.0f, roll = 4.0f, lt = 0.64f, bx = 398.0f,
        petals = floatArrayOf(
            0.408f, 8.2797f, 85.4795f, 62.6037f, 6.24f, 6.1942f, -1.6426f, 0.0f,
            0.9046f, 24.3524f, 92.1538f, 73.9175f, 6.24f, 1.5054f, -0.5505f, 0.0f,
            1.3744f, 26.734f, 59.4823f, 45.3947f, 4.8f, 5.3872f, 1.2734f, 1.0f,
            1.9261f, 13.3614f, 95.8661f, 67.3528f, 6.24f, 1.4531f, -0.1512f, 0.0f,
            2.331f, 9.895f, 76.058f, 65.3179f, 6.24f, 3.5772f, 1.4627f, 0.0f,
            2.9255f, 29.7224f, 92.4966f, 52.7537f, 4.8f, 3.0788f, 1.5131f, 1.0f,
            3.2522f, 11.3676f, 54.4707f, 73.0876f, 6.24f, 4.3362f, 0.7449f, 0.0f,
            3.86f, 19.8796f, 93.7886f, 61.8223f, 6.24f, 0.7299f, -1.5388f, 0.0f,
            4.4407f, 40.1716f, 75.5245f, 47.054f, 4.8f, 3.1529f, -1.0907f, 1.0f,
            5.115f, 16.4912f, 57.9393f, 64.663f, 6.24f, 5.1806f, -0.6179f, 0.0f,
            5.625f, 16.0683f, 69.2852f, 61.4773f, 6.24f, 5.6989f, 1.0069f, 0.0f,
            6.0134f, 22.7696f, 72.0866f, 46.811f, 4.8f, 5.2752f, 1.4551f, 1.0f
        ),
        stamens = floatArrayOf(
            0.2319f, 10.9141f, 63.5724f, 88.1455f, 1.0f,
            0.8004f, 6.0182f, 80.9972f, 76.252f, 1.0f,
            1.2971f, 1.6359f, 64.3448f, 86.7f, 1.0f,
            1.61f, 17.567f, 91.5545f, 79.4882f, 1.0f,
            2.1448f, 9.7138f, 65.2274f, 62.657f, 1.0f,
            2.4776f, 24.643f, 76.432f, 72.403f, 1.0f,
            3.0805f, 26.7976f, 84.6273f, 71.3781f, 1.0f,
            3.6489f, 30.4268f, 95.9529f, 88.1063f, 0.0f,
            3.7943f, 25.4283f, 75.2272f, 73.5872f, 0.0f,
            4.4884f, 5.4677f, 71.4784f, 90.8043f, 0.0f,
            4.8933f, 34.6941f, 88.0076f, 71.4667f, 0.0f,
            5.3715f, 22.9847f, 88.679f, 72.193f, 0.0f,
            5.7461f, 6.5444f, 94.7056f, 83.3912f, 0.0f
        )
    ),
    Lirio(
        x = 335.0f, y = 1218.0f, p = 62.0f, e = 48.0f, roll = -5.0f, lt = 0.84f, bx = 333.0f,
        petals = floatArrayOf(
            -0.0435f, 19.5315f, 67.9324f, 85.8757f, 8.06f, 2.5718f, 0.5362f, 0.0f,
            0.4478f, 23.2399f, 45.5571f, 83.3635f, 8.06f, 2.1042f, -1.2174f, 0.0f,
            1.1237f, 27.4426f, 88.4083f, 67.6569f, 6.2f, 1.592f, 1.338f, 1.0f,
            1.6674f, 24.0181f, 46.5053f, 86.0498f, 8.06f, 3.936f, -0.6928f, 0.0f,
            2.0078f, 15.435f, 59.2029f, 91.7966f, 8.06f, 2.1841f, -0.2614f, 0.0f,
            2.6629f, 42.7612f, 61.1162f, 56.3457f, 6.2f, 6.116f, 1.1307f, 1.0f,
            3.2328f, 20.5609f, 57.914f, 80.8023f, 8.06f, 1.9106f, -0.133f, 0.0f,
            3.5288f, 24.7828f, 85.0335f, 78.3469f, 8.06f, 5.2905f, -0.0288f, 0.0f,
            4.3203f, 31.4019f, 88.7656f, 61.4329f, 6.2f, 3.8498f, -0.0026f, 1.0f,
            4.5625f, 11.4548f, 57.7744f, 85.1719f, 8.06f, 2.3189f, 0.1333f, 0.0f,
            5.2861f, 17.6003f, 62.5656f, 86.9931f, 8.06f, 5.9834f, 0.9616f, 0.0f,
            5.8084f, 39.6077f, 57.5296f, 57.0512f, 6.2f, 0.5848f, -1.2868f, 1.0f
        ),
        stamens = floatArrayOf(
            -0.2056f, 23.7721f, 96.9126f, 84.8259f, 0.0f,
            0.5616f, 35.7419f, 91.0845f, 86.2983f, 1.0f,
            1.0246f, 9.7081f, 68.7696f, 81.0144f, 1.0f,
            1.4606f, 34.9214f, 65.9533f, 86.0772f, 1.0f,
            1.8865f, 1.4662f, 79.6494f, 107.7654f, 1.0f,
            2.4002f, 1.4834f, 63.1525f, 87.9731f, 1.0f,
            2.97f, 35.1475f, 81.1081f, 84.4424f, 1.0f,
            3.2643f, 15.8059f, 66.1132f, 84.9107f, 0.0f,
            3.8389f, 31.9398f, 71.0265f, 113.4455f, 0.0f,
            4.5074f, 16.4481f, 70.5453f, 87.4672f, 0.0f,
            4.9034f, 31.3764f, 94.6994f, 88.3639f, 0.0f,
            5.2858f, 0.8345f, 73.577f, 91.5724f, 0.0f,
            5.6423f, 2.8957f, 99.7433f, 91.9448f, 0.0f
        )
    ),
    Lirio(
        x = 185.0f, y = 1242.0f, p = 60.0f, e = 50.0f, roll = 5.0f, lt = 0.82f, bx = 215.0f,
        petals = floatArrayOf(
            0.5305f, 27.3606f, 97.8272f, 80.4657f, 7.8f, 4.8112f, 0.6943f, 0.0f,
            1.0979f, 10.6439f, 46.4815f, 82.0541f, 7.8f, 4.6874f, -0.8419f, 0.0f,
            1.5713f, 27.6184f, 91.548f, 65.3423f, 6.0f, 2.522f, 1.6947f, 1.0f,
            1.9569f, 27.5026f, 93.1424f, 78.1354f, 7.8f, 4.431f, 0.2002f, 0.0f,
            2.761f, 13.0402f, 74.698f, 90.4253f, 7.8f, 4.0115f, -0.6487f, 0.0f,
            3.0102f, 42.5546f, 71.0754f, 65.9559f, 6.0f, 0.8893f, 1.0615f, 1.0f,
            3.7636f, 30.0794f, 45.9809f, 81.8528f, 7.8f, 0.3245f, 0.8569f, 0.0f,
            4.1431f, 31.0281f, 65.6156f, 88.6095f, 7.8f, 5.4497f, -0.8876f, 0.0f,
            4.7302f, 42.9774f, 73.9805f, 58.3165f, 6.0f, 1.678f, 0.974f, 1.0f,
            5.1395f, 22.4935f, 75.5551f, 84.8985f, 7.8f, 0.8132f, 0.5391f, 0.0f,
            5.8904f, 15.6531f, 63.264f, 90.8719f, 7.8f, 3.632f, -0.7732f, 0.0f,
            6.1292f, 38.0785f, 64.1402f, 59.6059f, 6.0f, 1.7113f, 0.4525f, 1.0f
        ),
        stamens = floatArrayOf(
            0.3577f, 11.7719f, 64.8511f, 113.5245f, 1.0f,
            0.9169f, 0.7851f, 83.439f, 102.6959f, 1.0f,
            1.1878f, 27.8023f, 98.473f, 99.2453f, 1.0f,
            1.6663f, 7.4346f, 71.5539f, 83.4289f, 1.0f,
            2.0319f, 8.0708f, 93.9969f, 97.3312f, 1.0f,
            2.8061f, 34.9671f, 92.8098f, 79.7799f, 1.0f,
            3.3402f, 3.5261f, 91.2967f, 108.202f, 0.0f,
            3.711f, 15.3399f, 64.8506f, 81.0655f, 0.0f,
            4.1856f, 9.1848f, 82.2267f, 87.5482f, 0.0f,
            4.4707f, 11.2191f, 89.5449f, 95.5253f, 0.0f,
            5.0501f, 18.4863f, 83.0514f, 96.564f, 0.0f,
            5.5553f, 36.7607f, 90.5658f, 86.2462f, 0.0f,
            5.9855f, 7.1744f, 75.8355f, 79.0216f, 0.0f
        )
    ),
    Lirio(
        x = 55.0f, y = 1190.0f, p = 70.0f, e = 48.0f, roll = -6.0f, lt = 0.9f, bx = 25.0f,
        petals = floatArrayOf(
            0.2489f, 23.8743f, 63.4008f, 92.0796f, 9.1f, 3.0742f, -0.0203f, 0.0f,
            0.8663f, 18.9999f, 59.5492f, 93.1745f, 9.1f, 4.345f, -0.5969f, 0.0f,
            1.4512f, 38.8922f, 92.627f, 76.2164f, 7.0f, 1.473f, -0.8929f, 1.0f,
            1.9936f, 21.813f, 56.1028f, 101.4811f, 9.1f, 5.484f, 1.1417f, 0.0f,
            2.3543f, 15.1748f, 45.3665f, 107.3233f, 9.1f, 1.3844f, 0.7722f, 0.0f,
            2.979f, 34.2431f, 73.9705f, 74.5574f, 7.0f, 3.7676f, -0.6692f, 1.0f,
            3.3697f, 19.4577f, 95.7624f, 91.046f, 9.1f, 4.2951f, 0.4458f, 0.0f,
            3.9075f, 12.9641f, 82.7435f, 96.765f, 9.1f, 2.556f, -0.0668f, 0.0f,
            4.4126f, 36.9104f, 77.3609f, 70.479f, 7.0f, 2.1329f, 1.0594f, 1.0f,
            5.1632f, 21.0767f, 49.8777f, 91.0991f, 9.1f, 0.9557f, -1.4319f, 0.0f,
            5.6316f, 21.0436f, 56.2126f, 106.043f, 9.1f, 3.9551f, 0.9934f, 0.0f,
            6.2086f, 36.3567f, 73.9727f, 76.7863f, 7.0f, 0.8346f, 0.6435f, 1.0f
        ),
        stamens = floatArrayOf(
            0.3355f, 18.1788f, 93.0534f, 98.617f, 1.0f,
            0.6228f, 10.2936f, 77.0842f, 120.4788f, 1.0f,
            0.9919f, 12.8617f, 94.1505f, 103.6593f, 1.0f,
            1.4679f, 37.7856f, 82.5643f, 91.7613f, 1.0f,
            2.1377f, 5.5492f, 68.1862f, 122.0281f, 1.0f,
            2.6549f, 16.2028f, 81.5479f, 114.4637f, 1.0f,
            3.0573f, 3.8459f, 91.2094f, 123.3544f, 1.0f,
            3.5251f, 15.3488f, 85.1971f, 110.8233f, 0.0f,
            4.0056f, 33.2935f, 96.3858f, 97.3364f, 0.0f,
            4.3871f, 29.8121f, 98.3909f, 121.6711f, 0.0f,
            4.9227f, 2.2244f, 93.4393f, 130.0654f, 0.0f,
            5.5994f, 27.9666f, 98.9639f, 112.9949f, 0.0f,
            6.1546f, 9.9658f, 64.9032f, 126.257f, 0.0f
        )
    ),
    Lirio(
        x = 670.0f, y = 1190.0f, p = 78.0f, e = 44.0f, roll = 6.0f, lt = 0.92f, bx = 688.0f,
        petals = floatArrayOf(
            0.2651f, 26.8379f, 73.6256f, 109.451f, 10.14f, 2.4714f, 1.6892f, 0.0f,
            0.6669f, 11.5582f, 59.3593f, 103.9679f, 10.14f, 2.0559f, -0.7891f, 0.0f,
            1.1334f, 27.812f, 62.1086f, 79.0801f, 7.8f, 1.2662f, -1.4593f, 1.0f,
            1.6868f, 21.0186f, 66.3709f, 114.299f, 10.14f, 5.0432f, -0.2909f, 0.0f,
            2.178f, 25.4719f, 86.5615f, 106.93f, 10.14f, 4.1341f, -0.6832f, 0.0f,
            2.9578f, 40.0114f, 88.558f, 85.0811f, 7.8f, 1.4622f, 0.1539f, 1.0f,
            3.4237f, 27.2354f, 66.4654f, 101.3058f, 10.14f, 3.9333f, -1.3442f, 0.0f,
            3.9391f, 8.1669f, 69.9975f, 108.7578f, 10.14f, 0.7523f, -0.0673f, 0.0f,
            4.3983f, 28.8577f, 94.295f, 83.7107f, 7.8f, 5.5926f, -0.8674f, 1.0f,
            4.7729f, 17.0387f, 51.2512f, 113.6822f, 10.14f, 1.6512f, -1.2635f, 0.0f,
            5.3775f, 17.6822f, 85.447f, 108.3491f, 10.14f, 1.8914f, 0.6031f, 0.0f,
            5.8262f, 25.0209f, 82.8109f, 81.9319f, 7.8f, 0.6362f, -1.474f, 1.0f
        ),
        stamens = floatArrayOf(
            0.1071f, 24.9451f, 62.6124f, 121.8411f, 1.0f,
            0.4937f, 3.234f, 68.5033f, 114.7773f, 1.0f,
            1.0576f, 4.2645f, 85.5731f, 142.5257f, 1.0f,
            1.6317f, 2.5831f, 86.6428f, 131.065f, 1.0f,
            1.8322f, 14.6186f, 86.7969f, 145.8666f, 1.0f,
            2.701f, 21.6422f, 84.3763f, 146.2563f, 1.0f,
            2.8834f, 19.3474f, 64.3387f, 137.6511f, 1.0f,
            3.5523f, 8.0022f, 69.4892f, 125.9103f, 0.0f,
            4.0767f, 5.1637f, 74.2894f, 125.397f, 0.0f,
            4.3546f, 33.6102f, 89.5514f, 146.1128f, 0.0f,
            4.997f, 25.8885f, 72.8478f, 125.0205f, 0.0f,
            5.3916f, 18.1813f, 64.3738f, 141.1649f, 0.0f,
            5.7598f, 17.4166f, 97.3416f, 125.4063f, 0.0f
        )
    ),
    Lirio(
        x = 548.0f, y = 1035.0f, p = 108.0f, e = 44.0f, roll = -4.0f, lt = 1.0f, bx = 580.0f,
        petals = floatArrayOf(
            0.1274f, 24.4701f, 87.158f, 163.4356f, 14.04f, 1.6317f, 0.4615f, 0.0f,
            0.6508f, 28.9311f, 76.5117f, 141.202f, 14.04f, 2.5844f, 1.679f, 0.0f,
            0.9226f, 27.6593f, 97.2522f, 106.9071f, 10.8f, 1.3103f, -0.6225f, 1.0f,
            1.6992f, 16.0537f, 68.5054f, 155.0612f, 14.04f, 5.0591f, -0.0268f, 0.0f,
            1.9629f, 21.757f, 46.9303f, 138.9384f, 14.04f, 1.1953f, 0.6577f, 0.0f,
            2.55f, 36.566f, 53.9842f, 99.7423f, 10.8f, 0.1466f, 0.6997f, 1.0f,
            3.2544f, 13.272f, 58.0663f, 136.4725f, 14.04f, 4.0497f, -0.6775f, 0.0f,
            3.5511f, 23.525f, 77.9853f, 149.609f, 14.04f, 0.9609f, 0.4715f, 0.0f,
            4.2063f, 30.3896f, 54.0569f, 117.2628f, 10.8f, 5.4207f, 0.6453f, 1.0f,
            4.8682f, 21.9287f, 63.9628f, 139.5984f, 14.04f, 3.8163f, 0.0663f, 0.0f,
            5.216f, 31.8232f, 91.1715f, 139.5525f, 14.04f, 5.5529f, -1.6932f, 0.0f,
            5.8072f, 27.5678f, 85.1382f, 117.7748f, 10.8f, 3.3306f, 0.8939f, 1.0f
        ),
        stamens = floatArrayOf(
            -0.1867f, 25.3591f, 66.4667f, 169.8985f, 0.0f,
            0.4136f, 2.7779f, 90.3951f, 146.4434f, 1.0f,
            0.865f, 3.2649f, 87.1666f, 159.9054f, 1.0f,
            1.2591f, 1.0315f, 70.3462f, 173.2303f, 1.0f,
            1.7289f, 0.9038f, 87.3297f, 174.5689f, 1.0f,
            2.2638f, 11.8595f, 66.7893f, 158.2226f, 1.0f,
            2.853f, 8.2841f, 69.5063f, 155.0704f, 1.0f,
            3.3001f, 21.0908f, 95.6748f, 182.3884f, 0.0f,
            3.845f, 0.1232f, 69.1654f, 181.4966f, 0.0f,
            4.3101f, 32.1893f, 96.5355f, 159.6121f, 0.0f,
            4.7765f, 11.3324f, 87.7054f, 146.7943f, 0.0f,
            5.2228f, 33.3837f, 76.1829f, 203.2516f, 0.0f,
            5.7563f, 31.803f, 79.5757f, 146.8394f, 0.0f
        )
    )
)

// ───────────────────────── Dibujo ─────────────────────────

private const val N = 12                    // tramos por pétalo / estambre (las curvas se suavizan al dibujar)
private const val NP = 12                   // pétalos por flor
private const val NS = 13                   // estambres por flor
private const val RUF = 0.55f               // cuánto se ondula el borde del pétalo
private val D2R = (PI / 180.0).toFloat()
private val TWO_PI = (2.0 * PI).toFloat()
private val PI_F = PI.toFloat()

private fun gr(v: Float, a: Float = 1f): Color {
    val c = if (v < 0f) 0f else if (v > 1f) 1f else v
    return Color(c, c, c, a)
}

/** Brisa: tres ondas de frecuencia entera (ciclo exacto). Devuelve algo entre -1 y 1. */
private fun brisa(a: Float): Float = 0.6f * sin(a) + 0.25f * sin(2f * a + 1.3f) + 0.15f * sin(3f * a + 2.1f)

private class LirioPainter {
    // Memoria reutilizable: nada se crea en cada cuadro.
    private val g3 = FloatArray((N + 1) * 9)      // pétalo en 3D: centro, borde izquierdo, borde derecho
    private val s3 = FloatArray((N + 1) * 3)      // estambre en 3D
    private val cx = FloatArray(N + 1)
    private val cy = FloatArray(N + 1)
    private val lx = FloatArray(N + 1)
    private val ly = FloatArray(N + 1)
    private val rx = FloatArray(N + 1)
    private val ry = FloatArray(N + 1)
    private val px = FloatArray(2 * N + 2)
    private val py = FloatArray(2 * N + 2)
    private val pFill = Path()
    private val pMid = Path()
    private val pEdge = Path()
    private val pVein = Path()
    private val pStBack = Path()
    private val pStFront = Path()
    private val pTip = Path()
    private val pStem = Path()

    // Cámara de la flor actual.
    private var ce = 1f
    private var se = 0f
    private var cr = 1f
    private var sr = 0f
    private var hx = 0f
    private var hy = 0f
    private var k = 1f
    private var oy = 0f
    private var outX = 0f
    private var outY = 0f

    /** Pasa un punto 3D de la flor a la pantalla (vista desde arriba con elevación e, giro y posición de la cabeza). */
    private fun proj(x: Float, y: Float, z: Float) {
        val yd = -z * ce + y * se
        val xr = x * cr - yd * sr
        val yr = x * sr + yd * cr
        outX = (hx + xr) * k
        outY = oy + (hy + yr) * k
    }

    fun draw(ds: DrawScope, u: Float) {
        with(ds) {
            k = size.width / REF_W
            oy = size.height - REF_H * k            // anclado abajo
            val ph = TWO_PI * u
            for (fl in LIRIOS) drawLirio(fl, ph)
        }
    }

    private fun petalGeom(f: FloatArray, o: Int, a0: Float, aEnd: Float) {
        val phi0 = f[o]
        val ln = f[o + 3]
        val wmax = f[o + 4]
        val ph = f[o + 5]
        val tw = f[o + 6]
        var r = 0f
        var z = 0f
        val ds = ln / N
        for (i in 0..N) {
            val s = i.toFloat() / N
            val phi = phi0 + tw * s
            val cphi = cos(phi)
            val sphi = sin(phi)
            val al = (a0 + (aEnd - a0) * s.pow(1.3f)) * D2R
            val sa = sin(al)
            val ca = cos(al)
            if (i > 0) { r += ca * ds; z += sa * ds }
            val base = max(0f, sin(PI_F * s.pow(0.65f)))
            val w = wmax * (0.9f * base.pow(0.7f) + 0.1f * (1f - s))
            val nx = -sa * cphi
            val ny = -sa * sphi
            val nz = ca
            val rl = RUF * w * sin(s * 13f + ph) * (0.3f + s)
            val rr = RUF * w * sin(s * 13f + ph + 1.9f) * (0.3f + s)
            val ccx = r * cphi
            val ccy = r * sphi
            val tx = -sphi
            val ty = cphi
            val q = i * 9
            g3[q] = ccx; g3[q + 1] = ccy; g3[q + 2] = z
            g3[q + 3] = ccx + tx * w + nx * rl; g3[q + 4] = ccy + ty * w + ny * rl; g3[q + 5] = z + nz * rl
            g3[q + 6] = ccx - tx * w + nx * rr; g3[q + 7] = ccy - ty * w + ny * rr; g3[q + 8] = z + nz * rr
        }
    }

    private fun stamenGeom(f: FloatArray, o: Int, a1: Float) {
        val phi = f[o]
        val a0 = f[o + 1]
        val ln = f[o + 3]
        val cphi = cos(phi)
        val sphi = sin(phi)
        var r = 0f
        var z = 0f
        val ds = ln / N
        for (i in 0..N) {
            val s = i.toFloat() / N
            val al = (a0 + (a1 - a0) * s.pow(1.4f)) * D2R
            if (i > 0) { r += cos(al) * ds; z += sin(al) * ds }
            s3[i * 3] = r * cphi; s3[i * 3 + 1] = r * sphi; s3[i * 3 + 2] = z
        }
    }

    /** Suma a [p] una curva suave por los puntos (curvas cuadráticas entre puntos medios), como un subtrazo nuevo. */
    private fun addSmooth(p: Path, xs: FloatArray, ys: FloatArray, m: Int, close: Boolean) {
        p.moveTo(xs[0], ys[0])
        for (i in 1 until m - 1) {
            p.quadraticBezierTo(xs[i], ys[i], (xs[i] + xs[i + 1]) * 0.5f, (ys[i] + ys[i + 1]) * 0.5f)
        }
        p.lineTo(xs[m - 1], ys[m - 1])
        if (close) p.close()
    }

    /** Arma en px/py el contorno de la cinta del pétalo: f = fracción del ancho, bias = desplazamiento hacia el lado izquierdo. */
    private fun ribbon(f: Float, bias: Float): Int {
        var m = 0
        for (i in 0..N) {
            px[m] = cx[i] + (lx[i] - cx[i]) * (f + bias)
            py[m] = cy[i] + (ly[i] - cy[i]) * (f + bias)
            m++
        }
        for (i in N - 1 downTo 0) {
            px[m] = cx[i] + (rx[i] - cx[i]) * f + (lx[i] - cx[i]) * bias
            py[m] = cy[i] + (ry[i] - cy[i]) * f + (ly[i] - cy[i]) * bias
            m++
        }
        return m
    }

    private fun DrawScope.drawLirio(fl: Lirio, ph: Float) {
        val lt = fl.lt
        val lag = fl.x / REF_W * 2.4f
        val wnd = brisa(ph - lag)                  // tronco y pétalos
        val wnd2 = brisa(ph - lag - 0.7f)          // los estambres, más livianos, llegan un poco después
        val sway = wnd * 5f * D2R

        // Tallo: nace abajo (fijo) y la cabeza gira alrededor de ese punto.
        val bx = fl.bx
        val by = REF_H + 30f
        val vx = fl.x - bx
        val vy = fl.y - by
        val c = cos(sway)
        val s = sin(sway)
        hx = bx + vx * c - vy * s
        hy = by + vx * s + vy * c
        pStem.rewind()
        pStem.moveTo(bx * k, oy + by * k)
        pStem.quadraticBezierTo(((bx + hx) * 0.5f + wnd * 10f) * k, oy + ((by + hy) * 0.5f) * k, hx * k, oy + hy * k)
        drawPath(
            pStem, gr(0.46f * lt * lt + 0.05f),
            style = Stroke(max(1f, 1.5f * k * (0.5f + fl.p / 220f)), cap = StrokeCap.Round)
        )

        val er = fl.e * D2R
        ce = cos(er)
        se = sin(er)
        val roll = fl.roll * D2R + sway
        cr = cos(roll)
        sr = sin(roll)

        pFill.rewind(); pMid.rewind(); pEdge.rewind(); pVein.rewind()
        pStBack.rewind(); pStFront.rewind(); pTip.rewind()

        // Pétalos: todos juntos en 4 trazados (relleno, realce, borde, nervadura).
        for (i in 0 until NP) {
            val o = i * 8
            val a0 = fl.petals[o + 1] + wnd * 3f + 2f * sin(4f * ph + i)
            val aEnd = fl.petals[o + 2] + wnd * 16f * sin(i * 1.7f + 1f)
            petalGeom(fl.petals, o, a0, aEnd)
            for (q in 0..N) {
                val g = q * 9
                proj(g3[g], g3[g + 1], g3[g + 2]); cx[q] = outX; cy[q] = outY
                proj(g3[g + 3], g3[g + 4], g3[g + 5]); lx[q] = outX; ly[q] = outY
                proj(g3[g + 6], g3[g + 7], g3[g + 8]); rx[q] = outX; ry[q] = outY
            }
            var m = ribbon(1f, 0f)
            addSmooth(pFill, px, py, m, true)
            addSmooth(pEdge, px, py, m, true)
            m = ribbon(0.5f, 0.05f)
            addSmooth(pMid, px, py, m, true)
            addSmooth(pVein, cx, cy, N + 1, false)
        }

        // Estambres: los que miran hacia atrás van detrás de los pétalos, los otros delante. Las puntitas, todas en un trazo.
        for (j in 0 until NS) {
            val o = j * 5
            stamenGeom(fl.stamens, o, fl.stamens[o + 2] + wnd2 * 22f * sin(j * 2.1f + 0.5f))
            for (q in 0..N) {
                proj(s3[q * 3], s3[q * 3 + 1], s3[q * 3 + 2]); cx[q] = outX; cy[q] = outY
            }
            addSmooth(if (fl.stamens[o + 4] > 0.5f) pStFront else pStBack, cx, cy, N + 1, false)
            pTip.moveTo(cx[N], cy[N])
            pTip.lineTo(cx[N] + 0.1f, cy[N])
        }

        val thin = Stroke(max(1f, 0.7f * k), cap = StrokeCap.Round, join = StrokeJoin.Round)
        drawPath(pStBack, gr(0.78f * lt, 0.85f), style = thin)
        // Relleno con degradado: más oscuro hacia el centro y más claro hacia las puntas (volumen).
        val head = Offset(hx * k, oy + hy * k)
        val rad = max(1f, fl.p * 1.6f * k)
        drawPath(pFill, Brush.radialGradient(listOf(gr(0.28f * lt), gr(0.50f * lt)), head, rad))
        drawPath(pMid, gr(0.66f * lt, 0.45f))
        drawPath(pEdge, gr(0.88f * lt, 0.5f), style = Stroke(max(1f, 0.8f * k), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(pVein, gr(0.14f * lt, 0.8f), style = Stroke(max(1f, 0.9f * k), cap = StrokeCap.Round))
        drawPath(pStFront, gr(0.82f * lt, 0.9f), style = thin)
        // Puntitas brillantes con un halo suave.
        drawPath(pTip, Color(1f, 1f, 1f, 0.13f), style = Stroke(4.6f * k, cap = StrokeCap.Round))
        drawPath(pTip, Color.White, style = Stroke(max(1.6f, 1.9f * k), cap = StrokeCap.Round))
    }
}
