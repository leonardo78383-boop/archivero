package com.archivero

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Paleta de la app: rosa rojizo, blanco y negro. Tiene dos temas (oscuro y claro).
 * Los colores se leen de [light], que es un estado: al cambiarlo, toda la app se repinta sola.
 * En el tema claro, White y Black se intercambian (White = tinta del texto, Black = fondo), así todo lo que ya existe se adapta.
 */
object Pal {
    var light by mutableStateOf(false)

    val Pink = Color(0xFFFF0198)        // acento
    val Sel: Color get() = if (light) Color(0xFFE4E4EA) else Color(0xFF1F1F1F)   // fondo de lo seleccionado
    val Accent = Pink                   // único toque de color (barritas, globito). Pon Pal.White para dejarlo todo blanco y negro.

    // Carpeta: amarillo opaco, el de casi todos los exploradores.
    val FolderBack = Color(0xFFC9A54F)       // parte de atrás (arriba)
    val FolderBackDark = Color(0xFFA27F34)   // parte de atrás (abajo)
    val FolderFront = Color(0xFFE8CB7C)      // tapa de adelante (arriba)
    val FolderFrontDark = Color(0xFFC79F45)  // tapa de adelante (abajo)
    val FolderEdge = Color(0xFFF6E3A8)       // brillo del borde de la tapa
    val FolderPaper = Color(0xFFF4F1EA)      // hoja que asoma dentro de la carpeta
    val Black: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF000000)
    val Ink: Color get() = if (light) Color(0xFFF1F1F5) else Color(0xFF0B0B0B)    // superficies
    val Card: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF141414)   // tarjetas / menús
    val Line: Color get() = if (light) Color(0xFFD3D3DB) else Color(0xFF262626)    // líneas finas
    val White: Color get() = if (light) Color(0xFF101014) else Color(0xFFFFFFFF)
    val Muted: Color get() = if (light) Color(0xFF6A6A74) else Color(0xFF9A9A9A)   // texto secundario
}

/** Lee el tema guardado (al abrir la app). */
fun cargarTema(ctx: Context) {
    Pal.light = ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).getBoolean("claro", false)
}

/** Cambia entre tema claro y oscuro y lo recuerda. */
fun cambiarTema(ctx: Context, claro: Boolean) {
    Pal.light = claro
    ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).edit().putBoolean("claro", claro).apply()
}
