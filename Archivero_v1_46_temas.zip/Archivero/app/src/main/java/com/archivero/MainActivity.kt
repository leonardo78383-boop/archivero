package com.archivero

import android.content.Context
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.SideEffect
import android.app.Activity
import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cargarTema(this)
        store = Store(this)   // no lee disco: los datos llegan en segundo plano
        FriendLink.store = store
        setContent {
            ArchiveroTheme {
                Surface(Modifier.fillMaxSize()) {
                    when {
                        store.locked -> LockScreen(store)
                        !store.granted -> PermissionScreen()
                        else -> Box(Modifier.fillMaxSize()) {
                            App(store)
                        }
                    }
                }
            }
        }
    }

    // Al volver de Ajustes (tras dar el permiso) se actualiza todo.
    override fun onResume() {
        super.onResume()
        if (::store.isInitialized) {
            store.refresh()
            // Si la app estuvo más de 1 minuto fuera de pantalla, vuelve a pedir la contraseña.
            if (stoppedAt != 0L && SystemClock.elapsedRealtime() - stoppedAt > 60_000) store.lockNow()
            stoppedAt = 0L
        }
    }

    override fun onStart() {
        super.onStart()
        FriendLink.setVisible(true)     // la app está en pantalla: el amigo flotante se esconde
    }

    override fun onStop() {
        FriendLink.setVisible(false)    // saliste de la app: si el amigo anda suelto, te sigue
        stoppedAt = SystemClock.elapsedRealtime()
        if (::store.isInitialized) store.memory.flushNow()
        super.onStop()
    }

    override fun onDestroy() {
        FriendLink.store = null
        // El servicio solo se detiene si la app se cierra de verdad. Si Android solo destruye la actividad en segundo plano
        // (poca memoria), el amigo flotante sigue con el usuario.
        if (isFinishing) { FriendLink.stop(this); Musica.liberar() }
        if (::store.isInitialized) store.close()
        super.onDestroy()
    }
}

@Composable
fun ArchiveroTheme(content: @Composable () -> Unit) {
    // Rosa rojizo, blanco y negro. Tema oscuro o claro según Pal.light (se cambia desde el panel de las 3 rayitas).
    val light = Pal.light
    val scheme = remember(light) {
        if (light) lightColorScheme(
            primary = Pal.White, onPrimary = Pal.Black,
            primaryContainer = Pal.Sel, onPrimaryContainer = Pal.White,
            secondary = Pal.White, onSecondary = Pal.Black,
            secondaryContainer = Pal.Sel, onSecondaryContainer = Pal.White,
            tertiary = Pal.White,
            background = Pal.Black, onBackground = Pal.White,
            surface = Pal.Black, onSurface = Pal.White,
            surfaceVariant = Pal.Ink, onSurfaceVariant = Pal.Muted,
            surfaceContainerLowest = Pal.Black, surfaceContainerLow = Pal.Black,
            surfaceContainer = Pal.Card, surfaceContainerHigh = Pal.Card, surfaceContainerHighest = Pal.Card,
            outline = Pal.Line, outlineVariant = Pal.Line
        ) else darkColorScheme(
            primary = Pal.White, onPrimary = Pal.Black,
            primaryContainer = Pal.Sel, onPrimaryContainer = Pal.White,
            secondary = Pal.White, onSecondary = Pal.Black,
            secondaryContainer = Pal.Sel, onSecondaryContainer = Pal.White,
            tertiary = Pal.White,
            background = Pal.Black, onBackground = Pal.White,
            surface = Pal.Black, onSurface = Pal.White,
            surfaceVariant = Pal.Card, onSurfaceVariant = Pal.Muted,
            surfaceContainerLowest = Pal.Black, surfaceContainerLow = Pal.Black,
            surfaceContainer = Pal.Card, surfaceContainerHigh = Pal.Card, surfaceContainerHighest = Pal.Card,
            outline = Pal.Line, outlineVariant = Pal.Line
        )
    }
    // Barras del sistema: mismo fondo que la app y íconos que se lean en cualquiera de los dos temas.
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            @Suppress("DEPRECATION")
            w.statusBarColor = Pal.Black.toArgb()
            @Suppress("DEPRECATION")
            w.navigationBarColor = Pal.Black.toArgb()
            val ic = WindowCompat.getInsetsController(w, view)
            ic.isAppearanceLightStatusBars = light
            ic.isAppearanceLightNavigationBars = light
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

sealed interface Screen {
    data object Home : Screen
    /** [tab] = ficha de Inicio desde la que se abrió (filtra por tipo y define a dónde vuelve "atrás"); [root] = carpeta de esa ficha. */
    data class Folder(val dir: File, val tab: HomeTab? = null, val root: File? = null) : Screen
    data object Trash : Screen
    class Scan(val title: String, val key: String, val grid: Boolean, val match: (File) -> Boolean) : Screen
    data class Cat(val tab: HomeTab) : Screen
}

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        toast(ctx, "No hay una app para abrir este archivo")
    }
}

fun shareFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Compartir ${f.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast(ctx, "No se pudo compartir este archivo")
    }
}

// ───────────────────────── Permiso (se pide una sola vez) ─────────────────────────

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Permitir acceso a tus archivos", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "Archivero necesita este permiso para mostrar de verdad el almacenamiento principal y la tarjeta SD: " +
                "carpetas, música, fotos, vídeos, documentos, PDF y APKs. Solo te lo pedimos una vez.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }) { Text("Permitir") }
    }
}

// ───────────────────────── Estructura principal ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(store: Store) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var panelOpen by remember { mutableStateOf(false) }
    val cleaner = remember(store) { CleanerState(ctx, store) }
    var newFolder by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var pwMode by remember { mutableStateOf<PwMode?>(null) }

    fun go(s: Screen) {
        screen = s
        scope.launch { drawer.close() }
    }

    fun act(a: DrawerAction) {
        scope.launch { drawer.close() }
        when (a) {
            DrawerAction.REFRESH -> store.reload()
            DrawerAction.PW_SET -> pwMode = PwMode.SET
            DrawerAction.PW_LOCK -> store.lockNow()
            DrawerAction.PW_CHANGE -> pwMode = PwMode.CHANGE
            DrawerAction.PW_REMOVE -> pwMode = PwMode.REMOVE
            DrawerAction.EMPTY_TRASH -> if (store.trash.isEmpty()) toast(ctx, "La papelera ya está vacía") else confirmEmpty = true
        }
    }

    BackHandler(enabled = cleaner.chatOpen || cleaner.settingsOpen || panelOpen || drawer.isOpen || screen != Screen.Home) {
        val s = screen
        when {
            cleaner.chatOpen -> cleaner.chatOpen = false
            cleaner.settingsOpen -> cleaner.settingsOpen = false
            panelOpen -> panelOpen = false
            drawer.isOpen -> scope.launch { drawer.close() }
            s is Screen.Folder -> {
                val p = s.dir.parentFile
                val t = s.tab
                if (t != null) {
                    // Abierta desde una ficha: "atrás" vuelve a la lista de carpetas de esa ficha.
                    val r = s.root ?: s.dir
                    screen = if (s.dir == r || p == null) Screen.Cat(t) else Screen.Folder(p, t, r)
                } else {
                    screen = if (store.vols.any { it.dir == s.dir } || p == null) Screen.Home else Screen.Folder(p)
                }
            }
            s is Screen.Cat -> {
                store.homeTab = null          // al salir de la ficha, vuelve a su aspecto normal en Inicio
                screen = Screen.Home
            }
            else -> screen = Screen.Home
        }
    }

    val cur = screen
    val title = when (cur) {
        Screen.Home -> "Este equipo"
        is Screen.Folder -> store.vols.firstOrNull { it.dir == cur.dir }?.name ?: cur.dir.name
        Screen.Trash -> "Papelera de reciclaje"
        is Screen.Scan -> cur.title
        is Screen.Cat -> cur.tab.label
    }

    SideEffect { cleaner.hint = title }          // el amigo sabe en qué pantalla estás
    // Suelto = puede seguirte fuera de la app; guardado = no.
    LaunchedEffect(cleaner.out) {
        FriendLink.wantOut = cleaner.out
        FriendLink.sync(ctx)
    }

    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            // Solo observa los toques (no los consume): sirve para saber cuándo llevas un rato sin hacer nada.
            awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); cleaner.chat.touch() } }
        }
    ) {
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = { ModalDrawerSheet { DrawerBody(store, { go(it) }, { act(it) }) } }
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                Column {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menú") }
                    },
                    actions = {
                        IconButton(onClick = { panelOpen = !panelOpen }) { Icon(Icons.Default.Menu, "Limpiador") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Pal.Black,
                        titleContentColor = Pal.White,
                        navigationIconContentColor = Pal.White,
                        actionIconContentColor = Pal.White
                    )
                )
                Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.Line))
                }
            },
            bottomBar = { if (store.music.active) MiniPlayer(store.music, big = cur == Screen.Home) },
            floatingActionButton = {
                if (cur is Screen.Folder && cur.tab.kindFilter() == null) {
                    FloatingActionButton(onClick = { newFolder = true }, shape = ChamferShape(12.dp), containerColor = Pal.White, contentColor = Pal.Black) { Icon(Icons.Default.Add, "Nueva carpeta") }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (cur) {
                    Screen.Home -> HomeScreen(store) { go(it) }
                    is Screen.Folder -> FolderScreen(store, cur.dir, cur.tab, cur.root) { go(it) }
                    Screen.Trash -> TrashScreen(store)
                    is Screen.Scan -> ScanScreen(store, cur.key, cur.grid, cur.match) { go(it) }
                    is Screen.Cat -> CatGridScreen(store, cur.tab) { go(it) }
                }
            }
        }
    }
    store.viewer?.let { v -> MediaOverlay(v) { store.viewer = null } }
    CleanerLayer(cleaner, store, panelOpen) { panelOpen = false }
    }

    if (newFolder && cur is Screen.Folder) {
        NameDialog("Nueva carpeta", "", "Crear", { newFolder = false }) { n ->
            val d = File(cur.dir, n)
            when {
                d.exists() -> toast(ctx, "Ya existe ese nombre")
                d.mkdirs() -> store.reload()
                else -> toast(ctx, "No se pudo crear la carpeta")
            }
            newFolder = false
        }
    }
    pwMode?.let { m ->
        PasswordDialog(store, m, onDone = { toast(ctx, it); pwMode = null }, onDismiss = { pwMode = null })
    }
    store.busy?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(msg) },
            text = { ThinLoading() }
        )
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("¿Vaciar la papelera?") },
            text = { Text("Se liberará el espacio y no se podrá deshacer.") },
            confirmButton = { TextButton(onClick = { confirmEmpty = false; scope.launch { store.emptyTrash() } }) { Text("Vaciar") } },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancelar") } }
        )
    }
}

// ───────────────────────── Panel de las 3 rayitas ─────────────────────────

@Composable
fun DrawerBody(store: Store, go: (Screen) -> Unit, onAction: (DrawerAction) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState())) {
        // Cabecera: el fondo oscuro con el resplandor rosa de Inicio, la carpeta de la app y su nombre.
        Row(
            Modifier.fillMaxWidth().fondoInicio().padding(start = 18.dp, end = 18.dp, top = 28.dp, bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FolderIcon(40.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("ARCHIVERO", color = Pal.White, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 3.sp)
                Text("Tus archivos, en orden", color = Pal.Muted, fontSize = 12.sp)
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.Line))
        Spacer(Modifier.height(8.dp))
        DrawerItem("home", "Inicio") { go(Screen.Home) }
        val ctxTema = LocalContext.current
        DrawerItem(if (Pal.light) "🌙" else "☀", "Tema", if (Pal.light) "Claro · tocá para oscuro" else "Oscuro · tocá para claro") {
            cambiarTema(ctxTema, !Pal.light)
        }

        SectionTitle("Almacenamiento")
        store.vols.forEach { v ->
            val total = v.total.coerceAtLeast(1L)
            val free = v.free
            val used = (total - free).coerceAtLeast(0L)
            val shape = ChamferShape(14.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 5.dp)
                    .vidrio3D(shape, 6.dp)
                    .clip(shape)
                    .clickable { go(Screen.Folder(v.dir)) }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SdIcon(22.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(v.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${free * 100 / total}% libre", color = Pal.Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                SegBar(used.toFloat() / total, Modifier.fillMaxWidth(), segments = 20, height = 4.dp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Libre: ${gb(free)}\nOcupado: ${gb(used)}\nTotal: ${gb(total)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        SectionTitle("Papelera")
        DrawerItem("recycle", "Papelera de reciclaje", right = fmtSize(store.trash.sumOf { it.size })) { go(Screen.Trash) }
        DrawerItem("trash", "Vaciar papelera") { onAction(DrawerAction.EMPTY_TRASH) }
        if (store.hasPassword) {
            SectionTitle("Candado")
            DrawerItem("lock", "Bloquear ahora") { onAction(DrawerAction.PW_LOCK) }
            DrawerItem("key", "Cambiar contraseña") { onAction(DrawerAction.PW_CHANGE) }
            DrawerItem("unlock", "Quitar contraseña") { onAction(DrawerAction.PW_REMOVE) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** Lo que antes estaba en las 3 rayitas de la derecha; ahora vive al final del panel lateral. */
enum class DrawerAction { REFRESH, EMPTY_TRASH, PW_SET, PW_LOCK, PW_CHANGE, PW_REMOVE }

/** Una opción del panel lateral: el ícono dentro de una casilla redondeada, el título y, a la derecha, un dato opcional. */
@Composable
fun DrawerItem(icon: String, title: String, sub: String? = null, right: String? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(11.dp)).background(Pal.Card).border(1.dp, Pal.Line, RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            when (icon) {
                "📁" -> FolderIcon(26.dp)
                "home" -> HomeIcon(24.dp)
                "recycle" -> RecycleIcon(24.dp)
                "trash" -> TrashIcon(24.dp)
                "lock" -> LockIcon(false, 24.dp)
                "unlock" -> LockIcon(true, 24.dp)
                "key" -> KeyIcon(24.dp)
                else -> Text(icon, fontSize = 20.sp)
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (right != null) Text(right, style = MaterialTheme.typography.bodySmall, color = Pal.Muted)
    }
}

// ───────────────────────── Inicio ─────────────────────────

@Composable
fun HomeScreen(store: Store, go: (Screen) -> Unit) {
    var q by remember { mutableStateOf("") }

    // Fondo negro liso (ya no hay lirios).
    Box(Modifier.fillMaxSize().background(Pal.Black)) {
        Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            TextField(
                value = q, onValueChange = { q = it },
                placeholder = { Text("Buscar en Este equipo", color = Pal.Muted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Pal.Muted) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Pal.White, focusedTextColor = Pal.White, unfocusedTextColor = Pal.White
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    val s = q.trim()
                    if (s.isNotEmpty()) go(Screen.Scan("Resultados: $s", "q:${s.lowercase()}", false) { it.name.contains(s, ignoreCase = true) })
                }),
                modifier = Modifier.fillMaxWidth().padding(16.dp).vidrio3D(RoundedCornerShape(18.dp), 8.dp)
            )

            SectionTitle("Almacenamiento")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                store.vols.forEachIndexed { i, v ->
                    val used = if (v.total > 0L) (1f - v.free.toFloat() / v.total.toFloat()).coerceIn(0f, 1f) else 0f
                    Column(
                        Modifier.weight(1f)
                            .vidrio3D(ChamferShape(18.dp), 12.dp, glow = i == 0)
                            .esquinasLuz()
                            .clickable { go(Screen.Folder(v.dir)) }
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SdIcon(30.dp)
                            Spacer(Modifier.weight(1f))
                            Text("${(used * 100).toInt()}%", color = Pal.Accent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(v.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(
                            "${Math.round(v.free / 1073741824.0)} GB libres de ${Math.round(v.total / 1073741824.0)} GB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(12.dp))
                        SegBar(used, Modifier.fillMaxWidth(), segments = 16, height = 5.dp)
                    }
                }
            }

            SectionTitle("Categorías")
            // Las 5 fichas (Descargas, Música, Fotos, Vídeos, APKs), justo debajo del título.
            CategoryBar(store, go)
        }
        }
    }
}

// ───────────────────────── Carpetas y archivos reales ─────────────────────────

@Composable
fun FolderScreen(store: Store, dir: File, tab: HomeTab? = null, root: File? = null, go: (Screen) -> Unit) {
    LaunchedEffect(dir) { store.memory.visitFolder(dir) }
    // Si se abrió desde Música/Fotos/Vídeos/APKs, solo se muestran archivos de ese tipo (sin subcarpetas ni otros archivos).
    val kind = tab.kindFilter()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = store.tick
    var renaming by remember { mutableStateOf<Entry?>(null) }
    var menuFor by remember { mutableStateOf<Entry?>(null) }
    var infoFor by remember { mutableStateOf<Entry?>(null) }
    var zipFor by remember { mutableStateOf<Entry?>(null) }
    var showSort by remember { mutableStateOf(false) }
    var selected by remember(dir) { mutableStateOf(setOf<String>()) }
    val sortBy = store.sortBy
    val sortAsc = store.sortAsc

    // Si ya se vio esta carpeta, se muestra al instante lo guardado y se actualiza detrás (entrar y volver es inmediato).
    val cachedDir = remember(dir, kind) { if (kind == null) store.cachedDir(dir) else null }
    var list by remember(dir, kind) { mutableStateOf<List<Entry>?>(cachedDir?.raw) }
    var rowsState by remember(dir, kind) {
        mutableStateOf<List<Entry>?>(cachedDir?.takeIf { it.by == sortBy && it.asc == sortAsc }?.rows)
    }
    val sortedFor = remember(dir, kind) { SortStamp(cachedDir?.raw, cachedDir?.by, cachedDir?.asc) }

    // La carpeta se lee en segundo plano (y en paralelo si es grande). Si no cambió nada, la lista no se toca.
    LaunchedEffect(dir, tick, kind) {
        val old = list
        val (fresh, same) = withContext(Dispatchers.IO) {
            val all = readDir(dir)
            val f = if (kind == null) all else all.filter { !it.isDir && it.kind == kind }
            f to (old != null && sameEntries(old, f))
        }
        if (!same) list = fresh
    }
    // El orden también se calcula fuera del hilo principal.
    LaunchedEffect(list, sortBy, sortAsc) {
        val raw = list ?: return@LaunchedEffect
        if (rowsState != null && sortedFor.raw === raw && sortedFor.by == sortBy && sortedFor.asc == sortAsc) return@LaunchedEffect
        val sorted = withContext(Dispatchers.Default) { sortEntries(raw, sortBy, sortAsc) }
        sortedFor.raw = raw; sortedFor.by = sortBy; sortedFor.asc = sortAsc
        rowsState = sorted
        if (kind == null) store.putDir(dir, DirListing(raw, sorted, sortBy, sortAsc))   // lo filtrado no se guarda: la carpeta normal debe verse completa
    }
    val rows = rowsState
    val chosen = remember(rows, selected) { if (selected.isEmpty()) emptyList() else rows?.filter { it.file.path in selected } ?: emptyList() }
    val selecting = chosen.isNotEmpty()
    val folders = remember(rows) { rows?.count { it.isDir } ?: 0 }

    val v = store.vols.firstOrNull { dir.path.startsWith(it.dir.path) }
    val crumb = (v?.name ?: "") + dir.path.removePrefix(v?.dir?.path ?: "")

    // Con elementos marcados, "atrás" primero cancela la selección.
    BackHandler(enabled = selecting) { selected = emptySet() }

    fun toggle(e: Entry) {
        selected = if (e.file.path in selected) selected - e.file.path else selected + e.file.path
    }

    Column(Modifier.fillMaxSize()) {
        Text(crumb, Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(16.dp, 10.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1)

        if (selecting) {
            SelectionBar(
                count = chosen.size,
                onClose = { selected = emptySet() },
                onAll = { selected = rows?.map { it.file.path }?.toSet() ?: emptySet() },
                onCopy = {
                    store.clip = Clip(chosen.map { it.file }, false)
                    selected = emptySet()
                    toast(ctx, "Copiado: abrí otra carpeta y toca Pegar")
                },
                onCut = {
                    store.clip = Clip(chosen.map { it.file }, true)
                    selected = emptySet()
                    toast(ctx, "Cortado: abrí otra carpeta y toca Pegar")
                },
                onZip = {
                    val files = chosen.map { it.file }
                    selected = emptySet()
                    scope.launch { toast(ctx, store.zip(files) ?: "ZIP creado") }
                },
                onDelete = {
                    val files = chosen.map { it.file }
                    selected = emptySet()
                    scope.launch {
                        val n = store.moveToTrash(files)
                        toast(ctx, if (n == files.size) "Movido a la papelera" else "Se movieron $n de ${files.size}")
                    }
                }
            )
        }

        store.clip?.let { c ->
            PasteBar(c,
                onPaste = {
                    scope.launch {
                        val err = store.paste(c, dir)
                        toast(ctx, err ?: if (c.cut) "Movido" else "Copiado")
                    }
                },
                onCancel = { store.clip = null })
        }

        if (rows == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ThinSpinner() }
        }
        if (rows != null) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(start = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "$folders carpetas, ${rows.size - folders} archivos",
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall
                )
                Text("${sortBy.label} ${if (sortAsc) "↑" else "↓"}", style = MaterialTheme.typography.bodySmall)
                IconButton(onClick = { showSort = true }) { ViewSortIcon() }
            }
            if (rows.isEmpty()) {
                Text("Carpeta vacía. Toca + para crear una carpeta.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
            } else {
                // key(dir): cada carpeta empieza arriba del todo (antes heredaba el desplazamiento de la anterior).
                key(dir) {
                    // Al volver a una carpeta, la lista queda donde estaba.
                    val saved = remember { store.scrollPos[dir.path] }
                    val listState = rememberLazyListState(saved?.first ?: 0, saved?.second ?: 0)
                    DisposableEffect(Unit) {
                        onDispose { if (store.viewMode == ViewMode.LIST) store.scrollPos[dir.path] = listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
                    }
                    if (store.viewMode != ViewMode.LIST) {
                        val gridState = rememberLazyGridState(saved?.first ?: 0, saved?.second ?: 0)
                        DisposableEffect(Unit) {
                            onDispose { store.scrollPos[dir.path] = gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset }
                        }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.fillMaxSize(),
                            state = gridState,
                            contentPadding = PaddingValues(start = 8.dp, top = 8.dp, end = 8.dp, bottom = 88.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(rows, key = { it.file.path }, contentType = { if (it.isDir) 0 else 1 }) { e ->
                                EntryTile(
                                    e,
                                    circle = store.viewMode == ViewMode.CIRCLE,
                                    selected = e.file.path in selected,
                                    onLongClick = { toggle(e) },
                                    onClick = {
                                        if (selecting) toggle(e)
                                        else if (e.isDir) go(Screen.Folder(e.file, tab, root))
                                        else openEntry(store, ctx, e, rows)
                                    },
                                    onMenu = if (selecting) null else ({ menuFor = e })
                                ) {
                                    if (menuFor === e) EntryMenu(store, scope, e, onDismiss = { menuFor = null }, onRename = { renaming = e }, onInfo = { infoFor = e }, onZipView = { zipFor = e })
                                }
                            }
                        }
                    } else
                    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(rows, key = { it.file.path }, contentType = { if (it.isDir) 0 else 1 }) { e ->
                            EntryRow(
                                e,
                                selected = e.file.path in selected,
                                onLongClick = { toggle(e) },
                                onClick = {
                                    if (selecting) toggle(e)
                                    else if (e.isDir) go(Screen.Folder(e.file, tab, root))
                                    else openEntry(store, ctx, e, rows)
                                }
                            ) {
                                if (selecting) {
                                    Checkbox(checked = e.file.path in selected, onCheckedChange = { toggle(e) })
                                } else {
                                    Box {
                                        IconButton(onClick = { menuFor = e }) { Icon(Icons.Default.MoreVert, "Opciones") }
                                        // El menú solo existe mientras está abierto: ~15 elementos menos por fila al desplazarse.
                                        if (menuFor === e) EntryMenu(store, scope, e, onDismiss = { menuFor = null }, onRename = { renaming = e }, onInfo = { infoFor = e }, onZipView = { zipFor = e })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSort) ViewSortDialog(store) { showSort = false }

    infoFor?.let { e -> InfoDialog(e) { infoFor = null } }

    zipFor?.let { z ->
        ZipContentDialog(
            z.file,
            onExtract = {
                zipFor = null
                scope.launch { toast(ctx, store.unzip(z.file) ?: "Extraído") }
            },
            onDismiss = { zipFor = null }
        )
    }

    renaming?.let { e ->
        NameDialog("Renombrar", e.name, "Guardar", { renaming = null }) { n ->
            val d = File(e.file.parentFile, n)
            when {
                n == e.name -> {}
                // En tarjetas SD (FAT) "foto" y "Foto" son el mismo archivo: permitir cambiar solo mayúsculas.
                d.exists() && !(n.equals(e.name, ignoreCase = true) && runCatching { java.nio.file.Files.isSameFile(d.toPath(), e.file.toPath()) }.getOrDefault(false)) ->
                    toast(ctx, "Ya existe ese nombre")
                e.file.renameTo(d) -> store.reload()
                else -> toast(ctx, "No se pudo renombrar")
            }
            renaming = null
        }
    }
}

/** Lista todos los archivos de una categoría (música, fotos, PDF…) o los resultados de una búsqueda. */
@Composable
fun ScanScreen(store: Store, cacheKey: String, grid: Boolean, match: (File) -> Boolean, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val cached = remember(cacheKey) { store.scanCache[cacheKey] }
    var found by remember(cacheKey) { mutableStateOf(cached?.items) }
    var loading by remember(cacheKey) { mutableStateOf(true) }

    LaunchedEffect(cacheKey, store.vols.size) {
        if (store.vols.isEmpty()) return@LaunchedEffect   // los almacenamientos aún se están leyendo
        val c = store.scanCache[cacheKey]
        if (c != null && System.currentTimeMillis() - c.time < 30_000) { loading = false; return@LaunchedEffect }
        loading = true
        // Muestra lo encontrado mientras sigue buscando, y se cancela solo si sales de la pantalla.
        val res = withContext(Dispatchers.IO) { scan(store.vols, { part -> found = part }, match) }
        found = res
        store.scanCache[cacheKey] = ScanResult(res, System.currentTimeMillis())
        loading = false
    }

    val res = found
    when {
        res == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ThinSpinner() }
        res.isEmpty() && !loading -> Text("No se encontró nada.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        else -> Column(Modifier.fillMaxSize()) {
            if (loading) ThinLoading()
            key(cacheKey) {
                if (grid) {
                    GalleryGrid(res, loading) { e -> openEntry(store, ctx, e, res) }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        item {
                            Text(
                                "${res.size} encontrados" + if (loading) " (buscando…)" else "",
                                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp, 8.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        items(res, key = { it.file.path }) { e ->
                            val where = if (e.isDir) "carpeta en " else fmtSize(e.size) + " en "
                            EntryRow(e, subOverride = where + (e.file.parentFile?.name ?: ""),
                                onClick = { if (e.isDir) go(Screen.Folder(e.file)) else openEntry(store, ctx, e, res) })
                        }
                    }
                }
            }
        }
    }
}

/** Fotos y vídeos en cuadrícula, agrupados por día (lo más nuevo arriba). */
@Composable
fun GalleryGrid(res: List<Entry>, loading: Boolean, onOpen: (Entry) -> Unit) {
    val groups = remember(res) { res.groupBy { it.epochDay } }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(96.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "${res.size} encontrados" + if (loading) " (buscando…)" else "",
                Modifier.fillMaxWidth().padding(8.dp, 6.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
        groups.forEach { (day, list) ->
            item(key = "h$day", span = { GridItemSpan(maxLineSpan) }) {
                Text(dayLabel(LocalDate.ofEpochDay(day)), Modifier.fillMaxWidth().padding(8.dp, 10.dp, 8.dp, 4.dp), fontWeight = FontWeight.Medium)
            }
            items(list, key = { it.file.path }) { e ->
                Box(Modifier.aspectRatio(1f).clickable { onOpen(e) }) {
                    Thumb(e, Modifier.fillMaxSize())
                    if (e.kind == Kind.VID) {
                        Text("▶", Modifier.align(Alignment.Center), color = Color.White, fontSize = 24.sp)
                    }
                }
            }
        }
    }
}

/**
 * Miniatura que se carga en segundo plano (foto, vídeo, carátula de música, primera hoja de PDF o ícono de APK).
 * Mientras carga se ve un cuadro gris; si el archivo no tiene miniatura, se muestra [fallback].
 */
@Composable
fun Thumb(e: Entry, modifier: Modifier, fallback: @Composable () -> Unit = {}) {
    val ctx = LocalContext.current
    // (terminó de buscar, miniatura): si ya estaba en memoria o ya se sabe que no tiene, se muestra sin parpadeo.
    val res by produceState(
        (Thumbs.cached(e.file.path) != null || Thumbs.hasFailed(e.file.path)) to Thumbs.cached(e.file.path),
        e.file.path
    ) {
        if (!value.first) value = true to Thumbs.load(ctx, e.file, e.kind)
    }
    val (done, b) = res
    when {
        b != null -> {
            val img = remember(b) { b.asImageBitmap() }
            // El ícono de un APK se ve entero (sin recortar); lo demás llena el cuadro.
            val apk = e.kind == Kind.APK
            Image(
                bitmap = img, contentDescription = e.name,
                contentScale = if (apk) ContentScale.Fit else ContentScale.Crop,
                modifier = if (apk) modifier.padding(6.dp) else modifier
            )
        }
        done -> Box(modifier, contentAlignment = Alignment.Center) { fallback() }
        else -> Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
fun TrashScreen(store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (store.trash.isEmpty()) {
        Text("La papelera está vacía. Lo que elimines aparece aquí.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(store.trash, key = { it.trashPath }) { t ->
            val ext = t.name.substringAfterLast('.', "")
            FileRow(t.isDir, kindOfExt(ext), ext, t.name, "${fmtSize(t.size)} · ${File(t.origPath).parent ?: ""}", onClick = {}) {
                TextButton(onClick = { scope.launch { if (!store.restore(t)) toast(ctx, "No se pudo restaurar") } }) { Text("Restaurar") }
                IconButton(onClick = { scope.launch { store.deleteForever(t) } }) { Icon(Icons.Default.Close, "Eliminar definitivamente") }
            }
        }
    }
}

/** Barra superior mientras hay archivos marcados (se activa con una pulsación larga). */
@Composable
fun SelectionBar(
    count: Int, onClose: () -> Unit, onAll: () -> Unit,
    onCopy: () -> Unit, onCut: () -> Unit, onZip: () -> Unit, onDelete: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Cancelar selección") }
            Text("$count seleccionados", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            TextButton(onClick = onAll) { Text("Todo") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            TextButton(onClick = onCopy, modifier = Modifier.weight(1f)) { Text("Copiar") }
            TextButton(onClick = onCut, modifier = Modifier.weight(1f)) { Text("Cortar") }
            TextButton(onClick = onZip, modifier = Modifier.weight(1f)) { Text("ZIP") }
            TextButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Eliminar") }
        }
    }
}

@Composable
fun SortDialog(store: Store, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
        title = { Text("Ordenar por") },
        text = {
            Column {
                SortBy.values().forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(o, store.sortAsc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortBy == o, onClick = { store.setSort(o, store.sortAsc) })
                        Text(o.label)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                listOf(true to "Ascendente (A→Z, antiguo→nuevo, chico→grande)", false to "Descendente").forEach { (asc, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(store.sortBy, asc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortAsc == asc, onClick = { store.setSort(store.sortBy, asc) })
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    )
}

/** Muestra qué hay dentro de un ZIP sin extraerlo. */
@Composable
fun ZipContentDialog(f: File, onExtract: () -> Unit, onDismiss: () -> Unit) {
    val zipItems by produceState<List<ZipItem>?>(null, f) {
        value = withContext(Dispatchers.IO) { listZip(f) ?: emptyList() }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            val list = zipItems
            when {
                list == null -> ThinLoading()
                list.isEmpty() -> Text("El ZIP está vacío o no se puede leer.")
                else -> Column {
                    val files = list.count { !it.isDir }
                    val total = list.sumOf { it.size }
                    Text("$files archivos · ${fmtSize(total)} descomprimido", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(list.take(1000)) { z ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (z.isDir) "▸ " else "") + z.name,
                                    Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp
                                )
                                if (!z.isDir) Text(fmtSize(z.size), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (list.size > 1000) {
                            item { Text("…y ${list.size - 1000} más", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onExtract) { Text("Extraer aquí") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

/** Barra que aparece cuando hay algo copiado/cortado esperando ser pegado. */
@Composable
fun PasteBar(c: Clip, onPaste: () -> Unit, onCancel: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            (if (c.cut) "Mover: " else "Copiar: ") + (if (c.files.size == 1) c.files[0].name else "${c.files.size} elementos"),
            Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        TextButton(onClick = onPaste) { Text("Pegar aquí") }
        TextButton(onClick = onCancel) { Text("Cancelar") }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}

/** Datos del archivo o carpeta. En carpetas el tamaño total se calcula en segundo plano. */
@Composable
fun InfoDialog(e: Entry, onDismiss: () -> Unit) {
    val stats by produceState<Triple<Long, Int, Int>?>(null, e.file) {
        value = if (e.isDir) withContext(Dispatchers.IO) { folderStats(e.file) } else null
    }
    val dims by produceState<String?>(null, e.file) {
        value = if (e.kind == Kind.IMG && !e.isDir) withContext(Dispatchers.IO) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(e.file.path, o)
            if (o.outWidth > 0) "${o.outWidth} × ${o.outHeight} px" else null
        } else null
    }
    val tipo = if (e.isDir) "Carpeta" else e.kind.label.let { k -> if (e.ext.isEmpty()) k else "$k (.${e.ext})" }
    val tamano = when {
        !e.isDir -> fmtSize(e.size) + " (${e.size} bytes)"
        stats == null -> "Calculando…"
        else -> stats!!.let { (b, f, d) -> "${fmtSize(b)} · $f archivos, $d carpetas" }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                InfoLine("Tipo", tipo)
                InfoLine("Ubicación", e.file.parent ?: "")
                InfoLine("Tamaño", tamano)
                dims?.let { InfoLine("Dimensiones", it) }
                InfoLine("Modificado", fmtDateTime(e.modified))
                InfoLine("Permisos", "Lectura: " + (if (e.file.canRead()) "sí" else "no") + " · Escritura: " + (if (e.file.canWrite()) "sí" else "no"))
            }
        }
    )
}

// ───────────────────────── Candado ─────────────────────────

@Composable
private fun PwField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, onDone: (() -> Unit)? = null) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun LockScreen(store: Store) {
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    fun submit() {
        if (working || pw.isEmpty()) return
        working = true
        val tryPw = pw
        scope.launch {
            msg = store.unlock(tryPw)
            pw = ""
            working = false
        }
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", fontSize = 40.sp)
        Spacer(Modifier.height(8.dp))
        Text("Archivero", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))
        PwField("Contraseña", pw, { pw = it }, onDone = { submit() })
        msg?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { submit() }, enabled = !working) { Text("Entrar") }
    }
}

enum class PwMode { SET, CHANGE, REMOVE }

@Composable
fun PasswordDialog(store: Store, mode: PwMode, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val title = when (mode) {
        PwMode.SET -> "Poner contraseña"
        PwMode.CHANGE -> "Cambiar contraseña"
        PwMode.REMOVE -> "Quitar contraseña"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mode != PwMode.SET) PwField("Contraseña actual", cur, { cur = it })
                if (mode != PwMode.REMOVE) {
                    PwField("Nueva contraseña", n1, { n1 = it })
                    PwField("Repetir contraseña", n2, { n2 = it })
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    if (mode != PwMode.SET && !store.checkPassword(cur)) { err = "La contraseña actual no es correcta"; return@launch }
                    if (mode != PwMode.REMOVE) {
                        if (n1.length < 4) { err = "Usá al menos 4 caracteres"; return@launch }
                        if (n1 != n2) { err = "Las contraseñas no coinciden"; return@launch }
                    }
                    when (mode) {
                        PwMode.SET, PwMode.CHANGE -> store.setPassword(n1)
                        PwMode.REMOVE -> store.removePassword()
                    }
                    onDone(
                        when (mode) {
                            PwMode.SET -> "Contraseña activada"
                            PwMode.CHANGE -> "Contraseña cambiada"
                            PwMode.REMOVE -> "Contraseña quitada"
                        }
                    )
                }
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ───────────────────────── Piezas visuales ─────────────────────────

/** Fila de un archivo/carpeta ya leído. Las carpetas cuentan sus elementos en segundo plano, solo las que se ven. */
@Composable
fun EntryRow(
    e: Entry,
    subOverride: String? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    if (e.isDir && subOverride == null) {
        // Con caché: al desplazarse de ida y vuelta no se vuelve a leer el disco por cada carpeta.
        val count by produceState<Int?>(DirCounts.cached(e.file), e.file.path) { value = DirCounts.count(e.file) }
        FileRow(true, e.kind, "", e.name, count?.let { "$it elementos" } ?: "",
            onClick = onClick, onLongClick = onLongClick, selected = selected, trailing = trailing)
    } else {
        // Música, PDF, APK, fotos y vídeos: la miniatura reemplaza al ícono genérico.
        val lead: (@Composable () -> Unit)? = if (!e.isDir && Thumbs.supports(e.kind)) ({
            Thumb(e, Modifier.size(42.dp).clip(RoundedCornerShape(6.dp))) { FileIcon(false, e.kind, e.ext) }
        }) else null
        FileRow(e.isDir, e.kind, e.ext, e.name, subOverride ?: e.sub,
            onClick = onClick, onLongClick = onLongClick, selected = selected, leading = lead, trailing = trailing)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    isDir: Boolean, kind: Kind, ext: String, name: String, sub: String,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean = false,
    leading: (@Composable () -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(44.dp), contentAlignment = Alignment.Center) { if (leading != null) leading() else FileIcon(isDir, kind, ext) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}



@Composable
fun SdIcon(w: Dp = 40.dp) {
    Canvas(Modifier.size(w, w * 1.3f)) {
        val bw = size.width
        val bh = size.height
        val sw = 1.4.dp.toPx()
        val p = Path().apply {
            moveTo(sw, sw); lineTo(0.68f * bw, sw); lineTo(bw - sw, 0.3f * bh)
            lineTo(bw - sw, bh - sw); lineTo(sw, bh - sw); close()
        }
        drawPath(p, Brush.linearGradient(if (Pal.light) listOf(Color(0xFFFFFFFF), Color(0xFFE2E2E9)) else listOf(Color(0xFF42424D), Color(0xFF111115)), start = Offset(0f, 0f), end = Offset(bw, bh)))
        drawPath(p, Pal.White.copy(alpha = 0.9f), style = Stroke(sw, join = StrokeJoin.Round))
        repeat(4) { drawLine(Pal.White.copy(alpha = 0.9f), Offset(bw * (0.2f + it * 0.12f), bh * 0.1f), Offset(bw * (0.2f + it * 0.12f), bh * 0.28f), strokeWidth = sw) }
    }
}

@Composable
fun NameDialog(title: String, initial: String, okText: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val n = v.trim().replace("/", "-")
                if (n.isNotEmpty()) onOk(n)
            }) { Text(okText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

/** Menú de opciones de un archivo o carpeta (lo usan la vista de filas y la de cuadrícula). */
@Composable
private fun EntryMenu(store: Store, scope: kotlinx.coroutines.CoroutineScope, e: Entry, onDismiss: () -> Unit, onRename: () -> Unit, onInfo: () -> Unit, onZipView: () -> Unit) {
    val ctx = LocalContext.current
    // `scope` viene de la pantalla: el del menú se cancelaba al cerrarse (onDismiss) y dejaba a medias eliminar/comprimir/extraer.
    DropdownMenu(expanded = true, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Renombrar") }, onClick = { onDismiss(); onRename() })
        DropdownMenuItem(text = { Text("Copiar") }, onClick = { onDismiss(); store.clip = Clip(listOf(e.file), false); toast(ctx, "Copiado: abrí otra carpeta y toca Pegar") })
        DropdownMenuItem(text = { Text("Cortar") }, onClick = { onDismiss(); store.clip = Clip(listOf(e.file), true); toast(ctx, "Cortado: abrí otra carpeta y toca Pegar") })
        if (!e.isDir) {
            DropdownMenuItem(text = { Text("Compartir") }, onClick = { onDismiss(); shareFile(ctx, e.file) })
        }
        DropdownMenuItem(text = { Text("Comprimir en ZIP") }, onClick = {
            onDismiss()
            scope.launch { toast(ctx, store.zip(listOf(e.file)) ?: "ZIP creado") }
        })
        if (!e.isDir && e.ext.equals("zip", ignoreCase = true)) {
            DropdownMenuItem(text = { Text("Ver contenido del ZIP") }, onClick = { onDismiss(); onZipView() })
            DropdownMenuItem(text = { Text("Extraer aquí") }, onClick = {
                onDismiss()
                scope.launch { toast(ctx, store.unzip(e.file) ?: "Extraído") }
            })
        }
        if (!e.isDir && e.ext.equals("pdf", ignoreCase = true)) {
            DropdownMenuItem(text = { Text("Enseñar al amigo") }, onClick = {
                onDismiss()
                scope.launch {
                    store.busy = "El amigo está leyendo ${e.file.name}…"
                    val r = try { store.saber.aprender(e.file) } finally { store.busy = null }
                    toast(ctx, r)
                }
            })
        }
        DropdownMenuItem(text = { Text("Información") }, onClick = { onDismiss(); onInfo() })
        DropdownMenuItem(text = { Text("Eliminar (a la papelera)") }, onClick = {
            onDismiss()
            scope.launch {
                if (store.moveToTrash(e.file)) toast(ctx, "Movido a la papelera")
                else toast(ctx, "No se pudo eliminar")
            }
        })
    }
}

/** Icono del botón de vista y orden (tres rayitas con perillas, como en el Gestor de archivos). */
@Composable
private fun ViewSortIcon() {
    val c = LocalContentColor.current
    Canvas(Modifier.size(22.dp)) {
        val sw = 1.8.dp.toPx()
        val ys = listOf(0.25f, 0.5f, 0.75f)
        val ks = listOf(0.65f, 0.3f, 0.55f)
        for (i in 0..2) {
            val y = size.height * ys[i]
            drawLine(c, Offset(size.width * 0.08f, y), Offset(size.width * 0.92f, y), strokeWidth = sw)
            drawCircle(c, 3.2.dp.toPx(), Offset(size.width * ks[i], y))
        }
    }
}

/** Un archivo o carpeta en la vista de cuadrícula o circular: miniatura (o ícono) arriba y el nombre abajo. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryTile(
    e: Entry,
    circle: Boolean,
    selected: Boolean,
    onLongClick: () -> Unit,
    onClick: () -> Unit,
    onMenu: (() -> Unit)?,
    menu: @Composable () -> Unit
) {
    val shape = if (circle) CircleShape else RoundedCornerShape(10.dp)
    Column(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, shape) else Modifier),
                contentAlignment = Alignment.Center
            ) {
                when {
                    e.isDir -> FolderIcon(if (circle) 34.dp else 40.dp)
                    Thumbs.supports(e.kind) -> {
                        Thumb(e, Modifier.fillMaxSize()) { FileIcon(false, e.kind, e.ext) }
                        if (e.kind == Kind.VID) Text("▶", color = Color.White, fontSize = 20.sp)
                    }
                    else -> FileIcon(false, e.kind, e.ext)
                }
                if (selected) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)))
            }
            Box(Modifier.align(Alignment.TopEnd)) {
                if (onMenu != null) {
                    Box(Modifier.size(28.dp).clickable(onClick = onMenu), contentAlignment = Alignment.Center) {
                        Text(
                            "⋮", color = Color.White, fontSize = 16.sp,
                            modifier = Modifier.background(Color(0x99000000), CircleShape).padding(horizontal = 6.dp)
                        )
                    }
                }
                menu()
            }
        }
        Text(
            e.name, minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,   // siempre 2 líneas: todas las fichas miden igual
            fontSize = 11.sp, lineHeight = 13.sp, modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
        )
    }
}

/** Hoja de "Vista y orden": cómo se ven los archivos y por qué criterio se ordenan. */
@Composable
fun ViewSortDialog(store: Store, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
        title = { Text("Vista y orden") },
        text = {
            Column {
                Text("Ver", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                ViewMode.values().forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setView(m) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.viewMode == m, onClick = { store.setView(m) })
                        Text(m.label)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("Ordenar", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                SortBy.values().forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(o, store.sortAsc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortBy == o, onClick = { store.setSort(o, store.sortAsc) })
                        Text(o.label)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                listOf(true to "Ascendente (A→Z, antiguo→nuevo, chico→grande)", false to "Descendente").forEach { (asc, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(store.sortBy, asc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortAsc == asc, onClick = { store.setSort(store.sortBy, asc) })
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    )
}
