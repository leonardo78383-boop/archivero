package com.archivero

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ───────────── El diccionario del amigo: lo que TÚ le enseñas que significa cada palabra ─────────────
//
// Documents/Amigo/diccionario/diccionario.json   (y diccionario.txt, la versión para leer)
//
// El amigo no deduce significados: los guarda cuando se los dices («casa significa lugar donde se vive») y después los usa al
// responder, al relacionar palabras de los PDF y de la pantalla, y en el índice `conciencia.json`.
// Solo se escribe lo que el usuario enseña explícitamente. Nunca se borra nada sin que se lo pidas («olvida la palabra …»).

/** No se pudo abrir o guardar el diccionario. [lleno] = ya no caben más palabras. */
class DiccionarioError(val lleno: Boolean, msg: String) : IOException(msg)

object Diccionario {
    const val ARCHIVO = "diccionario.json"
    const val TEXTO = "diccionario.txt"
    const val MAX = 5000
    private const val MAX_SIGNIFICADO = 300

    class Entrada(val palabra: String, val significado: String, val cuando: Long)

    /** [anterior] = lo que decía antes si la palabra ya existía (se cambió su significado). */
    class Guardado(val entrada: Entrada, val anterior: String?)

    private val ES = Locale("es")
    private val lock = Any()
    private val mapa = LinkedHashMap<String, Entrada>()      // clave (minúsculas) -> entrada
    private var cargadoDe: String? = null                    // de qué carpeta se leyó (si cambia, se vuelve a leer)
    @Volatile private var claves: Set<String> = emptySet()   // copia para preguntar sin esperar al disco (hilo principal)

    private fun clave(p: String) = p.lowercase(ES)
    private fun sa(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun carpeta(raiz: File) = File(raiz, Conciencia.DICCIONARIO)

    // ───────────── Entrada del usuario ─────────────

    private val PREGUNTA = setOf("que", "cual", "cuales", "como", "quien", "quienes", "donde", "cuando", "cuanto", "cuantos")
    private val SUELTAS = setOf("eso", "esto", "aquello", "ello", "lo", "mi", "tu", "su", "el", "la", "los", "las", "un", "una", "yo", "vos", "me", "te", "se")

    private fun quitarBordes(raw: String): String =
        raw.replace(Regex("\\s+"), " ").trim().trim('"', '\'', '«', '»', '¿', '?', '¡', '!', '.', ',', ':', ';', ' ')

    /** La palabra (o expresión de hasta 3 palabras) limpia, o null si no parece una palabra («qué», «esto», una frase…). */
    fun limpiarPalabra(raw: String): String? {
        val p = quitarBordes(raw)
        if (p.length < 2 || p.length > 40) return null
        val toks = p.split(' ')
        if (toks.size > 3) return null
        if (toks.any { t -> t.none { it.isLetterOrDigit() } }) return null
        fun malo(t: String): Boolean {
            val m = t.lowercase(ES)
            val k = sa(m)
            return k in PREGUNTA || k in SUELTAS || m in STOP || k in STOP
        }
        if (malo(toks.first()) || malo(toks.last())) return null
        return p
    }

    /** El significado limpio y con tope de largo, o null si queda vacío. */
    fun limpiarSignificado(raw: String): String? {
        var s = raw.replace(Regex("\\s+"), " ").trim().trim('"', '«', '»', ' ').trimEnd('.', ' ')
        if (s.length < 3) return null
        if (s.length > MAX_SIGNIFICADO) s = s.take(MAX_SIGNIFICADO).trimEnd() + "…"
        return s
    }

    // ───────────── Disco ─────────────

    /** Lee el diccionario si todavía no se leyó de esta carpeta. Llamar con el candado tomado. Lanza si no se puede LEER. */
    private fun asegurar(raiz: File) {
        if (cargadoDe == raiz.path) return
        mapa.clear()
        claves = emptySet()
        val f = File(carpeta(raiz), ARCHIVO)
        if (f.isFile) {
            // Un error al LEER (SD sin montar, sin permiso) no se toma por archivo vacío: no se carga nada y se reintenta luego.
            val txt = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { throw DiccionarioError(false, "no se pudo leer") }
            try {
                val arr = JSONObject(txt).optJSONArray("palabras") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val p = o.optString("p")
                    val s = o.optString("s")
                    if (p.isNotBlank() && s.isNotBlank()) mapa[clave(p)] = Entrada(p, s, o.optLong("t", 0L))
                }
            } catch (e: JSONException) {
                // Solo un JSON realmente roto: se respalda y se empieza vacío.
                mapa.clear()
                val bak = File(f.parentFile, "diccionario.danado." + System.currentTimeMillis() + ".json")
                try { f.copyTo(bak, overwrite = false) } catch (e2: Exception) { throw DiccionarioError(false, "no se pudo respaldar") }
            }
        }
        claves = HashSet(mapa.keys)
        cargadoDe = raiz.path
    }

    private fun escribir(dest: File, contenido: String) {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.writeText(contenido, Charsets.UTF_8)
        if (!tmp.renameTo(dest)) {
            dest.writeText(contenido, Charsets.UTF_8)
            tmp.delete()
        }
    }

    /** Escribe diccionario.json (y la versión legible). Lanza si no se pudo escribir el JSON. */
    private fun guardar(raiz: File) {
        val dir = carpeta(raiz)
        if (!dir.isDirectory && !dir.mkdirs()) throw IOException("no se pudo crear la carpeta")
        val arr = JSONArray()
        for (e in mapa.values) arr.put(JSONObject().put("p", e.palabra).put("s", e.significado).put("t", e.cuando))
        val o = JSONObject().put("version", 1).put("actualizado", System.currentTimeMillis()).put("palabras", arr)
        escribir(File(dir, ARCHIVO), o.toString())
        try {
            val sb = StringBuilder("Diccionario del amigo\nActualizado: ")
                .append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
                .append("\nPalabras con significado: ").append(mapa.size).append("\n\n")
            for (e in mapa.values.sortedBy { sa(it.palabra.lowercase(ES)) }) sb.append(e.palabra).append(" — ").append(e.significado).append('\n')
            escribir(File(dir, TEXTO), sb.toString())
        } catch (e: Exception) {
            // La versión legible es un extra: si falla, lo importante (el JSON) ya quedó guardado.
        }
    }

    // ───────────── Lo que usa el resto de la app ─────────────

    /** Lee el diccionario del disco (idempotente). Nunca lanza: si no se puede, se reintenta en la próxima llamada. */
    fun cargar(raiz: File) {
        synchronized(lock) { try { asegurar(raiz) } catch (e: Exception) { } }
    }

    /** Cuántas palabras con significado tiene (en memoria; no toca el disco). */
    fun total(): Int = claves.size

    /** ¿Ya tiene significado para esta palabra? Solo mira la memoria, así que se puede llamar desde el hilo principal. */
    fun sabe(palabra: String): Boolean {
        val k = clave(quitarBordes(palabra))
        return k in claves
    }

    fun buscar(raiz: File, raw: String): Entrada? = synchronized(lock) {
        try { asegurar(raiz) } catch (e: Exception) { return@synchronized null }
        val q = clave(quitarBordes(raw))
        mapa[q] ?: run {
            val qs = sa(q)
            mapa.entries.firstOrNull { sa(it.key) == qs }?.value
        }
    }

    /**
     * Guarda (o cambia) el significado de una palabra. Null si lo recibido no sirve (no es una palabra o no hay significado).
     * Lanza [DiccionarioError] si no se puede abrir o guardar; en ese caso no queda nada a medias.
     */
    fun ensenar(raiz: File, palabraRaw: String, significadoRaw: String): Guardado? {
        val p = limpiarPalabra(palabraRaw) ?: return null
        val s = limpiarSignificado(significadoRaw) ?: return null
        return synchronized(lock) {
            asegurar(raiz)
            val k0 = clave(p)
            val qs = sa(k0)
            val k = if (k0 in mapa) k0 else (mapa.keys.firstOrNull { sa(it) == qs } ?: k0)   // «cancion» y «canción» son la misma
            val antes = mapa[k]
            if (antes == null && mapa.size >= MAX) throw DiccionarioError(true, "lleno")
            val nueva = Entrada(p, s, System.currentTimeMillis())
            mapa[k] = nueva
            claves = HashSet(mapa.keys)
            try {
                guardar(raiz)
            } catch (e: Exception) {
                if (antes == null) mapa.remove(k) else mapa[k] = antes
                claves = HashSet(mapa.keys)
                throw DiccionarioError(false, "no se pudo guardar")
            }
            Guardado(nueva, antes?.significado)
        }
    }

    /** Quita una palabra (solo si el usuario lo pide). Devuelve lo que se quitó, o null si no estaba. */
    fun olvidar(raiz: File, raw: String): Entrada? = synchronized(lock) {
        asegurar(raiz)
        val q = clave(quitarBordes(raw))
        val k = if (q in mapa) q else mapa.keys.firstOrNull { sa(it) == sa(q) }
        if (k == null) return@synchronized null
        val e = mapa.remove(k)!!
        claves = HashSet(mapa.keys)
        try {
            guardar(raiz)
        } catch (ex: Exception) {
            mapa[k] = e
            claves = HashSet(mapa.keys)
            throw DiccionarioError(false, "no se pudo guardar")
        }
        e
    }

    /**
     * Para `conciencia.json`: cuántas palabras tiene y cuáles de ellas también conoce por los PDF o vio en la pantalla
     * (con cuántas veces en cada lado). Null si no se pudo leer.
     */
    fun paraIndice(raiz: File, pdf: Map<String, Int>, pantalla: Map<String, Int>): JSONObject? {
        val lista = synchronized(lock) {
            try { asegurar(raiz) } catch (e: Exception) { return null }
            mapa.values.toList()
        }
        val arr = JSONArray()
        var conectadas = 0
        for (e in lista) {
            val k = clave(e.palabra)
            val a = pdf[k] ?: 0
            val b = pantalla[k] ?: 0
            if (a > 0 || b > 0) conectadas++
            if (arr.length() < 100) arr.put(JSONObject().put("palabra", e.palabra).put("pdf", a).put("pantalla", b))
        }
        return JSONObject().put("palabras", lista.size).put("conectadas", conectadas).put("detalle", arr)
    }
}
