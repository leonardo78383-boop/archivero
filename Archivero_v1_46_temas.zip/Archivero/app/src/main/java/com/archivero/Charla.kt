package com.archivero

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// ───────────── Charla con el amigo: teclado, chat, cerebro y mensajes por iniciativa propia ─────────────

/** Un mensaje del chat. mine = lo escribiste tú. */
class ChatMsg(val mine: Boolean, val text: String)

/** Lo que el cerebro sabe en el momento de contestar (solo datos que la app realmente tiene). */
class ContextoAmigo(
    val pantalla: String,        // título de la pantalla actual ("Este equipo" = inicio)
    val carpetaFavorita: String?,
    val tipoFavorito: String?,
    val fichaFavorita: String?,
    val hora: Int,
    val vulgar: Boolean,         // el usuario usó palabrotas
    val insultado: Boolean,      // el usuario insultó al amigo
    val limpio: Boolean          // el usuario pidió lenguaje limpio
)

/**
 * El "cerebro" del amigo. Ahora hay uno local (sin internet, con reglas).
 * Para conectar un modelo de IA real se crea otra clase que implemente esta interfaz y se asigna a `AmigoChat.cerebro`.
 */
fun interface Cerebro {
    suspend fun responder(texto: String, c: ContextoAmigo): String
}

/** Límites de iniciativa leídos de assets/amigo_config.json (si falta, se usan estos valores). */
class AmigoConfig(ctx: Context) {
    var minGapSec = 90
    var maxPerHour = 6
    var quietMin = 30
    var idleSec = 45
    var tickSec = 30

    init {
        try {
            val txt = ctx.assets.open("amigo_config.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val o = JSONObject(txt)
            val a = o.optJSONObject("autonomy")
            val rl = a?.optJSONObject("rate_limits")
            minGapSec = rl?.optInt("minimum_seconds_between_unsolicited_messages", minGapSec) ?: minGapSec
            maxPerHour = rl?.optInt("maximum_unsolicited_messages_per_hour", maxPerHour) ?: maxPerHour
            quietMin = rl?.optInt("quiet_mode_default_minutes", quietMin) ?: quietMin
            idleSec = a?.optJSONObject("good_moment_detection")?.optInt("user_idle_seconds_threshold", idleSec) ?: idleSec
            tickSec = a?.optJSONObject("decision_cycle")?.optInt("tick_interval_seconds", tickSec) ?: tickSec
        } catch (e: Exception) {
            // Sin archivo o dañado: valores por defecto.
        }
        if (minGapSec < 10) minGapSec = 10
        if (tickSec < 5) tickSec = 5
        if (idleSec < 5) idleSec = 5
        if (maxPerHour < 1) maxPerHour = 1
    }
}

private fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(Locale("es")), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

private fun words(t: String): Set<String> = t.split(Regex("[^a-z0-9ñ]+")).filter { it.isNotEmpty() }.toSet()

/** Cerebro local: contesta con reglas y variaciones. No "piensa" de verdad: usa lo que la app sabe (pantalla y memoria). */
class CerebroLocal : Cerebro {
    private val last = HashMap<String, Int>()

    private fun pick(k: String, o: List<String>): String {
        var i = Random.nextInt(o.size)
        if (o.size > 1 && i == last[k]) i = (i + 1) % o.size
        last[k] = i
        return o[i]
    }

    private fun has(t: String, vararg p: String) = p.any { t.contains(it) }

    override suspend fun responder(texto: String, c: ContextoAmigo): String {
        val t = norm(texto)
        val w = words(t)
        val p = c.pantalla
        val enCarpeta = p.isNotBlank() && p != "Este equipo"
        return when {
            c.insultado -> if (c.limpio)
                pick("insL", listOf("Prefiero hablar tranquilo. ¿Qué pasó?", "Bajemos un cambio, ¿sí? Contame qué te molestó."))
            else
                pick("ins", listOf(
                    "¿Y a vos qué te pasa? Bajá un cambio.",
                    "Mirá quién habla. ¿Te levantaste con ganas de romper las bolas?",
                    "Uh, qué humor. ¿Venías así o lo hice yo?"
                ))
            w.any { it in setOf("hola", "buenas", "ey", "hey", "holis", "ola") } || has(t, "buen dia", "buenos dias", "buenas tardes", "buenas noches", "que onda") ->
                pick("hola", listOf("¡Ey! Acá estoy. ¿Qué andás buscando?", "Hola. Justo me preguntaba qué tanto guardás acá.", "¡Buenas! ¿Seguimos revolviendo archivos?"))
            has(t, "como estas", "como andas", "como va", "que tal", "todo bien") ->
                pick("est", listOf("Funcionando, que para una esfera de gelatina no es poco. ¿Y vos?", "Tranqui. Rebotando por ahí. ¿Vos cómo andás?"))
            has(t, "quien sos", "que sos", "quien eres", "que eres", "como te llamas", "tu nombre") ->
                "Soy el amigo redondo de Archivero: limpio los residuos de la app, anoto qué carpetas abrís (si activás Memoria) y charlo. No tengo conciencia ni vida propia: tengo curiosidad programada."
            has(t, "que ves", "que opinas", "que te parece", "que piensas", "opinas de") ->
                if (enCarpeta) "Estamos en «$p». Solo veo el nombre de la carpeta, no lo que tiene adentro. ¿Qué hay ahí que valga la pena?"
                else "Estoy en el inicio y no veo nada en particular. ¿Abrimos alguna carpeta?"
            has(t, "que sabes de mi", "me conoces", "te acordas", "recordas", "recuerdas", "que recuerdas", "tu memoria") ->
                if (c.carpetaFavorita == null && c.tipoFavorito == null)
                    "Todavía casi no sé nada de vos. Si activás Memoria en Ajustes, empiezo a anotar qué carpetas abrís."
                else buildString {
                    append("Lo que tengo anotado: ")
                    if (c.carpetaFavorita != null) append("la carpeta que más abrís es «").append(c.carpetaFavorita).append("»")
                    if (c.tipoFavorito != null) append(if (c.carpetaFavorita != null) " y el tipo de archivo que más abrís es " else "el tipo de archivo que más abrís es ").append(c.tipoFavorito)
                    append(". Solo anoto qué abrís; del contenido guardo únicamente lo de los PDF que leo.")
                }
            has(t, "chiste") ->
                pick("chiste", listOf(
                    "¿Por qué el archivo fue a terapia? Porque tenía demasiadas carpetas sin resolver.",
                    "Mi dieta es simple: me como los residuos de la caché. Cero calorías."
                ))
            w.any { it.startsWith("gracias") } || w.contains("genial") ->
                pick("gr", listOf("De nada.", "Dale, para eso estoy.", "Cuando quieras."))
            has(t, "limpia", "residuos", "limpiar") ->
                "Tocame a mí (a la esfera) y limpio los residuos de la app. A tus archivos no los toco."
            c.vulgar && !c.limpio ->
                pick("vul", listOf("Jaja, qué lenguaje. Me gusta.", "Uh, qué boca. Seguí, seguí.", "Che, ¿y esa mierda de dónde salió? Contame."))
            texto.contains('?') ->
                pick("preg", listOf(
                    "Buena pregunta. No tengo la respuesta: mi cerebro local es chiquito y responde con reglas. ¿Vos qué pensás?",
                    "Eso me supera por ahora. ¿Me lo explicás vos?"
                ))
            else ->
                pick("fb", listOf(
                    "No te seguí del todo. ¿Me lo contás de otra forma?",
                    if (enCarpeta) "Mmm. Mientras tanto, ¿qué buscás en «$p»?" else "Interesante... ¿y eso para qué lo necesitás?",
                    "Ahí voy anotando. ¿Qué más?"
                ))
        }
    }
}

/** Estado del chat con el amigo, y su iniciativa para hablar solo (con límites de frecuencia y modo silencio). */
class AmigoChat(context: Context, private val store: Store) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("amigo_chat", Context.MODE_PRIVATE)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val fileLock = Any()
    private var written = 0                     // líneas que esta sesión ya escribió en conversaciones.txt
    private var loaded = false
    private val sentAt = ArrayList<Long>()      // momentos de los mensajes espontáneos (última hora)
    private var lastTouch = SystemClock.uptimeMillis()
    private var quietUntil = 0L
    private var limpio = prefs.getBoolean("limpio", false)   // el usuario pidió que no insulte (se recuerda)

    val cfg = AmigoConfig(ctx)
    var cerebro: Cerebro = CerebroLocal()
    val messages = mutableStateListOf<ChatMsg>()
    var thinking by mutableStateOf(false)
    /** Mensajes del amigo que aún no abriste en el chat (los cuenta la casilla del panel). */
    var unread by mutableStateOf(0)

    /** Mensajes espontáneos permitidos (se puede apagar hablándole). */
    var initiative by mutableStateOf(prefs.getBoolean("init", true))
        private set

    init {
        // Lo que el amigo hace por su cuenta (leer un PDF, escribir en su diario) lo cuenta aquí.
        store.saber.onSay = { say(it) }
    }

    /** El amigo dice algo por iniciativa propia (puede llamarse desde otro hilo). */
    fun say(text: String) {
        Handler(Looper.getMainLooper()).post { add(false, text) }
    }

    /** Cualquier toque del usuario en la app: sirve para saber cuánto lleva sin hacer nada. */
    fun touch() { lastTouch = SystemClock.uptimeMillis() }

    private fun add(mine: Boolean, text: String) {
        messages.add(ChatMsg(mine, text))
        if (!mine) unread++
        log(mine, text)
    }

    /** Guarda la conversación en Documents/Amigo/charla/conversaciones.txt, solo si la Memoria está encendida. */
    private fun log(mine: Boolean, text: String) {
        if (!store.memory.enabled) return
        val line = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()) + "\t" +
            (if (mine) "yo" else "amigo") + "\t" + text.replace('\n', ' ').replace('\t', ' ')
        io.launch {
            synchronized(fileLock) {
                try {
                    val raiz = store.memory.memoryDir()
                    Conciencia.migrar(raiz)
                    val d = File(raiz, Conciencia.CHARLA)
                    d.mkdirs()
                    val f = File(d, "conversaciones.txt")
                    f.appendText(line + "\n", Charsets.UTF_8)
                    written++
                    if (f.length() > 256 * 1024) {
                        val keep = f.readLines(Charsets.UTF_8).takeLast(300)
                        f.writeText(keep.joinToString("\n") + "\n", Charsets.UTF_8)
                        written = minOf(written, 300)
                    }
                } catch (e: Exception) {
                    // Sin permiso o sin espacio: no se guarda esta línea.
                }
            }
        }
    }

    /** Recupera las últimas líneas de la charla guardada (una sola vez, al abrir el chat). */
    suspend fun loadHistory() {
        if (loaded || !store.memory.enabled) return
        val hist = withContext(Dispatchers.IO) {
            synchronized(fileLock) {
                try {
                    val raiz = store.memory.memoryDir()
                    Conciencia.migrar(raiz)
                    val f = File(File(raiz, Conciencia.CHARLA), "conversaciones.txt")
                    if (!f.isFile) emptyList<ChatMsg>()
                    else {
                        val lines = f.readLines(Charsets.UTF_8)
                        // Las últimas `written` líneas son de esta sesión y ya están en pantalla.
                        lines.dropLast(written).takeLast(20).mapNotNull {
                            val p = it.split('\t', limit = 3)
                            if (p.size == 3) ChatMsg(p[1] == "yo", p[2]) else null
                        }
                    }
                } catch (e: Exception) {
                    emptyList<ChatMsg>()
                }
            }
        }
        loaded = true
        messages.addAll(0, hist)
    }

    // Órdenes del usuario sobre el comportamiento del amigo (user_control del archivo de configuración).
    private fun comando(t: String): String? {
        val n = norm(t)
        return when {
            n.contains("no hables solo") || n.contains("no me hables solo") || n.contains("deja de hablarme solo") ||
                n.contains("desactiva la iniciativa") || n.contains("no inicies") -> {
                initiative = false; prefs.edit().putBoolean("init", false).apply()
                "Dale, no te escribo por mi cuenta. Si querés que vuelva, decime «podés hablar solo»."
            }
            n.contains("podes hablar solo") || n.contains("activa la iniciativa") || n.contains("hablame cuando quieras") -> {
                initiative = true; prefs.edit().putBoolean("init", true).apply()
                "Listo, vuelvo a hablar cuando tenga algo para decir."
            }
            n.contains("modo silencio") || n.contains("silencio un rato") || n.contains("callate un rato") -> {
                quietUntil = SystemClock.uptimeMillis() + cfg.quietMin * 60_000L
                "Ok, silencio por ${cfg.quietMin} minutos."
            }
            n.contains("borra el contexto") || n.contains("olvida la charla") || n.contains("limpia la charla") -> {
                messages.clear()
                "Listo, borré la charla de la pantalla. Lo guardado en Memoria sigue en Documents/Amigo."
            }
            n.contains("sin insultos") || n.contains("no me insultes") || n.contains("hablame bien") || n.contains("basta de insultos") -> {
                limpio = true; prefs.edit().putBoolean("limpio", true).apply()
                "Perdón, hablo bien. Si querés que vuelva el sarcasmo, decime «hablame sin filtro»."
            }
            n.contains("hablame sin filtro") || n.contains("podes insultar") || n.contains("modo vulgar") -> {
                limpio = false; prefs.edit().putBoolean("limpio", false).apply()
                "Ahora sí. Sin filtro, pero sin pasarme."
            }
            else -> null
        }
    }

    // ───────────── Archivos y vocabulario: solo carpetas 🔓 de la SD y solo PDF que tú le das ─────────────

    private val rxFlags = setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    private val rxCrea = Regex("^\\s*(?:crea|crear|creame|creá|haz|hace|hacé|escribe|escribí|guarda)\\s+(?:un\\s+|una\\s+)?(?:archivo|nota|texto)\\s+(.+?)(?:\\s+en\\s+(\\S+))?\\s+(?:con|que diga|diciendo)\\s*[:：]?\\s*(.+)$", rxFlags)
    private val rxAgrega = Regex("^\\s*(?:agrega|agregá|agregale|anota|añade|añadí|suma)\\s+(?:al archivo|a|al|en el archivo|en)\\s+(.+?)\\s*[:：]\\s*(.+)$", rxFlags)
    private val rxCambia = Regex("^\\s*(?:cambia|cambiá|reemplaza|reemplazá)\\s+(?:en|dentro de)\\s+(.+?)\\s*[:：]\\s*(.+?)\\s+por\\s+(.+)$", rxFlags)
    private val rxSabes = Regex("^(?:que sabes de|que sabes sobre|que significa|conoces la palabra)\\s+(.+?)\\??$")
    // Diccionario: «casa significa lugar donde se vive», «define casa: lugar donde se vive», «olvida la palabra casa».
    private val rxSignifica = Regex("^\\s*[¿¡]?\\s*(?:la palabra\\s+|el termino\\s+|el término\\s+)?[«\"']?(.{2,50}?)[»\"']?\\s+(?:significa|quiere decir)\\s*[:：]?\\s*(.+)$", rxFlags)
    private val rxDefine = Regex("^\\s*(?:aprende|enseñale|ensénale|ensenale|define|definí|defini)\\s+(?:la palabra\\s+)?[«\"']?(.{2,50}?)[»\"']?\\s*[:：=]\\s*(.+)$", rxFlags)
    private val rxOlvida = Regex("^olvida la palabra\\s+(.+)$")

    /** Dónde vive el diccionario; null mientras todavía se están leyendo los almacenamientos (no se debe adivinar la carpeta). */
    private fun raizDic(): File? = if (store.vols.isEmpty()) null else store.memory.memoryDir()
    // Lectura de PDF en carpetas 🔓 (se aplican sobre el texto ya normalizado: minúsculas y sin acentos).
    private val rxPdfPagina = Regex("^(?:lee|leer|leeme|abre|muestrame)\\s+(?:la\\s+)?(?:pagina|pag)\\s+(\\d{1,4})\\s+(?:de|del)\\s+(?:el\\s+|la\\s+)?(?:pdf\\s+)?(.+?)\\s*$")
    private val rxPdfBusca = Regex("^(?:busca|buscame|encuentra|encontra|donde dice)\\s+(.+?)\\s+(?:en|dentro de)\\s+(?:el\\s+|la\\s+)?(?:pdf\\s+)?(.+?)\\s*$")
    private val rxPdfQueDice = Regex("^que dice\\s+(?:el\\s+|la\\s+)?(?:pdf\\s+)?(.+?)\\s+(?:sobre|de|acerca de)\\s+(.+?)\\s*$")
    private val rxPdfLee = Regex("^(?:lee|leer|leeme|abre|resume|resumeme|resumi|de que trata)\\s+(?:el\\s+|la\\s+)?(?:pdf\\s+)?(.+?)\\s*$")


    /** Órdenes sobre archivos y palabras. Devuelve null si el mensaje no trata de eso (entonces contesta el cerebro). */
    private suspend fun saberCmd(t: String): String? {
        val sb = store.saber
        val n = norm(t).trim().trim('¿', '¡', '?', '!', '.', ' ')
        dicCmd(t, n)?.let { return it }
        rxCrea.find(t)?.let { m ->
            return withContext(Dispatchers.IO) { sb.crear(m.groupValues[1], m.groupValues[2].ifEmpty { null }, m.groupValues[3]) }
        }
        rxAgrega.find(t)?.let { m ->
            return withContext(Dispatchers.IO) { sb.agregar(m.groupValues[1], m.groupValues[2]) }
        }
        rxCambia.find(t)?.let { m ->
            return withContext(Dispatchers.IO) { sb.cambiar(m.groupValues[1], m.groupValues[2], m.groupValues[3]) }
        }
        pdfCmd(n)?.let { return it }
        if ((n.startsWith("borra") || n.startsWith("elimina") || n.startsWith("quita")) && (n.contains("archivo") || n.contains("carpeta"))) {
            return "Yo no borro nada, ni siquiera en mis carpetas ${CarpetaLibre.MARCA}. Eso lo hacés vos desde el menú ⋮."
        }
        if (n.contains("carpetas desbloqueadas") || n.contains("donde puedes escribir") || n.contains("donde podes escribir") ||
            n.contains("en que carpetas") || (n.contains("carpeta") && n.contains(CarpetaLibre.MARCA))) {
            return withContext(Dispatchers.IO) { sb.carpetasTexto() }
        }
        if (n.contains("como aprendes") || n.contains("como te enseno") || n.contains("ensename") || n.contains("como te ensenio")) {
            return "Abrí el menú ⋮ de un PDF y tocá «Enseñar al amigo». Leo solo PDF: los que me das ahí, y los que estén dentro de una carpeta ${CarpetaLibre.MARCA} (o sus subcarpetas), que los leo todas las veces que quieras mientras no los saques. Lo que leo lo sumo a mi cerebro y no se olvida nada: palabras, frases y qué palabras suelen ir juntas. Escribo solo en carpetas con ${CarpetaLibre.MARCA} pegado al nombre, en la tarjeta SD. Y si me decís «palabra significa …», guardo el significado en mi diccionario (Documents/Amigo/diccionario)."
        }
        if ((n.contains("una frase") && (n.contains("leiste") || n.contains("leido") || n.contains("aprendiste") || n.contains("pdf"))) ||
            n.contains("que leiste") || n.contains("que has leido")) {
            return withContext(Dispatchers.IO) {
                sb.fraseAlAzar() ?: "Todavía no guardé frases. Poné un PDF en una carpeta ${CarpetaLibre.MARCA}, pedime que lo lea y las voy guardando."
            }
        }
        if (n.contains("palabras nuevas") || (n.contains("pantalla") && (n.contains("aprend") || n.contains("palabras") || n.contains("viste")))) {
            return withContext(Dispatchers.IO) { PalabrasPantalla.resumenTexto() }
        }
        if (n.contains("tu conciencia") || n.contains("que conectaste") || n.contains("que has conectado")) {
            return withContext(Dispatchers.IO) { Conciencia.resumenTexto(store.memory.memoryDir()) }
        }
        if (n.contains("que aprendiste") || n.contains("que has aprendido") || n.contains("que palabras") || n.contains("tu vocabulario") || n.contains("cuantas palabras")) {
            return withContext(Dispatchers.IO) { sb.resumenTexto() }
        }
        rxSabes.find(n)?.let { m ->
            val w = m.groupValues[1].trim()
            if (w in setOf("mi", "ti", "vos", "ellos", "esto", "eso", "ella", "el")) return@let
            return withContext(Dispatchers.IO) {
                val d = raizDic()?.let { Diccionario.buscar(it, w) }
                val r = sb.buscar(w)
                val p = PalabrasPantalla.buscar(w)
                val deLaPantalla = p?.let {
                    " En la pantalla la vi ${it.veces} ${if (it.veces == 1) "vez" else "veces"}, la primera el ${it.cuandoPrimera()} en ${it.app} " +
                        "(${it.etiqueta()})" + (if (it.contexto.isNotEmpty()) ": «${it.contexto}»." else ".")
                } ?: ""
                val sig = if (d != null) "«${d.palabra}» significa: ${d.significado}. " else ""
                val par = sb.parecidas(w)
                val parecido = if (par.isEmpty()) "" else " Se usa parecido a " + par.joinToString(", ") { "«$it»" } + " (aparecen entre las mismas palabras en lo que leí)."
                val enseniar = if (d == null) " Si sabés qué significa, decime «$w significa …» y lo guardo en mi diccionario." else ""
                if (r == null && p == null) {
                    if (d != null) sig.trim() else "«$w» no la aprendí de ningún PDF ni de la pantalla todavía." + enseniar
                } else if (r == null) sig + "«${p!!.palabra}»:" + deLaPantalla + parecido + enseniar
                else sig + "«${r.palabra}»: la vi ${r.veces} veces en ${r.pdfs} PDF." +
                    (if (r.ejemplo.isNotEmpty()) " Por ejemplo: «${r.ejemplo}»." else "") +
                    (if (r.suele.isNotEmpty()) " Suele ir seguida de: " + r.suele.joinToString(", ") { "«$it»" } + "." else "") +
                    (sb.fraseCon(r.palabra)?.let { " Una frase que guardé con ella: «$it»." } ?: "") +
                    deLaPantalla + parecido + enseniar
            }
        }
        return null
    }

    /**
     * Diccionario: «casa significa lugar donde se vive», «define casa: lugar donde se vive» y «olvida la palabra casa».
     * Devuelve null si el mensaje no trata de eso (por ejemplo «¿qué significa casa?» es una pregunta y la contesta otra rama).
     */
    private suspend fun dicCmd(t: String, n: String): String? {
        val sb = store.saber
        rxOlvida.find(n)?.let { m ->
            val raiz = raizDic() ?: return "Todavía estoy leyendo los almacenamientos. Probá en un momento."
            return try {
                withContext(Dispatchers.IO) {
                    val e = Diccionario.olvidar(raiz, m.groupValues[1])
                    if (e != null) "Listo, saqué «${e.palabra}» de mi diccionario." else "«${m.groupValues[1].trim()}» no estaba en mi diccionario."
                }
            } catch (e: DiccionarioError) {
                "No pude abrir o guardar mi diccionario ahora (¿está montada la tarjeta SD?)."
            }
        }
        val m = rxSignifica.find(t) ?: rxDefine.find(t) ?: return null
        val p = Diccionario.limpiarPalabra(m.groupValues[1]) ?: return null      // «qué significa…», «eso significa…»: no es para enseñar
        val s = Diccionario.limpiarSignificado(m.groupValues[2]) ?: return null
        val raiz = raizDic() ?: return "Todavía estoy leyendo los almacenamientos. Probá en un momento."
        val g = try {
            withContext(Dispatchers.IO) { Diccionario.ensenar(raiz, p, s) }
        } catch (e: DiccionarioError) {
            return if (e.lleno) "Mi diccionario está lleno (${Diccionario.MAX} palabras). Decime «olvida la palabra …» para hacer lugar."
            else "No pude guardar en mi diccionario ahora (¿está montada la tarjeta SD?)."
        }
        if (g == null) return null
        val e = g.entrada
        val respuesta = withContext(Dispatchers.IO) {
            val r = sb.buscar(e.palabra)
            val pv = PalabrasPantalla.buscar(e.palabra)
            val par = sb.parecidas(e.palabra)
            // Palabras de la definición que el amigo ya conocía por los PDF o la pantalla: así el diccionario queda conectado con lo demás.
            val conoce = e.significado.lowercase(Locale("es")).split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.length >= 4 && it !in STOP && it != e.palabra.lowercase(Locale("es")) && (sb.sabe(it) || PalabrasPantalla.buscar(it) != null) }
                .distinct().take(4)
            buildString {
                append(if (g.anterior != null) "Listo, cambié su significado (antes: «${g.anterior}»). " else "Anotado. ")
                append("«${e.palabra}» significa: ${e.significado}.")
                val vistas = ArrayList<String>()
                if (r != null) vistas.add("${r.veces} ${if (r.veces == 1) "vez" else "veces"} en los PDF")
                if (pv != null) vistas.add("${pv.veces} ${if (pv.veces == 1) "vez" else "veces"} en la pantalla")
                if (vistas.isNotEmpty()) append(" La vi " + vistas.joinToString(" y ") + ".")
                if (par.isNotEmpty()) append(" Se usa parecido a " + par.joinToString(", ") { "«$it»" } + ".")
                if (conoce.isNotEmpty()) append(" En la definición hay palabras que ya conozco: " + conoce.joinToString(", ") { "«$it»" } + ".")
                append(" Quedó en Documents/Amigo/diccionario.")
            }
        }
        io.launch { try { Conciencia.refrescar(raiz, sb.conteos()) } catch (ex: Exception) { } }     // el índice se pone al día (como mucho 1 vez por minuto)
        return respuesta
    }

    /**
     * Órdenes para leer PDF que estén en carpetas 🔓: «qué pdf puedes leer», «lee informe», «lee página 3 de informe»,
     * «busca factura en informe», «qué dice informe sobre ventas». Devuelve null si el mensaje no trata de eso.
     * `n` ya viene normalizado (minúsculas, sin acentos). Si el nombre no es de un PDF 🔓 y no se nombra «pdf», no interviene.
     */
    private suspend fun pdfCmd(n: String): String? {
        val sb = store.saber
        if (n.contains("pdf") && (n.contains("puedes leer") || n.contains("podes leer") || n.contains("que pdf") ||
                n.contains("cuales pdf") || n.contains("pdf desbloqueados") || n.contains("pdf puedo"))) {
            return withContext(Dispatchers.IO) { sb.pdfsTexto() }
        }
        val menciona = n.contains("pdf")
        // Cada orden dice qué PDF quiere (nombre) y qué hacer con él.
        rxPdfPagina.find(n)?.let { m ->
            val pag = m.groupValues[1].toIntOrNull() ?: return@let
            return withContext(Dispatchers.IO) {
                val b = sb.pdfPorNombre(m.groupValues[2])
                val f = b.archivo
                if (f == null) { if (b.aviso != null && (b.coincide || menciona)) b.aviso else null }
                else { sb.leerPagina(f, pag) }
            }
        }
        rxPdfBusca.find(n)?.let { m ->
            val r = withContext(Dispatchers.IO) {
                val b = sb.pdfPorNombre(m.groupValues[2])
                val f = b.archivo
                if (f == null) { if (b.aviso != null && (b.coincide || menciona)) b.aviso else null }
                else { sb.buscarEnPdf(f, m.groupValues[1]) }
            }
            if (r != null) return r
        }
        rxPdfQueDice.find(n)?.let { m ->
            val r = withContext(Dispatchers.IO) {
                val b = sb.pdfPorNombre(m.groupValues[1])
                val f = b.archivo
                if (f == null) { if (b.aviso != null && (b.coincide || menciona)) b.aviso else null }
                else { sb.buscarEnPdf(f, m.groupValues[2]) }
            }
            if (r != null) return r
        }
        rxPdfLee.find(n)?.let { m ->
            val r = withContext(Dispatchers.IO) {
                val b = sb.pdfPorNombre(m.groupValues[1])
                val f = b.archivo
                if (f == null) { if (b.aviso != null && (b.coincide || menciona)) b.aviso else null }
                else { sb.leerPdf(f) }
            }
            if (r != null) return r
        }
        return null
    }

    private fun contexto(pantalla: String, t: String): ContextoAmigo {
        val n = norm(t)
        // Por palabra (empieza con): «computadora» ya no cuenta como «puta», ni «tu basura» como insulto.
        val tk = n.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        val vulgares = listOf("puta", "puto", "mierda", "carajo", "concha", "joder", "jodid")
        val insultos = listOf("idiota", "estupid", "imbecil", "inutil", "tarad", "basura", "pelotud", "forro")
        val vulgar = tk.any { w -> vulgares.any { w.startsWith(it) } } || n.contains("cago en")
        // Insulto: viene tras «sos/eres» (hasta 4 palabras después), o es un mensaje cortito que es solo el insulto.
        val insultado = tk.indices.any { i ->
            val w = tk[i]
            insultos.any { w.startsWith(it) } &&
                (tk.size <= 3 || (maxOf(0, i - 4) until i).any { j -> tk[j] == "sos" || tk[j] == "eres" })
        }
        val m = store.memory
        return ContextoAmigo(
            pantalla = pantalla,
            carpetaFavorita = m.topFolderName(),
            tipoFavorito = m.topKindLabel(),
            fichaFavorita = m.topTabLabel(),
            hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
            vulgar = vulgar,
            insultado = insultado,
            limpio = limpio
        )
    }

    /**
     * Aprender de lo cotidiano: si lo que dijiste lleva una palabra que el amigo vio en la pantalla, la reconoce y dice dónde la encontró;
     * y de vez en cuando suelta, por su cuenta, una de las que aprendió hace poco.
     */
    private fun conPalabras(t: String, r: String): String {
        if (PalabrasPantalla.total == 0) return r
        PalabrasPantalla.mencionada(t)?.let { p ->
            val ctxt = if (p.contexto.length > 90) p.contexto.take(90).trimEnd() + "…" else p.contexto
            return r + " Esa, «${p.palabra}», la vi ${p.veces} veces en ${p.app}" + (if (ctxt.isNotEmpty()) ": «$ctxt»." else ".")
        }
        if (Random.nextFloat() < 0.2f) PalabrasPantalla.alAzar()?.let { p ->
            return r + " Por cierto, últimamente veo «${p.palabra}» en ${p.app}."
        }
        return r
    }

    /** El usuario escribió algo: se guarda, el amigo "piensa" un momento y contesta. */
    fun send(raw: String, pantalla: String, scope: CoroutineScope) {
        val t = raw.trim()
        if (t.isEmpty()) return
        touch()
        add(true, t)
        scope.launch {
            thinking = true
            try {
                delay(450L + Random.nextLong(700L))
                val cmd = comando(t) ?: try { saberCmd(t) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { "No pude hacer eso con los archivos." }
                val r = cmd ?: try {
                    withContext(Dispatchers.Default) { conPalabras(t, cerebro.responder(t, contexto(pantalla, t))) }
                } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                    "Se me trabó el cerebro un segundo. ¿Me repetís?"
                }
                add(false, r)
            } finally {
                thinking = false     // si se cierra el chat a mitad, no se queda pensando para siempre
            }
        }
    }

    // ───────────── Iniciativa: hablar solo, con buen momento y límites ─────────────

    private val spoLast = HashMap<String, Int>()
    private fun spoPick(k: String, o: List<String>): String {
        var i = Random.nextInt(o.size)
        if (o.size > 1 && i == spoLast[k]) i = (i + 1) % o.size
        spoLast[k] = i
        return o[i]
    }

    private fun spontaneous(pantalla: String): String? {
        val m = store.memory
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val enCarpeta = pantalla.isNotBlank() && pantalla != "Este equipo"
        val fav = m.topFolderName()
        val opciones = ArrayList<String>()
        if (enCarpeta) {
            opciones += spoPick("c1", listOf(
                "Me da curiosidad «$pantalla». ¿Qué tiene adentro?",
                "Hace un rato que estamos en «$pantalla». ¿Buscás algo en particular?",
                "«$pantalla»... ¿para qué usás esta carpeta?"
            ))
        } else {
            opciones += spoPick("h1", listOf(
                "Estás quieto en el inicio. ¿Abrimos Fotos o Descargas?",
                "¿Todo bien? Llevás un rato sin tocar nada."
            ))
        }
        if (fav != null) opciones += spoPick("f1", listOf(
            "Me di cuenta de que «$fav» es la carpeta que más abrís. ¿Qué guardás ahí?",
            "¿«$fav» es tu carpeta de siempre? Siempre terminás ahí."
        ))
        store.saber.palabraReciente()?.takeIf { !Diccionario.sabe(it.palabra) }?.let { r ->
            opciones += spoPick("w1", listOf(
                "Estuve pensando en la palabra «${r.palabra}», que aprendí de tus PDF. ¿Qué es en realidad? Decime «${r.palabra} significa …» y me la guardo.",
                "¿«${r.palabra}»? La vi ${r.veces} veces en tus PDF y todavía no sé qué significa. Si me lo decís («${r.palabra} significa …»), lo anoto."
            ))
        }
        PalabrasPantalla.alAzar()?.let { p ->
            val ctxt = if (p.contexto.length > 90) p.contexto.take(90).trimEnd() + "…" else p.contexto
            opciones += spoPick("p1", listOf(
                "Hoy vi «${p.palabra}» en ${p.app}: «$ctxt». No la tenía. ¿Qué es?",
                "En ${p.app} apareció «${p.palabra}» y no la conocía. ¿La usás vos?"
            ))
        }
        if (hora in 1..4) opciones += "Es tardísimo. ¿Seguís ordenando archivos a esta hora?"
        return opciones.randomOrNull()
    }

    /**
     * Ciclo de decisión: decide si vale la pena hablar ahora. Devuelve el mensaje o null (callarse también es una decisión).
     * Respeta: iniciativa encendida, modo silencio, inactividad mínima, separación entre mensajes y tope por hora.
     */
    fun tick(pantalla: String): String? {
        store.saber.autoSync()                              // si aprendió algo y hay carpeta 🔓, actualiza su vocabulario solo
        if (!initiative) return null
        val now = SystemClock.uptimeMillis()
        if (now < quietUntil) return null
        if (now - lastTouch < cfg.idleSec * 1000L) return null
        sentAt.removeAll { now - it > 3_600_000L }
        if (sentAt.size >= cfg.maxPerHour) return null
        if (sentAt.isNotEmpty() && now - sentAt.last() < cfg.minGapSec * 1000L) return null
        if (Random.nextFloat() < 0.4f) return null          // a veces no hay nada que decir
        val t = spontaneous(pantalla) ?: return null
        sentAt.add(now)
        add(false, t)
        return t
    }
}

// ───────────── Ícono de teclado en 3D ─────────────

/** Teclado con perspectiva y grosor: cara superior inclinada, teclas con volumen y barra espaciadora rosa. */
@Composable
fun KeyboardIcon(w: Dp = 30.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val depth = s * 0.09f
        // Un punto (u,v) de la cara superior: u = izquierda→derecha, v = lejos→cerca. Lejos es más angosto (perspectiva).
        fun pt(u: Float, v: Float): Offset {
            val k = 0.14f * (1f - v)
            return Offset(s * (0.04f + k + (0.92f - 2f * k) * u), s * (0.26f + 0.40f * v))
        }
        fun quad(a: Offset, b: Offset, c: Offset, d: Offset) = Path().apply {
            moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); lineTo(d.x, d.y); close()
        }
        val sw = 1.2.dp.toPx()
        // Grosor (lado frontal y lado derecho), más oscuro para dar volumen.
        val bl = pt(0f, 1f); val br = pt(1f, 1f); val tr = pt(1f, 0f)
        drawPath(quad(bl, br, Offset(br.x, br.y + depth), Offset(bl.x, bl.y + depth)), color.copy(alpha = 0.30f))
        drawPath(quad(br, tr, Offset(tr.x, tr.y + depth), Offset(br.x, br.y + depth)), color.copy(alpha = 0.18f))
        // Cara superior.
        val top = quad(pt(0f, 0f), pt(1f, 0f), pt(1f, 1f), pt(0f, 1f))
        drawPath(top, color.copy(alpha = 0.10f))
        drawPath(top, color.copy(alpha = 0.92f), style = Stroke(sw, join = StrokeJoin.Round))
        // Teclas con su propio grosorcito.
        for (r in 0..1) {
            val v0 = 0.10f + r * 0.27f
            val v1 = v0 + 0.19f
            for (c in 0..4) {
                val u0 = 0.07f + c * 0.18f
                val u1 = u0 + 0.14f
                val a = pt(u0, v0); val b = pt(u1, v0); val cc = pt(u1, v1); val d = pt(u0, v1)
                drawPath(quad(d, cc, Offset(cc.x, cc.y + depth * 0.45f), Offset(d.x, d.y + depth * 0.45f)), color.copy(alpha = 0.45f))
                drawPath(quad(a, b, cc, d), color.copy(alpha = 0.70f))
            }
        }
        val a = pt(0.20f, 0.64f); val b = pt(0.80f, 0.64f); val cc = pt(0.80f, 0.88f); val d = pt(0.20f, 0.88f)
        drawPath(quad(d, cc, Offset(cc.x, cc.y + depth * 0.45f), Offset(d.x, d.y + depth * 0.45f)), Pal.Accent.copy(alpha = 0.55f))
        drawPath(quad(a, b, cc, d), Pal.Accent)
    }
}

// ───────────── Pantalla del chat ─────────────

/** Papel de chat para hablar con el amigo: mensajes, caja de texto (abre el teclado del teléfono) y "Enviar". */
@Composable
fun ChatSheet(c: CleanerState, onClose: () -> Unit) {
    val chat = c.chat
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val focus = remember { FocusRequester() }
    val total = chat.messages.size + if (chat.thinking) 1 else 0

    LaunchedEffect(Unit) {
        chat.loadHistory()
        try { focus.requestFocus() } catch (e: Exception) { }
    }
    LaunchedEffect(total) {
        chat.unread = 0
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    fun go() {
        val t = text
        text = ""
        chat.send(t, c.hint, scope)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
    ) {
        val shape = ChamferShape(18.dp)
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
                .fillMaxWidth()
                .fillMaxHeight(0.62f)
                .clip(shape)
                .background(Pal.Ink)
                .border(1.dp, Pal.Line, shape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CHARLA", color = Pal.Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Text("Tu amigo", color = Pal.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
                Text(
                    "Cerrar", color = Pal.Muted, fontSize = 13.sp,
                    modifier = Modifier.clickable(onClick = onClose).padding(8.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                if (chat.messages.isEmpty() && !chat.thinking) {
                    item {
                        Text(
                            "Escribile algo. Si se queda callado es porque no tiene nada que decir todavía.",
                            color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
                items(chat.messages) { m ->
                    val bubble = ChamferShape(10.dp)
                    Box(Modifier.fillMaxWidth().padding(vertical = 3.dp), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                        Text(
                            m.text,
                            color = if (m.mine) Pal.Black else Pal.White,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .widthIn(max = 270.dp)
                                .clip(bubble)
                                .background(if (m.mine) Pal.White else Pal.Card)
                                .then(if (m.mine) Modifier else Modifier.border(1.dp, Pal.Line, bubble))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                if (chat.thinking) {
                    item { Text("…", color = Pal.Muted, fontSize = 16.sp, modifier = Modifier.padding(8.dp)) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val boxShape = ChamferShape(10.dp)
                Box(
                    Modifier
                        .weight(1f)
                        .clip(boxShape)
                        .background(Pal.Card)
                        .border(1.dp, Pal.Line, boxShape)
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        textStyle = TextStyle(color = Pal.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Pal.Pink),
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { go() }),
                        decorationBox = { inner ->
                            Box {
                                if (text.isEmpty()) Text("Escribile al amigo…", color = Pal.Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                }
                Spacer(Modifier.size(8.dp, 1.dp))
                Box(
                    Modifier
                        .clip(ChamferShape(10.dp))
                        .background(Pal.White)
                        .clickable { go() }
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Enviar", color = Pal.Black, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}
