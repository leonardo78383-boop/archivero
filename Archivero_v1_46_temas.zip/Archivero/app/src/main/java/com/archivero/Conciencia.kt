package com.archivero

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ───────────── La conciencia del amigo: una carpeta por tipo de recuerdo y un índice que los conecta ─────────────
//
// Documents/Amigo/            (en la tarjeta SD si hay; si no, en el almacenamiento interno)
//   conciencia.json           índice: qué hay en cada fuente y qué palabras conectan varias fuentes
//   memoria/                  memoria.json, memoria.txt          (qué carpetas y tipos de archivo abres)
//   charla/                   conversaciones.txt                 (tus charlas con él)
//   pdf/                      cerebro/ (un archivo por PDF), y los viejos vocabulario.json y literatura.json (solo se leen)
//   pantalla/                 palabras.json, palabras.txt        (lo que vio en la pantalla)
//   diccionario/              diccionario.json, diccionario.txt  (lo que tú le enseñaste que significa cada palabra)
//
// Las versiones anteriores guardaban todo suelto en Documents/Amigo. [migrar] lo pasa a las carpetas nuevas SIN perder nada:
// copia a un archivo temporal, comprueba que pesa lo mismo, lo renombra y solo entonces quita el original. Si algo falla, el
// original se queda donde estaba y se reintenta en el próximo arranque.

object Conciencia {
    const val MEMORIA = "memoria"
    const val CHARLA = "charla"
    const val PDF = "pdf"
    const val PANTALLA = "pantalla"
    const val DICCIONARIO = "diccionario"
    const val INDICE = "conciencia.json"

    private const val INDICE_CADA_MS = 60_000L          // el índice se reescribe como mucho una vez por minuto

    private val lock = Any()
    @Volatile private var migradoEn: String? = null
    @Volatile private var ultimoIndice = 0L

    // ───────────── Migración desde la carpeta suelta de las versiones anteriores ─────────────

    /** Idempotente y rápido cuando ya se hizo. Llamar antes de leer o escribir cualquier archivo del amigo. */
    fun migrar(raiz: File) {
        if (migradoEn == raiz.path) return
        synchronized(lock) {
            if (migradoEn == raiz.path) return
            if (!raiz.isDirectory) return                       // todavía no existe (o no hay permiso): nada que mover
            var bien = true
            bien = mover(File(raiz, "memoria.json"), File(File(raiz, MEMORIA), "memoria.json")) && bien
            bien = mover(File(raiz, "memoria.txt"), File(File(raiz, MEMORIA), "memoria.txt")) && bien
            bien = mover(File(raiz, "conversaciones.txt"), File(File(raiz, CHARLA), "conversaciones.txt")) && bien
            bien = mover(File(raiz, "vocabulario.json"), File(File(raiz, PDF), "vocabulario.json")) && bien
            bien = mover(File(raiz, "literatura.json"), File(File(raiz, PDF), "literatura.json")) && bien
            bien = moverCarpeta(File(raiz, "cerebro"), File(File(raiz, PDF), "cerebro")) && bien
            if (bien) migradoEn = raiz.path
        }
    }

    /** Copia, comprueba y recién entonces quita el original. true = no queda nada pendiente para este archivo. */
    private fun mover(origen: File, destino: File): Boolean {
        if (!origen.isFile) return true
        if (destino.exists()) return true                       // ya hay uno en el sitio nuevo: no se pisa nada y el viejo se queda
        val tmp = File(destino.parentFile, destino.name + ".tmp")
        return try {
            destino.parentFile?.mkdirs()
            origen.copyTo(tmp, overwrite = true)
            if (tmp.length() != origen.length()) {
                tmp.delete()
                return false
            }
            if (!tmp.renameTo(destino)) {
                tmp.delete()
                return false
            }
            origen.delete()
            true
        } catch (e: Exception) {
            try { tmp.delete() } catch (ignored: Exception) { }
            false
        }
    }

    private fun moverCarpeta(origen: File, destino: File): Boolean {
        if (!origen.isDirectory) return true
        val hijos = origen.listFiles() ?: return false
        var bien = true
        for (f in hijos) {
            if (!f.isFile) continue
            val d = File(destino, f.name)
            // Si ya hay uno con ese nombre y distinto contenido, el viejo entra con otro nombre: nada se pisa.
            val dest = if (d.exists() && d.length() != f.length()) File(destino, "migrado_" + f.name) else d
            bien = mover(f, dest) && bien
        }
        if (bien) {
            try { if (origen.listFiles()?.isEmpty() == true) origen.delete() } catch (e: Exception) { }
        }
        return bien
    }

    // ───────────── El índice que conecta las fuentes ─────────────

    /** Archivos, bytes y fecha más reciente de una carpeta (hasta 3 niveles). Sin contar los temporales. */
    private fun medir(d: File, nivel: Int = 0): Triple<Int, Long, Long> {
        var n = 0
        var bytes = 0L
        var ult = 0L
        val hijos = d.listFiles() ?: return Triple(0, 0L, 0L)
        for (f in hijos) {
            if (f.isFile) {
                if (f.name.endsWith(".tmp")) continue
                n++
                bytes += f.length()
                ult = maxOf(ult, f.lastModified())
            } else if (f.isDirectory && nivel < 3) {
                val t = medir(f, nivel + 1)
                n += t.first
                bytes += t.second
                ult = maxOf(ult, t.third)
            }
        }
        return Triple(n, bytes, ult)
    }

    /**
     * Reescribe `conciencia.json`: qué hay en cada fuente y las palabras que el amigo conoce por los PDF Y vio en la pantalla
     * (con cuántas veces en cada lado). [pdf] = palabra → veces en los PDF. Como mucho una vez por minuto; nunca lanza errores.
     */
    fun refrescar(raiz: File, pdf: Map<String, Int>) {
        val ahora = System.currentTimeMillis()
        if (ahora - ultimoIndice < INDICE_CADA_MS) return
        ultimoIndice = ahora
        try {
            if (!raiz.isDirectory) return
            migrar(raiz)
            val pantalla = PalabrasPantalla.conteos()
            Diccionario.cargar(raiz)                           // el diccionario se lee junto con lo demás
            val o = JSONObject()
            o.put("version", 2)
            o.put("actualizado", ahora)
            val fuentes = JSONObject()
            for (sub in listOf(MEMORIA, CHARLA, PDF, PANTALLA, DICCIONARIO)) {
                val m = medir(File(raiz, sub))
                fuentes.put(sub, JSONObject().put("archivos", m.first).put("bytes", m.second).put("actualizado", m.third))
            }
            o.put("fuentes", fuentes)
            val comunes = ArrayList<Triple<String, Int, Int>>()
            for ((w, veces) in pdf) {
                val p = pantalla[w] ?: continue
                comunes.add(Triple(w, veces, p))
            }
            comunes.sortByDescending { it.second + it.third }
            val arr = JSONArray()
            for (c in comunes.take(200)) arr.put(JSONObject().put("palabra", c.first).put("pdf", c.second).put("pantalla", c.third))
            o.put("palabras_conectadas", comunes.size)
            o.put("conexiones", arr)
            Diccionario.paraIndice(raiz, pdf, pantalla)?.let { o.put("diccionario", it) }   // palabras con significado y cuáles ya vio en PDF o pantalla
            escribir(File(raiz, INDICE), o.toString())
        } catch (e: Exception) {
            // Sin permiso o sin espacio: se intenta de nuevo más tarde.
        }
    }

    private fun escribir(dest: File, contenido: String) {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.writeText(contenido, Charsets.UTF_8)
        if (!tmp.renameTo(dest)) {
            dest.writeText(contenido, Charsets.UTF_8)
            tmp.delete()
        }
    }

    /** Lo que el amigo cuenta cuando le preguntas por su conciencia. */
    fun resumenTexto(raiz: File): String {
        val f = File(raiz, INDICE)
        if (!f.isFile) return "Todavía no armé mi conciencia: necesito un rato de uso (y el permiso de archivos) para conectar lo que sé."
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            val fu = o.optJSONObject("fuentes")
            fun archivos(s: String): Int = fu?.optJSONObject(s)?.optInt("archivos", 0) ?: 0
            val con = o.optJSONArray("conexiones")
            val ejemplos = ArrayList<String>()
            if (con != null) for (i in 0 until minOf(4, con.length())) {
                con.optJSONObject(i)?.let { ejemplos.add("«" + it.optString("palabra") + "»") }
            }
            "Mi conciencia junta cinco fuentes: lo que abres (${archivos(MEMORIA)} archivos), nuestras charlas (${archivos(CHARLA)}), " +
                "los PDF (${archivos(PDF)}), la pantalla (${archivos(PANTALLA)}) y mi diccionario (${o.optJSONObject("diccionario")?.optInt("palabras", 0) ?: 0} palabras con significado, " +
                "${o.optJSONObject("diccionario")?.optInt("conectadas", 0) ?: 0} de ellas también vistas en PDF o pantalla). " +
                "Hay ${o.optInt("palabras_conectadas", 0)} palabras que conozco por los PDF y también vi en la pantalla" +
                (if (ejemplos.isNotEmpty()) ", por ejemplo " + ejemplos.joinToString(", ") else "") +
                ". Todo está en Documents/Amigo."
        } catch (e: Exception) {
            "No pude leer mi índice (conciencia.json)."
        }
    }
}
