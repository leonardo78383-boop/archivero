plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.archivero"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.archivero"
        minSdk = 30          // Android 11+: permiso "Acceso a todos los archivos"
        targetSdk = 34
        versionCode = 43
        versionName = "1.43"
    }
    buildTypes {
        release {
            // Versión rápida: sin modo depuración, código reducido y optimizado (R8).
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Para instalarla directo en tu teléfono sin crear una llave propia, se firma con la llave de debug.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.core:core-ktx:1.13.1")
    // Instala el "perfil de arranque" (baseline-prof.txt) para que la app abra más rápido.
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Leer el texto de los PDF que le das al amigo (para que aprenda palabras).
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // OCR local para apps que no exponen su texto (juegos, imágenes, algunos vídeos): ML Kit Text Recognition, alfabeto latino.
    // Es la versión "empaquetada": el modelo viene dentro de la app (+ unos MB), funciona sin internet y sin Google Play Services.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
