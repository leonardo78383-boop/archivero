package com.archivero

import android.content.Context
import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)   // no lee disco: los datos llegan en segundo plano
        setContent {
            ArchiveroTheme {
                Surface(Modifier.fillMaxSize()) {
                    when {
                        store.locked -> LockScreen(store)
                        !store.granted -> PermissionScreen()
                        else -> App(store)
                    }
                }
            }
        }
    }

    // Al volver de Ajustes (tras dar el permiso) se actualiza todo.
    override fun onResume() {
        super.onResume()
        if (::store.isInitialized) {
            store.refresh()
            // Si la app estuvo más de 1 minuto fuera de pantalla, vuelve a pedir la contraseña.
            if (stoppedAt != 0L && SystemClock.elapsedRealtime() - stoppedAt > 60_000) store.lockNow()
            stoppedAt = 0L
        }
    }

    override fun onStop() {
        stoppedAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onDestroy() {
        if (::store.isInitialized) store.close()
        super.onDestroy()
    }
}

@Composable
fun ArchiveroTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(primary = Color(0xFF33C9AE))
    else lightColorScheme(primary = Color(0xFF0E9A84))
    MaterialTheme(colorScheme = scheme, content = content)
}

sealed interface Screen {
    data object Home : Screen
    data class Folder(val dir: File) : Screen
    data object Trash : Screen
    class Scan(val title: String, val key: String, val grid: Boolean, val match: (File) -> Boolean) : Screen
}

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        toast(ctx, "No hay una app para abrir este archivo")
    }
}

fun shareFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Compartir ${f.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast(ctx, "No se pudo compartir este archivo")
    }
}

// ───────────────────────── Permiso (se pide una sola vez) ─────────────────────────

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Permitir acceso a tus archivos", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "Archivero necesita este permiso para mostrar de verdad el almacenamiento principal y la tarjeta SD: " +
                "carpetas, música, fotos, vídeos, documentos, PDF y APKs. Solo te lo pedimos una vez.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }) { Text("Permitir") }
    }
}

// ───────────────────────── Estructura principal ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(store: Store) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var menuOpen by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var pwMode by remember { mutableStateOf<PwMode?>(null) }

    fun go(s: Screen) {
        screen = s
        scope.launch { drawer.close() }
    }

    BackHandler(enabled = drawer.isOpen || screen != Screen.Home) {
        val s = screen
        when {
            drawer.isOpen -> scope.launch { drawer.close() }
            s is Screen.Folder -> {
                val p = s.dir.parentFile
                screen = if (store.vols.any { it.dir == s.dir } || p == null) Screen.Home else Screen.Folder(p)
            }
            else -> screen = Screen.Home
        }
    }

    val cur = screen
    val title = when (cur) {
        Screen.Home -> "Este equipo"
        is Screen.Folder -> store.vols.firstOrNull { it.dir == cur.dir }?.name ?: cur.dir.name
        Screen.Trash -> "Papelera de reciclaje"
        is Screen.Scan -> cur.title
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = { ModalDrawerSheet { DrawerBody(store) { go(it) } } }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menú") }
                    },
                    actions = {
                        Box {
                            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Más opciones") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(text = { Text("Inicio") }, onClick = { menuOpen = false; screen = Screen.Home })
                                DropdownMenuItem(text = { Text("Actualizar") }, onClick = { menuOpen = false; store.reload() })
                                if (!store.hasPassword) {
                                    DropdownMenuItem(text = { Text("Poner contraseña") }, onClick = { menuOpen = false; pwMode = PwMode.SET })
                                } else {
                                    DropdownMenuItem(text = { Text("Bloquear ahora") }, onClick = { menuOpen = false; store.lockNow() })
                                    DropdownMenuItem(text = { Text("Cambiar contraseña") }, onClick = { menuOpen = false; pwMode = PwMode.CHANGE })
                                    DropdownMenuItem(text = { Text("Quitar contraseña") }, onClick = { menuOpen = false; pwMode = PwMode.REMOVE })
                                }
                                DropdownMenuItem(text = { Text("Vaciar papelera") }, onClick = {
                                    menuOpen = false
                                    if (store.trash.isEmpty()) toast(ctx, "La papelera ya está vacía") else confirmEmpty = true
                                })
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF222222),
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
            },
            floatingActionButton = {
                if (cur is Screen.Folder) {
                    FloatingActionButton(onClick = { newFolder = true }) { Icon(Icons.Default.Add, "Nueva carpeta") }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (cur) {
                    Screen.Home -> HomeScreen(store) { go(it) }
                    is Screen.Folder -> FolderScreen(store, cur.dir) { go(it) }
                    Screen.Trash -> TrashScreen(store)
                    is Screen.Scan -> ScanScreen(store, cur.key, cur.grid, cur.match) { go(it) }
                }
            }
        }
    }

    if (newFolder && cur is Screen.Folder) {
        NameDialog("Nueva carpeta", "", "Crear", { newFolder = false }) { n ->
            val d = File(cur.dir, n)
            when {
                d.exists() -> toast(ctx, "Ya existe ese nombre")
                d.mkdirs() -> store.reload()
                else -> toast(ctx, "No se pudo crear la carpeta")
            }
            newFolder = false
        }
    }
    pwMode?.let { m ->
        PasswordDialog(store, m, onDone = { toast(ctx, it); pwMode = null }, onDismiss = { pwMode = null })
    }
    store.busy?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(msg) },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        )
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("¿Vaciar la papelera?") },
            text = { Text("Se liberará el espacio y no se podrá deshacer.") },
            confirmButton = { TextButton(onClick = { confirmEmpty = false; scope.launch { store.emptyTrash() } }) { Text("Vaciar") } },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancelar") } }
        )
    }
}

// ───────────────────────── Panel de las 3 rayitas ─────────────────────────

@Composable
fun DrawerBody(store: Store, go: (Screen) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(
            "Archivero", color = Color.White, style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.fillMaxWidth().background(Color(0xFF222222)).padding(18.dp)
        )
        DrawerItem("🏠", "Inicio") { go(Screen.Home) }

        store.vols.forEach { v ->
            val total = v.total
            val free = v.free
            val used = total - free
            Row(
                Modifier.fillMaxWidth().clickable { go(Screen.Folder(v.dir)) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SdIcon(24.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(v.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { used.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Libre: ${gb(free)}\nOcupado: ${gb(used)}\nTotal: ${gb(total)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text("${free * 100 / total}% libre", style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
        }

        DrawerItem("♻️", "Papelera de reciclaje", right = fmtSize(store.trash.sumOf { it.size })) { go(Screen.Trash) }

        Text("Accesos rápidos", Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp), style = MaterialTheme.typography.bodySmall)
        store.shortcuts.forEach { s -> DrawerItem(s.icon, s.title, s.sub) { go(Screen.Folder(s.dir)) } }
    }
}

@Composable
fun DrawerItem(icon: String, title: String, sub: String? = null, right: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 22.sp, modifier = Modifier.width(38.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (right != null) Text(right, style = MaterialTheme.typography.bodySmall)
    }
    HorizontalDivider()
}

// ───────────────────────── Inicio ─────────────────────────

private fun pub(t: String): File = Environment.getExternalStoragePublicDirectory(t)

private val CATS = listOf(
    Triple(Kind.AUD, "🎵", "Música"), Triple(Kind.IMG, "🖼️", "Fotos"), Triple(Kind.VID, "🎬", "Vídeos"),
    Triple(Kind.DOC, "📄", "Documentos"), Triple(Kind.PDF, "📕", "PDF"), Triple(Kind.APK, "🤖", "APKs")
)

@Composable
fun HomeScreen(store: Store, go: (Screen) -> Unit) {
    var q by remember { mutableStateOf("") }
    val primary = store.vols.firstOrNull()?.dir ?: Environment.getExternalStorageDirectory()

    val quick = remember(primary) {
        listOf(
            Triple("Descargas", pub(Environment.DIRECTORY_DOWNLOADS), 0xFF14A58A),
            Triple("Desktop", File(primary, "Desktop"), 0xFF1F8EE0),
            Triple("Documentos", pub(Environment.DIRECTORY_DOCUMENTS), 0xFF7D93AB),
            Triple("Imágenes", pub(Environment.DIRECTORY_PICTURES), 0xFF2B86E8),
            Triple("Música", pub(Environment.DIRECTORY_MUSIC), 0xFFEE7F56),
            Triple("Vídeos", pub(Environment.DIRECTORY_MOVIES), 0xFF8A55D6)
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            placeholder = { Text("Buscar en Este equipo") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                val s = q.trim()
                if (s.isNotEmpty()) go(Screen.Scan("Resultados: $s", "q:${s.lowercase()}", false) { it.name.contains(s, ignoreCase = true) })
            }),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )

        quick.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                row.forEach { (name, dir, color) ->
                    Column(
                        Modifier.weight(1f).clickable { dir.mkdirs(); go(Screen.Folder(dir)) }.padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FolderIcon(Color(color), 46.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(name, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            store.vols.forEach { v ->
                Card(Modifier.weight(1f).clickable { go(Screen.Folder(v.dir)) }) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        SdIcon(36.dp)
                        Spacer(Modifier.height(6.dp))
                        Text(v.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(
                            "${Math.round(v.free / 1073741824.0)} GB / ${Math.round(v.total / 1073741824.0)} GB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Text("Categorías", Modifier.padding(16.dp, 22.dp, 16.dp, 6.dp), fontWeight = FontWeight.Medium)
        CATS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                row.forEach { (kind, emoji, label) ->
                    Column(
                        Modifier.weight(1f).clickable {
                            // Primero la extensión (barato) y solo después se consulta el disco.
                            go(Screen.Scan(label, "cat:$label", kind == Kind.IMG || kind == Kind.VID) { kindOf(it) == kind && it.isFile })
                        }.padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Color(kind.color).copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) { Text(emoji, fontSize = 24.sp) }
                        Spacer(Modifier.height(4.dp))
                        Text(label, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ───────────────────────── Carpetas y archivos reales ─────────────────────────

@Composable
fun FolderScreen(store: Store, dir: File, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = store.tick
    var renaming by remember { mutableStateOf<Entry?>(null) }
    var menuFor by remember { mutableStateOf<Entry?>(null) }
    var infoFor by remember { mutableStateOf<Entry?>(null) }
    var zipFor by remember { mutableStateOf<Entry?>(null) }
    var showSort by remember { mutableStateOf(false) }
    var selected by remember(dir) { mutableStateOf(setOf<String>()) }
    var list by remember(dir) { mutableStateOf<List<Entry>?>(null) }

    // La carpeta se lee en segundo plano: abrir una carpeta enorme ya no congela la pantalla.
    LaunchedEffect(dir, tick) { list = withContext(Dispatchers.IO) { listEntries(dir) } }

    val sortBy = store.sortBy
    val sortAsc = store.sortAsc
    val rows = remember(list, sortBy, sortAsc) { list?.let { sortEntries(it, sortBy, sortAsc) } }
    val chosen = remember(rows, selected) { rows?.filter { it.file.path in selected } ?: emptyList() }
    val selecting = chosen.isNotEmpty()
    val folders = remember(rows) { rows?.count { it.isDir } ?: 0 }

    val v = store.vols.firstOrNull { dir.path.startsWith(it.dir.path) }
    val crumb = (v?.name ?: "") + dir.path.removePrefix(v?.dir?.path ?: "")

    // Con elementos marcados, "atrás" primero cancela la selección.
    BackHandler(enabled = selecting) { selected = emptySet() }

    fun toggle(e: Entry) {
        selected = if (e.file.path in selected) selected - e.file.path else selected + e.file.path
    }

    Column(Modifier.fillMaxSize()) {
        Text(crumb, Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(16.dp, 10.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1)

        if (selecting) {
            SelectionBar(
                count = chosen.size,
                onClose = { selected = emptySet() },
                onAll = { selected = rows?.map { it.file.path }?.toSet() ?: emptySet() },
                onCopy = {
                    store.clip = Clip(chosen.map { it.file }, false)
                    selected = emptySet()
                    toast(ctx, "Copiado: abrí otra carpeta y toca Pegar")
                },
                onCut = {
                    store.clip = Clip(chosen.map { it.file }, true)
                    selected = emptySet()
                    toast(ctx, "Cortado: abrí otra carpeta y toca Pegar")
                },
                onZip = {
                    val files = chosen.map { it.file }
                    selected = emptySet()
                    scope.launch { toast(ctx, store.zip(files) ?: "ZIP creado") }
                },
                onDelete = {
                    val files = chosen.map { it.file }
                    selected = emptySet()
                    scope.launch {
                        val n = store.moveToTrash(files)
                        toast(ctx, if (n == files.size) "Movido a la papelera" else "Se movieron $n de ${files.size}")
                    }
                }
            )
        }

        store.clip?.let { c ->
            PasteBar(c,
                onPaste = {
                    scope.launch {
                        val err = store.paste(c, dir)
                        toast(ctx, err ?: if (c.cut) "Movido" else "Copiado")
                    }
                },
                onCancel = { store.clip = null })
        }

        if (rows != null) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(start = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "$folders carpetas, ${rows.size - folders} archivos",
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = { showSort = true }) {
                    Text("Ordenar: ${sortBy.label} ${if (sortAsc) "↑" else "↓"}", fontSize = 12.sp)
                }
            }
            if (rows.isEmpty()) {
                Text("Carpeta vacía. Toca + para crear una carpeta.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
            } else {
                // key(dir): cada carpeta empieza arriba del todo (antes heredaba el desplazamiento de la anterior).
                key(dir) {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(rows, key = { it.file.path }) { e ->
                            EntryRow(
                                e,
                                selected = e.file.path in selected,
                                onLongClick = { toggle(e) },
                                onClick = {
                                    if (selecting) toggle(e)
                                    else if (e.isDir) go(Screen.Folder(e.file))
                                    else openFile(ctx, e.file)
                                }
                            ) {
                                if (selecting) {
                                    Checkbox(checked = e.file.path in selected, onCheckedChange = { toggle(e) })
                                } else {
                                    Box {
                                        IconButton(onClick = { menuFor = e }) { Icon(Icons.Default.MoreVert, "Opciones") }
                                        DropdownMenu(expanded = menuFor === e, onDismissRequest = { menuFor = null }) {
                                            DropdownMenuItem(text = { Text("Renombrar") }, onClick = { menuFor = null; renaming = e })
                                            DropdownMenuItem(text = { Text("Copiar") }, onClick = { menuFor = null; store.clip = Clip(listOf(e.file), false); toast(ctx, "Copiado: abrí otra carpeta y toca Pegar") })
                                            DropdownMenuItem(text = { Text("Cortar") }, onClick = { menuFor = null; store.clip = Clip(listOf(e.file), true); toast(ctx, "Cortado: abrí otra carpeta y toca Pegar") })
                                            if (!e.isDir) {
                                                DropdownMenuItem(text = { Text("Compartir") }, onClick = { menuFor = null; shareFile(ctx, e.file) })
                                            }
                                            DropdownMenuItem(text = { Text("Comprimir en ZIP") }, onClick = {
                                                menuFor = null
                                                scope.launch { toast(ctx, store.zip(listOf(e.file)) ?: "ZIP creado") }
                                            })
                                            if (!e.isDir && e.ext.equals("zip", ignoreCase = true)) {
                                                DropdownMenuItem(text = { Text("Ver contenido del ZIP") }, onClick = { menuFor = null; zipFor = e })
                                                DropdownMenuItem(text = { Text("Extraer aquí") }, onClick = {
                                                    menuFor = null
                                                    scope.launch { toast(ctx, store.unzip(e.file) ?: "Extraído") }
                                                })
                                            }
                                            DropdownMenuItem(text = { Text("Información") }, onClick = { menuFor = null; infoFor = e })
                                            DropdownMenuItem(text = { Text("Eliminar (a la papelera)") }, onClick = {
                                                menuFor = null
                                                scope.launch {
                                                    if (store.moveToTrash(e.file)) toast(ctx, "Movido a la papelera")
                                                    else toast(ctx, "No se pudo eliminar")
                                                }
                                            })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSort) SortDialog(store) { showSort = false }

    infoFor?.let { e -> InfoDialog(e) { infoFor = null } }

    zipFor?.let { z ->
        ZipContentDialog(
            z.file,
            onExtract = {
                zipFor = null
                scope.launch { toast(ctx, store.unzip(z.file) ?: "Extraído") }
            },
            onDismiss = { zipFor = null }
        )
    }

    renaming?.let { e ->
        NameDialog("Renombrar", e.name, "Guardar", { renaming = null }) { n ->
            val d = File(e.file.parentFile, n)
            when {
                n == e.name -> {}
                // En tarjetas SD (FAT) "foto" y "Foto" son el mismo archivo: permitir cambiar solo mayúsculas.
                d.exists() && !n.equals(e.name, ignoreCase = true) -> toast(ctx, "Ya existe ese nombre")
                e.file.renameTo(d) -> store.reload()
                else -> toast(ctx, "No se pudo renombrar")
            }
            renaming = null
        }
    }
}

/** Lista todos los archivos de una categoría (música, fotos, PDF…) o los resultados de una búsqueda. */
@Composable
fun ScanScreen(store: Store, cacheKey: String, grid: Boolean, match: (File) -> Boolean, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val cached = remember(cacheKey) { store.scanCache[cacheKey] }
    var found by remember(cacheKey) { mutableStateOf(cached?.items) }
    var loading by remember(cacheKey) { mutableStateOf(true) }

    LaunchedEffect(cacheKey, store.vols.size) {
        if (store.vols.isEmpty()) return@LaunchedEffect   // los almacenamientos aún se están leyendo
        val c = store.scanCache[cacheKey]
        if (c != null && System.currentTimeMillis() - c.time < 30_000) { loading = false; return@LaunchedEffect }
        loading = true
        // Muestra lo encontrado mientras sigue buscando, y se cancela solo si sales de la pantalla.
        val res = withContext(Dispatchers.IO) { scan(store.vols, { part -> found = part }, match) }
        found = res
        store.scanCache[cacheKey] = ScanResult(res, System.currentTimeMillis())
        loading = false
    }

    val res = found
    when {
        res == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        res.isEmpty() && !loading -> Text("No se encontró nada.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        else -> Column(Modifier.fillMaxSize()) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            key(cacheKey) {
                if (grid) {
                    GalleryGrid(res, loading) { e -> openFile(ctx, e.file) }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        item {
                            Text(
                                "${res.size} encontrados" + if (loading) " (buscando…)" else "",
                                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp, 8.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        items(res, key = { it.file.path }) { e ->
                            val where = if (e.isDir) "carpeta en " else fmtSize(e.size) + " en "
                            EntryRow(e, subOverride = where + (e.file.parentFile?.name ?: ""),
                                onClick = { if (e.isDir) go(Screen.Folder(e.file)) else openFile(ctx, e.file) })
                        }
                    }
                }
            }
        }
    }
}

/** Fotos y vídeos en cuadrícula, agrupados por día (lo más nuevo arriba). */
@Composable
fun GalleryGrid(res: List<Entry>, loading: Boolean, onOpen: (Entry) -> Unit) {
    val groups = remember(res) { res.groupBy { dayOf(it.modified) } }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(96.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "${res.size} encontrados" + if (loading) " (buscando…)" else "",
                Modifier.fillMaxWidth().padding(8.dp, 6.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
        groups.forEach { (day, list) ->
            item(key = "h$day", span = { GridItemSpan(maxLineSpan) }) {
                Text(dayLabel(day), Modifier.fillMaxWidth().padding(8.dp, 10.dp, 8.dp, 4.dp), fontWeight = FontWeight.Medium)
            }
            items(list, key = { it.file.path }) { e ->
                Box(Modifier.aspectRatio(1f).clickable { onOpen(e) }) {
                    Thumb(e, Modifier.fillMaxSize())
                    if (e.kind == Kind.VID) {
                        Text("▶", Modifier.align(Alignment.Center), color = Color.White, fontSize = 24.sp)
                    }
                }
            }
        }
    }
}

/** Miniatura que se carga en segundo plano; mientras tanto, un cuadro gris. */
@Composable
fun Thumb(e: Entry, modifier: Modifier) {
    val bmp by produceState(Thumbs.cached(e.file.path), e.file.path) {
        if (value == null) value = Thumbs.load(e.file, e.kind == Kind.VID)
    }
    val b = bmp
    if (b != null) {
        val img = remember(b) { b.asImageBitmap() }
        Image(bitmap = img, contentDescription = e.name, contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
fun TrashScreen(store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (store.trash.isEmpty()) {
        Text("La papelera está vacía. Lo que elimines aparece aquí.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(store.trash, key = { it.trashPath }) { t ->
            val ext = t.name.substringAfterLast('.', "")
            FileRow(t.isDir, kindOfExt(ext), ext, t.name, "${fmtSize(t.size)} · ${File(t.origPath).parent ?: ""}", onClick = {}) {
                TextButton(onClick = { scope.launch { if (!store.restore(t)) toast(ctx, "No se pudo restaurar") } }) { Text("Restaurar") }
                IconButton(onClick = { scope.launch { store.deleteForever(t) } }) { Icon(Icons.Default.Close, "Eliminar definitivamente") }
            }
        }
    }
}

/** Barra superior mientras hay archivos marcados (se activa con una pulsación larga). */
@Composable
fun SelectionBar(
    count: Int, onClose: () -> Unit, onAll: () -> Unit,
    onCopy: () -> Unit, onCut: () -> Unit, onZip: () -> Unit, onDelete: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Cancelar selección") }
            Text("$count seleccionados", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            TextButton(onClick = onAll) { Text("Todo") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            TextButton(onClick = onCopy, modifier = Modifier.weight(1f)) { Text("Copiar") }
            TextButton(onClick = onCut, modifier = Modifier.weight(1f)) { Text("Cortar") }
            TextButton(onClick = onZip, modifier = Modifier.weight(1f)) { Text("ZIP") }
            TextButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Eliminar") }
        }
    }
}

@Composable
fun SortDialog(store: Store, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
        title = { Text("Ordenar por") },
        text = {
            Column {
                SortBy.values().forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(o, store.sortAsc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortBy == o, onClick = { store.setSort(o, store.sortAsc) })
                        Text(o.label)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                listOf(true to "Ascendente (A→Z, antiguo→nuevo, chico→grande)", false to "Descendente").forEach { (asc, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { store.setSort(store.sortBy, asc) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = store.sortAsc == asc, onClick = { store.setSort(store.sortBy, asc) })
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    )
}

/** Muestra qué hay dentro de un ZIP sin extraerlo. */
@Composable
fun ZipContentDialog(f: File, onExtract: () -> Unit, onDismiss: () -> Unit) {
    val zipItems by produceState<List<ZipItem>?>(null, f) {
        value = withContext(Dispatchers.IO) { listZip(f) ?: emptyList() }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            val list = zipItems
            when {
                list == null -> LinearProgressIndicator(Modifier.fillMaxWidth())
                list.isEmpty() -> Text("El ZIP está vacío o no se puede leer.")
                else -> Column {
                    val files = list.count { !it.isDir }
                    val total = list.sumOf { it.size }
                    Text("$files archivos · ${fmtSize(total)} descomprimido", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(list.take(1000)) { z ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (z.isDir) "📁 " else "") + z.name,
                                    Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp
                                )
                                if (!z.isDir) Text(fmtSize(z.size), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (list.size > 1000) {
                            item { Text("…y ${list.size - 1000} más", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onExtract) { Text("Extraer aquí") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

/** Barra que aparece cuando hay algo copiado/cortado esperando ser pegado. */
@Composable
fun PasteBar(c: Clip, onPaste: () -> Unit, onCancel: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            (if (c.cut) "Mover: " else "Copiar: ") + (if (c.files.size == 1) c.files[0].name else "${c.files.size} elementos"),
            Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        TextButton(onClick = onPaste) { Text("Pegar aquí") }
        TextButton(onClick = onCancel) { Text("Cancelar") }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}

/** Datos del archivo o carpeta. En carpetas el tamaño total se calcula en segundo plano. */
@Composable
fun InfoDialog(e: Entry, onDismiss: () -> Unit) {
    val stats by produceState<Triple<Long, Int, Int>?>(null, e.file) {
        value = if (e.isDir) withContext(Dispatchers.IO) { folderStats(e.file) } else null
    }
    val dims by produceState<String?>(null, e.file) {
        value = if (e.kind == Kind.IMG && !e.isDir) withContext(Dispatchers.IO) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(e.file.path, o)
            if (o.outWidth > 0) "${o.outWidth} × ${o.outHeight} px" else null
        } else null
    }
    val tipo = if (e.isDir) "Carpeta" else e.kind.label.let { k -> if (e.ext.isEmpty()) k else "$k (.${e.ext})" }
    val tamano = when {
        !e.isDir -> fmtSize(e.size) + " (${e.size} bytes)"
        stats == null -> "Calculando…"
        else -> stats!!.let { (b, f, d) -> "${fmtSize(b)} · $f archivos, $d carpetas" }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                InfoLine("Tipo", tipo)
                InfoLine("Ubicación", e.file.parent ?: "")
                InfoLine("Tamaño", tamano)
                dims?.let { InfoLine("Dimensiones", it) }
                InfoLine("Modificado", fmtDateTime(e.modified))
                InfoLine("Permisos", "Lectura: " + (if (e.file.canRead()) "sí" else "no") + " · Escritura: " + (if (e.file.canWrite()) "sí" else "no"))
            }
        }
    )
}

// ───────────────────────── Candado ─────────────────────────

@Composable
private fun PwField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, onDone: (() -> Unit)? = null) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun LockScreen(store: Store) {
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    fun submit() {
        if (working || pw.isEmpty()) return
        working = true
        val tryPw = pw
        scope.launch {
            msg = store.unlock(tryPw)
            pw = ""
            working = false
        }
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", fontSize = 40.sp)
        Spacer(Modifier.height(8.dp))
        Text("Archivero", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))
        PwField("Contraseña", pw, { pw = it }, onDone = { submit() })
        msg?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { submit() }, enabled = !working) { Text("Entrar") }
    }
}

enum class PwMode { SET, CHANGE, REMOVE }

@Composable
fun PasswordDialog(store: Store, mode: PwMode, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val title = when (mode) {
        PwMode.SET -> "Poner contraseña"
        PwMode.CHANGE -> "Cambiar contraseña"
        PwMode.REMOVE -> "Quitar contraseña"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mode != PwMode.SET) PwField("Contraseña actual", cur, { cur = it })
                if (mode != PwMode.REMOVE) {
                    PwField("Nueva contraseña", n1, { n1 = it })
                    PwField("Repetir contraseña", n2, { n2 = it })
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    if (mode != PwMode.SET && !store.checkPassword(cur)) { err = "La contraseña actual no es correcta"; return@launch }
                    if (mode != PwMode.REMOVE) {
                        if (n1.length < 4) { err = "Usá al menos 4 caracteres"; return@launch }
                        if (n1 != n2) { err = "Las contraseñas no coinciden"; return@launch }
                    }
                    when (mode) {
                        PwMode.SET, PwMode.CHANGE -> store.setPassword(n1)
                        PwMode.REMOVE -> store.removePassword()
                    }
                    onDone(
                        when (mode) {
                            PwMode.SET -> "Contraseña activada"
                            PwMode.CHANGE -> "Contraseña cambiada"
                            PwMode.REMOVE -> "Contraseña quitada"
                        }
                    )
                }
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ───────────────────────── Piezas visuales ─────────────────────────

/** Fila de un archivo/carpeta ya leído. Las carpetas cuentan sus elementos en segundo plano, solo las que se ven. */
@Composable
fun EntryRow(
    e: Entry,
    subOverride: String? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    if (e.isDir && subOverride == null) {
        val count by produceState<Int?>(null, e.file) { value = withContext(Dispatchers.IO) { countVisible(e.file) } }
        FileRow(true, e.kind, "", e.name, count?.let { "$it elementos" } ?: "",
            onClick = onClick, onLongClick = onLongClick, selected = selected, trailing = trailing)
    } else {
        FileRow(e.isDir, e.kind, e.ext, e.name, subOverride ?: e.sub,
            onClick = onClick, onLongClick = onLongClick, selected = selected, trailing = trailing)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    isDir: Boolean, kind: Kind, ext: String, name: String, sub: String,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean = false,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(44.dp), contentAlignment = Alignment.Center) { FileIcon(isDir, kind, ext) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun FileIcon(isDir: Boolean, kind: Kind, ext: String) {
    if (isDir) { FolderIcon(Color(0xFFF0B429), 42.dp); return }
    Box(Modifier.size(36.dp, 40.dp).clip(RoundedCornerShape(6.dp)).background(Color(kind.color)), contentAlignment = Alignment.Center) {
        Text(ext.take(4).uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FolderIcon(c: Color, w: Dp = 44.dp) {
    Canvas(Modifier.size(w, w * 0.85f)) {
        val bw = size.width
        val bh = size.height
        drawRoundRect(c, Offset(0f, bh * 0.1f), Size(bw * 0.42f, bh * 0.3f), CornerRadius(8f))
        drawRoundRect(c, Offset(0f, bh * 0.22f), Size(bw, bh * 0.78f), CornerRadius(12f))
    }
}

@Composable
fun SdIcon(w: Dp = 40.dp) {
    Canvas(Modifier.size(w, w * 1.3f)) {
        val bw = size.width
        val bh = size.height
        val p = Path().apply {
            moveTo(0.1f * bw, 0f); lineTo(0.65f * bw, 0f); lineTo(bw, 0.3f * bh)
            lineTo(bw, bh); lineTo(0f, bh); lineTo(0f, 0.1f * bh); close()
        }
        drawPath(p, Color(0xFF4A4A60))
        repeat(4) { drawRect(Color(0xFFF4CF6E), Offset(bw * (0.15f + it * 0.14f), bh * 0.08f), Size(bw * 0.08f, bh * 0.2f)) }
    }
}

@Composable
fun NameDialog(title: String, initial: String, okText: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val n = v.trim().replace("/", "-")
                if (n.isNotEmpty()) onOk(n)
            }) { Text(okText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
