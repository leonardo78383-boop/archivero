package com.archivero

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        setContent {
            ArchiveroTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (!store.granted) PermissionScreen() else App(store)
                }
            }
        }
    }

    // Al volver de Ajustes (tras dar el permiso) se actualiza todo.
    override fun onResume() {
        super.onResume()
        if (::store.isInitialized) store.refresh()
    }
}

@Composable
fun ArchiveroTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(primary = Color(0xFF33C9AE))
    else lightColorScheme(primary = Color(0xFF0E9A84))
    MaterialTheme(colorScheme = scheme, content = content)
}

sealed interface Screen {
    data object Home : Screen
    data class Folder(val dir: File) : Screen
    data object Trash : Screen
    class Scan(val title: String, val match: (File) -> Boolean) : Screen
}

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        toast(ctx, "No hay una app para abrir este archivo")
    }
}

fun subOf(f: File): String =
    if (f.isDirectory) "${f.listFiles()?.size ?: 0} elementos"
    else fmtSize(f.length()) + "  " + SimpleDateFormat("dd/MM/yyyy", Locale("es")).format(Date(f.lastModified()))

// ───────────────────────── Permiso (se pide una sola vez) ─────────────────────────

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Permitir acceso a tus archivos", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "Archivero necesita este permiso para mostrar de verdad el almacenamiento principal y la tarjeta SD: " +
                "carpetas, música, fotos, vídeos, documentos, PDF y APKs. Solo te lo pedimos una vez.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }) { Text("Permitir") }
    }
}

// ───────────────────────── Estructura principal ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(store: Store) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var menuOpen by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }

    fun go(s: Screen) {
        screen = s
        scope.launch { drawer.close() }
    }

    BackHandler(enabled = drawer.isOpen || screen != Screen.Home) {
        val s = screen
        when {
            drawer.isOpen -> scope.launch { drawer.close() }
            s is Screen.Folder -> {
                val p = s.dir.parentFile
                screen = if (store.vols.any { it.dir == s.dir } || p == null) Screen.Home else Screen.Folder(p)
            }
            else -> screen = Screen.Home
        }
    }

    val cur = screen
    val title = when (cur) {
        Screen.Home -> "Este equipo"
        is Screen.Folder -> store.vols.firstOrNull { it.dir == cur.dir }?.name ?: cur.dir.name
        Screen.Trash -> "Papelera de reciclaje"
        is Screen.Scan -> cur.title
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = { ModalDrawerSheet { DrawerBody(store) { go(it) } } }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menú") }
                    },
                    actions = {
                        Box {
                            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Más opciones") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(text = { Text("Inicio") }, onClick = { menuOpen = false; screen = Screen.Home })
                                DropdownMenuItem(text = { Text("Actualizar") }, onClick = { menuOpen = false; store.refresh() })
                                DropdownMenuItem(text = { Text("Vaciar papelera") }, onClick = {
                                    menuOpen = false
                                    if (store.trash.isEmpty()) toast(ctx, "La papelera ya está vacía") else confirmEmpty = true
                                })
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF222222),
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
            },
            floatingActionButton = {
                if (cur is Screen.Folder) {
                    FloatingActionButton(onClick = { newFolder = true }) { Icon(Icons.Default.Add, "Nueva carpeta") }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (cur) {
                    Screen.Home -> HomeScreen(store) { go(it) }
                    is Screen.Folder -> FolderScreen(store, cur.dir) { go(it) }
                    Screen.Trash -> TrashScreen(store)
                    is Screen.Scan -> ScanScreen(store, cur.match) { go(it) }
                }
            }
        }
    }

    if (newFolder && cur is Screen.Folder) {
        NameDialog("Nueva carpeta", "", "Crear", { newFolder = false }) { n ->
            val d = File(cur.dir, n)
            when {
                d.exists() -> toast(ctx, "Ya existe ese nombre")
                d.mkdirs() -> store.refresh()
                else -> toast(ctx, "No se pudo crear la carpeta")
            }
            newFolder = false
        }
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("¿Vaciar la papelera?") },
            text = { Text("Se liberará el espacio y no se podrá deshacer.") },
            confirmButton = { TextButton(onClick = { store.emptyTrash(); confirmEmpty = false }) { Text("Vaciar") } },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancelar") } }
        )
    }
}

// ───────────────────────── Panel de las 3 rayitas ─────────────────────────

@Composable
fun DrawerBody(store: Store, go: (Screen) -> Unit) {
    val tick = store.tick // vuelve a leer el espacio cuando algo cambia
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(
            "Archivero", color = Color.White, style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.fillMaxWidth().background(Color(0xFF222222)).padding(18.dp)
        )
        DrawerItem("🏠", "Inicio") { go(Screen.Home) }

        store.vols.forEach { v ->
            val total = v.total
            val free = v.free
            val used = total - free
            Row(
                Modifier.fillMaxWidth().clickable { go(Screen.Folder(v.dir)) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SdIcon(24.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(v.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { used.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Libre: ${gb(free)}\nOcupado: ${gb(used)}\nTotal: ${gb(total)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text("${free * 100 / total}% libre", style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
        }

        DrawerItem("♻️", "Papelera de reciclaje", right = fmtSize(store.trash.sumOf { it.size })) { go(Screen.Trash) }

        Text("Accesos rápidos", Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp), style = MaterialTheme.typography.bodySmall)
        val music = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        if (music.exists()) DrawerItem("🎧", "Audio", "/${music.name}") { go(Screen.Folder(music)) }
        store.vols.forEachIndexed { i, v ->
            firstFolder(v)?.let { f ->
                DrawerItem(if (i == 0) "📁" else "💾", v.name, "/${f.name}") { go(Screen.Folder(f)) }
            }
        }
    }
}

@Composable
fun DrawerItem(icon: String, title: String, sub: String? = null, right: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 22.sp, modifier = Modifier.width(38.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (right != null) Text(right, style = MaterialTheme.typography.bodySmall)
    }
    HorizontalDivider()
}

// ───────────────────────── Inicio ─────────────────────────

@Composable
fun HomeScreen(store: Store, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val tick = store.tick
    var q by remember { mutableStateOf("") }
    val primary = store.vols.firstOrNull()?.dir ?: Environment.getExternalStorageDirectory()
    fun pub(t: String) = Environment.getExternalStoragePublicDirectory(t)

    val quick = listOf(
        Triple("Descargas", pub(Environment.DIRECTORY_DOWNLOADS), 0xFF14A58A),
        Triple("Desktop", File(primary, "Desktop"), 0xFF1F8EE0),
        Triple("Documentos", pub(Environment.DIRECTORY_DOCUMENTS), 0xFF7D93AB),
        Triple("Imágenes", pub(Environment.DIRECTORY_PICTURES), 0xFF2B86E8),
        Triple("Música", pub(Environment.DIRECTORY_MUSIC), 0xFFEE7F56),
        Triple("Vídeos", pub(Environment.DIRECTORY_MOVIES), 0xFF8A55D6)
    )
    val cats = listOf(
        Triple(Kind.AUD, "🎵", "Música"), Triple(Kind.IMG, "🖼️", "Fotos"), Triple(Kind.VID, "🎬", "Vídeos"),
        Triple(Kind.DOC, "📄", "Documentos"), Triple(Kind.PDF, "📕", "PDF"), Triple(Kind.APK, "🤖", "APKs")
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            placeholder = { Text("Buscar en Este equipo") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                val s = q.trim()
                if (s.isNotEmpty()) go(Screen.Scan("Resultados: $s") { it.name.contains(s, ignoreCase = true) })
            }),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )

        quick.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                row.forEach { (name, dir, color) ->
                    Column(
                        Modifier.weight(1f).clickable { dir.mkdirs(); go(Screen.Folder(dir)) }.padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FolderIcon(Color(color), 46.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(name, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            store.vols.forEach { v ->
                Card(Modifier.weight(1f).clickable { go(Screen.Folder(v.dir)) }) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        SdIcon(36.dp)
                        Spacer(Modifier.height(6.dp))
                        Text(v.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(
                            "${Math.round(v.free / 1073741824.0)} GB / ${Math.round(v.total / 1073741824.0)} GB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Text("Categorías", Modifier.padding(16.dp, 22.dp, 16.dp, 6.dp), fontWeight = FontWeight.Medium)
        cats.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                row.forEach { (kind, emoji, label) ->
                    Column(
                        Modifier.weight(1f).clickable {
                            go(Screen.Scan(label) { it.isFile && kindOf(it) == kind })
                        }.padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Color(kind.color).copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) { Text(emoji, fontSize = 24.sp) }
                        Spacer(Modifier.height(4.dp))
                        Text(label, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ───────────────────────── Carpetas y archivos reales ─────────────────────────

@Composable
fun FolderScreen(store: Store, dir: File, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val tick = store.tick
    var renaming by remember { mutableStateOf<File?>(null) }
    val list = remember(dir, tick) { listDir(dir) }
    val v = store.vols.firstOrNull { dir.path.startsWith(it.dir.path) }
    val crumb = (v?.name ?: "") + dir.path.removePrefix(v?.dir?.path ?: "")

    Column(Modifier.fillMaxSize()) {
        Text(crumb, Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(16.dp, 10.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1)
        Text(
            "${list.count { it.isDirectory }} carpetas, ${list.count { !it.isDirectory }} archivos",
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp, 8.dp),
            style = MaterialTheme.typography.bodySmall
        )
        if (list.isEmpty()) {
            Text("Carpeta vacía. Toca + para crear una carpeta.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.path }) { f ->
                    var m by remember { mutableStateOf(false) }
                    FileRow(f, subOf(f), onClick = { if (f.isDirectory) go(Screen.Folder(f)) else openFile(ctx, f) }) {
                        Box {
                            IconButton(onClick = { m = true }) { Icon(Icons.Default.MoreVert, "Opciones") }
                            DropdownMenu(expanded = m, onDismissRequest = { m = false }) {
                                DropdownMenuItem(text = { Text("Renombrar") }, onClick = { m = false; renaming = f })
                                DropdownMenuItem(text = { Text("Eliminar (a la papelera)") }, onClick = {
                                    m = false
                                    if (store.moveToTrash(f)) toast(ctx, "Movido a la papelera") else toast(ctx, "No se pudo eliminar")
                                })
                            }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { f ->
        NameDialog("Renombrar", f.name, "Guardar", { renaming = null }) { n ->
            val d = File(f.parentFile, n)
            when {
                d.exists() -> toast(ctx, "Ya existe ese nombre")
                f.renameTo(d) -> store.refresh()
                else -> toast(ctx, "No se pudo renombrar")
            }
            renaming = null
        }
    }
}

/** Lista todos los archivos de una categoría (música, fotos, PDF…) o los resultados de una búsqueda. */
@Composable
fun ScanScreen(store: Store, match: (File) -> Boolean, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var found by remember { mutableStateOf<List<File>?>(null) }
    LaunchedEffect(Unit) { found = withContext(Dispatchers.IO) { scan(store.vols, match) } }

    val res = found
    when {
        res == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        res.isEmpty() -> Text("No se encontró nada.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        else -> LazyColumn(Modifier.fillMaxSize()) {
            item {
                Text("${res.size} encontrados", Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp, 8.dp), style = MaterialTheme.typography.bodySmall)
            }
            items(res, key = { it.path }) { f ->
                FileRow(f, (if (f.isFile) fmtSize(f.length()) + " en " else "carpeta en ") + (f.parentFile?.name ?: ""),
                    onClick = { if (f.isDirectory) go(Screen.Folder(f)) else openFile(ctx, f) })
            }
        }
    }
}

@Composable
fun TrashScreen(store: Store) {
    if (store.trash.isEmpty()) {
        Text("La papelera está vacía. Lo que elimines aparece aquí.", Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center)
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(store.trash, key = { it.trashPath }) { t ->
            FileRow(File(t.trashPath), "${fmtSize(t.size)} · ${File(t.origPath).parent ?: ""}", onClick = {}) {
                TextButton(onClick = { store.restore(t) }) { Text("Restaurar") }
                IconButton(onClick = { store.deleteForever(t) }) { Icon(Icons.Default.Close, "Eliminar definitivamente") }
            }
        }
    }
}

// ───────────────────────── Piezas visuales ─────────────────────────

@Composable
fun FileRow(f: File, sub: String, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(44.dp), contentAlignment = Alignment.Center) { FileIcon(f) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun FileIcon(f: File) {
    if (f.isDirectory) { FolderIcon(Color(0xFFF0B429), 42.dp); return }
    val k = kindOf(f)
    Box(Modifier.size(36.dp, 40.dp).clip(RoundedCornerShape(6.dp)).background(Color(k.color)), contentAlignment = Alignment.Center) {
        Text(f.extension.take(4).uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FolderIcon(c: Color, w: Dp = 44.dp) {
    Canvas(Modifier.size(w, w * 0.85f)) {
        val bw = size.width
        val bh = size.height
        drawRoundRect(c, Offset(0f, bh * 0.1f), Size(bw * 0.42f, bh * 0.3f), CornerRadius(8f))
        drawRoundRect(c, Offset(0f, bh * 0.22f), Size(bw, bh * 0.78f), CornerRadius(12f))
    }
}

@Composable
fun SdIcon(w: Dp = 40.dp) {
    Canvas(Modifier.size(w, w * 1.3f)) {
        val bw = size.width
        val bh = size.height
        val p = Path().apply {
            moveTo(0.1f * bw, 0f); lineTo(0.65f * bw, 0f); lineTo(bw, 0.3f * bh)
            lineTo(bw, bh); lineTo(0f, bh); lineTo(0f, 0.1f * bh); close()
        }
        drawPath(p, Color(0xFF4A4A60))
        repeat(4) { drawRect(Color(0xFFF4CF6E), Offset(bw * (0.15f + it * 0.14f), bh * 0.08f), Size(bw * 0.08f, bh * 0.2f)) }
    }
}

@Composable
fun NameDialog(title: String, initial: String, okText: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val n = v.trim().replace("/", "-")
                if (n.isNotEmpty()) onOk(n)
            }) { Text(okText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
