package com.archivero

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Tipos de archivo que la app reconoce por su extensión. */
enum class Kind(val label: String, val color: Long, val exts: Set<String>) {
    IMG("Fotos", 0xFF2B7DE9, setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    VID("Vídeos", 0xFF8A55D6, setOf("mp4", "mkv", "3gp", "webm", "avi", "mov")),
    AUD("Música", 0xFFE2733D, setOf("mp3", "m4a", "wav", "ogg", "flac", "aac", "opus")),
    PDF("PDF", 0xFFD64545, setOf("pdf")),
    APK("APKs", 0xFF3AA356, setOf("apk")),
    DOC("Documentos", 0xFF5B7AA0, setOf("doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "csv", "rtf")),
    OTHER("Archivos", 0xFF888888, emptySet())
}

// Tabla extensión → tipo: búsqueda directa en vez de recorrer todos los tipos por cada archivo.
private val KIND_BY_EXT: Map<String, Kind> = HashMap<String, Kind>().also { m ->
    for (k in Kind.values()) for (e in k.exts) m[e] = k
}

fun kindOfExt(ext: String): Kind = KIND_BY_EXT[ext.lowercase()] ?: Kind.OTHER

fun kindOf(f: File): Kind = kindOfExt(f.extension)

/** Un almacenamiento real: memoria principal o tarjeta SD. El espacio se lee una sola vez al cargar. */
class Vol(val name: String, val dir: File, val total: Long, val free: Long)

data class TrashItem(
    val trashPath: String,
    val origPath: String,
    val name: String,
    val size: Long,
    val isDir: Boolean
)

/** Acceso rápido del panel lateral (ya calculado, para no leer carpetas mientras se dibuja). */
class Shortcut(val icon: String, val title: String, val sub: String, val dir: File)

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(Locale("es"), "%.2f %s", v, u[i])
}

fun gb(b: Long): String = String.format(Locale("es"), "%.2f GB", b / 1073741824.0)

// DateTimeFormatter es seguro entre hilos (SimpleDateFormat no lo es y es caro de crear por fila).
private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale("es"))
fun fmtDate(ms: Long): String = DATE_FMT.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

private val DATETIME_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", Locale("es"))
fun fmtDateTime(ms: Long): String = DATETIME_FMT.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

/**
 * Un archivo o carpeta con todos sus datos ya leídos (una sola vez, fuera del hilo principal).
 * Así dibujar una fila no hace ninguna lectura de disco.
 */
class Entry(val file: File, val isDir: Boolean, val size: Long, val modified: Long) {
    val name: String = file.name
    val lowerName: String = name.lowercase()
    val ext: String = if (isDir) "" else name.substringAfterLast('.', "")
    val kind: Kind = if (isDir) Kind.OTHER else kindOfExt(ext)
    val sub: String = if (isDir) "" else fmtSize(size) + "  " + fmtDate(modified)

    companion object {
        fun of(f: File): Entry = try {
            // Una sola consulta al sistema de archivos en vez de tres (isDirectory + length + lastModified).
            val a = Files.readAttributes(f.toPath(), BasicFileAttributes::class.java)
            Entry(f, a.isDirectory, if (a.isDirectory) 0L else a.size(), a.lastModifiedTime().toMillis())
        } catch (e: Exception) {
            val d = f.isDirectory
            Entry(f, d, if (d) 0L else f.length(), f.lastModified())
        }
    }
}

fun sizeOf(f: File): Long =
    if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

fun move(src: File, dst: File): Boolean {
    dst.parentFile?.mkdirs()
    if (src.renameTo(dst)) return true
    return try {
        if (src.copyRecursively(dst, true)) src.deleteRecursively()
        else { dst.deleteRecursively(); false }   // si la copia falló, no dejar basura a medias
    } catch (e: Exception) {
        dst.deleteRecursively()
        false
    }
}

/** Cuántos elementos visibles tiene una carpeta (list() solo trae nombres: mucho más barato que listFiles()). */
fun countVisible(d: File): Int = d.list()?.count { !it.startsWith(".") } ?: 0

/** Carpetas primero, luego archivos, en orden alfabético. Oculta los que empiezan con punto. LLAMAR FUERA DEL HILO PRINCIPAL. */
fun listEntries(d: File): List<Entry> {
    val files = d.listFiles() ?: return emptyList()
    val out = ArrayList<Entry>(files.size)
    for (f in files) if (!f.name.startsWith(".")) out.add(Entry.of(f))
    out.sortWith(compareBy<Entry>({ !it.isDir }, { it.lowerName }))
    return out
}

fun firstFolder(v: Vol): File? =
    listEntries(v.dir).firstOrNull { it.isDir && it.name != "Android" }?.file

private const val SCAN_LIMIT = 20000

/**
 * Recorre todos los almacenamientos buscando lo que cumpla [match].
 * - Se puede cancelar (si sales de la pantalla, deja de recorrer).
 * - Avisa resultados parciales con [onPartial] para mostrarlos mientras sigue buscando.
 * - Devuelve todo ordenado por fecha (lo más nuevo primero).
 */
suspend fun scan(vols: List<Vol>, onPartial: (List<Entry>) -> Unit, match: (File) -> Boolean): List<Entry> {
    val out = ArrayList<Entry>()
    var lastEmit = 0L
    outer@ for (v in vols) {
        val walk = v.dir.walkTopDown()
            .onEnter { d -> !d.name.startsWith(".") && !(d.parentFile == v.dir && d.name == "Android") }
        for (f in walk) {
            currentCoroutineContext().ensureActive()
            if (f == v.dir || f.name.startsWith(".")) continue
            if (match(f)) {
                out.add(Entry.of(f))
                if (out.size >= SCAN_LIMIT) break@outer
                val now = System.currentTimeMillis()
                if (now - lastEmit > 400) {
                    lastEmit = now
                    onPartial(out.sortedByDescending { it.modified })
                }
            }
        }
    }
    return out.sortedByDescending { it.modified }
}

class ScanResult(val items: List<Entry>, val time: Long)

/** Lo que el usuario copió o cortó y todavía no pegó (uno o varios elementos). */
class Clip(val files: List<File>, val cut: Boolean)

enum class SortBy(val label: String) { NAME("Nombre"), DATE("Fecha"), SIZE("Tamaño"), TYPE("Tipo") }

/** Ordena la lista; las carpetas siempre van primero. */
fun sortEntries(list: List<Entry>, by: SortBy, asc: Boolean): List<Entry> {
    val base: Comparator<Entry> = when (by) {
        SortBy.NAME -> compareBy<Entry> { it.lowerName }
        SortBy.DATE -> compareBy<Entry> { it.modified }
        SortBy.SIZE -> compareBy<Entry> { it.size }
        SortBy.TYPE -> compareBy<Entry>({ it.ext.lowercase() }, { it.lowerName })
    }
    val ordered = if (asc) base else base.reversed()
    return list.sortedWith(compareBy<Entry> { !it.isDir }.then(ordered))
}

private val DAY_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("d 'de' MMMM yyyy", Locale("es"))
fun dayOf(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
fun dayLabel(d: LocalDate): String {
    val today = LocalDate.now()
    return when (d) {
        today -> "Hoy"
        today.minusDays(1) -> "Ayer"
        else -> DAY_FMT.format(d)
    }
}

class ZipItem(val name: String, val size: Long, val isDir: Boolean)

fun openZip(f: File): ZipFile? = try {
    ZipFile(f)
} catch (e: Exception) {
    try { ZipFile(f, Charsets.ISO_8859_1) } catch (e2: Exception) { null }
}

/** Contenido de un ZIP sin extraerlo. LLAMAR FUERA DEL HILO PRINCIPAL. */
fun listZip(f: File): List<ZipItem>? {
    val z = openZip(f) ?: return null
    return z.use { zf -> java.util.Collections.list(zf.entries()).map { ZipItem(it.name, maxOf(it.size, 0L), it.isDirectory) } }
}

/** Espacio libre del almacenamiento donde está [d]. Si no se puede saber, no bloquea la operación. */
fun freeBytes(d: File): Long = try { StatFs(d.path).availableBytes } catch (e: Exception) { Long.MAX_VALUE }

/** Un nombre que no exista en [dir]: "foto.jpg" → "foto (2).jpg". */
fun uniqueFile(dir: File, name: String, isDir: Boolean): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val dot = name.lastIndexOf('.')
    val hasExt = !isDir && dot > 0
    val base = if (hasExt) name.substring(0, dot) else name
    val ext = if (hasExt) name.substring(dot) else ""
    var i = 2
    while (true) {
        f = File(dir, "$base ($i)$ext")
        if (!f.exists()) return f
        i++
    }
}

/** Tamaño total, archivos y carpetas que contiene una carpeta. LLAMAR FUERA DEL HILO PRINCIPAL. */
fun folderStats(d: File): Triple<Long, Int, Int> {
    var bytes = 0L; var files = 0; var dirs = 0
    for (f in d.walkTopDown()) {
        if (f == d) continue
        if (f.isDirectory) dirs++ else { files++; bytes += f.length() }
    }
    return Triple(bytes, files, dirs)
}

private const val MAX_FAILS = 5
private const val LOCKOUT_MS = 5 * 60_000L

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("archivero", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    var granted by mutableStateOf(Environment.isExternalStorageManager())
    var vols by mutableStateOf<List<Vol>>(emptyList())
    var shortcuts by mutableStateOf<List<Shortcut>>(emptyList())
    var trash by mutableStateOf<List<TrashItem>>(emptyList())
    var tick by mutableIntStateOf(0)

    /** Copiar / cortar: se pega desde cualquier carpeta. */
    var clip by mutableStateOf<Clip?>(null)

    /** Mensaje mientras corre una operación larga (copiar, comprimir…); null si no hay ninguna. */
    var busy by mutableStateOf<String?>(null)

    /** Candado: hay contraseña puesta / la app está bloqueada ahora. */
    var hasPassword by mutableStateOf(prefs.getString("pw_hash", null) != null)
    var locked by mutableStateOf(hasPassword)

    /** Orden de las carpetas (se recuerda entre usos). */
    var sortBy by mutableStateOf(SortBy.values().getOrElse(prefs.getInt("sort_by", 0)) { SortBy.NAME })
    var sortAsc by mutableStateOf(prefs.getBoolean("sort_asc", true))

    fun setSort(by: SortBy, asc: Boolean) {
        sortBy = by
        sortAsc = asc
        prefs.edit().putInt("sort_by", by.ordinal).putBoolean("sort_asc", asc).apply()
    }

    /** Resultados de categorías/búsquedas ya calculados, para abrirlos al instante. */
    val scanCache = HashMap<String, ScanResult>()

    init {
        // Nada de leer disco aquí: la app dibuja la primera pantalla enseguida y los datos llegan después.
        refresh()
        scope.launch { trash = withContext(Dispatchers.IO) { loadTrash() } }
    }

    fun close() { scope.cancel() }

    fun refresh() {
        granted = Environment.isExternalStorageManager()
        scope.launch {
            val (v, s) = withContext(Dispatchers.IO) {
                val vv = loadVols()
                vv to loadShortcuts(vv)
            }
            vols = v
            shortcuts = s
            tick++
        }
    }

    /** Como refresh(), pero además olvida los resultados guardados de categorías (hubo cambios en disco). */
    fun reload() {
        scanCache.clear()
        refresh()
    }

    private fun loadVols(): List<Vol> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        var sd = 0
        return sm.storageVolumes
            .filter { it.state == Environment.MEDIA_MOUNTED && it.directory != null }
            .map { v ->
                val name = if (v.isPrimary) "Almacenamiento primordial" else {
                    sd++
                    if (sd > 1) "Tarjeta SD $sd" else "Tarjeta SD"
                }
                val dir = v.directory!!
                val (total, free) = try {
                    val s = StatFs(dir.path)
                    s.totalBytes to s.availableBytes
                } catch (e: Exception) {
                    1L to 0L
                }
                Vol(name, dir, total, free)
            }
    }

    private fun loadShortcuts(vs: List<Vol>): List<Shortcut> {
        val out = ArrayList<Shortcut>()
        val music = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        if (music.exists()) out.add(Shortcut("🎧", "Audio", "/${music.name}", music))
        vs.forEachIndexed { i, v ->
            firstFolder(v)?.let { f ->
                out.add(Shortcut(if (i == 0) "📁" else "💾", v.name, "/${f.name}", f))
            }
        }
        return out
    }

    // ---- Papelera: cada almacenamiento guarda lo borrado en su carpeta oculta .ArchiveroTrash ----
    // Todo lo pesado (calcular tamaño, mover, borrar) corre en segundo plano para no congelar la pantalla.

    private fun trashDir(f: File, vs: List<Vol>): File {
        val root = vs.firstOrNull { f.path == it.dir.path || f.path.startsWith(it.dir.path + "/") }?.dir
        return File(root ?: f.parentFile!!, ".ArchiveroTrash")
    }

    private fun trashOne(f: File, vs: List<Vol>): TrashItem? {
        val dst = File(trashDir(f, vs), "${System.currentTimeMillis()}_${f.name}")
        val isDir = f.isDirectory
        val size = sizeOf(f)
        return if (move(f, dst)) TrashItem(dst.path, f.path, f.name, size, isDir) else null
    }

    /** Mueve varios elementos a la papelera. Devuelve cuántos se pudieron mover. */
    suspend fun moveToTrash(files: List<File>): Int {
        val vs = vols
        val showBusy = files.size > 1
        if (showBusy) busy = "Moviendo a la papelera…"
        try {
            val items = withContext(Dispatchers.IO) { files.mapNotNull { trashOne(it, vs) } }
            if (items.isNotEmpty()) {
                trash = trash + items
                saveTrash()
                reload()
            }
            return items.size
        } finally {
            if (showBusy) busy = null
        }
    }

    suspend fun moveToTrash(f: File): Boolean = moveToTrash(listOf(f)) == 1

    suspend fun restore(t: TrashItem): Boolean {
        val ok = withContext(Dispatchers.IO) {
            var dest = File(t.origPath)
            if (dest.exists()) {
                val ext = if (dest.extension.isEmpty()) "" else "." + dest.extension
                dest = File(dest.parentFile, "${dest.nameWithoutExtension} (restaurado)$ext")
            }
            move(File(t.trashPath), dest)
        }
        if (ok) {
            trash = trash - t
            saveTrash()
            reload()
        }
        return ok
    }

    suspend fun deleteForever(t: TrashItem) {
        withContext(Dispatchers.IO) { File(t.trashPath).deleteRecursively() }
        trash = trash - t
        saveTrash()
        reload()
    }

    suspend fun emptyTrash() {
        val items = trash
        withContext(Dispatchers.IO) { items.forEach { File(it.trashPath).deleteRecursively() } }
        trash = emptyList()
        saveTrash()
        reload()
    }

    // ---- Copiar / cortar / pegar ----

    private fun volDirOf(f: File, vs: List<Vol>): File? =
        vs.firstOrNull { f.path == it.dir.path || f.path.startsWith(it.dir.path + "/") }?.dir

    /** Pega [c] (uno o varios elementos) dentro de [destDir]. Devuelve el mensaje de error, o null si salió bien. */
    suspend fun paste(c: Clip, destDir: File): String? {
        val srcs = c.files.filter { it.exists() }
        if (srcs.isEmpty()) { clip = null; return "Los originales ya no existen" }
        for (src in srcs) {
            if (src.isDirectory && (destDir.path == src.path || destDir.path.startsWith(src.path + "/")))
                return "No se puede pegar una carpeta dentro de sí misma"
        }
        val todo = if (c.cut) srcs.filter { it.parentFile != destDir } else srcs
        if (todo.isEmpty()) { clip = null; return "Ya están en esta carpeta" }
        val vs = vols
        busy = if (c.cut) "Moviendo…" else "Copiando…"
        try {
            val err = withContext(Dispatchers.IO) {
                // Mover dentro del mismo almacenamiento no gasta espacio; copiar (o mover a otra tarjeta) sí.
                val destVol = volDirOf(destDir, vs)
                val need = todo.filter { !c.cut || volDirOf(it, vs) != destVol }.sumOf { sizeOf(it) }
                if (need > 0L) {
                    val free = freeBytes(destDir)
                    if (need > free) return@withContext "No hay espacio suficiente: hacen falta ${fmtSize(need)} y hay ${fmtSize(free)}"
                }
                var failed = 0
                for (src in todo) {
                    val dst = uniqueFile(destDir, src.name, src.isDirectory)
                    val ok = if (c.cut) {
                        move(src, dst)
                    } else {
                        val r = try { src.copyRecursively(dst, false) } catch (e: Exception) { false }
                        if (!r) dst.deleteRecursively()
                        r
                    }
                    if (!ok) failed++
                }
                if (failed == 0) null else "No se pudieron pegar $failed de ${todo.size}"
            }
            if (err == null && c.cut) clip = null
            return err
        } finally {
            busy = null
            reload()
        }
    }

    // ---- ZIP ----

    suspend fun zip(src: File): String? = zip(listOf(src))

    /** Comprime uno o varios elementos (de la misma carpeta) en un .zip al lado. Devuelve el error, o null si salió bien. */
    suspend fun zip(files: List<File>): String? {
        busy = "Comprimiendo…"
        try {
            return withContext(Dispatchers.IO) {
                val first = files.firstOrNull() ?: return@withContext "No hay nada que comprimir"
                val parent = first.parentFile ?: return@withContext "No se pudo comprimir"
                val need = files.sumOf { sizeOf(it) }
                val free = freeBytes(parent)
                if (need > free) return@withContext "No hay espacio suficiente: hacen falta ${fmtSize(need)} y hay ${fmtSize(free)}"
                val base = when {
                    files.size > 1 -> "Archivos"
                    first.isDirectory -> first.name
                    else -> first.nameWithoutExtension
                }
                val dst = uniqueFile(parent, "$base.zip", false)
                try {
                    ZipOutputStream(BufferedOutputStream(FileOutputStream(dst), 64 * 1024)).use { zos ->
                        val cut = parent.path.length + 1
                        for (src in files) {
                            val seq: Sequence<File> = if (src.isDirectory) src.walkTopDown() else sequenceOf(src)
                            for (f in seq) {
                                val rel = f.path.substring(cut).replace(File.separatorChar, '/')
                                if (f.isDirectory) {
                                    zos.putNextEntry(ZipEntry("$rel/"))
                                    zos.closeEntry()
                                } else {
                                    zos.putNextEntry(ZipEntry(rel))
                                    FileInputStream(f).use { it.copyTo(zos, 64 * 1024) }
                                    zos.closeEntry()
                                }
                            }
                        }
                    }
                    null
                } catch (e: Exception) {
                    dst.delete()
                    "No se pudo comprimir: ${e.message}"
                }
            }
        } finally {
            busy = null
            reload()
        }
    }

    /** Extrae un .zip en una carpeta nueva al lado, con el nombre del zip. Devuelve el error, o null si salió bien. */
    suspend fun unzip(zipFile: File): String? {
        busy = "Extrayendo…"
        try {
            return withContext(Dispatchers.IO) {
                val parent = zipFile.parentFile ?: return@withContext "No se pudo extraer"
                val zf = openZip(zipFile) ?: return@withContext "El ZIP está dañado o no se puede leer"
                zf.use { z ->
                    val entries = java.util.Collections.list(z.entries())
                    var total = 0L
                    for (en in entries) total += maxOf(en.size, 0L)
                    val free = freeBytes(parent)
                    if (total > free) return@withContext "No hay espacio suficiente: hacen falta ${fmtSize(total)} y hay ${fmtSize(free)}"
                    val dest = uniqueFile(parent, zipFile.nameWithoutExtension, true)
                    val destCanon = dest.canonicalPath
                    dest.mkdirs()
                    try {
                        for (en in entries) {
                            val out = File(dest, en.name)
                            val canon = out.canonicalPath
                            // Protección: un zip malicioso no puede escribir fuera de su carpeta.
                            if (canon != destCanon && !canon.startsWith(destCanon + File.separator))
                                throw SecurityException("el ZIP trae una ruta no permitida")
                            if (en.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                z.getInputStream(en).use { inp -> FileOutputStream(out).use { inp.copyTo(it, 64 * 1024) } }
                            }
                        }
                        null
                    } catch (e: Exception) {
                        dest.deleteRecursively()
                        "No se pudo extraer: ${e.message}"
                    }
                }
            }
        } finally {
            busy = null
            reload()
        }
    }

    // ---- Candado con contraseña ----
    // Es un candado de comodidad para que otros no abran la app; no cifra los archivos.

    private fun hashPw(pw: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 20_000, 256)).encoded

    suspend fun setPassword(pw: String) {
        withContext(Dispatchers.Default) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            prefs.edit()
                .putString("pw_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("pw_hash", Base64.encodeToString(hashPw(pw, salt), Base64.NO_WRAP))
                .putInt("pw_fails", 0).putLong("pw_until", 0L)
                .apply()
        }
        hasPassword = true
    }

    suspend fun checkPassword(pw: String): Boolean = withContext(Dispatchers.Default) {
        val salt = prefs.getString("pw_salt", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        val hash = prefs.getString("pw_hash", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        salt != null && hash != null && MessageDigest.isEqual(hash, hashPw(pw, salt))
    }

    fun removePassword() {
        prefs.edit().remove("pw_salt").remove("pw_hash").remove("pw_fails").remove("pw_until").apply()
        hasPassword = false
        locked = false
    }

    fun lockNow() { if (hasPassword) locked = true }

    /** Intenta desbloquear. Devuelve el mensaje de error, o null si la contraseña era correcta. */
    suspend fun unlock(pw: String): String? {
        val wait = prefs.getLong("pw_until", 0L) - System.currentTimeMillis()
        if (wait > 0) return "Demasiados intentos. Esperá ${(wait + 59_999) / 60_000} min."
        if (checkPassword(pw)) {
            prefs.edit().putInt("pw_fails", 0).apply()
            locked = false
            return null
        }
        val fails = prefs.getInt("pw_fails", 0) + 1
        return if (fails >= MAX_FAILS) {
            prefs.edit().putInt("pw_fails", 0).putLong("pw_until", System.currentTimeMillis() + LOCKOUT_MS).apply()
            "Demasiados intentos. Esperá ${LOCKOUT_MS / 60_000} min."
        } else {
            prefs.edit().putInt("pw_fails", fails).apply()
            "Contraseña incorrecta (${MAX_FAILS - fails} intentos restantes)"
        }
    }

    private fun saveTrash() {
        val arr = JSONArray(trash.map {
            JSONObject().put("t", it.trashPath).put("o", it.origPath)
                .put("n", it.name).put("s", it.size).put("d", it.isDir)
        })
        prefs.edit().putString("trash", arr.toString()).apply()
    }

    private fun loadTrash(): List<TrashItem> = try {
        val a = JSONArray(prefs.getString("trash", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }
            .map { TrashItem(it.getString("t"), it.getString("o"), it.getString("n"), it.getLong("s"), it.getBoolean("d")) }
            .filter { File(it.trashPath).exists() }
    } catch (e: Exception) {
        emptyList()   // datos guardados dañados: empezar con la papelera vacía en vez de cerrarse la app
    }
}
