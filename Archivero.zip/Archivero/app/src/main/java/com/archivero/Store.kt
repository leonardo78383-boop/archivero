package com.archivero

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Tipos de archivo que la app reconoce por su extensión. */
enum class Kind(val label: String, val color: Long, val exts: Set<String>) {
    IMG("Fotos", 0xFF2B7DE9, setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    VID("Vídeos", 0xFF8A55D6, setOf("mp4", "mkv", "3gp", "webm", "avi", "mov")),
    AUD("Música", 0xFFE2733D, setOf("mp3", "m4a", "wav", "ogg", "flac", "aac", "opus")),
    PDF("PDF", 0xFFD64545, setOf("pdf")),
    APK("APKs", 0xFF3AA356, setOf("apk")),
    DOC("Documentos", 0xFF5B7AA0, setOf("doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "csv", "rtf")),
    OTHER("Archivos", 0xFF888888, emptySet())
}

fun kindOf(f: File): Kind =
    Kind.values().firstOrNull { f.extension.lowercase() in it.exts } ?: Kind.OTHER

/** Un almacenamiento real: memoria principal o tarjeta SD. */
data class Vol(val name: String, val dir: File) {
    val total: Long get() = try { StatFs(dir.path).totalBytes } catch (e: Exception) { 1L }
    val free: Long get() = try { StatFs(dir.path).availableBytes } catch (e: Exception) { 0L }
}

data class TrashItem(
    val trashPath: String,
    val origPath: String,
    val name: String,
    val size: Long,
    val isDir: Boolean
)

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(Locale("es"), "%.2f %s", v, u[i])
}

fun gb(b: Long): String = String.format(Locale("es"), "%.2f GB", b / 1073741824.0)

fun sizeOf(f: File): Long =
    if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

fun move(src: File, dst: File): Boolean {
    dst.parentFile?.mkdirs()
    if (src.renameTo(dst)) return true
    return try { src.copyRecursively(dst, true) && src.deleteRecursively() } catch (e: Exception) { false }
}

/** Carpetas primero, luego archivos, en orden alfabético. Oculta los que empiezan con punto. */
fun listDir(d: File): List<File> =
    (d.listFiles()?.toList() ?: emptyList())
        .filter { !it.name.startsWith(".") }
        .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))

fun firstFolder(v: Vol): File? =
    listDir(v.dir).firstOrNull { it.isDirectory && it.name != "Android" }

/** Recorre todos los almacenamientos buscando lo que cumpla [match]. */
fun scan(vols: List<Vol>, match: (File) -> Boolean): List<File> {
    val out = ArrayList<File>()
    for (v in vols) {
        v.dir.walkTopDown()
            .onEnter { d -> !d.name.startsWith(".") && !(d.parentFile == v.dir && d.name == "Android") }
            .forEach { f ->
                if (f != v.dir && !f.name.startsWith(".") && match(f)) out.add(f)
                if (out.size >= 3000) return out.sortedByDescending { it.lastModified() }
            }
    }
    return out.sortedByDescending { it.lastModified() }
}

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("archivero", Context.MODE_PRIVATE)

    var granted by mutableStateOf(Environment.isExternalStorageManager())
    var vols by mutableStateOf(loadVols())
    var trash by mutableStateOf(loadTrash())
    var tick by mutableIntStateOf(0)

    fun refresh() {
        granted = Environment.isExternalStorageManager()
        vols = loadVols()
        tick++
    }

    private fun loadVols(): List<Vol> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        var sd = 0
        return sm.storageVolumes
            .filter { it.state == Environment.MEDIA_MOUNTED && it.directory != null }
            .map { v ->
                val name = if (v.isPrimary) "Almacenamiento primordial" else {
                    sd++
                    if (sd > 1) "Tarjeta SD $sd" else "Tarjeta SD"
                }
                Vol(name, v.directory!!)
            }
    }

    // ---- Papelera: cada almacenamiento guarda lo borrado en su carpeta oculta .ArchiveroTrash ----

    private fun volOf(f: File): Vol? = vols.firstOrNull { f.path.startsWith(it.dir.path) }

    private fun trashDir(f: File) = File(volOf(f)?.dir ?: f.parentFile!!, ".ArchiveroTrash")

    fun moveToTrash(f: File): Boolean {
        val dst = File(trashDir(f), "${System.currentTimeMillis()}_${f.name}")
        val size = sizeOf(f)
        val isDir = f.isDirectory
        if (!move(f, dst)) return false
        trash = trash + TrashItem(dst.path, f.path, f.name, size, isDir)
        saveTrash()
        refresh()
        return true
    }

    fun restore(t: TrashItem) {
        var dest = File(t.origPath)
        if (dest.exists()) {
            val ext = if (dest.extension.isEmpty()) "" else "." + dest.extension
            dest = File(dest.parentFile, "${dest.nameWithoutExtension} (restaurado)$ext")
        }
        if (move(File(t.trashPath), dest)) {
            trash = trash - t
            saveTrash()
            refresh()
        }
    }

    fun deleteForever(t: TrashItem) {
        File(t.trashPath).deleteRecursively()
        trash = trash - t
        saveTrash()
        refresh()
    }

    fun emptyTrash() {
        trash.forEach { File(it.trashPath).deleteRecursively() }
        trash = emptyList()
        saveTrash()
        refresh()
    }

    private fun saveTrash() {
        val arr = JSONArray(trash.map {
            JSONObject().put("t", it.trashPath).put("o", it.origPath)
                .put("n", it.name).put("s", it.size).put("d", it.isDir)
        })
        prefs.edit().putString("trash", arr.toString()).apply()
    }

    private fun loadTrash(): List<TrashItem> {
        val a = JSONArray(prefs.getString("trash", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it) }
            .map { TrashItem(it.getString("t"), it.getString("o"), it.getString("n"), it.getLong("s"), it.getBoolean("d")) }
            .filter { File(it.trashPath).exists() }
    }
}
