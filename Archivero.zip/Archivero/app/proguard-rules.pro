# Archivero no usa reflexión propia; las reglas por defecto de Android y Compose alcanzan.
