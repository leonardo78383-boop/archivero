# Archivero (Android, Kotlin + Jetpack Compose)

## Cómo obtener el APK
1. Instala Android Studio (versión reciente, Ladybug o superior).
2. File > Open > elige esta carpeta `Archivero` y espera a que termine "Gradle Sync".
3. Para la versión RÁPIDA (la que debes instalar): View > Tool Windows > Build Variants, cambia `app` a **release**,
   y luego Build > Build Bundle(s) / APK(s) > Build APK(s). O por terminal: `./gradlew assembleRelease`.
4. El APK queda en `app/build/outputs/apk/release/app-release.apk`.
   (El de `debug` sirve para probar, pero va notablemente más lento: no lo uses de día a día.)

## Qué hace
- Pide UNA sola vez el permiso "Acceso a todos los archivos" (Ajustes del sistema). Android lo recuerda.
- Muestra la memoria principal y la tarjeta SD reales: carpetas, archivos, espacio libre / ocupado / total exacto.
- Categorías reales: Música, Fotos, Vídeos, Documentos, PDF y APKs (recorre ambos almacenamientos).
- Panel de las 3 rayitas: Inicio, almacenamientos con barra y espacio, papelera, accesos rápidos.
- Papelera: lo eliminado va a `.ArchiveroTrash` en el mismo almacenamiento; se puede restaurar o vaciar.
- Crear carpeta, renombrar, abrir archivos con la app correspondiente, buscar.
- Copiar, cortar y pegar (menú ⋮ de cada archivo; luego abrí otra carpeta y toca "Pegar aquí"). Avisa si no hay espacio.
- Información del archivo/carpeta: tipo, ubicación, tamaño, fecha y permisos.
- Compartir archivos con cualquier app, comprimir en ZIP y extraer ZIP (con protección contra ZIP maliciosos).
- Ordenar por nombre, fecha, tamaño o tipo (ascendente/descendente), botón "Ordenar" sobre la lista. Se recuerda.
- Selección múltiple: mantené presionado un archivo; después marcá más y usá Copiar, Cortar, ZIP o Eliminar.
- Galería: las categorías Fotos y Vídeos se ven en cuadrícula con miniaturas, agrupadas por día.
- Ver el contenido de un ZIP sin extraerlo (menú ⋮ del .zip). Información muestra también las dimensiones de las fotos.
- Candado con contraseña (menú ⋮ de arriba): se pide al abrir y tras 1 minuto fuera de la app; 5 intentos
  fallidos bloquean 5 minutos. Es un candado de comodidad, no cifra tus archivos.

## Notas
- Android 11 o superior (minSdk 30).
- Google Play restringe el permiso de "todos los archivos"; para uso personal o instalación directa no hay problema.
- Para instalar APKs desde la app, Android pedirá permitir "instalar apps desconocidas" a Archivero.
- No incluye ícono propio (usa el de Android por defecto); se agrega luego con File > New > Image Asset.

## Versión 1.3: ordenar, selección múltiple, galería y ver ZIP (ver "Qué hace")
## Versión 1.2: copiar/pegar, información, compartir, ZIP y candado

## Cambios de la versión 1.1 (rendimiento)
- Carpetas, categorías y papelera se leen en segundo plano; ya no se congela la pantalla.
- Cada fila ya no consulta el disco al dibujarse (antes lo hacía en cada desplazamiento).
- La app abre primero la pantalla y carga almacenamiento/papelera después.
- Categorías y búsquedas muestran resultados mientras siguen buscando, se pueden cancelar y se guardan 30 s.
- Build release con R8 y perfil de arranque.
