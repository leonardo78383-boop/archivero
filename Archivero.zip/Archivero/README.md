# Archivero (Android, Kotlin + Jetpack Compose)

## Cómo obtener el APK
1. Instala Android Studio (versión reciente, Ladybug o superior).
2. File > Open > elige esta carpeta `Archivero` y espera a que termine "Gradle Sync".
3. Conecta tu teléfono con "Depuración USB" activada y pulsa Run, o genera el instalador con
   Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Qué hace
- Pide UNA sola vez el permiso "Acceso a todos los archivos" (Ajustes del sistema). Android lo recuerda.
- Muestra la memoria principal y la tarjeta SD reales: carpetas, archivos, espacio libre / ocupado / total exacto.
- Categorías reales: Música, Fotos, Vídeos, Documentos, PDF y APKs (recorre ambos almacenamientos).
- Panel de las 3 rayitas: Inicio, almacenamientos con barra y espacio, papelera, accesos rápidos.
- Papelera: lo eliminado va a `.ArchiveroTrash` en el mismo almacenamiento; se puede restaurar o vaciar.
- Crear carpeta, renombrar, abrir archivos con la app correspondiente, buscar.

## Notas
- Android 11 o superior (minSdk 30).
- Google Play restringe el permiso de "todos los archivos"; para uso personal o instalación directa no hay problema.
- Para instalar APKs desde la app, Android pedirá permitir "instalar apps desconocidas" a Archivero.
- No incluye ícono propio (usa el de Android por defecto); se agrega luego con File > New > Image Asset.
