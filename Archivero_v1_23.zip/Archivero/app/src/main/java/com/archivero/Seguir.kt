package com.archivero

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.min

// ───────────── Enlace entre la app y el amigo flotante ─────────────

/**
 * Punto de encuentro entre la pantalla de la app y el servicio que dibuja al amigo sobre otras apps.
 * El amigo flotante solo aparece si: está suelto (no guardado), la app NO está en pantalla y se dio el permiso
 * "Mostrar sobre otras apps".
 */
object FriendLink {
    @Volatile var store: Store? = null          // para que el mini reproductor use la misma música de la app
    @Volatile var appVisible = true
    @Volatile var wantOut = false               // el amigo anda suelto
    var listener: (() -> Unit)? = null

    fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun setVisible(v: Boolean) {
        appVisible = v
        listener?.invoke()
    }

    /** Arranca el servicio si el amigo anda suelto y hay permiso; si no, lo detiene. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        if (wantOut && canDraw(app)) {
            try { app.startForegroundService(Intent(app, FriendService::class.java)) } catch (e: Exception) { }
        } else stop(app)
    }

    fun stop(ctx: Context) {
        try { ctx.applicationContext.stopService(Intent(ctx.applicationContext, FriendService::class.java)) } catch (e: Exception) { }
    }
}

/** Servicio en primer plano (con un aviso discreto) que mantiene viva la esfera flotante al salir de la app. */
class FriendService : Service() {
    private var overlay: FriendOverlay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = FriendOverlay(this)
        FriendLink.listener = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        refresh()
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (FriendLink.appVisible) overlay?.hide() else overlay?.show()
    }

    override fun onDestroy() {
        FriendLink.listener = null
        overlay?.hide()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Tu amigo te sigue", NotificationManager.IMPORTANCE_MIN))
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pi = if (launch != null) PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else null
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("Archivero")
            .setContentText("Tu amigo te sigue fuera de la app")
            .setOngoing(true)
        if (pi != null) b.setContentIntent(pi)
        return b.build()
    }

    companion object {
        private const val CHANNEL = "amigo_sigue"
        private const val NOTIF_ID = 8
    }
}

// ───────────── La esfera flotante y sus mini paneles ─────────────

/** La esfera dibujada a mano (negra con brillo y borde de cristal), igual que la del explorador pero ligera. */
private class BubbleView(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * ctx.resources.displayMetrics.density
        color = 0x88FFFFFF.toInt()
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF0198.toInt() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f
        fill.shader = RadialGradient(
            w / 2f - r * 0.35f, h / 2f - r * 0.4f, r * 1.5f,
            intArrayOf(0xFF3A3A44.toInt(), 0xFF101014.toInt(), 0xFF000000.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - rim.strokeWidth
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, rim)
        c.drawOval(RectF(cx - r * 0.55f, cy - r * 0.78f, cx - r * 0.05f, cy - r * 0.38f), glow)
        c.drawCircle(cx + r * 0.38f, cy + r * 0.42f, r * 0.09f, dot)
    }
}

/**
 * Dibuja al amigo sobre las demás apps. Al tocarlo salen 3 casillas pequeñas:
 *  1) (vacía, para después)   2) 🎵 mini reproductor ⏮ ⏯ ⏭ con ✕ para cerrarlo   3) (vacía, para después)
 * Se arrastra con el dedo y recuerda dónde lo dejaste.
 */
class FriendOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val size = dp(56)

    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var slots: View? = null
    private var slotsLp: WindowManager.LayoutParams? = null
    private var music: View? = null
    private var musicLp: WindowManager.LayoutParams? = null
    private var musicTick: Runnable? = null
    private var slotsClosedAt = 0L

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun params(outside: Boolean, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            (if (outside) WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH else 0),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun shape(color: Int, radius: Int, stroke: Int, dashed: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (dashed) setStroke(dp(1), stroke, dp(4).toFloat(), dp(3).toFloat()) else setStroke(dp(1), stroke)
    }

    // ── Mostrar y ocultar ──

    fun show() {
        if (bubble != null || !Settings.canDrawOverlays(ctx)) return
        val d = ctx.resources.displayMetrics
        val v = BubbleView(ctx)
        val p = params(false, size, size)
        p.x = prefs.getInt("x", d.widthPixels - size - dp(8)).coerceIn(0, maxOf(0, d.widthPixels - size))
        p.y = prefs.getInt("y", d.heightPixels / 3).coerceIn(0, maxOf(0, d.heightPixels - size))

        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!moved && hypot(dx, dy) > slop) moved = true
                    if (moved) {
                        p.x = (startX + dx).toInt().coerceIn(0, maxOf(0, d.widthPixels - size))
                        p.y = (startY + dy).toInt().coerceIn(0, maxOf(0, d.heightPixels - size))
                        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
                        reposition()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("x", p.x).putInt("y", p.y).apply() else togglePanel()
                }
            }
            true
        }
        try {
            wm.addView(v, p)
            bubble = v
            bubbleLp = p
        } catch (e: Exception) {
            // Sin permiso o Android no lo permite ahora: simplemente no se muestra.
        }
    }

    fun hide() {
        closeSlots()
        closeMusic()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        bubbleLp = null
    }

    // ── Colocar los paneles junto a la esfera (debajo si cabe, si no arriba) ──

    private fun position(v: View, p: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val d = ctx.resources.displayMetrics
        v.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val pw = v.measuredWidth
        val ph = v.measuredHeight
        val gap = dp(8)
        p.x = (b.x + size / 2 - pw / 2).coerceIn(0, maxOf(0, d.widthPixels - pw))
        p.y = (if (b.y + size + gap + ph <= d.heightPixels) b.y + size + gap else b.y - gap - ph).coerceAtLeast(0)
    }

    private fun reposition() {
        slots?.let { v -> slotsLp?.let { p -> position(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
        music?.let { v -> musicLp?.let { p -> position(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
    }

    // ── Las 3 casillas ──

    private fun togglePanel() {
        if (music != null) return                       // el reproductor se cierra con su ✕
        if (slots != null) { closeSlots(); return }
        if (SystemClock.uptimeMillis() - slotsClosedAt < 300) return   // el toque que lo cerró fuera no lo reabre
        openSlots()
    }

    private fun slot(label: String?, onClick: (() -> Unit)?): TextView = TextView(ctx).apply {
        val s = dp(48)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(4), 0, dp(4), 0) }
        gravity = Gravity.CENTER
        textSize = 20f
        setTextColor(0xFFFFFFFF.toInt())
        if (label != null && onClick != null) {
            text = label
            background = shape(0xFF141414.toInt(), dp(10), 0xFF262626.toInt())
            setOnClickListener { onClick() }
        } else {
            background = shape(0x00000000, dp(10), 0xFF262626.toInt(), dashed = true)   // casilla vacía: para después
        }
    }

    private fun openSlots() {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(0xFF0B0B0B.toInt(), dp(14), 0xFF262626.toInt())
            addView(slot(null, null))                    // 1) borrar caché: más adelante
            addView(slot("🎵") { openMusic() })          // 2) música
            addView(slot(null, null))                    // 3) notificaciones: más adelante
            setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) { closeSlots() }
                false
            }
        }
        val p = params(true, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        position(row, p)
        try { wm.addView(row, p); slots = row; slotsLp = p } catch (e: Exception) { }
    }

    private fun closeSlots() {
        slots?.let { try { wm.removeView(it) } catch (e: Exception) { } ; slotsClosedAt = SystemClock.uptimeMillis() }
        slots = null
        slotsLp = null
    }

    // ── Mini reproductor ──

    private fun musicBtn(label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        val s = dp(44)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(3), 0, dp(3), 0) }
        gravity = Gravity.CENTER
        textSize = 20f
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        background = shape(0xFF141414.toInt(), dp(10), 0xFF262626.toInt())
        setOnClickListener { onClick() }
    }

    private fun openMusic() {
        closeSlots()
        fun player(): MusicPlayer? = FriendLink.store?.music?.takeIf { it.active }

        val title = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            maxWidth = dp(210)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(6), 0, dp(6), dp(6))
        }
        val play = musicBtn("▶") { player()?.toggle() }
        val buttons = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(musicBtn("⏮") { player()?.prev() })
            addView(play)
            addView(musicBtn("⏭") { player()?.next() })
            addView(musicBtn("✕") { closeMusic() })      // quita solo el panel; la música sigue
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(8))
            background = shape(0xFF0B0B0B.toInt(), dp(14), 0xFF262626.toInt())
            addView(title)
            addView(buttons)
        }
        val tick = object : Runnable {
            override fun run() {
                val m = player()
                title.text = m?.current?.nameWithoutExtension ?: "Abre una canción en Archivero"
                play.text = if (m != null && m.playing) "⏸" else "▶"
                ui.postDelayed(this, 500)
            }
        }
        val p = params(false, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        tick.run()
        position(box, p)
        try {
            wm.addView(box, p)
            music = box
            musicLp = p
            musicTick = tick
        } catch (e: Exception) {
            ui.removeCallbacks(tick)
        }
    }

    private fun closeMusic() {
        musicTick?.let { ui.removeCallbacks(it) }
        musicTick = null
        music?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        music = null
        musicLp = null
    }
}
