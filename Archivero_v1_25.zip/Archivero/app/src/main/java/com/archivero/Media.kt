package com.archivero

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Qué se está viendo a pantalla completa. */
sealed interface Viewer {
    class Images(val files: List<File>, val index: Int) : Viewer
    class Video(val files: List<File>, val index: Int) : Viewer
}

/** Abre un archivo con el visor/reproductor interno si es foto, vídeo o música; si no, con otra app. */
fun openEntry(store: Store, ctx: Context, e: Entry, siblings: List<Entry>) {
    store.memory.openFile(e.kind)
    when (e.kind) {
        Kind.IMG -> {
            val imgs = siblings.filter { !it.isDir && it.kind == Kind.IMG }.map { it.file }
            val i = imgs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.viewer = Viewer.Images(imgs, i) else openFile(ctx, e.file)
        }
        Kind.VID -> {
            val vids = siblings.filter { !it.isDir && it.kind == Kind.VID }.map { it.file }
            val i = vids.indexOfFirst { it.path == e.file.path }
            store.viewer = if (i >= 0) Viewer.Video(vids, i) else Viewer.Video(listOf(e.file), 0)
        }
        Kind.AUD -> {
            val songs = siblings.filter { !it.isDir && it.kind == Kind.AUD }.map { it.file }
            val i = songs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.music.start(songs, i) else openFile(ctx, e.file)
        }
        else -> openFile(ctx, e.file)
    }
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ───────────────────────── Capa a pantalla completa ─────────────────────────

@Composable
fun MediaOverlay(v: Viewer, onClose: () -> Unit) {
    // El pointerInput vacío hace que los toques no "atraviesen" hacia la pantalla de abajo.
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }) {
        when (v) {
            is Viewer.Images -> ImageViewer(v, onClose)
            is Viewer.Video -> VideoViewer(v, onClose)
        }
    }
}

@Composable
private fun TopBar(title: String, onClose: () -> Unit, extra: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onClose) { Text("✕", color = Color.White, fontSize = 20.sp) }
        Text(title, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        extra()
    }
}

// ───────────────────────── Visor de imágenes ─────────────────────────

/** Lee la imagen reducida (máx. ~2048 px) y ya girada según su orientación. */
suspend fun loadBitmap(f: File, maxDim: Int = 2048): Bitmap? = withContext(Dispatchers.IO) {
    try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { decoder, info, _ ->
            val s = maxOf(info.size.width, info.size.height) / maxDim
            if (s > 1) decoder.setTargetSampleSize(s)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }
}

@Composable
fun ImageViewer(v: Viewer.Images, onClose: () -> Unit) {
    BackHandler { onClose() }
    val pager = rememberPagerState(initialPage = v.index, pageCount = { v.files.size })
    var zoomed by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = !zoomed,
            beyondViewportPageCount = 1,   // la foto siguiente/anterior ya está cargada al deslizar
            key = { v.files[it].path }
        ) { page ->
            ImagePage(v.files[page]) { zoomed = it }
        }
        val cur = pager.currentPage.coerceIn(0, v.files.size - 1)
        TopBar("${cur + 1}/${v.files.size}  ${v.files[cur].name}", onClose)
    }
}

@Composable
private fun ImagePage(f: File, onZoom: (Boolean) -> Unit) {
    val res by produceState(false to (null as ImageBitmap?), f) {
        value = true to loadBitmap(f)?.asImageBitmap()
    }
    val (done, img) = res
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            !done -> ThinSpinner()
            img == null -> Text("No se pudo mostrar esta imagen", color = Color.White, textAlign = TextAlign.Center)
            else -> ZoomImage(img, onZoom)
        }
    }
}

/** Zoom con dos dedos, arrastrar cuando está ampliada y doble toque para ampliar o volver. */
@Composable
private fun ZoomImage(img: ImageBitmap, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                    } else {
                        scale = 2.5f
                    }
                    onZoom(scale > 1f)
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val fingers = ev.changes.count { it.pressed }
                        // Con un dedo y sin zoom no se toca nada: así el deslizar pasa a la foto siguiente.
                        if (fingers >= 2 || scale > 1f) {
                            val ns = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                            val mx = box.width * (ns - 1f) / 2f
                            val my = box.height * (ns - 1f) / 2f
                            val o = if (ns > 1f) offset + ev.calculatePan() else Offset.Zero
                            offset = Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
                            scale = ns
                            onZoom(ns > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        Image(
            bitmap = img,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )
    }
}

// ───────────────────────── Reproductor de vídeo ─────────────────────────

@Composable
fun VideoViewer(v: Viewer.Video, onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = LocalContext.current
    val vv = remember { VideoView(ctx) }
    var idx by remember { mutableIntStateOf(v.index.coerceIn(0, v.files.size - 1)) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showUi by remember { mutableStateOf(true) }
    var landscape by remember { mutableStateOf(false) }
    val file = v.files[idx]

    DisposableEffect(vv) {
        onDispose {
            vv.stopPlayback()
            ctx.findActivity()?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Cada vez que cambia el vídeo (⏮ ⏭ o fin del anterior) se carga el nuevo en el mismo reproductor.
    LaunchedEffect(idx) {
        pos = 0
        dur = 0
        playing = false
        vv.setVideoURI(Uri.fromFile(v.files[idx]))
    }

    // Barra de progreso propia (sin MediaController): se actualiza cada 300 ms mientras reproduce.
    LaunchedEffect(playing, idx) {
        while (playing) {
            if (drag == null) pos = try { vv.currentPosition } catch (e: Exception) { pos }
            delay(300)
        }
    }

    // Los controles se esconden solos a los 4 segundos mientras reproduce.
    LaunchedEffect(showUi, playing, idx, drag) {
        if (showUi && playing && drag == null) {
            delay(4000)
            showUi = false
        }
    }

    fun next() { if (idx + 1 < v.files.size) idx++ }
    fun prev() { if (pos > 3000 || idx == 0) { vv.seekTo(0); pos = 0 } else idx-- }
    fun toggle() {
        if (vv.isPlaying) { vv.pause(); playing = false } else { vv.start(); playing = true }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                vv.apply {
                    setOnPreparedListener { mp ->
                        dur = mp.duration
                        start()
                        playing = true
                    }
                    setOnCompletionListener {
                        if (idx + 1 < v.files.size) idx++ else { playing = false; showUi = true }
                    }
                    setOnErrorListener { _, _, _ ->
                        playing = false
                        showUi = true
                        toast(ctx, "No se puede reproducir este vídeo")
                        true
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        // Capa transparente: un toque muestra u oculta los controles.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showUi = !showUi } }
        )
        if (showUi) {
            Box(Modifier.align(Alignment.TopCenter)) {
                TopBar("${idx + 1}/${v.files.size}  ${file.name}", onClose) {
                    TextButton(onClick = {
                        landscape = !landscape
                        ctx.findActivity()?.requestedOrientation =
                            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }) { Text("⟳ Girar", color = Color.White) }
                }
            }
            val max = maxOf(1, dur).toFloat()
            val shown = (drag ?: pos.toFloat()).coerceIn(0f, max)
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Slider(
                    value = shown,
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let { vv.seekTo(it.toInt()); pos = it.toInt() }
                        drag = null
                    },
                    valueRange = 0f..max
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        fmtTime(shown.toInt()) + " / " + fmtTime(dur),
                        Modifier.padding(start = 8.dp).weight(1f),
                        color = Color.White, style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { prev() }) { Text("⏮", fontSize = 22.sp) }
                    TextButton(onClick = { toggle() }) { Text(if (playing) "⏸" else "▶", fontSize = 22.sp) }
                    TextButton(onClick = { next() }, enabled = idx + 1 < v.files.size) { Text("⏭", fontSize = 22.sp) }
                }
            }
        }
    }
}

// ───────────────────────── Reproductor de música ─────────────────────────

class MusicPlayer(private val appCtx: Context? = null) {
    private var mp: MediaPlayer? = null

    var queue by mutableStateOf<List<File>>(emptyList())
    var index by mutableIntStateOf(0)
    var playing by mutableStateOf(false)
    var position by mutableIntStateOf(0)
    var duration by mutableIntStateOf(0)

    val current: File? get() = queue.getOrNull(index)
    val active: Boolean get() = queue.isNotEmpty()

    fun start(files: List<File>, i: Int) {
        queue = files
        play(i)
    }

    private fun play(i: Int) {
        if (i !in queue.indices) return
        index = i
        position = 0
        duration = 0
        releasePlayer()
        val m = MediaPlayer()
        try {
            // Con la pantalla apagada o fuera de la app, que la música no se corte.
            appCtx?.let { m.setWakeMode(it, android.os.PowerManager.PARTIAL_WAKE_LOCK) }
            m.setDataSource(queue[i].path)
            m.setOnPreparedListener {
                it.start()
                duration = it.duration
                playing = true
            }
            m.setOnCompletionListener { next() }
            m.setOnErrorListener { _, _, _ ->
                playing = false
                true
            }
            mp = m
            m.prepareAsync()
        } catch (e: Exception) {
            mp = null
            try { m.release() } catch (ignored: Exception) { }
            playing = false
        }
    }

    fun toggle() {
        val m = mp ?: return
        try {
            if (m.isPlaying) {
                m.pause()
                playing = false
            } else {
                m.start()
                playing = true
            }
        } catch (e: Exception) {
            playing = false
        }
    }

    fun next() {
        if (index + 1 < queue.size) play(index + 1) else { playing = false; position = 0 }
    }

    fun prev() {
        if (position > 3000 || index == 0) seek(0) else play(index - 1)
    }

    fun seek(ms: Int) {
        try { mp?.seekTo(ms) } catch (ignored: Exception) { }
        position = ms
    }

    /** Lo llama la pantalla cada medio segundo para mover la barra de progreso. */
    fun tick() {
        val m = mp ?: return
        try { if (m.isPlaying) position = m.currentPosition } catch (ignored: Exception) { }
    }

    private fun releasePlayer() {
        mp?.let { try { it.release() } catch (ignored: Exception) { } }
        mp = null
    }

    fun stop() {
        releasePlayer()
        queue = emptyList()
        playing = false
        position = 0
        duration = 0
    }

    fun release() = releasePlayer()
}

fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

/** Barra de música que queda abajo mientras navegás por las carpetas. */
@Composable
fun MiniPlayer(m: MusicPlayer) {
    val f = m.current ?: return
    LaunchedEffect(m.playing, m.index) {
        while (m.playing) {
            m.tick()
            delay(500)
        }
    }
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = maxOf(1, m.duration).toFloat()
    val shown = (drag ?: m.position.toFloat()).coerceIn(0f, max)
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)) {
        Text(
            "🎵 " + f.nameWithoutExtension,
            Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp),
            maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Slider(
            value = shown,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { m.seek(it.toInt()) }
                drag = null
            },
            valueRange = 0f..max,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                fmtTime(shown.toInt()) + " / " + fmtTime(m.duration),
                Modifier.padding(start = 16.dp).weight(1f),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            TextButton(onClick = { m.prev() }) { Text("⏮", fontSize = 18.sp) }
            TextButton(onClick = { m.toggle() }) { Text(if (m.playing) "⏸" else "▶", fontSize = 18.sp) }
            TextButton(onClick = { m.next() }) { Text("⏭", fontSize = 18.sp) }
            TextButton(onClick = { m.stop() }) { Text("✕", fontSize = 18.sp) }
        }
    }
}
