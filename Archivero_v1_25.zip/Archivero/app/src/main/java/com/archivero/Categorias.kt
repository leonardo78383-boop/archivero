package com.archivero

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ───────────── Las 5 fichas de la pantalla de inicio ─────────────

/**
 * Orden de izquierda a derecha, igual que en el diseño.
 * [label] es el nombre en español (título de la ventana), [text] el texto escrito en la ficha e [icon] su dibujo vectorial.
 */
enum class HomeTab(val label: String, val text: String, val icon: Int) {
    DOWNLOADS("Descargas", "DOWNLOADS", R.drawable.ic_tab_downloads),
    MUSIC("Música", "MUSIC", R.drawable.ic_tab_music),
    PHOTOS("Fotos", "PHOTOS", R.drawable.ic_tab_photos),
    VIDEOS("Vídeos", "VÍDEOS", R.drawable.ic_tab_videos),
    APKS("APKs", "APKS", R.drawable.ic_tab_apks)
}

/**
 * Una carpeta de la ficha: cuántos archivos DE ESE TIPO tiene y cuánto ocupan. [vol] = en qué almacenamiento está.
 * [loose] (solo Descargas) = la propia carpeta Download, contando los archivos sueltos en ella.
 */
class CatFolder(val dir: File, val files: Int, val bytes: Long, val loose: Boolean = false, val vol: String = "")

/** Resultado de una ficha: carpetas (internas + SD juntas) y espacio total que ocupan. */
class CatInfo(val folders: List<CatFolder>, val bytes: Long, val time: Long)

/** Qué tipo de archivo muestra cada ficha. Cada una muestra SOLO ese tipo (Descargas es la excepción: muestra la carpeta Download entera). */
private val KIND_TAB: Map<Kind, HomeTab> = mapOf(
    Kind.AUD to HomeTab.MUSIC,
    Kind.IMG to HomeTab.PHOTOS,
    Kind.VID to HomeTab.VIDEOS,
    Kind.APK to HomeTab.APKS
)

/** Qué tipo de archivo muestra la carpeta abierta desde una ficha; null = todo (Descargas y navegación normal). */
fun HomeTab?.kindFilter(): Kind? = when (this) {
    HomeTab.MUSIC -> Kind.AUD
    HomeTab.PHOTOS -> Kind.IMG
    HomeTab.VIDEOS -> Kind.VID
    HomeTab.APKS -> Kind.APK
    else -> null
}

/** Carpetas Download de cada almacenamiento (interno y SD). */
fun downloadDirs(vols: List<Vol>): List<File> =
    vols.flatMap { v -> listOf("Download", "Downloads").map { File(v.dir, it) } }.filter { it.isDirectory }

/** Cuenta archivos por carpeta (la que los contiene directamente), separados por ficha. */
private class Acc {
    val m = HashMap<Pair<HomeTab, File>, LongArray>()
    fun add(f: File) {
        val tab = KIND_TAB[kindOf(f)] ?: return        // primero la extensión (barato)
        if (f.name.startsWith(".") || !f.isFile) return
        val parent = f.parentFile ?: return
        val e = m.getOrPut(tab to parent) { LongArray(2) }
        e[0] += 1
        e[1] += f.length()
    }
    fun out(vol: String): List<Pair<HomeTab, CatFolder>> =
        m.map { (k, v) -> k.first to CatFolder(k.second, v[0].toInt(), v[1], vol = vol) }
}

/** [archivos, bytes] de todo lo que hay dentro de una carpeta. Se puede cancelar. */
private suspend fun statAll(d: File): LongArray {
    var n = 0L
    var b = 0L
    for (f in d.walkTopDown().onEnter { it == d || !it.name.startsWith(".") }) {
        currentCoroutineContext().ensureActive()
        if (!f.isFile || f.name.startsWith(".")) continue
        n++
        b += f.length()
    }
    return longArrayOf(n, b)
}

/**
 * Calcula TODAS las fichas de una vez. Cada ficha muestra las carpetas (de la memoria interna y de la SD) que tienen
 * archivos de su tipo, y cada carpeta cuenta solo esos archivos. LLAMAR FUERA DEL HILO PRINCIPAL; se puede cancelar.
 * Una sola pasada por el disco, con cada carpeta de primer nivel en paralelo (antes era una pasada por ficha).
 */
suspend fun computeAllCats(vols: List<Vol>): Map<HomeTab, CatInfo> = coroutineScope {
    val gate = Semaphore(3)                         // pocos hilos a la vez: la pantalla no se traba mientras se recorre el disco
    val jobs = ArrayList<kotlinx.coroutines.Deferred<List<Pair<HomeTab, CatFolder>>>>()
    for (v in vols) {
        val top = v.dir.listFiles() ?: continue
        // archivos sueltos en la raíz del almacenamiento
        jobs.add(async(Dispatchers.IO) {
            val acc = Acc()
            for (f in top) if (f.isFile) acc.add(f)
            acc.out(v.name)
        })
        for (d in top) {
            if (!d.isDirectory || d.name.startsWith(".")) continue
            if (d.name == "Android") continue            // datos de otras apps: no se puede ver y solo estorba
            jobs.add(async(Dispatchers.IO) {
                gate.withPermit {
                    val acc = Acc()
                    for (f in d.walkTopDown().onEnter { it == d || !it.name.startsWith(".") }) {
                        currentCoroutineContext().ensureActive()
                        acc.add(f)
                    }
                    acc.out(v.name)
                }
            })
        }
    }
    val byTab = HashMap<HomeTab, ArrayList<CatFolder>>()
    for (list in jobs.awaitAll()) for ((tab, f) in list) byTab.getOrPut(tab) { ArrayList() }.add(f)

    val now = System.currentTimeMillis()
    val out = HashMap<HomeTab, CatInfo>()
    for (tab in KIND_TAB.values) {
        val folders = (byTab[tab] ?: ArrayList<CatFolder>()).sortedBy { it.dir.name.lowercase() }
        out[tab] = CatInfo(folders, folders.sumOf { it.bytes }, now)
    }
    out
}

/** Descargas: la carpeta Download (interna y SD) con todo lo que hay dentro: sus subcarpetas y los archivos sueltos. */
suspend fun computeDownloads(vols: List<Vol>): CatInfo = coroutineScope {
    val gate = Semaphore(4)
    val tasks = ArrayList<kotlinx.coroutines.Deferred<CatFolder?>>()
    for (v in vols) for (n in listOf("Download", "Downloads")) {
        val root = File(v.dir, n)
        val children = root.listFiles() ?: continue
        tasks.add(async(Dispatchers.IO) {
            val files = children.filter { it.isFile && !it.name.startsWith(".") }
            if (files.isEmpty()) null else CatFolder(root, files.size, files.sumOf { it.length() }, loose = true, vol = v.name)
        })
        for (c in children) {
            if (!c.isDirectory || c.name.startsWith(".")) continue
            tasks.add(async(Dispatchers.IO) {
                val st = gate.withPermit { statAll(c) }
                CatFolder(c, st[0].toInt(), st[1], vol = v.name)
            })
        }
    }
    val folders = tasks.awaitAll().filterNotNull().sortedBy { it.dir.name.lowercase() }
    CatInfo(folders, folders.sumOf { it.bytes }, System.currentTimeMillis())
}

/**
 * Descargas, PRIMERA VISTA: solo las carpetas de Download (interna y SD), sin contar todavía lo que hay dentro (files = -1).
 * Es casi instantánea; el conteo exacto llega después con [computeDownloads].
 */
fun quickDownloads(vols: List<Vol>): CatInfo {
    val folders = ArrayList<CatFolder>()
    for (v in vols) for (n in listOf("Download", "Downloads")) {
        val root = File(v.dir, n)
        val children = root.listFiles() ?: continue
        if (children.any { !it.name.startsWith(".") && it.isFile }) folders.add(CatFolder(root, -1, -1L, loose = true, vol = v.name))
        for (c in children) {
            if (!c.name.startsWith(".") && c.isDirectory) folders.add(CatFolder(c, -1, -1L, vol = v.name))
        }
    }
    val sorted = folders.sortedBy { it.dir.name.lowercase() }
    return CatInfo(sorted, -1L, System.currentTimeMillis())
}

/** Las 4 fichas que salen del índice del sistema, cada una se consulta por separado y en paralelo. */
val MEDIA_TABS: List<HomeTab> = listOf(HomeTab.MUSIC, HomeTab.PHOTOS, HomeTab.VIDEOS, HomeTab.APKS)

/**
 * Una ficha (Música, Fotos, Vídeos o APKs) desde el índice del sistema (MediaStore, el mismo que usa la Galería): responde en un
 * instante porque no recorre el disco. Se piden solo las extensiones de ese tipo, así llegan pocas filas.
 * LLAMAR FUERA DEL HILO PRINCIPAL.
 */
fun mediaStoreTab(ctx: Context, vols: List<Vol>, tab: HomeTab): CatInfo {
    val kind = tab.kindFilter()
    val acc = HashMap<String, LongArray>()
    if (kind != null) {
        val exts = kind.exts.toList()
        val uri = MediaStore.Files.getContentUri("external")
        val cols = arrayOf(MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.SIZE)
        val sel = exts.joinToString(" OR ") { MediaStore.Files.FileColumns.DATA + " LIKE ?" }
        val args = Array(exts.size) { "%." + exts[it] }
        val cur = ctx.contentResolver.query(uri, cols, sel, args, null)
        if (cur != null) {
            cur.use { c ->
                val iData = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                while (c.moveToNext()) {
                    val path = c.getString(iData)
                    if (path == null) continue
                    if (path.contains("/.") || path.contains("/Android/")) continue     // ocultos y datos de otras apps
                    val slash = path.lastIndexOf('/')
                    if (slash <= 0) continue
                    val e = acc.getOrPut(path.substring(0, slash)) { LongArray(2) }
                    e[0] += 1L
                    e[1] += c.getLong(iSize)
                }
            }
        }
    }
    val folders = ArrayList<CatFolder>()
    for ((path, v) in acc) {
        val dir = File(path)
        if (!dir.isDirectory) continue
        val vol = vols.firstOrNull { dir.path == it.dir.path || dir.path.startsWith(it.dir.path + "/") }?.name ?: ""
        folders.add(CatFolder(dir, v[0].toInt(), v[1], vol = vol))
    }
    val sorted = folders.sortedBy { it.dir.name.lowercase() }
    return CatInfo(sorted, sorted.sumOf { it.bytes }, System.currentTimeMillis())
}

/** Guarda lo último que se calculó de las fichas, para mostrarlo al instante la próxima vez que se abra la app. */
fun saveCatCache(file: File, m: Map<HomeTab, CatInfo>) {
    try {
        val root = JSONObject()
        for ((tab, info) in m) {
            val arr = JSONArray()
            for (f in info.folders) {
                val o = JSONObject()
                o.put("p", f.dir.path)
                o.put("n", f.files)
                o.put("b", f.bytes)
                o.put("l", f.loose)
                o.put("v", f.vol)
                arr.put(o)
            }
            val t = JSONObject()
            t.put("t", info.time)
            t.put("bytes", info.bytes)
            t.put("f", arr)
            root.put(tab.name, t)
        }
        file.writeText(root.toString())
    } catch (e: Exception) {
        // Si no se puede guardar, no pasa nada: solo se calcula de nuevo.
    }
}

/** Lee lo guardado por [saveCatCache]; null si no hay nada o está dañado. LLAMAR FUERA DEL HILO PRINCIPAL. */
fun loadCatCache(file: File): Map<HomeTab, CatInfo>? {
    if (!file.isFile) return null
    try {
        val root = JSONObject(file.readText())
        val out = HashMap<HomeTab, CatInfo>()
        for (tab in HomeTab.values()) {
            val o = root.optJSONObject(tab.name)
            if (o == null) continue
            val arr = o.optJSONArray("f")
            if (arr == null) continue
            val list = ArrayList<CatFolder>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                list.add(CatFolder(File(e.getString("p")), e.getInt("n"), e.getLong("b"), e.optBoolean("l", false), e.optString("v", "")))
            }
            out[tab] = CatInfo(list, o.optLong("bytes", 0L), o.optLong("t", 0L))
        }
        return if (out.isEmpty()) null else out
    } catch (e: Exception) {
        return null
    }
}

/**
 * Datos de una ficha. Si ya hay algo guardado se muestra AL INSTANTE (aunque sea viejo): el cálculo ocurre en segundo plano
 * desde que abre la app (Store.prefetchCats), así que al tocar la ficha normalmente ya está listo.
 */
@Composable
fun rememberCatInfo(store: Store, tab: HomeTab?): CatInfo? {
    val ready = store.catVersion          // cambia cuando termina de calcularse
    return remember(tab, ready) { if (tab == null) null else store.catCache[tab] }
}

// ───────────── Barra de abajo ─────────────

/**
 * Primer toque: la ficha se pone blanca, hace zoom y muestra el número de carpetas y el espacio que ocupan.
 * Segundo toque sobre la misma ficha: abre la pantalla con las carpetas en cuadrícula.
 */
@Composable
fun CategoryBar(store: Store, go: (Screen) -> Unit) {
    val sel = store.homeTab
    val info = rememberCatInfo(store, sel)
    // La ficha se queda blanca solo 5 segundos; después vuelve a su aspecto normal.
    LaunchedEffect(sel) {
        if (sel != null) {
            delay(5000L)
            store.homeTab = null
        }
    }
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 16.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            for (t in HomeTab.values()) {
                val on = t == sel
                TabItem(t, on, if (on) info else null, Modifier.weight(1f)) {
                    if (on) { store.memory.visitTab(t); go(Screen.Cat(t)) } else store.homeTab = t
                }
            }
        }
    }
}

@Composable
private fun TabItem(tab: HomeTab, selected: Boolean, info: CatInfo?, modifier: Modifier, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1.14f else 1f, tween(180), label = "tabScale")
    val body = if (selected) Pal.White else Pal.Ink
    val edge = if (selected) Pal.White else Pal.Line
    val ink = if (selected) Pal.Black else Pal.Muted
    val dot = if (selected) Color(0x55000000) else Pal.Line

    Box(
        modifier
            .height(86.dp)
            .zIndex(if (selected) 1f else 0f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin(0.5f, 1f)
            }
            .drawBehind {
                val w = size.width
                val h = size.height
                val cut = w * 0.26f
                val rad = 9.dp.toPx()
                val sw = 1.5.dp.toPx()
                // Forma de ficha: esquina superior izquierda cortada en diagonal.
                val poly = Path().apply {
                    moveTo(0f, cut); lineTo(cut, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(0f, h); close()
                }
                // Botón con volumen: canto inferior (grosor), tapa con degradado y borde con brillo.
                val lip = 4.dp.toPx()
                val lipColor = if (selected) Pal.Accent else Color(0xFF050507)
                val cap = if (selected) Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFC9C9D2)))
                          else Brush.verticalGradient(listOf(Color(0xFF2E2E36), Color(0xFF15151A)))
                val rim = if (selected) Brush.verticalGradient(listOf(Color.White, Color(0xFFE8E8EE)))
                          else Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x12FFFFFF)))
                translate(0f, lip) { clipPath(poly) { drawRoundRect(lipColor, cornerRadius = CornerRadius(rad)) } }
                clipPath(poly) {
                    drawRoundRect(cap, cornerRadius = CornerRadius(rad))
                    drawRoundRect(rim, cornerRadius = CornerRadius(rad), style = Stroke(width = sw))
                }
                drawLine(edge, Offset(0f, cut), Offset(cut, 0f), strokeWidth = sw)
                // Los tres puntitos de arriba a la derecha.
                val r = 2.2.dp.toPx()
                drawCircle(dot, r, Offset(w - 19.dp.toPx(), 11.dp.toPx()))
                drawCircle(dot, r, Offset(w - 11.dp.toPx(), 11.dp.toPx()))
                drawCircle(dot, r, Offset(w - 11.dp.toPx(), 18.dp.toPx()))
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    ) {
        Column(
            Modifier.fillMaxSize().padding(top = 13.dp, bottom = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Ícono vectorial (nítido a cualquier resolución) y texto de la ficha.
            Image(
                painter = painterResource(tab.icon),
                contentDescription = tab.label,
                modifier = Modifier.size(36.dp),
                colorFilter = ColorFilter.tint(ink)
            )
            Spacer(Modifier.height(2.dp))
            Text(
                tab.text,
                modifier = Modifier.fillMaxWidth(),
                color = ink,
                fontSize = with(LocalDensity.current) { 10.dp.toSp() },   // tamaño fijo en dp: no se desarma con la letra grande del sistema
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.3).sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Clip
            )
            Spacer(Modifier.weight(1f))
            if (selected) {
                // Espacio total que ocupan (interna + SD sumadas); mientras se calcula, "…".
                Text(
                    if (info == null || info.bytes < 0L) "…" else fmtSize(info.bytes),
                    color = ink, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Clip
                )
            } else {
                Box(Modifier.width(18.dp).height(2.dp).background(Pal.Line, RoundedCornerShape(2.dp)))
            }
        }
    }
}

// ───────────── Ventana con las carpetas de la ficha ─────────────

@Composable
fun CatGridScreen(store: Store, tab: HomeTab, go: (Screen) -> Unit) {
    val i = rememberCatInfo(store, tab)
    when {
        i == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ThinSpinner() }
        i.folders.isEmpty() -> Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (tab == HomeTab.DOWNLOADS) "No hay nada en Descargas." else "No hay ${tab.label.lowercase()} en este equipo.",
                textAlign = TextAlign.Center, color = Pal.Muted
            )
        }
        else -> {
            val maxBytes = i.folders.maxOf { it.bytes }.coerceAtLeast(1L)
            val showVol = store.vols.size > 1
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),   // 5 carpetas por fila
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(i.folders, key = { it.dir.path + if (it.loose) "#" else "" }) { f ->
                    FolderTile(f, maxBytes, showVol) { go(Screen.Folder(f.dir, tab, f.dir)) }
                }
            }
        }
    }
}

/** Carpeta compacta (5 por fila): ícono, nombre, barrita de peso y, debajo, peso y cantidad de archivos. */
@Composable
private fun FolderTile(f: CatFolder, maxBytes: Long, showVol: Boolean, onClick: () -> Unit) {
    val shape = ChamferShape(8.dp)
    val frac = (f.bytes.toFloat() / maxBytes).coerceIn(0.04f, 1f)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.Ink)
            .border(1.dp, Pal.Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FolderIcon(34.dp)
        Spacer(Modifier.height(5.dp))
        Text(
            if (f.loose) "${f.dir.name} (sueltos)" else f.dir.name,
            minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            fontSize = 10.sp, lineHeight = 12.sp, color = Pal.White
        )
        // Con dos almacenamientos, la línea del volumen SIEMPRE ocupa su sitio: así todas las fichas miden igual.
        if (showVol) {
            Text(f.vol.ifEmpty { " " }, fontSize = 9.sp, color = Pal.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(6.dp))
        SegBar(frac, Modifier.fillMaxWidth(), segments = 6, height = 3.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            if (f.files < 0) "…" else fmtSize(f.bytes),
            fontSize = 9.sp, color = Pal.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Text(
            if (f.files < 0) " " else "${f.files} arch.",
            fontSize = 9.sp, color = Pal.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}
