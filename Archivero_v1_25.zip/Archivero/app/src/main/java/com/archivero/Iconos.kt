package com.archivero

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil

/** Rectángulo con la esquina superior derecha cortada en diagonal: el "sello" de la app (tarjetas, fichas, botón). */
class ChamferShape(private val cut: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { cut.toPx() }.coerceAtMost(minOf(size.width, size.height) / 2f)
        return Outline.Generic(Path().apply {
            moveTo(0f, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c)
            lineTo(size.width, size.height); lineTo(0f, size.height); close()
        })
    }
}

/** Ruedita de carga: un arco fino que gira sobre un aro tenue. */
@Composable
fun ThinSpinner(d: Dp = 32.dp, color: Color = Pal.White) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart), label = "angle"
    )
    Canvas(Modifier.size(d)) {
        val sw = 2.dp.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(Pal.Line, 0f, 360f, false, tl, sz, style = Stroke(sw))
        drawArc(color, angle - 90f, 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
    }
}

/** Línea de carga fina (indeterminada). */
@Composable
fun ThinLoading(modifier: Modifier = Modifier.fillMaxWidth()) {
    LinearProgressIndicator(modifier = modifier.height(2.dp), color = Pal.White, trackColor = Pal.Line)
}

/** Barrita digital por segmentos: se llenan según [frac] (0..1). */
@Composable
fun SegBar(frac: Float, modifier: Modifier = Modifier, segments: Int = 14, height: Dp = 4.dp) {
    val on = if (frac <= 0f) 0 else ceil(frac * segments).toInt().coerceIn(1, segments)
    Row(modifier.height(height), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(segments) { i ->
            Box(Modifier.weight(1f).fillMaxHeight().background(if (i < on) Pal.Accent else Pal.Line))
        }
    }
}

/** Carpeta en dos tonos de amarillo opaco, limpia y plana. */
@Composable
fun FolderIcon(w: Dp = 44.dp) {
    Canvas(Modifier.size(w, w * 0.8f)) {
        val bw = size.width
        val bh = size.height
        val back = Path().apply {
            moveTo(0f, bh * 0.08f); lineTo(bw * 0.38f, bh * 0.08f); lineTo(bw * 0.46f, bh * 0.2f)
            lineTo(bw, bh * 0.2f); lineTo(bw, bh); lineTo(0f, bh); close()
        }
        drawPath(back, Pal.FolderBack)
        val r = bw * 0.04f
        drawRoundRect(Pal.FolderFront, Offset(0f, bh * 0.32f), Size(bw, bh * 0.68f), CornerRadius(r))
        drawLine(Pal.FolderEdge, Offset(r, bh * 0.32f + 1f), Offset(bw - r, bh * 0.32f + 1f), strokeWidth = 1.5f)
    }
}

/** Archivo: hoja con la esquina cortada, un dibujo de línea fina según el tipo y la extensión debajo. */
@Composable
fun FileIcon(isDir: Boolean, kind: Kind, ext: String) {
    if (isDir) { FolderIcon(42.dp); return }
    Box(Modifier.size(34.dp, 42.dp), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 1.3.dp.toPx()
            val l = sw / 2; val t = sw / 2
            val r = size.width - sw / 2; val b = size.height - sw / 2
            val c = size.width * 0.3f
            val sheet = Path().apply {
                moveTo(l, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b); lineTo(l, b); close()
            }
            drawPath(sheet, Pal.Card)
            val line = Pal.White.copy(alpha = 0.9f)
            val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(sheet, line, style = st)
            drawPath(Path().apply { moveTo(r - c, t); lineTo(r - c, t + c); lineTo(r, t + c) }, line, style = st)
            glyph(kind, size.width / 2f, size.height * 0.45f, size.width * 0.15f, line, st)
        }
        if (ext.isNotEmpty()) {
            Text(
                ext.take(4).uppercase(), color = Pal.Muted, fontSize = 9.sp, letterSpacing = 0.5.sp,
                modifier = Modifier.padding(bottom = 3.dp), maxLines = 1
            )
        }
    }
}

private fun poly(p: List<Offset>, close: Boolean = false) = Path().apply {
    moveTo(p[0].x, p[0].y)
    for (i in 1 until p.size) lineTo(p[i].x, p[i].y)
    if (close) close()
}

/** Dibujo de línea de cada tipo; [u] es la unidad de medida (el dibujo mide unas 4,5 u de ancho). */
private fun DrawScope.glyph(kind: Kind, cx: Float, cy: Float, u: Float, color: Color, st: Stroke) {
    fun o(x: Float, y: Float) = Offset(cx + x * u, cy + y * u)
    when (kind) {
        Kind.IMG -> {
            drawPath(poly(listOf(o(-2.2f, 1.4f), o(-0.6f, -0.6f), o(0.4f, 0.6f), o(1.2f, -0.2f), o(2.2f, 1.4f))), color, style = st)
            drawCircle(color, u * 0.5f, o(-1.2f, -1.5f), style = st)
        }
        Kind.VID -> drawPath(poly(listOf(o(-1f, -1.6f), o(1.7f, 0f), o(-1f, 1.6f)), close = true), color, style = st)
        Kind.AUD -> {
            drawLine(color, o(0.9f, 1f), o(0.9f, -1.8f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawCircle(color, u * 1f, o(-0.2f, 1.2f), style = st)
            drawLine(color, o(0.9f, -1.8f), o(2.1f, -1f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
        Kind.APK -> {
            drawPath(poly(listOf(o(0f, -1.9f), o(1.7f, -0.95f), o(1.7f, 0.95f), o(0f, 1.9f), o(-1.7f, 0.95f), o(-1.7f, -0.95f)), close = true), color, style = st)
            drawPath(poly(listOf(o(-1.7f, -0.95f), o(0f, 0f), o(1.7f, -0.95f))), color, style = st)
            drawLine(color, o(0f, 0f), o(0f, 1.9f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
        else -> {
            drawLine(color, o(-1.8f, -1.2f), o(1.8f, -1.2f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(color, o(-1.8f, 0f), o(1.8f, 0f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(color, o(-1.8f, 1.2f), o(0.6f, 1.2f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
    }
}


// ───────────── Íconos del panel lateral (línea fina, esquinas cortadas, un toque rosa) ─────────────

/** Casita: techo en ángulo, esquinas cortadas y la puerta en rosa. */
@Composable
fun HomeIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val body = Path().apply {
            moveTo(s * 0.5f, s * 0.08f)
            lineTo(s * 0.94f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.48f)
            lineTo(s * 0.06f, s * 0.48f)
            close()
        }
        drawPath(body, Pal.Card)
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        val door = Path().apply {
            moveTo(s * 0.42f, s * 0.92f); lineTo(s * 0.42f, s * 0.64f); lineTo(s * 0.58f, s * 0.64f); lineTo(s * 0.58f, s * 0.92f)
        }
        drawPath(door, Pal.Accent, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Papelera de reciclaje: tres flechas formando un triángulo (rosa) sobre línea blanca. */
@Composable
fun RecycleIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val cx = s * 0.5f
        val cy = s * 0.56f
        val r = s * 0.4f
        val pts = listOf(
            Offset(cx, cy - r),
            Offset(cx + r * 0.866f, cy + r * 0.5f),
            Offset(cx - r * 0.866f, cy + r * 0.5f)
        )
        for (i in 0 until 3) {
            val a = pts[i]
            val b = pts[(i + 1) % 3]
            val p0 = Offset(a.x + (b.x - a.x) * 0.16f, a.y + (b.y - a.y) * 0.16f)
            val p1 = Offset(a.x + (b.x - a.x) * 0.7f, a.y + (b.y - a.y) * 0.7f)
            drawLine(line, p0, p1, strokeWidth = sw, cap = StrokeCap.Round)
            // Punta de flecha: la dirección girada +150° y -150°.
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len = kotlin.math.sqrt(dx * dx + dy * dy)
            val ux = dx / len
            val uy = dy / len
            val h = s * 0.15f
            val lx = ux * (-0.866f) - uy * 0.5f
            val ly = ux * 0.5f + uy * (-0.866f)
            val rx = ux * (-0.866f) + uy * 0.5f
            val ry = -ux * 0.5f + uy * (-0.866f)
            drawLine(Pal.Accent, p1, Offset(p1.x + lx * h, p1.y + ly * h), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(Pal.Accent, p1, Offset(p1.x + rx * h, p1.y + ry * h), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Tacho de basura: tapa con asa, cuerpo con esquinas inferiores cortadas y rayitas en rosa. */
@Composable
fun TrashIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        drawLine(line, Offset(s * 0.12f, s * 0.26f), Offset(s * 0.88f, s * 0.26f), strokeWidth = sw, cap = StrokeCap.Round)
        val handle = Path().apply {
            moveTo(s * 0.38f, s * 0.26f); lineTo(s * 0.38f, s * 0.1f); lineTo(s * 0.62f, s * 0.1f); lineTo(s * 0.62f, s * 0.26f)
        }
        drawPath(handle, line, style = Stroke(sw, join = StrokeJoin.Round))
        val body = Path().apply {
            moveTo(s * 0.2f, s * 0.26f); lineTo(s * 0.2f, s * 0.82f); lineTo(s * 0.3f, s * 0.92f)
            lineTo(s * 0.7f, s * 0.92f); lineTo(s * 0.8f, s * 0.82f); lineTo(s * 0.8f, s * 0.26f)
        }
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        for (x in listOf(0.4f, 0.5f, 0.6f)) {
            drawLine(Pal.Accent, Offset(s * x, s * 0.42f), Offset(s * x, s * 0.78f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}
