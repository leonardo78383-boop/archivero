package com.archivero

import androidx.compose.ui.graphics.Color

/** Paleta de la app: rosa rojizo, blanco y negro (tomada de la imagen de referencia). */
object Pal {
    val Pink = Color(0xFFFF0198)        // acento
    val Sel = Color(0xFF1F1F1F)         // fondo de lo seleccionado
    val Accent = Pink                   // único toque de color (barritas, globito). Pon Pal.White para dejarlo todo blanco y negro.

    // Carpeta: amarillo opaco, el de casi todos los exploradores.
    val FolderBack = Color(0xFFB89440)
    val FolderFront = Color(0xFFD6B560)
    val FolderEdge = Color(0xFFE6CD8E)
    val Black = Color(0xFF000000)
    val Ink = Color(0xFF0B0B0B)         // superficies
    val Card = Color(0xFF141414)        // tarjetas / menús
    val Line = Color(0xFF262626)        // líneas finas
    val White = Color(0xFFFFFFFF)
    val Muted = Color(0xFF9A9A9A)       // texto secundario
}
