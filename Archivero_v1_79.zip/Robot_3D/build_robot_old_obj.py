#!/usr/bin/env python3
"""
build_robot.py - Genera un robot 3D (OBJ + MTL) sin dependencias externas.

Uso:
    python build_robot.py                 -> crea robot.obj y robot.mtl
    python build_robot.py -o salida       -> crea salida.obj y salida.mtl
    python build_robot.py --scale 2.0     -> escala el modelo

Abre el .obj en Blender, MeshLab, Windows 3D Viewer, etc.
"""
import argparse
import math


class Mesh:
    def __init__(self):
        self.vertices = []   # (x, y, z)
        self.groups = []     # (nombre, material, [caras])

    def _add_group(self, name, material, verts, faces):
        base = len(self.vertices)
        self.vertices.extend(verts)
        self.groups.append((name, material, [tuple(i + base + 1 for i in f) for f in faces]))

    # ---------- primitivas ----------
    def box(self, name, material, center, size):
        cx, cy, cz = center
        sx, sy, sz = (s / 2 for s in size)
        v = [(cx + dx * sx, cy + dy * sy, cz + dz * sz)
             for dx in (-1, 1) for dy in (-1, 1) for dz in (-1, 1)]
        # indices: x(0/1) y(0/1) z(0/1) -> i = x*4 + y*2 + z
        f = [
            (0, 1, 3, 2), (4, 6, 7, 5),  # -x, +x
            (0, 4, 5, 1), (2, 3, 7, 6),  # -y, +y
            (0, 2, 6, 4), (1, 5, 7, 3),  # -z, +z
        ]
        self._add_group(name, material, v, f)

    def cylinder(self, name, material, center, radius, height, axis="y", seg=24):
        cx, cy, cz = center
        h = height / 2
        v, f = [], []
        for i in range(seg):
            a = 2 * math.pi * i / seg
            c, s = radius * math.cos(a), radius * math.sin(a)
            for t in (-h, h):
                if axis == "y":
                    v.append((cx + c, cy + t, cz + s))
                elif axis == "x":
                    v.append((cx + t, cy + c, cz + s))
                else:
                    v.append((cx + c, cy + s, cz + t))
        for i in range(seg):
            j = (i + 1) % seg
            f.append((i * 2, j * 2, j * 2 + 1, i * 2 + 1))
        f.append(tuple(i * 2 for i in reversed(range(seg))))
        f.append(tuple(i * 2 + 1 for i in range(seg)))
        self._add_group(name, material, v, f)

    def sphere(self, name, material, center, radius, rings=12, seg=20):
        cx, cy, cz = center
        v, f = [], []
        for r in range(rings + 1):
            phi = math.pi * r / rings
            for s in range(seg):
                th = 2 * math.pi * s / seg
                v.append((cx + radius * math.sin(phi) * math.cos(th),
                          cy + radius * math.cos(phi),
                          cz + radius * math.sin(phi) * math.sin(th)))
        for r in range(rings):
            for s in range(seg):
                a = r * seg + s
                b = r * seg + (s + 1) % seg
                f.append((a, b, b + seg, a + seg))
        self._add_group(name, material, v, f)

    # ---------- exportar ----------
    def save(self, base, scale=1.0):
        mats = {
            "metal":  (0.70, 0.72, 0.78),
            "dark":   (0.15, 0.16, 0.19),
            "accent": (0.95, 0.45, 0.10),
            "eye":    (0.10, 0.85, 1.00),
        }
        with open(base + ".mtl", "w") as m:
            for n, (r, g, b) in mats.items():
                m.write(f"newmtl {n}\nKd {r} {g} {b}\nKa 0.1 0.1 0.1\nKs 0.4 0.4 0.4\nNs 40\n\n")
        with open(base + ".obj", "w") as o:
            o.write(f"# Robot generado con build_robot.py\nmtllib {base.split('/')[-1].split(chr(92))[-1]}.mtl\n")
            for x, y, z in self.vertices:
                o.write(f"v {x*scale:.5f} {y*scale:.5f} {z*scale:.5f}\n")
            for name, mat, faces in self.groups:
                o.write(f"g {name}\nusemtl {mat}\n")
                for face in faces:
                    o.write("f " + " ".join(map(str, face)) + "\n")


def build_robot():
    m = Mesh()

    # Piernas y pies
    for side, x in (("L", -0.25), ("R", 0.25)):
        m.box(f"pie_{side}", "dark", (x, 0.05, 0.08), (0.28, 0.10, 0.42))
        m.cylinder(f"pierna_{side}", "metal", (x, 0.45, 0), 0.075, 0.70)
        m.sphere(f"rodilla_{side}", "accent", (x, 0.55, 0), 0.10)

    # Cadera y torso
    m.box("cadera", "dark", (0, 0.88, 0), (0.70, 0.18, 0.38))
    m.box("torso", "metal", (0, 1.30, 0), (0.80, 0.70, 0.45))
    m.box("pecho_panel", "accent", (0, 1.35, 0.23), (0.40, 0.28, 0.03))
    m.cylinder("reactor", "eye", (0, 1.35, 0.25), 0.07, 0.03, axis="z")

    # Hombros y brazos
    for side, x in (("L", -1), ("R", 1)):
        m.sphere(f"hombro_{side}", "accent", (x * 0.52, 1.55, 0), 0.16)
        m.cylinder(f"brazo_{side}", "metal", (x * 0.56, 1.20, 0), 0.07, 0.60)
        m.sphere(f"codo_{side}", "dark", (x * 0.56, 0.88, 0), 0.08)
        m.cylinder(f"antebrazo_{side}", "metal", (x * 0.56, 0.62, 0.05), 0.06, 0.50)
        m.box(f"mano_{side}", "dark", (x * 0.56, 0.32, 0.05), (0.14, 0.16, 0.14))

    # Cuello y cabeza
    m.cylinder("cuello", "dark", (0, 1.70, 0), 0.08, 0.10)
    m.box("cabeza", "metal", (0, 1.92, 0), (0.46, 0.38, 0.40))
    m.box("visor", "dark", (0, 1.94, 0.205), (0.36, 0.14, 0.02))
    for x in (-0.09, 0.09):
        m.sphere("ojo", "eye", (x, 1.94, 0.22), 0.035, rings=6, seg=10)
    m.cylinder("antena", "dark", (0.12, 2.22, 0), 0.015, 0.28)
    m.sphere("antena_punta", "accent", (0.12, 2.38, 0), 0.04, rings=6, seg=10)

    return m


def main():
    p = argparse.ArgumentParser(description="Genera un robot 3D en formato OBJ.")
    p.add_argument("-o", "--output", default="robot", help="nombre base de salida (sin extensión)")
    p.add_argument("--scale", type=float, default=1.0, help="factor de escala")
    a = p.parse_args()

    mesh = build_robot()
    mesh.save(a.output, a.scale)
    nf = sum(len(g[2]) for g in mesh.groups)
    print(f"Listo: {a.output}.obj / {a.output}.mtl  ({len(mesh.vertices)} vértices, {nf} caras)")


if __name__ == "__main__":
    main()
