# Archivero (Android, Kotlin + Jetpack Compose)

## Cómo obtener el APK
1. Instala Android Studio (versión reciente, Ladybug o superior).
2. File > Open > elige esta carpeta `Archivero` y espera a que termine "Gradle Sync".
3. Para la versión RÁPIDA (la que debes instalar): View > Tool Windows > Build Variants, cambia `app` a **release**,
   y luego Build > Build Bundle(s) / APK(s) > Build APK(s). O por terminal: `gradle assembleRelease` (Gradle 8.9).
4. El APK queda en `app/build/outputs/apk/release/app-release.apk`.
   (El de `debug` sirve para probar, pero va notablemente más lento: no lo uses de día a día.)

## Qué hace
- Pide UNA sola vez el permiso "Acceso a todos los archivos" (Ajustes del sistema). Android lo recuerda.
- Muestra la memoria principal y la tarjeta SD reales: carpetas, archivos, espacio libre / ocupado / total exacto.
- Categorías reales: Música, Fotos, Vídeos, Documentos, PDF y APKs (recorre ambos almacenamientos).
- Panel de las 3 rayitas: Inicio, almacenamientos con barra y espacio, papelera, accesos rápidos.
- Papelera: lo eliminado va a `.ArchiveroTrash` en el mismo almacenamiento; se puede restaurar o vaciar.
- Crear carpeta, renombrar, abrir archivos con la app correspondiente, buscar.
- Copiar, cortar y pegar (menú ⋮ de cada archivo; luego abrí otra carpeta y toca "Pegar aquí"). Avisa si no hay espacio.
- Información del archivo/carpeta: tipo, ubicación, tamaño, fecha y permisos.
- Compartir archivos con cualquier app, comprimir en ZIP y extraer ZIP (con protección contra ZIP maliciosos).
- Ordenar por nombre, fecha, tamaño o tipo (ascendente/descendente), botón "Ordenar" sobre la lista. Se recuerda.
- Selección múltiple: mantené presionado un archivo; después marcá más y usá Copiar, Cortar, ZIP o Eliminar.
- Galería: las categorías Fotos y Vídeos se ven en cuadrícula con miniaturas, agrupadas por día.
- Ver el contenido de un ZIP sin extraerlo (menú ⋮ del .zip). Información muestra también las dimensiones de las fotos.
- Candado con contraseña (menú ⋮ de arriba): se pide al abrir y tras 1 minuto fuera de la app; 5 intentos
  fallidos bloquean 5 minutos. Es un candado de comodidad, no cifra tus archivos.

## Notas
- Android 11 o superior (minSdk 30).
- Google Play restringe el permiso de "todos los archivos"; para uso personal o instalación directa no hay problema.
- Para instalar APKs desde la app, Android pedirá permitir "instalar apps desconocidas" a Archivero.
- No incluye ícono propio (usa el de Android por defecto); se agrega luego con File > New > Image Asset.

## Versión 1.3: ordenar, selección múltiple, galería y ver ZIP (ver "Qué hace")
## Versión 1.2: copiar/pegar, información, compartir, ZIP y candado

## Cambios de la versión 1.1 (rendimiento)
- Carpetas, categorías y papelera se leen en segundo plano; ya no se congela la pantalla.
- Cada fila ya no consulta el disco al dibujarse (antes lo hacía en cada desplazamiento).
- La app abre primero la pantalla y carga almacenamiento/papelera después.
- Categorías y búsquedas muestran resultados mientras siguen buscando, se pueden cancelar y se guardan 30 s.
- Build release con R8 y perfil de arranque.

## Versión 1.4: visor, vídeo y música internos
- Tocar una foto la abre en un visor propio: zoom con dos dedos, doble toque para ampliar, deslizar para pasar a la siguiente de la carpeta.
- Tocar un vídeo lo reproduce dentro de la app (pausa, barra de avance, botón "Girar" para pantalla horizontal).
- Tocar una canción abre la barra de música de abajo (anterior, pausa, siguiente, barra de progreso, cerrar) y sigue sonando mientras navegás.
- Los demás archivos (PDF, documentos, APK…) se abren con otra app, como antes.

## Versión 1.5: fondo animado (quitado en 1.32: el Inicio vuelve a fondo negro liso)
- 
- La app usa siempre colores oscuros para que el texto se lea sobre el fondo.

## Versión 1.6: carpetas blancas (íconos de carpeta en Inicio, listas y panel lateral)

## Versión 1.7: inicio nuevo con barra de 5 fichas
- La pantalla de inicio ya no tiene las 6 carpetas de arriba ni las 6 categorías de abajo. Queda: búsqueda, memoria interna/SD,
  el título "Categorías" y una barra abajo con 5 fichas: Descargas, Música, Fotos, Vídeos y APKs (mismo orden que el diseño).
- Primer toque en una ficha: se pone blanca, hace un pequeño zoom y muestra un globito rojo con la cantidad de carpetas
  (memoria interna + SD sumadas) y, abajo, el espacio total que ocupan.
- Segundo toque sobre la misma ficha: abre una ventana con esas carpetas en cuadrícula (Descargas = subcarpetas de Download;
  las demás = carpetas que tienen música / fotos / vídeos / APKs). Tocar una carpeta la abre como siempre.
- Los 3 puntitos de la derecha ahora son 3 rayitas. El menú que abren es el mismo de antes (Inicio, Actualizar, contraseña, vaciar papelera).
- Archivos nuevos/cambiados: `Categorias.kt` (nuevo), `HomeScreen` y `Screen.Cat` en `MainActivity.kt`, `catCache` y `homeTab` en `Store.kt`,
  y los íconos `res/drawable/ic_tab_*.xml`: dibujos vectoriales rehechos desde cero (nítidos a cualquier resolución, sin PNG). El texto de cada ficha es
  texto real (`HomeTab.text`); íconos y texto se pintan de gris o de oscuro por código.
- Para cambiar el orden de las fichas: reordena los valores de `enum class HomeTab` en `Categorias.kt`.
- Los accesos a Documentos y PDF ya no están en Inicio (siguen en el panel de las 3 rayitas > Accesos rápidos).

## Versión 1.8: optimización, fondo nuevo y corrección de errores
**Fondo animado**: (histórico) el GIF de la 1.7 ya no existe; desde la 1.17 se quitó del proyecto.

**Rapidez**
- Abrir: el GIF ya no se decodifica en el hilo principal al arrancar; color de ventana oscuro desde el primer cuadro; perfil de arranque
  (`app/src/main/baseline-prof.txt`, antes faltaba el archivo y el perfil no hacía nada).
- Carpetas: las ya visitadas se abren al instante (caché de las últimas 24) y se actualizan detrás; las grandes se leen en 4 hilos;
  el ordenado ya no corre en el hilo principal; si nada cambió, la lista no se redibuja; al volver atrás queda en la misma posición.
- Desplazamiento: el contador "N elementos" de cada carpeta se guarda en caché y se lee con 2 hilos (antes cada carpeta leía el disco
  cada vez que entraba en pantalla); el menú ⋮ de cada fila solo existe mientras está abierto; `contentType` para reutilizar filas;
  la galería agrupa por día sin crear una fecha por archivo; durante una búsqueda larga la lista se refresca menos seguido.
- Visor de fotos: precarga la foto vecina, así deslizar no muestra la ruedita.

**Errores corregidos**
- División por cero en el panel lateral si un almacenamiento reportaba 0 bytes.
- Al extraer un ZIP que declara un tamaño falso ya no puede llenar el almacenamiento: se corta si lo real no cabe.
- Carpeta recién abierta mostraba un área en blanco mientras cargaba; ahora muestra la ruedita.

## Versión 1.9: diseño rosa/blanco/negro y fichas rápidas
- Paleta nueva en `Palette.kt` (`Pal`): rosa rojizo `#FF0198`, blanco y negro. Se cambia todo desde ahí.
- Fondo negro liso (más limpio). El fondo GIF y su código se quitaron en la 1.17.
- Barra superior y panel lateral negros con línea fina rosa; ficha seleccionada en rosa; globito blanco con el número de carpetas.
- Íconos de archivo neutros (extensión en rosa) en vez de colores por tipo.
- **Fichas lentas (corregido)**: antes cada ficha recorría toda la memoria al tocarla (una pasada por tipo). Ahora una sola pasada
  calcula las 5 fichas a la vez, en paralelo por almacenamiento, y empieza en segundo plano al abrir la app
  (`Store.prefetchCats`). Al tocar una ficha el resultado ya está listo y, si se vuelve a actualizar, se sigue mostrando lo anterior sin ruedita.

### Fichas (1.9)
- Cada ficha muestra SOLO su tipo, con las carpetas de la memoria interna y de la SD que lo tienen:
  Música (mp3, m4a, wav, ogg, flac, aac, opus), Fotos (jpg, png, gif, webp, bmp, heic), Vídeos (mp4, mkv, 3gp, webm, avi, mov), APKs (apk).
  Cada carpeta cuenta solo archivos de ese tipo. Descargas muestra la carpeta Download entera (subcarpetas y archivos sueltos).
- Cada carpeta lleva una barrita (peso relativo) y debajo "peso · archivos". Si hay SD, también el almacenamiento donde está.
- Todo se calcula en segundo plano al abrir la app (`Store.prefetchCats`), en una sola pasada y en paralelo; no se mira `Android/`.

### Diseño limpio (1.9)
- Explorador en blanco y negro. Carpeta en amarillo opaco de dos tonos (`Pal.FolderBack/Front/Edge` en `Palette.kt`).
- `Iconos.kt`: carpeta, íconos de archivo (hoja con esquina cortada + dibujo de línea fina por tipo), ruedita de carga fina,
  barrita digital por segmentos (`SegBar`) y la forma con esquina cortada (`ChamferShape`) usada en tarjetas, fichas y botón.
- Íconos de las fichas redibujados como línea fina (`res/drawable/ic_tab_*.xml`).
- El único color de acento es `Pal.Accent` (rosa): barritas Pon `Pal.White` ahí para dejarlo todo blanco y negro.

### Limpiador (1.9)
- Las 3 rayitas de la derecha ya no tienen el menú viejo: abren el mini panel del **Limpiador** (esfera con ojitos).
  Las opciones que tenía (Actualizar, Vaciar papelera, contraseña) pasaron al final del panel lateral, en "Opciones".
- Toca la esfera o "Limpiar ahora": borra los residuos de la app (archivos temporales de la caché, miniaturas y carpetas
  guardadas en memoria) y dice cuánto liberó. No toca tus archivos, la papelera ni otras apps.
- Arrástrala fuera del panel: al cerrar el panel con las 3 rayitas, se queda flotando y te acompaña por todas las pantallas
  (se puede mover a cualquier lado; recuerda dónde la dejaste). Para guardarla: abre el panel y suéltala en el hueco punteado.
- Código: `Limpiador.kt` (estado, esfera animada, capa flotante y panel).

## Versión 1.10: fichas rápidas y barra arriba
- Música, Fotos, Vídeos y APKs se leen del índice del sistema (MediaStore, el mismo de la Galería): ya no recorren el disco, aparecen casi al instante (`mediaStoreCats` en `Categorias.kt`). Si el índice no devolviera nada, se usa el recorrido del disco como plan B.
- Descargas: las carpetas aparecen primero (`quickDownloads`) y el peso y la cantidad de archivos se completan enseguida detrás ("…" mientras tanto).
- El recorrido de disco usa pocos hilos a la vez, para no frenar la pantalla.
- La barra de 5 fichas ahora va justo debajo del título "Categorías".

## Versión 1.11: fichas más claras
- La ficha blanca de Inicio vuelve a su aspecto normal a los 5 segundos (`CategoryBar`, `LaunchedEffect`), y también al salir de su ventana de carpetas.
- Al abrir una carpeta desde Música / Fotos / Vídeos / APKs solo se ven archivos de ese tipo, sin subcarpetas ni otros archivos (`kindFilter` en `Categorias.kt`, `FolderScreen`). La cuenta de la ficha usa la misma regla (por extensión), así el número y lo que se ve coinciden. Descargas muestra todo.
- Botón atrás: carpeta abierta desde una ficha → vuelve a la lista de carpetas de la ficha → otro atrás → Inicio (`Screen.Folder(dir, tab, root)` y `BackHandler` en `App`).

## Versión 1.12: panel limpio, íconos digitales y fichas más rápidas
- Panel izquierdo: se quitaron "Accesos rápidos", "Actualizar" y "Poner contraseña". Quedan Inicio, los almacenamientos, Papelera de reciclaje y Vaciar papelera (más "Bloquear/Cambiar/Quitar contraseña" solo si ya hay una contraseña puesta, para no quedar atrapado).
- Íconos de línea fina dibujados con Canvas (`HomeIcon`, `RecycleIcon`, `TrashIcon` en `Iconos.kt`) en lugar de emojis.
- Fichas: las 4 del índice del sistema se consultan en paralelo (`mediaStoreTab`) pidiendo solo las extensiones de cada tipo, y cada una aparece apenas termina.
- Lo último calculado se guarda en `filesDir/cats.json` (`saveCatCache` / `loadCatCache`) y se muestra al instante al abrir la app, mientras se actualiza por detrás.

## Versión 1.13: el amigo en 3D, paseo libre, burbujitas y Ajustes
- El amigo (`Mascot` en `Limpiador.kt`) ahora es una esfera de gelatina en 3D: negro con un poco de transparencia, luz arriba a la izquierda, brillos y borde de cristal. Se estira hacia donde va y rebota al parar (resorte en el bucle de cuadros de `CleanerLayer`).
- Cuando se saca del panel, pasea solo por la app (se detiene un rato al soltarlo) y deja una estela suave de burbujitas (`Bubble`).
- Tocarlo limpia los residuos de la app, así que se quitó el botón "Limpiar ahora": en su lugar, la casilla blanca del panel ahora es "Ajustes".
- Ajustes (`AjustesSheet` en `Amigo.kt`): papel grande con 6 casillas. Ya funcionan 2:
  1. **Siempre activo**: servicio en primer plano (`FriendService`, aviso discreto) + permiso para que la batería no lo duerma. Se reactiva al abrir la app.
  2. **Memoria**: guarda en `Documents/Amigo` de la tarjeta SD (o del almacenamiento interno si no hay SD) `memoria.txt` (resumen legible) y `memoria.json` (contadores): carpetas, tipos de archivo y fichas que más usas y la hora más activa. Solo anota qué abres, nunca el contenido.
- Las otras 4 casillas son huecos para lo que sigue. Con "Ajustes" se quitaron del panel izquierdo las opciones que ya no hacían falta (versión 1.12).

## Versión 1.17: teclado 3D y charla con el amigo
- En el panel de las 3 rayitas, junto a "Ajustes", hay un ícono de teclado 3D (`KeyboardIcon`). Al tocarlo se abre el chat (`ChatSheet`) y sale el teclado del teléfono para hablar con el amigo.
- Si el amigo te habla solo (globito con borde rosa, dura 9 s), tocá el globito: se abre el chat con su pregunta para que le respondas.
- Código nuevo: `Charla.kt` (chat, `CerebroLocal`, iniciativa con límites, ícono y hoja de chat). Cambios pequeños en `Limpiador.kt`, `Amigo.kt`, `MainActivity.kt` y `AndroidManifest.xml` (`adjustResize`).
- Configuración: `assets/amigo_config.json` (límites de iniciativa: 90 s entre mensajes, 6 por hora, inactividad de 45 s, silencio de 30 min).
- Habla solo únicamente cuando anda suelto por la app, lleva un rato sin que toques nada y no está el panel/chat abierto. Órdenes por chat: "no hables solo", "podés hablar solo", "modo silencio", "borra el contexto", "sin insultos", "hablame sin filtro".
- Si la Memoria está encendida, la charla se guarda en `Documents/Amigo/conversaciones.txt` y se recupera al abrir el chat.
- El cerebro es LOCAL (reglas, sin internet). Para uno con IA real: crear otra clase que implemente `Cerebro` y asignarla a `AmigoChat.cerebro` (requiere permiso INTERNET y una clave).


## Versión 1.17: limpieza de lo que no funcionaba
- Se quitó `fondo.gif` (4.4 MB), `GifBackground`, `GIF_SCRIM` y `USE_GIF_BACKGROUND`: nunca se usaban.
- Se quitaron las 4 casillas "Próximamente" de Ajustes y `SlotIcon`. Quedan Siempre activo y Memoria.
- `assets/amigo_config.json` ahora trae solo lo que lee `AmigoConfig` (`autonomy`). El resto (modelo de IA, cámara, micrófono, etc.) está en `docs/amigo_config_ia_futura.json`, fuera del APK, para cuando exista un `Cerebro` con IA real.
- No se tocó el movimiento del amigo (`Limpiador.kt`) ni el explorador.
- Nota: el proyecto no trae `gradlew`; compila con el workflow de GitHub o con `gradle assembleRelease` si tienes Gradle 8.9 instalado.

## Versión 1.18: fichas en cuadrícula de 5 y vista/orden dentro de las carpetas
- Al entrar en una ficha (Música, Fotos, Vídeos, APKs, Descargas) las carpetas salen en cuadrícula de **5 por fila**, más pequeñas (`CatGridScreen` / `FolderTile` en `Categorias.kt`). Cada una muestra nombre, barrita, peso y cantidad de archivos.
- Dentro de una carpeta, en la esquina de la barra de resumen hay un botón (rayitas con perillas) que abre **Vista y orden**:
  - **Ver:** Filas (como antes), Cuadrícula (4 por fila, miniaturas) o Circular (miniaturas redondas). Se recuerda entre usos (`Store.viewMode`).
  - **Ordenar:** Nombre, Fecha, Tamaño o Tipo, ascendente o descendente (igual que antes).
- En cuadrícula y circular, el menú de cada elemento (renombrar, copiar, cortar, compartir, ZIP, información, eliminar) sale con el botón ⋮ de la esquina; mantener pulsado sigue seleccionando.
- No se tocó el amigo (`Limpiador.kt`).

## Versión 1.21: Herramientas

- Se quitó "Change shape" y el botón del teclado del panel del amigo (el amigo vuelve a ser la esfera). El código de la forma (Forma.kt, Cuerpo.kt) y del chat (Charla.kt) sigue en el proyecto pero ya no se usa desde la pantalla.
- Nuevo botón **Herramientas**: al tocarlo se abre un mini panel con tres fichas, del mismo estilo que las del explorador: Editor de fotos, Editor de vídeos y Editor de música (Herramientas.kt). Por ahora solo son el panel y los íconos; las herramientas funcionales vienen después.

## Versión 1.20: cuerpo con volumen y esqueleto (Cuerpo.kt)

- **Volumen:** de la silueta de la foto se calcula una "altura" y se pinta luz y sombra encima (se ve redondo, no plano). Se hace una vez, sin internet.
- **Esqueleto automático:** la figura se convierte en una malla con huesos (cabeza, 2 brazos, 2 piernas; o 4 patas). Al caminar las piernas y los brazos giran desde sus articulaciones, la cabeza se mece y el pecho respira. Al agarrarlo estira brazos y piernas.
- Los huesos se colocan según la silueta, así que sirve con cualquier foto (en fotos raras puede quedar aproximado).
- Pendiente: pelo/cola con resortes, parpadeo, y que invente las partes que no se ven (requiere IA).

## Versión 1.19: Change shape (el amigo toma la forma de una foto)
- En el panel del amigo, donde estaba el botón blanco "Ajustes", ahora dice **Change shape**. Ajustes sigue disponible como enlace debajo.
- Change shape: elegir una foto de la galería → se le quita el fondo → se elige cómo es (dos patas, cuatro patas u objeto; la app sugiere uno) → el amigo toma esa forma. También se puede **volver a ser esfera**.
- Dos patas: camina en dos (rebota, se balancea y levanta una pata y luego la otra). Cuatro patas: igual, con cuatro patas y un trote más rápido. Mira hacia donde va. Objeto: se queda quieto (se le puede arrastrar y lanzar como siempre).
- Sigue siendo blandito: se estira y rebota igual que la esfera. Tocarlo sigue limpiando los residuos.
- La forma se guarda (`filesDir/forma_amigo.png`) y se recupera al abrir la app.
- El recorte del fondo se hace sin internet ni modelos de IA (`Forma.kt`, `makeCutout`): funciona mejor con fondo liso o transparente. Con fondos complicados puede traer algo del fondo; la vista previa lo muestra antes de aceptar.
- Código nuevo: `Forma.kt`. Cambios en `Limpiador.kt` (estado de la forma, dibujo, un objeto no pasea solo, panel). La esfera sin forma funciona igual que antes.

## Versión 1.22: fichas iguales, vídeo con lista, miniaturas y panel simplificado
- Fichas de archivos y de carpetas: el nombre siempre reserva 2 líneas, así todas miden lo mismo.
- Reproductor de vídeo con lista de la carpeta: ⏮ / ⏭ cambian de vídeo, pasa solo al siguiente y los controles son propios (sin `MediaController`).
- Miniaturas de música (carátula), PDF (primera hoja) y APK (ícono) además de fotos y vídeos (`Thumbs.kt`).
- Más rápido: fecha y tamaño de cada archivo se calculan solo al dibujarlo; miniaturas con 4 hilos y las más recientes primero.
- Panel del amigo: se quitó el botón **Herramientas** (y `Herramientas.kt`, íconos `ic_tool_*`).
- Se quitó **Siempre activo** (`FriendService`, `FriendBackground` y sus permisos de notificación, servicio y batería).
- **Memoria** ahora está siempre encendida: ya no se activa ni se apaga. Ajustes solo la muestra como información.

## Versión 1.23: el amigo te sigue fuera de la app (`Seguir.kt`)
- Si sacas al amigo (no está guardado) y sales de la app, aparece una esfera flotante sobre las demás apps. Se arrastra y recuerda dónde la dejaste. Al volver a Archivero se esconde.
- Al tocarla salen 3 casillas pequeñas: **1** vacía (borrar caché, más adelante), **2** 🎵 mini reproductor (⏮ ⏯ ⏭ y una **✕** que cierra solo el panel; la música sigue), **3** vacía (notificaciones, más adelante). Tocar fuera cierra las casillas.
- Necesita el permiso "Mostrar sobre otras apps": en Ajustes hay una ficha **Seguirte fuera de la app** que lo pide. Mientras el amigo anda suelto corre un servicio con un aviso discreto (`FriendService`); si lo guardas, se detiene.
- Arreglo: al abrir la app, el amigo ya no aparece un instante en la esquina de arriba a la izquierda (se dibujaba antes de medir la pantalla).
- Pendiente: que evite tus zonas de toque en juegos y la casilla de notificaciones.

## Versión 1.24: el amigo flotante cobra vida y el mini reproductor tiene carpetas (`Seguir.kt`)
- **Animado fuera de la app**: la esfera ya no es un dibujo fijo. Tiene la misma cara que en la app (ojitos), se estira hacia donde va, respira, parpadea, mira a los lados, y si suena música baila y suelta notitas ♪ (`BubbleView`, bucle con `Choreographer` en `FriendOverlay.step`).
- **Se mueve sola**: pasea libre por toda la pantalla (camino curvo, paradas, ritmo distinto en cada paseo) o se queda en una esquina. Se puede agarrar y soltar en cualquier lado. Con un panel abierto se queda quieta al lado.
- **Al tocarla**: salen las 3 casillas de siempre; la 🎵 abre el mini reproductor.
- **Mini reproductor**: lista de carpetas de música (las mismas de la ficha Música) → tocas una carpeta → canciones → tocas una y suena. Arriba: título, barra de progreso, ⏮ ⏯ ⏭, botón 🫧/📌 (paseo libre / esquina) y **✕** que cierra solo el panel; la música sigue y el amigo sigue por la pantalla.
- La música ya no se corta con la pantalla apagada (`WAKE_LOCK`, `MusicPlayer.setWakeMode`).
- Las casillas 1 y 3 siguen vacías (borrar caché / notificaciones, para después).

## Versión 1.25: pantalla horizontal y amigo fijo (`Seguir.kt`)
- **Girar el teléfono**: el amigo flotante detecta la orientación (tamaño real de la pantalla). Si giras con un panel abierto, se rehace: en vertical va apilado; en horizontal los controles quedan a la izquierda y las carpetas/canciones a la derecha, y el panel se coloca al costado de la esfera si no cabe arriba/abajo. Vuelve a la carpeta que tenías abierta.
- **Doble toque** sobre el amigo: se queda **fijo** (aro rosa, no se mueve ni se deja arrastrar). Otro doble toque lo suelta. Se recuerda aunque se reinicie el servicio.
- Un toque simple abre las casillas tras un instante (el que tarda Android en distinguir un doble toque).

## Versión 1.26
- Lista de carpetas del mini reproductor: el nombre va arriba y debajo, en pequeño, "N canciones · almacenamiento" (antes se cortaba con "…" y no se veía si era la SD). Se quitó el 📁 repetido cuando la carpeta ya traía su propio emoji.

## Versión 1.27: corrección de errores, estabilidad, rendimiento y diseño
**Errores corregidos**
- Papelera: dos archivos con el mismo nombre eliminados a la vez (por ejemplo desde una búsqueda) podían pisarse y perderse; ahora cada uno recibe un nombre único (`Store.trashOne`).
- Papelera: si algo se eliminaba antes de que terminara de leerse la lista guardada, desaparecía de la lista (`Store.init`).
- Miniaturas de PDF: un PDF con contraseña o dañado dejaba abierto su descriptor de archivo; al listar muchos PDF se agotaban y la app fallaba (`Thumbs.pdfFirstPage`).
- Música: ahora respeta el foco de audio. Una llamada u otra app que reproduce sonido pausa la música, y se reanuda sola al terminar (`MusicPlayer`). Antes seguía sonando encima.
- Estabilidad: la actividad ya no se recrea al cambiar tamaño de letra, densidad, idioma o disposición de pantalla (`configChanges` en el manifiesto). Antes eso cerraba al amigo flotante, la música y perdía la carpeta abierta.

**Rendimiento y fluidez**
- Amigo (dentro de la app): ya no se recompone toda la capa en cada cuadro mientras se mueve; la posición se lee al medir (`CleanerLayer`). El lienzo de burbujitas de pantalla completa solo se repinta mientras hay burbujitas.
- Amigo flotante (fuera de la app): quieto, sin música y sin arrastre dibuja a la mitad de los cuadros (menos batería, mismo aspecto) (`FriendOverlay.frame`).
- Barra de fichas de Inicio: la forma y los degradados se arman una vez (`drawWithCache`) en vez de en cada cuadro del zoom.

**Diseño**
- Carpeta nueva (`FolderIcon`): fondo con pestaña redondeada, una hoja que asoma y tapa con degradado y brillo. Colores nuevos en `Pal.Folder*`.
- Ícono de archivo nuevo (`FileIcon`): hoja con esquinas suaves, esquina doblada con volumen y la extensión en una pastilla rosa.
- Panel lateral rehecho: cabecera con el resplandor de Inicio, secciones (Almacenamiento, Papelera, Candado), almacenamientos en tarjetas de vidrio con barrita, y opciones con el ícono dentro de una casilla redondeada. Los emojis del candado se cambiaron por íconos de línea (`LockIcon`, `KeyIcon`).
- Panel del amigo y Ajustes: mismo vidrio 3D que Inicio; el hueco para guardar al amigo ahora es rosa tenue.
- Tarjetas de carpeta en las fichas (`FolderTile`): degradado y canto con brillo.
- No se cambió la estructura del proyecto, los nombres de archivos ni el comportamiento de las pantallas.


## Versión 1.30: lirios de araña rehechos (dibujados con código, ligeros y nítidos)
- El GIF de la 1.29 se veía pixelado y se quitó (`assets/lirios.gif` ya no existe). Los lirios se vuelven a DIBUJAR con código, como el amigo flotante,
  pero rehechos desde cero (`Lirios.kt`, `LirioFondo`): 11 flores de 12 pétalos en espiral y 13 estambres con puntitas de luz, tallos que se doblan.
  Todo se calcula a la resolución real de la pantalla, así que queda nítido.
- Brisa: ciclo de 12 s que empalma perfecto (bucle infinito); la brisa recorre las flores de izquierda a derecha, los tallos se mecen, los pétalos
  ceden y tiemblan un poco, y los estambres ondean más tarde. Más amplitud que en la 1.28.
- Ligero (la 1.28 se sentía pesada): el lienzo es solo la franja de abajo con flores; los pétalos de cada flor se pintan juntos (relleno con degradado,
  realce, bordes, nervaduras) y los estambres con sus puntitas van en un solo trazo: unas 90 llamadas de dibujo por cuadro en vez de unas 380;
  nada se crea en cada cuadro y la animación solo se lee al dibujar. Existe solo mientras Inicio está visible.
- Se mantienen los arreglos de la 1.29: carga de la primera vez tras dar el permiso y el amigo flotante que ya no se escapa del dedo.
- Para cambiar posiciones, tamaños, luz o la fuerza de la brisa: tabla `LIRIOS` y `drawLirio` en `Lirios.kt`.

## Versión 1.31: panel de música del amigo flotante
- Cada carpeta y cada canción muestra su miniatura (carátula; en carpetas, cover/folder.jpg o la carátula de su primera canción). Sin carátula: ícono de nota o de carpeta.
- Botones ⏮ ▶/⏸ ⏭ dibujados como vectores (sin emojis).
- Botón de repetir (arriba, junto a ✕): toca una vez y la canción que suena se repite sin parar; toca otra vez y la música sigue normal.
- Pasear libre / quedarse en la esquina: ahora se cambia manteniendo pulsado el título "Música".

## Versión 1.32: reproductor nuevo
- En Inicio, al sonar música, el panel de abajo es alto: carátula grande, título, barra de progreso con perilla rosa y botones vectoriales (anterior, reproducir/pausa, siguiente, cerrar). En carpetas se ve una versión baja con la misma carátula pequeña.
- Se quitaron los emojis (⏮ ⏸ ▶ ⏭ ✕ 🎵): ahora son íconos dibujados.
- Se quitó el fondo de lirios del Inicio.

## Versión 1.33: el amigo escribe y aprende
- **Escribir:** el amigo crea y modifica archivos de texto solo en la tarjeta SD y solo dentro de carpetas con 🔓 pegado al nombre (sin espacio), por ejemplo `🔓carpeta`. Nunca borra; antes de cambiar un texto guarda un `.bak`.
  - Por su cuenta: crea y actualiza `Amigo - diario.txt` y `Amigo - vocabulario.txt` en la primera carpeta 🔓.
  - Por orden en el chat: «crea archivo notas en 🔓carpeta con comprar pan», «agrega a notas: leche», «cambia en notas: pan por galletas».
- **Leer:** solo PDF, y solo los que le das con ⋮ > «Enseñar al amigo». Aprende las palabras (sin artículos ni conectores), cuántas veces aparecen y una frase de ejemplo.
  Todo va a su memoria: `Documents/Amigo/vocabulario.json`. Tope de 12 000 palabras (olvida las menos vistas).
- Chat: «qué aprendiste», «qué sabes de <palabra>», «en qué carpetas puedes escribir», «cómo aprendes».
- Usa la librería pdfbox-android (necesita internet la primera vez que compilas).

## Versión 1.34: el amigo lee los PDF de tus carpetas 🔓
- **Regla:** un PDF que esté dentro de una carpeta con 🔓 pegado al nombre (sin espacio), por ejemplo `🔓carpeta`, o dentro de una subcarpeta de ella, el amigo lo puede leer **todas las veces que quieras**, mientras no lo saques de ahí.
  - `🔓 carpeta` (con espacio) **no cuenta**. Solo las carpetas que tú marcas con el candado; el resto de carpetas siguen cerradas para él.
  - Vale solo para la tarjeta SD, igual que la escritura (la regla es una sola: `CarpetaLibre` en `Saber.kt`).
  - El permiso se comprueba **en cada lectura** (no se recuerda): si mueves el PDF fuera de la carpeta 🔓, o le quitas el 🔓 a la carpeta, o le pones un espacio, el amigo deja de poder leerlo en ese mismo momento.
  - Solo lee PDF (máx. 40 MB, las primeras 300 páginas, sin contraseña, con texto). Nunca borra ni modifica un PDF.
- **Chat:** «qué pdf puedes leer», «lee informe», «lee página 3 de informe», «busca factura en informe», «qué dice informe sobre ventas».
  El nombre puede ir con o sin `.pdf`, sin importar mayúsculas ni acentos, y vale un trozo del nombre (mínimo 3 letras).
- «Enseñar al amigo» (⋮ en un PDF) sigue igual: sirve para cualquier PDF, aprende sus palabras y se hace una vez por archivo.
- Código: `AmigoSaber.puedeLeer`, `pdfsLibres`, `pdfPorNombre`, `leerPdf`, `leerPagina`, `buscarEnPdf` (`Saber.kt`) y `AmigoChat.pdfCmd` (`Charla.kt`).

## Versión 1.35: lo que lee, lo guarda en su memoria
- Cada PDF que el amigo lee (los de carpetas 🔓 cuando se lo pides en el chat, y los que le das con ⋮ > «Enseñar al amigo») alimenta su memoria, **una sola vez por PDF** (si lo relee, no cuenta dos veces; si el PDF cambia, sí lo vuelve a aprender):
  - **Vocabulario:** palabras y cuántas veces las vio (`Documents/Amigo/vocabulario.json`, como antes).
  - **Literatura:** frases enteras y legibles de cada PDF (hasta 40 por PDF, 3 000 en total; al llenarse olvida las más viejas) en `Documents/Amigo/literatura.json`.
  - **Cómo se arman las palabras:** qué palabras suelen ir justo después de cada una (las 6 más frecuentes), en el mismo `literatura.json`.
- Con eso contesta mejor: «qué sabes de <palabra>» ahora añade con qué palabras suele ir y una frase guardada; «dime una frase de lo que leíste» saca una frase al azar; «qué aprendiste» cuenta también las frases.
- Lo que lee de los PDF **sí** queda en el historial del chat (`conversaciones.txt`) como cualquier otra respuesta.
- Los textos de Ajustes y de la memoria dicen ahora la verdad: del resto de tus archivos nunca se guarda el contenido; de los PDF que lee, sí palabras y frases.
- Se sigue leyendo solo en lo permitido: PDF dentro de carpetas 🔓 (SD) o los que tú le das; el permiso de las carpetas 🔓 se comprueba en cada lectura.
- Código: `AmigoSaber.absorber`, `alimentarMemoria`, `elegirFrases`, `fraseAlAzar`, `fraseCon` (`Saber.kt`).

## Versión 1.36: el cerebro (nada se olvida)
- Se quitaron todos los topes que hacían olvidar: ya no hay máximo de palabras (antes 12 000) ni de frases (antes 3 000).
- **Un archivo por PDF:** cada PDF que el amigo aprende crea su propio archivo pequeño en `Documents/Amigo/cerebro/` (`000001_nombre.json`, `000002_…`) con sus palabras, hasta 100 frases y las palabras que suelen ir juntas.
  Escribir uno nuevo **no toca** los anteriores (nunca los pisa: el número sale de lo que ya hay en la carpeta). Se pueden crear tantos como se quiera.
- **Una sola conciencia:** al abrir la app el amigo suma todos los archivos del cerebro, en orden, en una sola memoria; después de aprender un PDF nuevo suma ese mismo archivo a lo que ya sabe, con el mismo código (`fusionar`), así que lo que sabe ahora es idéntico a lo que sabrá la próxima vez.
- Lo de las versiones 1.33–1.35 (`vocabulario.json` y `literatura.json`) se sigue leyendo como la **base** del cerebro; ya no se reescribe, y no se pierde nada.
- Ocupa poco: el ejemplo de cada palabra solo se guarda la primera vez que la ve, y por PDF se guardan como máximo 30 000 pares de palabras (los más repetidos).
- Si un archivo del cerebro se daña, se salta y los demás siguen. Si el amigo no pudo escribir uno (sin permiso o sin espacio), lo reintenta en el siguiente guardado.
- Si borras un archivo de la carpeta `cerebro`, el amigo deja de saber lo de ese PDF la próxima vez que abra la app (y lo puede volver a aprender).
- En la memoria viva (RAM) se guardan, por palabra, las 20 que más suelen seguirle; los archivos conservan todas. Los límites de lectura por PDF (40 MB, primeras 300 páginas) siguen siendo los de la 1.34.
- Código: `AmigoSaber.fusionar`, `cargarCerebro`, `guardarCerebro`, `absorber` (`Saber.kt`).


## Versión 1.37: el amigo aprende de la pantalla (accesibilidad)
**Qué hace:** con la función encendida, el amigo lee el texto que ves en el teléfono (con un servicio de accesibilidad de Android), detecta palabras que todavía no conoce
(jerga, términos técnicos, hashtags, abreviaturas, formas de escribir alargadas como «holaaaa», y expresiones de dos palabras que se repiten), las guarda y después las usa al charlar.

**Cómo se enciende (dos pasos, a propósito):**
1. Ajustes del amigo > **Aprender de la pantalla** (interruptor propio de la app). Si el servicio no está activo, abre Accesibilidad del sistema.
2. Ajustes del sistema > Accesibilidad > **Archivero: aprender de la pantalla** > Activar.
   En Android 13+ puede salir en gris por ser una app instalada a mano: Info de la app > ⋮ > **Permitir ajustes restringidos**, y vuelve a Accesibilidad.
Apagar cualquiera de los dos pasos detiene la lectura. Con la pantalla apagada no lee.

**Qué guarda** (`Documents/Amigo/pantalla/`, en la SD si hay, igual que el resto de su memoria):
- `palabras.json`: por palabra → veces, frase de contexto (≈90 caracteres), app donde la vio, primera y última vez, tipo. También las expresiones que se repiten ≥3 veces.
- `palabras.txt`: lo mismo, legible (las 300 más vistas).
- Una palabra cuenta una vez por pantalla y no se vuelve a contar hasta pasado 1 minuto, para no inflar los números mientras dejas la misma pantalla abierta.
- Nada se borra solo, salvo que se llene (20 000 palabras): entonces se olvidan primero las vistas una sola vez hace más tiempo.
- Si `palabras.json` se daña, guarda una copia `palabras.dañado.json` antes de empezar de cero.

**Qué NO lee ni guarda:** campos de contraseña; lo que escribes tú (campos editables); la propia app, el teclado, la barra de estado/notificaciones, Ajustes y el lanzador;
apps cuyo nombre de paquete sugiere banco, billetera, contraseñas, autenticador o VPN (lista aproximada en `PalabrasPantalla.OMITIR_TROZOS`: no puede conocer todos los bancos del mundo);
direcciones web, correos, @usuarios y números largos (teléfonos, tarjetas, códigos); capturas de pantalla (en la 1.37 no hacía ninguna; desde la 1.39 solo hace capturas si enciendes el OCR aparte, y nunca las guarda).
**Ojo:** en apps de chat sí lee los mensajes que ves (de otros y tuyos ya enviados); si no quieres eso, apaga la función o añade el paquete a `OMITIR_TROZOS`.

**Cómo lo usa el amigo:**
- «qué sabes de <palabra>» ahora también dice cuántas veces la vio, cuándo y en qué app, con la frase donde apareció.
- «qué palabras nuevas viste» / «qué aprendiste de la pantalla» da un resumen (últimas y más repetidas).
- Si en el chat usas una palabra que aprendió de la pantalla (vista ≥2 veces), la reconoce y dice dónde la encontró; de vez en cuando suelta una reciente por su cuenta, y entre sus mensajes espontáneos pregunta qué significa alguna.
- No tiene diccionario: sabe dónde la vio y cuántas veces, no su significado.

**Rendimiento:** lee como mucho cada ~2,5 s, hasta 700 nodos y 30 000 letras por lectura; todo el análisis y la escritura corren en un hilo aparte, y se guarda cada ~30 s si hubo cambios.

**OCR:** en la 1.37 no estaba incluido por ser más invasivo (captura la pantalla entera) y gastar más batería. Se agregó como interruptor aparte en la **1.39** (ver abajo).

- Archivos nuevos/cambiados: `Pantalla.kt` (nuevo: `LeerPantallaService`, `PalabrasPantalla`), `res/xml/leer_pantalla_config.xml`, `AndroidManifest.xml` (servicio + `<queries>` para mostrar el nombre de las apps),
  `strings.xml`, `Amigo.kt` (casilla en Ajustes, que ahora se desplaza), `Charla.kt` (comandos, iniciativa y `conPalabras`), `Saber.kt` (`sabe`, `STOP` interno), `Store.kt`.

## Versión 1.38: casillas nuevas del amigo flotante (Descansar · Música · No lectura)
Al tocar al amigo flotante salen 3 casillas con diseño nuevo (ícono dibujado + nombre; **rosa = encendida**):
1. **Descansar** (luna): la esfera desaparece de la pantalla y no lee nada (queda como «No lectura»). En su lugar flota una casilla **Llamar** (se puede arrastrar; un toque lo trae de vuelta).
   Mientras descansa «pasea» por la SD: cada ~45 s entra a la siguiente carpeta 🔓 (da la vuelta a todas) y, si hay un PDF que todavía no leyó, lo lee y lo suma a su cerebro. Las reglas de siempre: solo lee dentro de carpetas 🔓,
   solo escribe su diario ahí y nunca borra. Al volver avisa con un mensaje (cuántas carpetas recorrió, PDF leídos y palabras nuevas) y lo anota en su diario.
   Si la app está cerrada, usa un cerebro propio sobre la misma carpeta Documents/Amigo. El descanso se recuerda aunque se reinicie el servicio; si guardas al amigo en la app (deja de andar suelto) el descanso termina,
   y también se puede llamar desde Ajustes del amigo > «Aprender de la pantalla» (muestra «descansando» y un toque lo llama).
2. **Música**: la misma de siempre (mini reproductor), solo cambió la casilla.
3. **No lectura** (ojo tachado): un toque = no lee la pantalla (la casilla se pone rosa); otro toque = deja de estar rosa y vuelve a leer. Se recuerda entre usos.
- La lectura de pantalla ahora exige: función encendida en Ajustes **y** no estar en «No lectura» **y** no estar descansando (`PalabrasPantalla.puedeLeer`).
- Código: `SlotView`, `FriendOverlay.descansar / volver / mostrarLlamar / empezarPaseo` (`Seguir.kt`), `PalabrasPantalla.noLectura / descansando / puedeLeer` (`Pantalla.kt`), `AmigoSaber.pasear` (`Saber.kt`).

## Versión 1.39: OCR de respaldo para apps que no exponen su texto (interruptor aparte)
(La 1.38 ya existía —las casillas del amigo flotante—, por eso este paso es la 1.39.)

**Qué hace:** en apps que no muestran su texto por accesibilidad (juegos, imágenes, algunos vídeos), el amigo puede leer la pantalla con **OCR**: captura la pantalla **en memoria** (`AccessibilityService.takeScreenshot`, Android 11+),
reconoce el texto con **ML Kit Text Recognition** (modelo local, alfabeto latino, **sin internet**), lo pasa por `PalabrasPantalla.procesar(...)` y **descarta la imagen** (`bitmap.recycle()`). La captura **nunca** se guarda en disco.

**Cómo se enciende (todo a propósito, apagado por defecto):**
- Ajustes del amigo > **Leer imágenes y juegos (OCR)** (interruptor propio, con su advertencia: captura la pantalla entera y gasta más batería).
- Solo funciona si «Aprender de la pantalla» también está encendido, el servicio está activo en Accesibilidad y el amigo no está en «No lectura» ni descansando (`PalabrasPantalla.puedeOcr = puedeLeer && ocrActivo`).
- El servicio ahora declara `android:canTakeScreenshot="true"` (y `flagRetrieveInteractiveWindows`). Ojo: ese permiso sale en el aviso de Android al activar el servicio, **aunque el OCR esté apagado**; mientras el interruptor del OCR esté apagado el servicio nunca captura.
  Si ya tenías el servicio activo antes de actualizar, puede hacer falta apagarlo y volver a encenderlo en Accesibilidad (la casilla del OCR avisa si falta el permiso de capturas: `PalabrasPantalla.capturaPermitida`).

**Solo como respaldo y con freno:**
- Se pide OCR únicamente cuando la lectura normal de nodos da **menos de 60 caracteres** (`OCR_SI_MENOS_DE`). Si hay texto accesible, se usa ese y no se captura nada.
- Como mucho **1 captura cada 10 s** (`OCR_CADA_MS`) y solo una a la vez; si una captura no termina en 1 minuto se da por perdida.
- Las capturas se piden cuando llega un evento de accesibilidad (igual que la lectura normal): una pantalla que no emite ningún evento no se vuelve a capturar.
- Nunca con la pantalla apagada: se comprueba antes de pedirla y otra vez al recibirla. También se vuelve a comprobar que sigue al frente la misma app y que el OCR sigue permitido; si algo cambió, la imagen se descarta sin leerla.
- Si no se pudo recorrer toda la pantalla (topes de 700 nodos / 30 000 letras) o no se sabe con certeza qué ventanas hay, no se hace OCR.

**Privacidad (mismas exclusiones que la lectura normal, más lo propio de una imagen):**
- Se usa `PalabrasPantalla.debeOmitir` (bancos, billeteras, contraseñas, teclado, ajustes, propia app) antes de capturar y otra vez después.
- Antes de reconocer, la imagen se **tapa de negro**: todo lo que queda fuera de la ventana de la app activa (barra de estado, navegación, otra app en pantalla dividida), toda ventana **por encima** de la app (teclado, avisos emergentes, burbujas)
  y los rectángulos de los campos de **contraseña** y de los campos **editables** (lo que escribes tú).
- El texto reconocido pasa por la misma limpieza que el resto (URLs, correos, @usuarios y números largos) porque entra por `PalabrasPantalla.procesar`; además cada bloque se junta en una sola línea para que un número largo partido en renglones también se limpie.
- Lo que aprende se guarda igual que antes (palabras sueltas + trozo de contexto en `Documents/Amigo/pantalla`), nunca la imagen ni el texto completo.
- Límites conocidos: un campo de texto que la app no marque como editable (dibujado a mano, p. ej. en un juego) no se puede tapar; y las apps que se protegen con `FLAG_SECURE` devuelven captura vacía o error (eso también protege).

**Rendimiento:** el recorrido de nodos y el pedido de la captura son rápidos; la conversión de la captura, el tapado y el reconocimiento corren en hilos aparte (un hilo propio de baja prioridad + los hilos de ML Kit) y el procesamiento de palabras en el hilo de siempre de `PalabrasPantalla`.
El reconocedor se crea al primer uso y se suelta de la memoria tras 1 minuto sin usarse. El APK crece unos MB por el modelo incluido (versión «empaquetada» de ML Kit: no depende de Google Play Services).

**Revisión de compilación (1.37 y 1.38):** no se pudo compilar donde se escribió ni donde se revisó (sin SDK de Android). Se revisó a mano `Pantalla.kt` completo y las partes que cambiaron en 1.37 y 1.38 de `Amigo.kt`, `Charla.kt`, `Saber.kt`, `Seguir.kt` y `Store.kt`, más el manifest y los XML:
imports, tipos, smart casts, firmas entre archivos (cada método de `AmigoSaber` y `PalabrasPantalla` que se usa existe), uso de API de Android 11+, llaves/paréntesis balanceados en todos los `.kt` y XML bien formados. No se encontró nada que corregir en esas partes. Sigue sin haberse compilado: la verificación real es `gradle assembleRelease`.

- Archivos cambiados: `Pantalla.kt` (`ocrActivo`, `puedeOcr`, `capturaPermitida`; el servicio ahora incluye `pedirOcr`, `planOcr`, `atenderCaptura`, `taparZonas`, `entregar`), `Amigo.kt` (casilla y advertencia del OCR, `OcrIcon`),
  `res/xml/leer_pantalla_config.xml`, `res/values/strings.xml` (descripción del servicio), `app/build.gradle.kts` (ML Kit `com.google.mlkit:text-recognition:16.0.1`, versionCode 39 / versionName 1.39).

## Versión 1.40: la conciencia del amigo (carpetas ordenadas) y correcciones
**Carpetas nuevas** (`Conciencia.kt`). Todo lo del amigo sigue en `Documents/Amigo` (SD si hay), pero ahora cada tipo de recuerdo tiene su subcarpeta:
```
Documents/Amigo/
  conciencia.json   índice: qué hay en cada fuente y qué palabras conectan PDF y pantalla
  memoria/          memoria.json, memoria.txt
  charla/           conversaciones.txt
  pdf/              cerebro/ (un archivo por PDF) + vocabulario.json y literatura.json viejos (solo se leen)
  pantalla/         palabras.json, palabras.txt
```
- **Migración sin pérdidas** (`Conciencia.migrar`): al abrir, lo que las versiones anteriores dejaron suelto pasa a su carpeta. Copia a un temporal, comprueba que pesa lo mismo, lo renombra y solo entonces quita el original. Si algo falla, el original se queda y se reintenta. Si un nombre ya existe en el destino con otro contenido, el viejo entra como `migrado_<nombre>`; nada se pisa.
- **Conexiones**: `conciencia.json` (como mucho una vez por minuto) guarda archivos/bytes/fecha de cada fuente y hasta 200 palabras que el amigo conoce por los PDF **y** vio en la pantalla, con cuántas veces en cada lado. Pregúntale «tu conciencia» o «qué conectaste» en el chat.
- Sigue igual: el diario y los textos que escribe van solo en carpetas 🔓; nunca borra.

**Correcciones**
- El amigo flotante ya no desaparece si Android destruye la actividad en segundo plano: el servicio solo se detiene si la app se cierra de verdad (`isFinishing`).
- `PalabrasPantalla.cargar`: un error al LEER `palabras.json` (SD sin montar, sin permiso) ya no se trata como archivo dañado ni vacía la memoria; solo un JSON roto lo es (y se respalda en `palabras.dañado.json`).
- `AmigoSaber.cambiar`: si ya existe un `.bak`, el respaldo nuevo lleva fecha (`nombre.20261113-231500.bak`) en vez de pisar el anterior.
- PDF: `PDDocument.load` usa `MemoryUsageSetting.setupMixed(16 MB)`; los PDF grandes pasan a un archivo temporal en vez de agotar la memoria.
- `podar()`: si todas las palabras se repiten, se olvidan las más antiguas para no pasar del tope.
- Manifest: se declara `POST_NOTIFICATIONS` (Android 13+) para poder ver el aviso del amigo flotante (se activa en los ajustes de notificaciones de la app).
- **Reproductor en el servicio** (`Musica.kt`): el reproductor de música ahora es uno solo para toda la app (`Musica.get`), ya no vive dentro de la pantalla (`Store`). Si Android destruye la actividad en segundo plano, la música sigue y el mini reproductor del amigo flotante sigue funcionando (carpetas, canciones, ⏮ ⏯ ⏭, repetir): ya no necesita la actividad ni el `Store` (usa `Musica.get` y, para listar carpetas, `volumenesPropios()` en `Seguir.kt`). Al volver a abrir la app, ve la misma música sonando. La música solo se detiene y se suelta (`Musica.liberar`) cuando la app se cierra de verdad (`isFinishing`), como antes.
- Versión 1.40 (versionCode 40).
- Pendiente: el proyecto sigue sin compilarse donde se escribió; la verificación real es `gradle assembleRelease`.

## Versión 1.41: revisión de Charla, Limpiador y Store
- **Chat**: «¿Qué sabes de X?», «¿qué dice el pdf sobre Y?» y similares ya funcionan con los signos ¿ ? ¡ !; antes el «¿» inicial y el «?» final hacían que no se reconociera la orden.
- **Chat**: si cierras el chat mientras el amigo «piensa», ya no se queda en «…» para siempre (`try/finally`).
- **Chat**: palabrotas e insultos se detectan por palabra: «computadora» ya no cuenta como palabrota, y «limpia la basura de tu caché» o «archivos inútiles» ya no se toman como insulto (hace falta «sos/eres …» o un mensaje cortito).
- **Chat**: «memoria» (RAM, SD) ya no dispara «qué sabes de mí»; ahora es «tu memoria». El modo «sin insultos» se recuerda al reabrir la app.
- **Limpiador**: si se cancela la limpieza a mitad (sales de la pantalla), el amigo no queda en «limpiando» y se puede volver a limpiar.
- **Manifest**: `allowBackup="false"`: el hash de la contraseña, el contador de intentos y la lista de la papelera ya no van a la copia de seguridad de Google.
- Versión 1.41 (versionCode 41).
- Pendiente (no tocado): el bloqueo por intentos usa la hora del teléfono (se salta cambiando la fecha); PBKDF2 con 20 000 vueltas; la lista de la papelera se guarda al terminar de mover todo (si la app muere en medio, quedan archivos en `.ArchiveroTrash` sin listar). Sigue sin compilarse aquí: la prueba real es `gradle assembleRelease`.

## Versión 1.42: revisión de MainActivity
- **Menú ⋮ de un archivo** (eliminar, comprimir, extraer, «Enseñar al amigo»): su corrutina vivía en el menú y se cancelaba al cerrarse; al **eliminar** podía mover el archivo a `.ArchiveroTrash` sin anotarlo en la papelera (parecía haberse perdido). Ahora usa el scope de la pantalla (`EntryMenu` recibe `scope`).
- **Renombrar**: solo se permite cambiar mayúsculas si el nombre «existente» es el mismo archivo (`Files.isSameFile`); en almacenamiento con distinción de mayúsculas ya no puede pisar otro archivo.
- **Restaurar de la papelera**: si ya existe el original y también «(restaurado)», usa `uniqueFile` en vez de pisarlo.
- Versión 1.42 (versionCode 42).
- Sin tocar: la pantalla (miniatura de recientes) queda visible con contraseña puesta (se arregla con `FLAG_SECURE`, pero bloquea capturas); los diálogos de «ocupado» no se pueden cancelar; los dos botones de la barra superior usan el mismo ícono.

## Versión 1.43: el diccionario del amigo y palabras que se usan parecido
**Carpeta nueva** (`Diccionario.kt`): `Documents/Amigo/diccionario/` con `diccionario.json` (y `diccionario.txt`, para leer). Está en el mismo árbol que `memoria/`, `charla/`, `pdf/` y `pantalla/`, y `conciencia.json` ahora lo cuenta como quinta fuente (versión 2 del índice): trae cuántas palabras tiene y cuáles de ellas también conoce por los PDF o vio en la pantalla (con las veces de cada lado).
- **Enseñarle** (solo se guarda lo que tú dices): «casa significa lugar donde se vive», «la palabra lag quiere decir retraso», «define casa: …». Quitar: «olvida la palabra casa». Cambiar el significado = enseñárselo de nuevo.
- **Preguntarle** («qué significa X», «qué sabes de X», «conoces la palabra X»): primero dice el significado que le enseñaste, luego lo que sabe de los PDF y la pantalla. Si la conoce pero no tiene significado, te invita a enseñárselo. Al enseñar, dice cuántas veces la vio y qué palabras de la definición ya conocía (así el diccionario queda conectado con el resto).
- **Palabras que se usan parecido** (`AmigoSaber.parecidas`): compara qué palabras aparecen a ±3 lugares de cada una en las frases de los PDF (coseno entre vecinas; mínimo 3 vecinas en común). No es entender: es «suelen ir con las mismas compañeras». Hace falta haber leído PDF.
- Los mensajes espontáneos ya no preguntan por una palabra que ya tiene significado, y avisan cómo enseñarla.
- Seguridad de datos: un error al LEER el diccionario (SD sin montar) no lo vacía; solo un JSON roto se respalda como `diccionario.danado.<fecha>.json`. Si no se puede guardar, el cambio se revierte y se avisa. Tope de 5000 palabras. No se escribe nada hasta conocer los almacenamientos (así no se guarda en la carpeta equivocada).
- Versión 1.43 (versionCode 43). Sin compilar aquí: la prueba real es `gradle assembleRelease`.
- Pendiente: el parecido solo usa los PDF (no la pantalla); el diccionario no se muestra todavía en Ajustes.

## Versión 1.44: el amigo contesta mejor y deja de interrumpir
- **Respuestas cortas** (`cortaCmd` en `Charla.kt`): «ok», «dale», «si», «no», «jaja», «mmm» y «nose» ya tienen respuesta propia (con variaciones, nunca la misma dos veces seguidas). Si el amigo te había preguntado por una palabra y dices «nose», la deja pasar y no vuelve a preguntarla.
- **Menos relleno**: dos mensajes seguidos que no entiende → en vez de repetir relleno, dice qué sí sabe hacer (leer PDF, buscar, guardar palabras, «qué aprendiste»). Se quitaron «Interesante… ¿y eso para qué lo necesitás?» y «Ahí voy anotando…». El «Por cierto, últimamente veo…» ya no sale tras mensajes muy cortos.
- **No habla solo con el chat abierto**: `tick` no genera nada mientras el chat esté abierto, ni hasta 2 minutos después de la última charla. Los avisos que el amigo genera por su cuenta (p. ej. al terminar de leer) esperan y salen al cerrar el chat.
- **Mensajes largos**: con el teclado abierto la ventana se achica y la hoja del chat quedaba chiquita; ahora ocupa casi toda la ventana cuando el teclado está arriba (62 % si no) y se vuelve a desplazar al último mensaje.
- Versión 1.44 (versionCode 44). Sin compilar aquí: la prueba real es `gradle assembleRelease`.

## Versión 1.45: el diccionario guarda lo esencial
- **Primera oración**: si le pegas un texto largo como significado (p. ej. la definición de un PDF), `Diccionario.limpiarSignificado` guarda solo la primera oración (dos si la primera es muy corta), de hasta ~160 caracteres y cortando en una palabra entera. Vale para todo: «X significa …», «define X: …» y la respuesta a su pregunta.
- **Sin repetir la palabra**: al contestar a su pregunta, «prefijo: elemento que…» o «prefijo es un elemento…» se guarda como «elemento que…».
- Más frases de desconcierto y de duda para que rote entre más variantes.
- Versión 1.45 (versionCode 45). Sin compilar aquí: la prueba real es `gradle assembleRelease`.
