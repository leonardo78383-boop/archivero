package com.archivero

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * El dron (amigo flotante) en 3D de verdad, dibujado con código: casco esférico negro grafito con vetas cian, un gran lente
 * al frente, un puerto con puntitos atrás, aleta dorsal y dos alas hacia adelante (según los planos).
 *  - Gira a CUALQUIER ángulo sin límites (matriz de rotación, no hay "tope" de giro).
 *  - Sólido cuando nadie lo toca; al tocarlo o moverlo se vuelve gelatina: se aplasta, se estira y ondula, y las aleta y alas
 *    se doblan con la inercia.
 *  - Se pinta sobre fondo transparente, con negro puro y brillos cian, pensado para pantallas AMOLED.
 * Lo usan la mascota de dentro de la app (Limpiador.kt) y la esfera flotante de fuera (Aspecto.kt).
 */

private const val D_PI = 3.1415927f
private const val D_TAU = 6.2831855f

// Medidas del casco (elipsoide).
private const val HA = 0.90f
private const val HB = 0.84f
private const val HC = 0.92f

// Cámara y luz.
private const val FOCAL = 7f
private const val LX = -0.4f
private const val LY = 0.55f
private const val LZ = 0.73f
private const val HXV = -0.25f
private const val HYV = 0.33f
private const val HZV = 0.91f

// Cian de los detalles luminosos.
private const val CYR = 0.20f
private const val CYG = 0.88f
private const val CYB = 0.96f

/** Una pieza del dron: vértices, normales, color base, brillo propio (em), cuánto se dobla (flex) y triángulos. */
internal class DronMesh(
    val n: Int,
    val px: FloatArray, val py: FloatArray, val pz: FloatArray,
    val nx: FloatArray, val ny: FloatArray, val nz: FloatArray,
    val br: FloatArray, val bg: FloatArray, val bb: FloatArray,
    val em: FloatArray, val flex: FloatArray,
    val tri: ShortArray
) {
    // Cuadro actual: posición 3D ya girada y deformada, posición en pantalla y color con luz.
    val vx = FloatArray(n)
    val vy = FloatArray(n)
    val vz = FloatArray(n)
    val scr = FloatArray(n * 2)
    val col = IntArray(n)
    val nzr = FloatArray(n)          // componente Z de la normal ya girada (>0 = mira a la cámara)
    val cx = px.average().toFloat()
    val cy = py.average().toFloat()
    val cz = pz.average().toFloat()
}

private fun clamp01(v: Float): Float = if (v < 0f) 0f else if (v > 1f) 1f else v

private fun buildHull(nlon: Int, nlat: Int): DronMesh {
    val n = (nlat + 1) * (nlon + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    var k = 0
    for (i in 0..nlat) {
        val th = D_PI * i / nlat
        for (j in 0..nlon) {
            val ph = D_TAU * j / nlon
            // Casco de perfil blindado: superelipsoide suavizado, menos esfera y más cápsula
            // facetada como la referencia. Se estrecha arriba/abajo y conserva hombros anchos.
            fun spow(v: Float, e: Float): Float = kotlin.math.sign(v) * Math.pow(abs(v).toDouble(), e.toDouble()).toFloat()
            val rawY = cos(th)
            val y = spow(rawY, 0.86f)
            val ring = Math.pow(abs(sin(th)).toDouble(), 0.82).toFloat()
            val taper = 0.84f + 0.16f * (1f - abs(y))
            val x = spow(sin(ph), 0.78f) * ring * taper
            val z = spow(cos(ph), 0.78f) * ring * 1.04f
            px[k] = HA * x; py[k] = HB * y; pz[k] = HC * z
            val ax = x / HA; val ay = y / HB; val az = z / HC
            val l = sqrt(ax * ax + ay * ay + az * az)
            nx[k] = ax / l; ny[k] = ay / l; nz[k] = az / l
            br[k] = 0.14f; bg[k] = 0.16f; bb[k] = 0.20f
            em[k] = clamp01((-y - 0.60f) / 0.16f) * 0.55f        // franja cian bajo la panza
            k++
        }
    }
    val tri = ShortArray(nlat * nlon * 6)
    var t = 0
    for (i in 0 until nlat) for (j in 0 until nlon) {
        val a = i * (nlon + 1) + j
        val b = a + 1
        val c = a + nlon + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    return DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
}

/** Aleta dorsal: una hoja afilada que sube y se curva hacia atrás, con una franja cian en el frente. */
private fun buildBlade(ns: Int): DronMesh {
    val n = (ns + 1) * 4
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    // Curva (Bézier) en el plano Y-Z.
    val y0 = 0.50f; val z0 = -0.10f
    val y1 = 1.10f; val z1 = -0.20f
    val y2 = 1.40f; val z2 = -0.80f
    var k = 0
    for (i in 0..ns) {
        val s = i.toFloat() / ns
        val a = (1f - s) * (1f - s)
        val b = 2f * (1f - s) * s
        val c = s * s
        val sy = a * y0 + b * y1 + c * y2
        val sz = a * z0 + b * z1 + c * z2
        var ty = -2f * (1f - s) * y0 + 2f * (1f - 2f * s) * y1 + 2f * s * y2
        var tz = -2f * (1f - s) * z0 + 2f * (1f - 2f * s) * z1 + 2f * s * z2
        val tl = sqrt(ty * ty + tz * tz)
        ty /= tl; tz /= tl
        val ny0 = -tz          // normal dentro del plano (lado del frente)
        val nz0 = ty
        val w = 0.44f * Math.pow((1f - s).toDouble(), 0.7).toFloat() + 0.015f
        val t = 0.16f * Math.pow((1f - s).toDouble(), 0.85).toFloat() + 0.012f
        for (q in 0 until 4) {
            when (q) {
                0 -> { px[k] = -w; py[k] = sy; pz[k] = sz; nx[k] = -1f; ny[k] = 0f; nz[k] = 0f }
                1 -> { px[k] = 0f; py[k] = sy + ny0 * t; pz[k] = sz + nz0 * t; nx[k] = 0f; ny[k] = ny0; nz[k] = nz0 }
                2 -> { px[k] = w; py[k] = sy; pz[k] = sz; nx[k] = 1f; ny[k] = 0f; nz[k] = 0f }
                else -> { px[k] = 0f; py[k] = sy - ny0 * t; pz[k] = sz - nz0 * t; nx[k] = 0f; ny[k] = -ny0; nz[k] = -nz0 }
            }
            if (q == 1) { br[k] = 0.17f; bg[k] = 0.19f; bb[k] = 0.23f } else { br[k] = 0.10f; bg[k] = 0.115f; bb[k] = 0.14f }
            em[k] = if (q == 1) clamp01((s - 0.05f) / 0.2f) * (1f - clamp01((s - 0.8f) / 0.2f)) else 0f
            fl[k] = s
            k++
        }
    }
    return DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, ringTris(ns))
}

/** Ala: una placa fina que sale del costado hacia adelante y abajo, con una franja cian arriba. */
private fun buildWing(side: Float, ns: Int): DronMesh {
    val n = (ns + 1) * 4
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val x0 = side * 0.78f; val y0 = -0.10f; val z0 = 0.05f
    val x1 = side * 1.10f; val y1 = -0.28f; val z1 = 0.42f
    val x2 = side * 1.30f; val y2 = -0.52f; val z2 = 0.82f
    var k = 0
    for (i in 0..ns) {
        val s = i.toFloat() / ns
        val a = (1f - s) * (1f - s)
        val b = 2f * (1f - s) * s
        val c = s * s
        val sx = a * x0 + b * x1 + c * x2
        val sy = a * y0 + b * y1 + c * y2
        val sz = a * z0 + b * z1 + c * z2
        val w = 0.22f * (1f - 0.6f * s) + 0.02f
        val t = 0.07f * (1f - 0.5f * s)
        for (q in 0 until 4) {
            when (q) {
                0 -> { px[k] = sx; py[k] = sy; pz[k] = sz - w; nx[k] = 0f; ny[k] = 0f; nz[k] = -1f }
                1 -> { px[k] = sx; py[k] = sy + t; pz[k] = sz; nx[k] = 0f; ny[k] = 1f; nz[k] = 0f }
                2 -> { px[k] = sx; py[k] = sy; pz[k] = sz + w; nx[k] = 0f; ny[k] = 0f; nz[k] = 1f }
                else -> { px[k] = sx; py[k] = sy - t; pz[k] = sz; nx[k] = 0f; ny[k] = -1f; nz[k] = 0f }
            }
            if (q == 1) { br[k] = 0.17f; bg[k] = 0.19f; bb[k] = 0.23f } else { br[k] = 0.10f; bg[k] = 0.115f; bb[k] = 0.14f }
            em[k] = if (q == 1 && s > 0.15f && s < 0.9f) 0.9f else 0f
            fl[k] = s
            k++
        }
    }
    return DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, ringTris(ns))
}

/** Triángulos de un tubo de 4 caras con (ns + 1) anillos; cada cara son dos triángulos seguidos (a,c,b) y (b,c,d). */
private fun ringTris(ns: Int): ShortArray {
    val tri = ShortArray(ns * 4 * 6)
    var t = 0
    for (i in 0 until ns) for (q in 0 until 4) {
        val a = i * 4 + q
        val b = i * 4 + (q + 1) % 4
        val c = (i + 1) * 4 + q
        val d = (i + 1) * 4 + (q + 1) % 4
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    return tri
}

/** Motor lateral blindado: aro toroidal con una banda luminosa cian integrada en el canal interior. */
private fun buildSideEngine(side: Float, nu: Int = 36, nv: Int = 12): DronMesh {
    val n = (nu + 1) * (nv + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val major = 0.405f
    val minor = 0.105f
    var k = 0
    for (i in 0..nu) {
        val u = D_TAU * i / nu
        val cu = cos(u); val su = sin(u)
        for (j in 0..nv) {
            val v = D_TAU * j / nv
            val cv = cos(v); val sv = sin(v)
            px[k] = side * (0.82f + minor * sv)
            py[k] = -0.035f + (major + minor * cv) * cu
            pz[k] = 0.02f + (major + minor * cv) * su
            nx[k] = side * sv; ny[k] = cv * cu; nz[k] = cv * su
            // Carcasa metálica con una línea emisiva en el labio interior del impulsor.
            br[k] = 0.34f; bg[k] = 0.37f; bb[k] = 0.42f
            val innerLip = if (cv < -0.58f) 0.92f else 0f
            em[k] = innerLip
            fl[k] = 0f
            k++
        }
    }
    val tri = ShortArray(nu * nv * 6)
    var t = 0
    for (i in 0 until nu) for (j in 0 until nv) {
        val a = i * (nv + 1) + j
        val b = a + 1
        val c = a + nv + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    return DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
}

/** Anillo sobre el casco (línea de panel): puntos con su normal, para saber cuándo se ve. */
private class Belt(val n: Int, val x: FloatArray, val y: FloatArray, val z: FloatArray, val nx: FloatArray, val ny: FloatArray, val nz: FloatArray)

private fun hullBelt(n: Int, ux: Float, uy: Float, uz: Float, wx: Float, wy: Float, wz: Float, off: Float): Belt {
    val x = FloatArray(n + 1); val y = FloatArray(n + 1); val z = FloatArray(n + 1)
    val nx = FloatArray(n + 1); val ny = FloatArray(n + 1); val nz = FloatArray(n + 1)
    for (i in 0..n) {
        val a = D_TAU * i / n
        var qx = cos(a) * ux + sin(a) * wx
        var qy = cos(a) * uy + sin(a) * wy
        var qz = cos(a) * uz + sin(a) * wz + off
        val k = 1f / sqrt((qx / HA) * (qx / HA) + (qy / HB) * (qy / HB) + (qz / HC) * (qz / HC))
        qx *= k; qy *= k; qz *= k
        x[i] = qx; y[i] = qy; z[i] = qz
        val ax = qx / (HA * HA); val ay = qy / (HB * HB); val az = qz / (HC * HC)
        val l = sqrt(ax * ax + ay * ay + az * az)
        nx[i] = ax / l; ny[i] = ay / l; nz[i] = az / l
    }
    return Belt(n + 1, x, y, z, nx, ny, nz)
}

internal class Dron3D {
    private val hull = buildHull(48, 32)
    private val blade = buildBlade(9)
    private val wingL = buildWing(-1f, 6)
    private val wingR = buildWing(1f, 6)
    private val engineL = buildSideEngine(-1f)
    private val engineR = buildSideEngine(1f)

    // Dos líneas de panel: un cinturón detrás del lente y un aro oblicuo (se nota mejor cómo gira).
    private val beltA = hullBelt(64, 1f, 0f, 0f, 0f, 1f, 0f, -0.42f)
    private val beltB = hullBelt(64, 1f, 0f, 0f, 0f, 0.55f, 0.83f, 0f)

    // Rotación actual (3x3, por filas).
    private val r = FloatArray(9)
    private var cs = 1f
    private var sn = 0f
    private var sxs = 1f
    private var sys = 1f
    private var rip = 0f
    private var ph = 0f
    private var fx = 0f
    private var fy = 0f
    private var s = 1f
    private var cx0 = 0f
    private var cy0 = 0f
    private var glow = 1f

    // Salida del último cuadro: dónde quedó el lente, qué tan de frente está y su matriz (1 unidad = 1 px de frente).
    var lensFacing = 0f
        private set
    var lensCx = 0f
        private set
    var lensCy = 0f
        private set
    var lensRpx = 1f
        private set
    val lensMat = Matrix()

    private var ox = 0f
    private var oy = 0f
    private var oz = 0f
    private val m9 = FloatArray(9)
    private val tmpPath = Path()
    private val silPath = Path()
    private val ringPath = Path()
    private val binX = FloatArray(BINS)
    private val binY = FloatArray(BINS)
    private val binR = FloatArray(BINS)
    private val idx = ShortArray(hull.tri.size)
    // Del tamaño de la malla con MÁS triángulos (los motores tienen 864; antes se dimensionaba con la aleta y se salía del arreglo).
    private val maxTris = maxOf(blade.tri.size, wingL.tri.size, wingR.tri.size, engineL.tri.size, engineR.tri.size, hull.tri.size) / 3
    private val keyZ = FloatArray(maxTris)
    private val ord = IntArray(maxTris)
    private val ord2 = IntArray(maxTris)
    private val keyB = IntArray(maxTris)
    private val bucket = IntArray(NB + 1)
    private val triPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL_AND_STROKE; strokeJoin = Paint.Join.ROUND }
    private val vertPaint = Paint()
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val irisGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val irisRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val irisFill = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Matriz de giro de Euler: primero yaw (izquierda/derecha), luego pitch (arriba/abajo) y roll (de lado). Los ángulos no tienen tope. */
    private fun setEuler(yaw: Float, pitch: Float, roll: Float) {
        val cy = cos(yaw); val sy = sin(yaw)
        val cp = cos(pitch); val sp = sin(pitch)
        val cr = cos(roll); val sr = sin(roll)
        val a0 = cy; val a1 = 0f; val a2 = sy
        val b0 = sp * sy; val b1 = cp; val b2 = -sp * cy
        val c0 = -cp * sy; val c1 = sp; val c2 = cp * cy
        r[0] = cr * a0 - sr * b0; r[1] = cr * a1 - sr * b1; r[2] = cr * a2 - sr * b2
        r[3] = sr * a0 + cr * b0; r[4] = sr * a1 + cr * b1; r[5] = sr * a2 + cr * b2
        r[6] = c0; r[7] = c1; r[8] = c2
    }

    /** Pasa un punto del modelo a pantalla con el mismo giro y la misma gelatina que el cuerpo. Deja el resultado en ox, oy, oz. */
    private fun pt(mx: Float, my: Float, mz: Float) {
        val x = r[0] * mx + r[1] * my + r[2] * mz
        val y = r[3] * mx + r[4] * my + r[5] * mz
        val z = r[6] * mx + r[7] * my + r[8] * mz
        var u = x * cs + y * sn
        var v = -x * sn + y * cs
        u *= sxs; v *= sys
        var xx = u * cs - v * sn
        var yy = u * sn + v * cs
        var zz = z
        if (rip > 0.0005f) {
            val k = 1f + rip * sin(4.2f * (xx * 0.7f + yy * 0.7f + zz * 0.4f) + ph)
            xx *= k; yy *= k; zz *= k
        }
        val p = FOCAL / (FOCAL - zz)
        ox = cx0 + xx * s * p
        oy = cy0 - yy * s * p
        oz = zz
    }

    private fun transform(m: DronMesh) {
        for (i in 0 until m.n) {
            val mx = m.px[i]; val my = m.py[i]; val mz = m.pz[i]
            val x = r[0] * mx + r[1] * my + r[2] * mz
            val y = r[3] * mx + r[4] * my + r[5] * mz
            val z = r[6] * mx + r[7] * my + r[8] * mz
            var u = x * cs + y * sn
            var v = -x * sn + y * cs
            u *= sxs; v *= sys
            var xx = u * cs - v * sn
            var yy = u * sn + v * cs
            var zz = z
            if (rip > 0.0005f) {
                val k = 1f + rip * sin(4.2f * (xx * 0.7f + yy * 0.7f + zz * 0.4f) + ph)
                xx *= k; yy *= k; zz *= k
            }
            val fl = m.flex[i]
            if (fl > 0f) { xx -= fx * fl * 0.25f; yy -= fy * fl * 0.25f }
            m.vx[i] = xx; m.vy[i] = yy; m.vz[i] = zz
            val p = FOCAL / (FOCAL - zz)
            m.scr[2 * i] = cx0 + xx * s * p
            m.scr[2 * i + 1] = cy0 - yy * s * p
        }
    }

    private fun light(m: DronMesh) {
        for (i in 0 until m.n) {
            val ax = m.nx[i]; val ay = m.ny[i]; val az = m.nz[i]
            val nx = r[0] * ax + r[1] * ay + r[2] * az
            val ny = r[3] * ax + r[4] * ay + r[5] * az
            val nz = r[6] * ax + r[7] * ay + r[8] * az
            m.nzr[i] = nz
            val lam = max(0f, nx * LX + ny * LY + nz * LZ)
            var sp = max(0f, nx * HXV + ny * HYV + nz * HZV)
            sp *= sp; sp *= sp; sp *= sp; sp *= sp; sp *= sp            // ^32: brillo de plástico pulido
            val fr0 = 1f - clamp01(nz)
            val fres = fr0 * fr0 * sqrt(fr0)                             // borde cian (se ve el contorno sobre negro)
            val k = 0.42f + 0.95f * lam
            var rr = m.br[i] * k + sp * 0.55f + fres * CYR * 0.55f
            var gg = m.bg[i] * k + sp * 0.55f + fres * CYG * 0.55f
            var bl = m.bb[i] * k + sp * 0.55f + fres * CYB * 0.55f
            val e = clamp01(m.em[i] * glow)
            val ke = 0.55f + 0.45f * lam
            rr = rr * (1f - e) + CYR * ke * e
            gg = gg * (1f - e) + CYG * ke * e
            bl = bl * (1f - e) + CYB * ke * e
            val ir = (clamp01(rr) * 255f).toInt()
            val ig = (clamp01(gg) * 255f).toInt()
            val ib = (clamp01(bl) * 255f).toInt()
            m.col[i] = (255 shl 24) or (ir shl 16) or (ig shl 8) or ib
        }
    }

    /**
     * Dibuja el dron centrado en (cx, cy); [scale] = píxeles por unidad del modelo (el casco mide ~0.9 unidades de radio).
     * [yaw]/[pitch]/[roll]: orientación en radianes, sin límites.
     * [st] y [ang]: estiramiento de gelatina (>0 estirado, <0 aplastado) y hacia dónde (radianes).
     * [rip]: ondulación (0 = sólido), [phase]: fase de la onda, [flexX]/[flexY]: cuánto se doblan aleta y alas.
     * [glowK]: 1 = brillo normal.
     */
    fun draw(
        c: Canvas, cx: Float, cy: Float, scale: Float,
        yaw: Float, pitch: Float, roll: Float,
        st: Float, ang: Float, ripple: Float, phase: Float, flexX: Float, flexY: Float, glowK: Float
    ) {
        setEuler(yaw, pitch, roll)
        val stc = st.coerceIn(-0.4f, 0.5f)
        cs = cos(ang); sn = sin(ang)
        sxs = 1f + stc; sys = 1f / (1f + stc)
        rip = ripple; ph = phase
        fx = flexX; fy = flexY
        s = scale; cx0 = cx; cy0 = cy
        glow = glowK

        // Halo AMOLED: un resplandor cian muy suave detrás (negro puro alrededor).
        val hr = scale * 1.25f
        haloP.color = 0x0A33E1F5
        c.drawCircle(cx, cy, hr, haloP)
        haloP.color = 0x0E33E1F5
        c.drawCircle(cx, cy, hr * 0.80f, haloP)
        haloP.color = 0x1233E1F5
        c.drawCircle(cx, cy, hr * 0.60f, haloP)

        transform(hull); transform(blade); transform(wingL); transform(wingR)
        transform(engineL); transform(engineR)
        light(hull); light(blade); light(wingL); light(wingR)
        light(engineL); light(engineR)

        // Piezas que quedan detrás del casco se pintan primero; las de delante, al final.
        val zBlade = r[6] * blade.cx + r[7] * blade.cy + r[8] * blade.cz
        val zWl = r[6] * wingL.cx + r[7] * wingL.cy + r[8] * wingL.cz
        val zWr = r[6] * wingR.cx + r[7] * wingR.cy + r[8] * wingR.cz
        if (zBlade < 0f) drawFlat(c, blade)
        if (zWl < 0f) drawFlat(c, wingL)
        if (zWr < 0f) drawFlat(c, wingR)
        // Los impulsores se dibujan antes del casco: la parte interior queda integrada
        // en el cuerpo y el aro exterior sobresale como una pieza mecánica independiente.
        drawFlat(c, engineL)
        drawFlat(c, engineR)

        drawHull(c)
        drawBelts(c)
        drawLens(c)
        drawPort(c)

        if (zBlade >= 0f) drawFlat(c, blade)
        if (zWl >= 0f) drawFlat(c, wingL)
        if (zWr >= 0f) drawFlat(c, wingR)
    }

    private fun drawHull(c: Canvas) {
        // Silueta: el punto más lejano del centro en cada rebanada de ángulo (el casco es convexo).
        var mx = 0f
        var my = 0f
        for (i in 0 until hull.n) { mx += hull.scr[2 * i]; my += hull.scr[2 * i + 1] }
        mx /= hull.n; my /= hull.n
        for (b in 0 until BINS) binR[b] = -1f
        for (i in 0 until hull.n) {
            val dx = hull.scr[2 * i] - mx
            val dy = hull.scr[2 * i + 1] - my
            val a = kotlin.math.atan2(dy, dx)
            var b = ((a + D_PI) / D_TAU * BINS).toInt()
            if (b >= BINS) b = BINS - 1
            if (b < 0) b = 0
            val d = dx * dx + dy * dy
            if (d > binR[b]) { binR[b] = d; binX[b] = hull.scr[2 * i]; binY[b] = hull.scr[2 * i + 1] }
        }
        silPath.reset()
        var started = false
        for (b in 0 until BINS) {
            if (binR[b] < 0f) continue
            if (!started) { silPath.moveTo(binX[b], binY[b]); started = true } else silPath.lineTo(binX[b], binY[b])
        }
        silPath.close()
        // Relleno oscuro con borde suave (quita los dientes de la malla en el contorno).
        fillP.color = 0xFF0B0E13.toInt()
        c.drawPath(silPath, fillP)

        // Triángulos de cara al frente.
        var cnt = 0
        val t = hull.tri
        var k = 0
        while (k < t.size) {
            val a = t[k].toInt(); val b = t[k + 1].toInt(); val d = t[k + 2].toInt()
            val cross = (hull.vx[b] - hull.vx[a]) * (hull.vy[d] - hull.vy[a]) - (hull.vy[b] - hull.vy[a]) * (hull.vx[d] - hull.vx[a])
            if (cross > 0f) { idx[cnt++] = t[k]; idx[cnt++] = t[k + 1]; idx[cnt++] = t[k + 2] }
            k += 3
        }
        if (cnt > 0) {
            c.drawVertices(Canvas.VertexMode.TRIANGLES, hull.n * 2, hull.scr, 0, null, 0, hull.col, 0, idx, 0, cnt, vertPaint)
        }
        // Borde de cristal cian.
        strokeP.strokeWidth = max(1f, s * 0.028f)
        strokeP.color = 0x663EC7E8
        c.drawPath(silPath, strokeP)
        strokeP.strokeWidth = max(0.8f, s * 0.012f)
        strokeP.color = 0xAA9BEFFF.toInt()
        c.drawPath(silPath, strokeP)
    }

    private fun drawBelts(c: Canvas) {
        drawBelt(c, beltA, 0xAA3A4552.toInt(), max(1f, s * 0.026f))
        drawBelt(c, beltB, 0x7733E1F5, max(0.8f, s * 0.016f))
    }

    private fun drawBelt(c: Canvas, b: Belt, color: Int, w: Float) {
        ringPath.reset()
        var pen = false
        for (i in 0 until b.n) {
            val nzv = r[6] * b.nx[i] + r[7] * b.ny[i] + r[8] * b.nz[i]
            if (nzv <= 0.06f) { pen = false; continue }
            pt(b.x[i] * 1.012f, b.y[i] * 1.012f, b.z[i] * 1.012f)
            if (!pen) { ringPath.moveTo(ox, oy); pen = true } else ringPath.lineTo(ox, oy)
        }
        strokeP.strokeWidth = w
        strokeP.color = color
        c.drawPath(ringPath, strokeP)
    }

    /** Polígono de un círculo pegado al casco, en el plano de la cara delantera (+1) o trasera (-1). */
    private fun discPath(p: Path, face: Float, rad: Float, lift: Float) {
        p.reset()
        val n = 40
        for (i in 0 until n) {
            val a = D_TAU * i / n
            var qx = rad * cos(a)
            var qy = rad * sin(a)
            var qz = face * HC
            val k = 1f / sqrt((qx / HA) * (qx / HA) + (qy / HB) * (qy / HB) + (qz / HC) * (qz / HC))
            qx *= k; qy *= k; qz *= k
            qz += face * lift
            pt(qx, qy, qz)
            if (i == 0) p.moveTo(ox, oy) else p.lineTo(ox, oy)
        }
        p.close()
    }

    /** Matriz que pone un dibujo plano (unidades = píxeles vistos de frente) sobre la cara delantera o trasera. */
    private fun faceMat(m: Matrix, face: Float, lift: Float) {
        val z = face * (HC + lift)
        val h = 0.1f
        pt(0f, 0f, z); val x0 = ox; val y0 = oy
        pt(h, 0f, z); val ax = (ox - x0) / (h * s); val ay = (oy - y0) / (h * s)
        pt(0f, h, z); val bx = -(ox - x0) / (h * s); val by = -(oy - y0) / (h * s)
        m9[0] = ax; m9[1] = bx; m9[2] = x0
        m9[3] = ay; m9[4] = by; m9[5] = y0
        m9[6] = 0f; m9[7] = 0f; m9[8] = 1f
        m.setValues(m9)
    }

    private fun drawLens(c: Canvas) {
        val facing = r[8]
        lensFacing = if (facing > 0f) facing else 0f
        lensRpx = 0.39f * s
        // Centro del lente en pantalla (se calcula siempre, para que los gestos y accesorios sepan dónde está).
        pt(0f, 0f, HC + 0.08f)
        lensCx = ox; lensCy = oy
        faceMat(lensMat, 1f, 0.08f)
        if (facing <= 0.03f) return
        discPath(tmpPath, 1f, 0.50f, 0.03f)
        fillP.color = 0xFF1B2028.toInt()
        c.drawPath(tmpPath, fillP)
        discPath(tmpPath, 1f, 0.43f, 0.06f)
        fillP.color = 0xFF33E1F5.toInt()
        c.drawPath(tmpPath, fillP)
        discPath(tmpPath, 1f, 0.39f, 0.07f)
        fillP.color = 0xFF05080D.toInt()
        c.drawPath(tmpPath, fillP)
    }

    private fun drawPort(c: Canvas) {
        val facing = -r[8]
        if (facing <= 0.03f) return
        discPath(tmpPath, -1f, 0.27f, 0.03f)
        fillP.color = 0xFF1B2028.toInt()
        c.drawPath(tmpPath, fillP)
        discPath(tmpPath, -1f, 0.22f, 0.05f)
        fillP.color = 0xFF080B10.toInt()
        c.drawPath(tmpPath, fillP)
        // Puntitos del puerto, vistos con el mismo giro.
        faceMat(portMat, -1f, 0.06f)
        c.save()
        c.concat(portMat)
        fillP.color = 0xFF3A6272.toInt()
        val rr = 0.12f * s
        for (i in 0 until 7) {
            val a = D_TAU * i / 7
            c.drawCircle(rr * cos(a), rr * sin(a), s * 0.022f, fillP)
        }
        c.drawCircle(0f, 0f, s * 0.026f, fillP)
        c.restore()
    }

    private val portMat = Matrix()

    /** Pinta una pieza fina (aleta o ala) triángulo por triángulo, de lejos a cerca. */
    private fun drawFlat(c: Canvas, m: DronMesh) {
        val nt = m.tri.size / 3
        triPaint.strokeWidth = max(0.8f, s * 0.012f)
        if (nt <= SMALL_MESH) {
            // Piezas chicas (aleta, alas): ordenación por inserción.
            for (t in 0 until nt) {
                val a = m.tri[3 * t].toInt(); val b = m.tri[3 * t + 1].toInt(); val d = m.tri[3 * t + 2].toInt()
                keyZ[t] = (m.vz[a] + m.vz[b] + m.vz[d]) / 3f
                ord[t] = t
            }
            for (i in 1 until nt) {
                val cur = ord[i]
                val key = keyZ[cur]
                var j = i - 1
                while (j >= 0 && keyZ[ord[j]] > key) { ord[j + 1] = ord[j]; j-- }
                ord[j + 1] = cur
            }
            for (o in 0 until nt) drawTri(c, m, ord[o])
            return
        }
        // Piezas grandes (motores): se descartan los triángulos que dan la espalda y el resto se ordena por cubetas (rápido, sin lag).
        var cnt = 0
        var zmin = Float.MAX_VALUE
        var zmax = -Float.MAX_VALUE
        for (t in 0 until nt) {
            val a = m.tri[3 * t].toInt(); val b = m.tri[3 * t + 1].toInt(); val d = m.tri[3 * t + 2].toInt()
            if ((m.nzr[a] + m.nzr[b] + m.nzr[d]) / 3f < -0.12f) continue
            val z = (m.vz[a] + m.vz[b] + m.vz[d]) / 3f
            keyZ[cnt] = z
            ord[cnt] = t
            if (z < zmin) zmin = z
            if (z > zmax) zmax = z
            cnt++
        }
        if (cnt == 0) return
        val span = max(zmax - zmin, 1e-4f)
        java.util.Arrays.fill(bucket, 0)
        for (i in 0 until cnt) {
            var bk = ((keyZ[i] - zmin) / span * (NB - 1)).toInt()
            if (bk < 0) bk = 0 else if (bk > NB - 1) bk = NB - 1
            keyB[i] = bk
            bucket[bk + 1]++
        }
        for (b in 1..NB) bucket[b] += bucket[b - 1]
        for (i in 0 until cnt) ord2[bucket[keyB[i]]++] = ord[i]
        for (o in 0 until cnt) drawTri(c, m, ord2[o])
    }

    /** Pinta una cara (el triángulo t y su pareja) con el color promedio de sus 4 vértices (evita rayas). */
    private fun drawTri(c: Canvas, m: DronMesh, t: Int) {
        val a = m.tri[3 * t].toInt(); val b = m.tri[3 * t + 1].toInt(); val d = m.tri[3 * t + 2].toInt()
        val other = if (t % 2 == 0) m.tri[3 * t + 5].toInt() else m.tri[3 * t - 3].toInt()
        triPaint.color = avgColor(m.col[a], m.col[b], m.col[d], m.col[other])
        tmpPath.reset()
        tmpPath.moveTo(m.scr[2 * a], m.scr[2 * a + 1])
        tmpPath.lineTo(m.scr[2 * b], m.scr[2 * b + 1])
        tmpPath.lineTo(m.scr[2 * d], m.scr[2 * d + 1])
        tmpPath.close()
        c.drawPath(tmpPath, triPaint)
    }

    private fun avgColor(c0: Int, c1: Int, c2: Int, c3: Int): Int {
        val r0 = (((c0 shr 16) and 255) + ((c1 shr 16) and 255) + ((c2 shr 16) and 255) + ((c3 shr 16) and 255)) / 4
        val g0 = (((c0 shr 8) and 255) + ((c1 shr 8) and 255) + ((c2 shr 8) and 255) + ((c3 shr 8) and 255)) / 4
        val b0 = ((c0 and 255) + (c1 and 255) + (c2 and 255) + (c3 and 255)) / 4
        return (255 shl 24) or (r0 shl 16) or (g0 shl 8) or b0
    }

    /**
     * Ojo del lente para la mascota de dentro de la app: aro blanco brillante con pupila; parpadea ([open]),
     * mira ([lookX], [lookY]) y, si está contento ([happy]), se hace un arquito. Va pegado al lente y gira con él.
     */
    fun drawIris(c: Canvas, open: Float, lookX: Float, lookY: Float, happy: Boolean) {
        if (lensFacing <= 0.04f) return
        val fade = clamp01(lensFacing * 4f)
        val rr = lensRpx * 0.74f
        c.save()
        c.concat(lensMat)
        irisGlow.color = ((0x55 * fade).toInt() shl 24) or 0x003EC7E8
        c.drawCircle(lookX * rr * 0.16f, lookY * rr * 0.12f, rr * 1.05f, irisGlow)
        if (happy) {
            irisRing.strokeCap = Paint.Cap.ROUND
            irisRing.strokeWidth = rr * 0.22f
            irisRing.color = ((255 * fade).toInt() shl 24) or 0x00FFFFFF
            tmpPath.reset()
            tmpPath.moveTo(-rr * 0.55f, rr * 0.18f)
            tmpPath.quadTo(0f, -rr * 0.60f, rr * 0.55f, rr * 0.18f)
            c.drawPath(tmpPath, irisRing)
        } else {
            c.save()
            c.scale(1f, open.coerceIn(0.08f, 1f))
            val ex = lookX * rr * 0.16f
            val ey = lookY * rr * 0.12f
            irisRing.strokeWidth = rr * 0.20f
            irisRing.color = ((255 * fade).toInt() shl 24) or 0x00FFFFFF
            c.drawCircle(ex, ey, rr * 0.62f, irisRing)
            irisFill.color = ((255 * fade).toInt() shl 24) or 0x00030305
            c.drawCircle(ex + lookX * rr * 0.06f, ey + lookY * rr * 0.05f, rr * 0.36f, irisFill)
            irisFill.color = ((220 * fade).toInt() shl 24) or 0x00FFFFFF
            c.drawCircle(ex - rr * 0.20f, ey - rr * 0.24f, rr * 0.09f, irisFill)
            c.restore()
        }
        c.restore()
    }

    private companion object {
        const val BINS = 96
        const val NB = 64            // cubetas para ordenar los triángulos de los motores
        const val SMALL_MESH = 128   // hasta aquí se ordena por inserción
    }
}
