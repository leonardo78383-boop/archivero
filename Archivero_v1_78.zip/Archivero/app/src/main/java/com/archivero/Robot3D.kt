package com.archivero

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * El robot en 3D de verdad, dibujado con código (sin librerías 3D): 10 piezas rígidas con biseles (cabeza, antenas, cuello,
 * torso, brazos, piernas y articulaciones) texturizadas con el atlas del diseño (metal violeta, franjas reflectantes, bordes
 * cromados). Se pinta con una sola llamada a drawVertices, con los triángulos ordenados de lejos a cerca, sobre fondo transparente.
 *  - Los LED rojos del pecho y el ojo rojo se dibujan encima, encendidos: el ojo parpadea y los LED laten con la música.
 *  - Gira a cualquier ángulo (yaw, pitch, roll sin tope) y mueve cabeza y brazos con la pose ([Pose], ver Animaciones.kt).
 * El modelo y su atlas vienen de assets/robot/robot.bin y res/drawable-nodpi/robot_atlas.png (ver build_robot.py).
 * Al terminar, llamar a [liberar] para soltar el atlas.
 */

private const val FOCAL = 7f
private const val NB = 160

// Dimensiones del diseño (deben coincidir con build_robot.py).
private const val TORSO_FRENTE_Z = 0.75f
private const val CABEZA_FRENTE_Z = 0.425f + 0.05f
private const val CABEZA_Y = 1.70f
// LED del pecho: x de cada barra (unidades del modelo), altura y.
private val LED_X = floatArrayOf(-0.64f, -0.45f, -0.28f, -0.12f, 0.05f, 0.19f, 0.35f, 0.52f)
private const val LED_Y = 0.69f
private const val LED_ALTO = 0.30f

internal class Robot3D(ctx: Context) {
    private val m = RobotModelo.cargar(ctx)
    private var activo = true
    private val np = m.partes.size
    private val iHead = m.indice("head")
    private val iArmL = m.indice("armL")
    private val iArmR = m.indice("armR")
    private val iTorso = m.indice("torso")

    init { RobotTex.adquirir(ctx.applicationContext) }

    /** Suelta el atlas. Después de esto, draw() no hace nada. */
    fun liberar() {
        if (!activo) return
        activo = false
        RobotTex.liberar()
    }

    // Por pieza: rotación local (9) y transformación total (9 + 3) con el giro global ya aplicado.
    private val loc = FloatArray(np * 9)
    private val tot = FloatArray(np * 12)
    private val tmpA = FloatArray(9)
    private val tmpB = FloatArray(9)
    private val tmpC = FloatArray(9)
    private val g = FloatArray(9)
    private val tmp = FloatArray(12)       // transformación del modelo (sin giro global) de la pieza que se calcula
    private val mm = FloatArray(np * 12)   // la misma, guardada por pieza para los hijos

    // Por vértice.
    private val wx = FloatArray(m.nv)
    private val wy = FloatArray(m.nv)
    private val wz = FloatArray(m.nv)
    private val scr = FloatArray(m.nv * 2)
    private val tex = FloatArray(m.nv * 2)
    private val col = IntArray(m.nv)
    private var nivelTex = -1

    // Triángulos.
    private val keyZ = FloatArray(m.nt)
    private val ord = IntArray(m.nt)
    private val ord2 = IntArray(m.nt)
    private val keyB = IntArray(m.nt)
    private val bucket = IntArray(NB + 1)
    private val sidx = ShortArray(m.nt * 3)

    private val meshPaint = Paint().apply { isFilterBitmap = true }
    private val flat = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloMat = Matrix()
    private val haloShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(0x1E7A4DFF, 0x0E7A4DFF, 0x007A4DFF), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
    )
    private val plane = Matrix()
    private val pm = FloatArray(9)
    private val box = RectF()
    private var pp = 0f; private var qq = 0f

    // ───── Matrices 3x3 (por filas) ─────
    private fun rotX(a: Float, o: FloatArray) { val c = cos(a); val s = sin(a); o[0] = 1f; o[1] = 0f; o[2] = 0f; o[3] = 0f; o[4] = c; o[5] = -s; o[6] = 0f; o[7] = s; o[8] = c }
    private fun rotY(a: Float, o: FloatArray) { val c = cos(a); val s = sin(a); o[0] = c; o[1] = 0f; o[2] = s; o[3] = 0f; o[4] = 1f; o[5] = 0f; o[6] = -s; o[7] = 0f; o[8] = c }
    private fun rotZ(a: Float, o: FloatArray) { val c = cos(a); val s = sin(a); o[0] = c; o[1] = -s; o[2] = 0f; o[3] = s; o[4] = c; o[5] = 0f; o[6] = 0f; o[7] = 0f; o[8] = 1f }
    private fun mul(a: FloatArray, b: FloatArray, o: FloatArray) {
        for (i in 0 until 3) for (j in 0 until 3) o[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j]
    }
    private fun ident(o: FloatArray) { for (i in 0 until 9) o[i] = 0f; o[0] = 1f; o[4] = 1f; o[8] = 1f }
    private fun d2r(d: Float) = d * 0.017453292f

    /** Rotación local de una pieza = Rz · Ry · Rx (grados). */
    private fun setLoc(i: Int, ax: Float, ay: Float, az: Float) {
        if (i < 0) return
        rotX(d2r(ax), tmpA); rotY(d2r(ay), tmpB); mul(tmpB, tmpA, tmpC)       // Ry·Rx
        rotZ(d2r(az), tmpA); mul(tmpA, tmpC, tmpB)                            // Rz·(Ry·Rx)
        for (k in 0 until 9) loc[i * 9 + k] = tmpB[k]
    }

    /** Calcula la transformación total de cada pieza (jerarquía por pivotes) y le aplica el giro global [g]. */
    private fun transformaciones() {
        for (i in 0 until np) {
            val p = m.partes[i]
            val r = loc
            val o = i * 9
            val cx = p.pivote[0]; val cy = p.pivote[1]; val cz = p.pivote[2]
            // t_l = c - Rl·c
            val tlx = cx - (r[o] * cx + r[o + 1] * cy + r[o + 2] * cz)
            val tly = cy - (r[o + 3] * cx + r[o + 4] * cy + r[o + 5] * cz)
            val tlz = cz - (r[o + 6] * cx + r[o + 7] * cy + r[o + 8] * cz)
            if (p.padre >= 0) {
                val b = p.padre * 12
                // Rp·Rl y Rp·t_l + tp (en modelo, antes del giro global: se guarda en tm del padre)
                for (a in 0 until 3) for (c in 0 until 3) tmp[a * 3 + c] = mm[b + a * 3] * r[o + c] + mm[b + a * 3 + 1] * r[o + 3 + c] + mm[b + a * 3 + 2] * r[o + 6 + c]
                tmp[9] = mm[b] * tlx + mm[b + 1] * tly + mm[b + 2] * tlz + mm[b + 9]
                tmp[10] = mm[b + 3] * tlx + mm[b + 4] * tly + mm[b + 5] * tlz + mm[b + 10]
                tmp[11] = mm[b + 6] * tlx + mm[b + 7] * tly + mm[b + 8] * tlz + mm[b + 11]
            } else {
                for (k in 0 until 9) tmp[k] = r[o + k]
                tmp[9] = tlx; tmp[10] = tly; tmp[11] = tlz
            }
            for (k in 0 until 12) mm[i * 12 + k] = tmp[k]
            // Giro global: G·R y G·t
            val q = i * 12
            for (a in 0 until 3) for (c in 0 until 3) tot[q + a * 3 + c] = g[a * 3] * tmp[c] + g[a * 3 + 1] * tmp[3 + c] + g[a * 3 + 2] * tmp[6 + c]
            tot[q + 9] = g[0] * tmp[9] + g[1] * tmp[10] + g[2] * tmp[11]
            tot[q + 10] = g[3] * tmp[9] + g[4] * tmp[10] + g[5] * tmp[11]
            tot[q + 11] = g[6] * tmp[9] + g[7] * tmp[10] + g[8] * tmp[11]
        }
    }

    /**
     * Dibuja el robot centrado en (cx, cy). [scale] = píxeles por unidad del modelo (alto total ≈ 5.3 unidades).
     * [yaw]/[pitch]/[roll] en radianes, sin tope. [pose] = cabeza, brazos y ojo del momento. [glowK] = brillo de los LED (1 = normal).
     */
    fun draw(c: Canvas, cx: Float, cy: Float, scale: Float, yaw: Float, pitch: Float, roll: Float, pose: Pose, glowK: Float) {
        if (!activo) return
        centro(cx, cy)
        val shader = RobotTex.shader(nivelPara(scale)) ?: return
        val nivel = nivelPara(scale)

        // Orientación del cuerpo: giro global = Rz(roll) · Rx(pitch) · Ry(yaw)
        rotY(yaw + pose.bodyYaw, tmpA); rotX(pitch + pose.bodyPitch, tmpB); mul(tmpB, tmpA, tmpC)
        rotZ(roll, tmpA); mul(tmpA, tmpC, g)

        // Poses locales
        ident(tmpA)
        for (i in 0 until np) for (k in 0 until 9) loc[i * 9 + k] = tmpA[k]
        setLoc(iHead, pose.headP, pose.headY, pose.headR)
        setLoc(iArmL, pose.lax, pose.lay, pose.laz)
        setLoc(iArmR, pose.rax, pose.ray, pose.raz)
        transformaciones()

        // Halo suave detrás (violeta muy tenue sobre fondo negro)
        val hr = scale * 3.4f
        haloMat.setScale(hr, hr); haloMat.postTranslate(cx, cy)
        haloShader.setLocalMatrix(haloMat)
        haloP.shader = haloShader
        c.drawCircle(cx, cy, hr, haloP)

        if (nivel != nivelTex) {
            nivelTex = nivel
            val w = RobotTex.tamano[nivel].toFloat()
            for (i in 0 until m.nv) { tex[2 * i] = m.u[i] * w; tex[2 * i + 1] = m.v[i] * w }
        }

        // Vértices: posición, luz y pantalla
        val lx = -0.40f; val ly = 0.55f; val lz = 0.73f
        for (i in 0 until m.nv) {
            val q = m.parteDe[i] * 12
            val x = m.px[i]; val y = m.py[i]; val z = m.pz[i]
            val X = tot[q] * x + tot[q + 1] * y + tot[q + 2] * z + tot[q + 9]
            val Y = tot[q + 3] * x + tot[q + 4] * y + tot[q + 5] * z + tot[q + 10]
            val Z = tot[q + 6] * x + tot[q + 7] * y + tot[q + 8] * z + tot[q + 11]
            wx[i] = X; wy[i] = Y; wz[i] = Z
            val pr = FOCAL / (FOCAL - Z)
            scr[2 * i] = cx + X * scale * pr
            scr[2 * i + 1] = cy - Y * scale * pr
            // normal girada
            val ax = m.nx[i]; val ay = m.ny[i]; val az = m.nz[i]
            val nx = tot[q] * ax + tot[q + 1] * ay + tot[q + 2] * az
            val ny = tot[q + 3] * ax + tot[q + 4] * ay + tot[q + 5] * az
            val nz = tot[q + 6] * ax + tot[q + 7] * ay + tot[q + 8] * az
            val lam = max(0f, nx * lx + ny * ly + nz * lz)
            val fr = 1f - (if (nz < 0f) 0f else if (nz > 1f) 1f else nz)
            var f = 0.58f + 0.42f * lam + 0.05f * fr * fr
            if (f > 1f) f = 1f
            val gch = (f * 255f).toInt()
            col[i] = (255 shl 24) or (gch shl 16) or (gch shl 8) or gch
        }

        // Triángulos de cara, de lejos a cerca
        var cnt = 0
        var zmin = Float.MAX_VALUE
        var zmax = -Float.MAX_VALUE
        for (t in 0 until m.nt) {
            val a = m.tri[3 * t].toInt(); val b = m.tri[3 * t + 1].toInt(); val d = m.tri[3 * t + 2].toInt()
            val cross = (wx[b] - wx[a]) * (wy[d] - wy[a]) - (wy[b] - wy[a]) * (wx[d] - wx[a])
            if (cross <= 0f) continue
            val z = (wz[a] + wz[b] + wz[d]) / 3f
            keyZ[cnt] = z; ord[cnt] = t
            if (z < zmin) zmin = z
            if (z > zmax) zmax = z
            cnt++
        }
        if (cnt > 0) {
            val span = max(zmax - zmin, 1e-4f)
            java.util.Arrays.fill(bucket, 0)
            for (i in 0 until cnt) {
                var bk = ((keyZ[i] - zmin) / span * (NB - 1)).toInt()
                if (bk < 0) bk = 0 else if (bk > NB - 1) bk = NB - 1
                keyB[i] = bk; bucket[bk + 1]++
            }
            for (b in 1..NB) bucket[b] += bucket[b - 1]
            for (i in 0 until cnt) ord2[bucket[keyB[i]]++] = ord[i]
            var w = 0
            for (o in 0 until cnt) {
                val t = ord2[o]
                sidx[w++] = m.tri[3 * t]; sidx[w++] = m.tri[3 * t + 1]; sidx[w++] = m.tri[3 * t + 2]
            }
            meshPaint.shader = shader
            c.drawVertices(Canvas.VertexMode.TRIANGLES, m.nv * 2, scr, 0, tex, 0, col, 0, sidx, 0, w, meshPaint)
        }

        // LED del pecho y ojo, encendidos encima del modelo
        drawLeds(c, scale, glowK)
        drawEye(c, scale, pose.eyeOpen)
    }

    /** Nivel del atlas a usar según el tamaño en pantalla: baja de tamaño cuando el robot se ve pequeño (menos parpadeo y memoria). */
    private fun nivelPara(scale: Float): Int {
        val ratio = 400f / (1.9f * max(scale, 1f))            // píxeles de atlas por píxel de pantalla en el torso
        val k = (ln(max(ratio / 1.3f, 1f)) / ln(2f)).toInt() + (if (ratio / 1.3f > 1f) 1 else 0)
        return k.coerceIn(0, 2)
    }

    /** Matriz que pone un dibujo plano (unidades del modelo) sobre el plano de una pieza. false si ese plano no mira a la cámara. */
    private fun planoMat(parte: Int, ox: Float, oy: Float, oz: Float, scale: Float, cx: Float, cy: Float): Boolean {
        if (parte < 0) return false
        val q = parte * 12
        val nzp = tot[q + 8]                        // la normal (0,0,1) de la pieza, ya girada
        if (nzp <= 0.08f) return false
        val h = 0.2f
        proy(q, ox, oy, oz, scale, cx, cy); val x0 = pp; val y0 = qq
        proy(q, ox + h, oy, oz, scale, cx, cy); val ax = (pp - x0) / h; val ay = (qq - y0) / h
        proy(q, ox, oy + h, oz, scale, cx, cy); val bx = (pp - x0) / h; val by = (qq - y0) / h
        pm[0] = ax; pm[1] = bx; pm[2] = x0
        pm[3] = ay; pm[4] = by; pm[5] = y0
        pm[6] = 0f; pm[7] = 0f; pm[8] = 1f
        plane.setValues(pm)
        return true
    }

    private fun proy(q: Int, x: Float, y: Float, z: Float, scale: Float, cx: Float, cy: Float) {
        val X = tot[q] * x + tot[q + 1] * y + tot[q + 2] * z + tot[q + 9]
        val Y = tot[q + 3] * x + tot[q + 4] * y + tot[q + 5] * z + tot[q + 10]
        val Z = tot[q + 6] * x + tot[q + 7] * y + tot[q + 8] * z + tot[q + 11]
        val p = FOCAL / (FOCAL - Z)
        pp = cx + X * scale * p
        qq = cy - Y * scale * p
    }

    private var lastCx = 0f
    private var lastCy = 0f

    private fun drawLeds(c: Canvas, scale: Float, glowK: Float) {
        // El centro del dibujo ya se usó en draw(); se reconstruye con la proyección del origen del torso.
        val cx = lastCx; val cy = lastCy
        if (!planoMat(iTorso, 0f, 0f, TORSO_FRENTE_Z + 0.004f, scale, cx, cy)) return
        val nm = DronNeon.modo
        val r = DronNeon.r(nm); val gg = DronNeon.g(nm); val b = DronNeon.b(nm)
        val pul = DronNeon.pulso()
        val k = (if (pul < 0f) 1f else 0.40f + 0.80f * pul) * (0.85f + 0.15f * glowK)
        val rgb = ((r * 255f).toInt() shl 16) or ((gg * 255f).toInt() shl 8) or (b * 255f).toInt()
        c.save()
        c.concat(plane)
        for (x in LED_X) {
            // hueco oscuro de la barra (tapa el LED pintado en el atlas)
            fillP.color = 0xFF07030E.toInt()
            box.set(x - 0.075f, LED_Y - LED_ALTO / 2f - 0.05f, x + 0.075f, LED_Y + LED_ALTO / 2f + 0.05f)
            c.drawRoundRect(box, 0.06f, 0.06f, fillP)
            strokeP.strokeWidth = 0.17f
            strokeP.color = (min255(0x30 * k) shl 24) or rgb
            c.drawLine(x, LED_Y - 0.10f, x, LED_Y + 0.10f, strokeP)
            strokeP.strokeWidth = 0.10f
            strokeP.color = (min255(0x70 * k) shl 24) or rgb
            c.drawLine(x, LED_Y - 0.11f, x, LED_Y + 0.11f, strokeP)
            strokeP.strokeWidth = 0.052f
            strokeP.color = (min255(0xFF * k) shl 24) or rgb
            c.drawLine(x, LED_Y - 0.12f, x, LED_Y + 0.12f, strokeP)
            strokeP.strokeWidth = 0.018f
            strokeP.color = (min255(0xE0 * k) shl 24) or 0x00FFE8E8
            c.drawLine(x, LED_Y - 0.115f, x, LED_Y + 0.115f, strokeP)
        }
        c.restore()
    }

    private fun drawEye(c: Canvas, scale: Float, open: Float) {
        val cx = lastCx; val cy = lastCy
        if (!planoMat(iHead, 0.28f, CABEZA_Y + 0.02f, CABEZA_FRENTE_Z + 0.004f, scale, cx, cy)) return
        val o = open.coerceIn(0.06f, 1f)
        c.save()
        c.concat(plane)
        c.scale(1f, o)
        fillP.color = 0x44FF1830
        c.drawCircle(0f, 0f, 0.15f, fillP)
        fillP.color = 0x99FF1830.toInt()
        c.drawCircle(0f, 0f, 0.095f, fillP)
        fillP.color = 0xFFFF2038.toInt()
        c.drawCircle(0f, 0f, 0.062f, fillP)
        fillP.color = 0xFFFFD8DC.toInt()
        c.drawCircle(0f, 0f, 0.026f, fillP)
        c.restore()
    }

    private fun min255(v: Float): Int = if (v > 255f) 255 else if (v < 0f) 0 else v.toInt()

    /** Fija el centro del dibujo (lo llama draw antes de pintar LED y ojo). */
    private fun centro(cx: Float, cy: Float) { lastCx = cx; lastCy = cy }
}
