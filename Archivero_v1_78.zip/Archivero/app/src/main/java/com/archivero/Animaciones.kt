package com.archivero

import kotlin.math.PI
import kotlin.math.sin

/*
 * Las cinco animaciones del robot:
 *   1. Estirarse y abrazar    2. Bostezar    3. Señalar
 *   4. Desplazamiento libre   (lo mueve el controlador de cada pantalla; aquí solo está su giro de orientación en Seguir.kt/Limpiador.kt)
 *   5. Parpadeo del ojo rojo
 * Las tres primeras son poses de los brazos y la cabeza; se hacen de vez en cuando, solo con el robot quieto, y se cortan con suavidad
 * si lo tocas, lo agarras o echa a andar. Los ángulos son grados y los brazos usan el mismo convenio que el modelo:
 * x = adelante (negativo = levantar al frente), y = barrido hacia el frente, z = abrir al costado (izquierdo negativo, derecho positivo).
 */

internal class Pose {
    var lax = 0f; var lay = 0f; var laz = 0f        // brazo izquierdo (el de la izquierda de la pantalla)
    var rax = 0f; var ray = 0f; var raz = 0f        // brazo derecho
    var headP = 0f; var headY = 0f; var headR = 0f  // cabeza: cabeceo, giro, ladeo
    var bodyYaw = 0f                                 // giro extra del cuerpo (radianes)
    var bodyPitch = 0f                               // inclinación extra del cuerpo (radianes)
    var eyeOpen = 1f                                 // 1 = ojo abierto, ~0.08 = cerrado

    fun reset() {
        lax = 0f; lay = 0f; laz = 0f; rax = 0f; ray = 0f; raz = 0f
        headP = 0f; headY = 0f; headR = 0f; bodyYaw = 0f; bodyPitch = 0f; eyeOpen = 1f
    }
}

private fun sm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

internal class Animaciones {
    private val rnd = java.util.Random()
    private var cur = -1                 // 0 = abrazo, 1 = bostezo, 2 = señalar; -1 = ninguna
    private var last = -1
    private var start = 0L
    private var nextAt = 0L
    private var lado = 1f                // hacia qué lado señala (1 = derecha, -1 = izquierda)
    private var cortando = false
    private var cortaDesde = 0L
    private var blinkAt = 0L
    private var blinkStart = -1L

    /** Descarta lo que esté en curso (por ejemplo, al ocultar el robot). */
    fun reiniciar() { cur = -1; cortando = false; nextAt = 0L; blinkStart = -1L }

    /** Una vez por cuadro: deja en [p] la pose del momento. [quieto] = puede hacer gestos (no lo tocan ni anda). */
    fun update(p: Pose, now: Long, quieto: Boolean) {
        p.reset()
        updateBlink(p, now)
        if (nextAt == 0L) nextAt = now + 2500L
        if (cur >= 0 && !quieto && !cortando) { cortando = true; cortaDesde = now }
        if (cur < 0) {
            if (!quieto || now < nextAt) return
            var pick = rnd.nextInt(3)
            if (pick == last) pick = (pick + 1 + rnd.nextInt(2)) % 3
            cur = pick; last = pick; start = now; cortando = false
            lado = if (rnd.nextBoolean()) 1f else -1f
        }
        val dur = when (cur) { 0 -> 4400f; 1 -> 3400f; else -> 3600f }
        val t = ((now - start) / dur).coerceIn(0f, 1f)
        var w = 1f
        if (cortando) w = 1f - ((now - cortaDesde) / 350f).coerceIn(0f, 1f)
        when (cur) {
            0 -> abrazo(p, t, w)
            1 -> bostezo(p, t, w)
            else -> senalar(p, t, w)
        }
        if (t >= 1f || w <= 0f) {
            cur = -1; cortando = false
            nextAt = now + 4000L + rnd.nextInt(7000)
        }
    }

    /** 1. Estirarse y abrazar: abre los brazos a los lados (estira) y los lleva hacia el frente rodeando; luego los suelta. */
    private fun abrazo(p: Pose, t: Float, w: Float) {
        val s1 = sm(t / 0.28f)
        val s2 = sm((t - 0.40f) / 0.25f)
        val s3 = sm((t - 0.80f) / 0.20f)
        val abre = s1 * (1f - s2 * 0.55f) * (1f - s3)
        val cierra = s2 * (1f - s3)
        val abd = 80f * abre
        val bar = 62f * cierra
        p.laz = -abd * w; p.raz = abd * w
        p.lay = bar * w; p.ray = -bar * w
        p.headP = 6f * cierra * w
        p.bodyPitch = 0.07f * (s1 * (1f - s3) + cierra) * w * 0.5f
    }

    /** 2. Bostezar: inclina la cabeza hacia atrás y de lado, y sube un brazo hacia la cabeza. */
    private fun bostezo(p: Pose, t: Float, w: Float) {
        val a = sm(t / 0.30f) * (1f - sm((t - 0.75f) / 0.25f))
        p.rax = -100f * a * w; p.raz = -20f * a * w
        p.headP = (-12f + 3f * sin(2f * PI.toFloat() * t * 2f)) * a * w
        p.headR = 7f * a * w
    }

    /** 3. Señalar: gira el cuerpo hacia un lado y levanta ese brazo apuntando en esa dirección. */
    private fun senalar(p: Pose, t: Float, w: Float) {
        val a = sm(t / 0.28f) * (1f - sm((t - 0.78f) / 0.22f))
        val pulso = 6f * a * sin(2f * PI.toFloat() * 3f * t)
        val ax = -28f * a
        val az = (72f * a + pulso) * lado
        if (lado > 0f) { p.rax = ax * w; p.raz = az * w } else { p.lax = ax * w; p.laz = az * w }
        p.bodyYaw = 0.5f * lado * a * w
        p.headY = 14f * lado * a * w
    }

    /** 5. Parpadeo: cierra y abre el ojo rojo, de forma ocasional y breve. */
    private fun updateBlink(p: Pose, now: Long) {
        if (blinkAt == 0L) blinkAt = now + 1800L
        if (now >= blinkAt) { blinkStart = now; blinkAt = now + 2800L + rnd.nextInt(4500) }
        if (blinkStart >= 0L) {
            val dt = (now - blinkStart) / 230f
            if (dt < 1f) p.eyeOpen = 1f - 0.92f * sin(PI.toFloat() * dt) else blinkStart = -1L
        }
    }
}
