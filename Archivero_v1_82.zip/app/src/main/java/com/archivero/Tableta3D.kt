package com.archivero

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader

/*
 * La tableta digital en 3D de verdad, dibujada con código (sin librerías 3D). La geometría, la luz y el reflejo del vidrio
 * los calcula TabletaMotor (TabletaModelo.kt); la imagen de la pantalla la dibuja TabletaPantalla (TabletaPantalla.kt).
 * Aquí solo se ejecuta el plan de dibujo del motor:
 *   - triángulos de color con luz y brillo metálico (una sola llamada a drawVertices por tanda),
 *   - el vidrio y la espalda como mallas con textura (drawBitmapMesh), con el reflejo encima,
 *   - un borde suave oscuro y un resplandor detrás que se enciende al cargar.
 * Gira a cualquier ángulo (yaw, pitch, roll sin tope). Al terminar, llamar a [liberar].
 */
internal class Tableta3D {
    private val m = TabletaModelo.obtener()
    private val motor = TabletaMotor(m)
    private val pantalla = TabletaPantalla()
    private val espalda: Bitmap = TabletaEspalda.crear()
    private var activo = true

    private val solidoP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
    private val mallaP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val bordeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL_AND_STROKE; strokeJoin = Paint.Join.ROUND; color = 0xFF080A0F.toInt() }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ledP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloMat = Matrix()
    private val haloShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(0xCC6FD9FF.toInt(), 0x556FD9FF, 0x006FD9FF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )
    private val casco = Path()

    /** Suelta los mapas de bits. Después de esto, draw() no hace nada. */
    fun liberar() {
        if (!activo) return
        activo = false
        pantalla.liberar()
        if (!espalda.isRecycled) espalda.recycle()
    }

    /**
     * Dibuja la tableta centrada en (cx, cy). [scale] = píxeles por unidad del modelo (alto total ≈ 4.2 unidades).
     * [yaw]/[pitch]/[roll] en radianes. [ahora] = reloj (uptimeMillis). [carga] = ms desde que se tocó (-1 = reposo).
     * [glowK] = brillo extra de las luces (1 = normal).
     */
    fun draw(c: Canvas, cx: Float, cy: Float, scale: Float, yaw: Float, pitch: Float, roll: Float, ahora: Long, carga: Long, glowK: Float) {
        if (!activo) return
        val pul = DronNeon.pulso()
        val k = glowK * (if (pul < 0f) 1f else 0.60f + 0.90f * pul)
        pantalla.actualizar(ahora, carga)
        motor.ledRgb = when (DronNeon.modo) { 1 -> 0x38FF57; 2 -> 0xA45CFF; else -> TCol.TEAL }
        motor.calcular(cx, cy, scale, yaw, pitch, roll, k)

        // Resplandor detrás: tenue en reposo, fuerte mientras carga (la pantalla ilumina alrededor)
        val d = TabletaCarga.DURACION_MS
        val e = d + TabletaCarga.EXITO_MS
        var luz = 0.10f
        if (carga in 0 until d) luz = 0.22f + 0.10f * kotlin.math.sin(carga / 170f)
        else if (carga in d until e) luz = 0.34f
        if (pul >= 0f) luz += 0.18f * pul
        val hr = scale * 3.1f
        haloMat.setScale(hr, hr); haloMat.postTranslate(cx, cy)
        haloShader.setLocalMatrix(haloMat)
        haloP.shader = haloShader
        haloP.alpha = (luz.coerceIn(0f, 0.7f) * 255f).toInt()
        c.drawCircle(cx, cy, hr, haloP)

        // Borde oscuro suave (respaldo del contorno, con borde antialias)
        val n = motor.nhull
        if (n >= 3) {
            casco.reset()
            casco.moveTo(motor.hull[0], motor.hull[1])
            for (i in 1 until n) casco.lineTo(motor.hull[2 * i], motor.hull[2 * i + 1])
            casco.close()
            bordeP.strokeWidth = (scale * 0.030f).coerceAtLeast(1.4f)
            c.drawPath(casco, bordeP)
        }

        // Plan de dibujo
        for (i in 0 until motor.ncmd) {
            val tipo = motor.cmd[3 * i]
            val a = motor.cmd[3 * i + 1]
            val b = motor.cmd[3 * i + 2]
            if (tipo == 0) {
                c.drawVertices(Canvas.VertexMode.TRIANGLES, m.nv * 2, motor.scr, 0, null, 0, motor.col, 0, motor.sidx, a, b, solidoP)
            } else {
                val p = m.piezas[a]
                val bmp = if (b == 0) pantalla.bitmap else espalda
                if (!bmp.isRecycled) c.drawBitmapMesh(bmp, p.mw, p.mh, motor.scr, 2 * p.v0, motor.col, p.v0, mallaP)
            }
        }

        // Resplandor del LED (se ve cuando el frente mira a la cámara)
        if (motor.ledVisible) {
            val rgb = motor.ledRgb and 0xFFFFFF
            val f = (0.55f * k).coerceIn(0.15f, 1f)
            val r = scale * 0.11f
            ledP.color = ((0.12f * f * 255f).toInt() shl 24) or rgb
            c.drawCircle(motor.ledX, motor.ledY, r * 2.6f, ledP)
            ledP.color = ((0.22f * f * 255f).toInt() shl 24) or rgb
            c.drawCircle(motor.ledX, motor.ledY, r * 1.6f, ledP)
            ledP.color = ((0.40f * f * 255f).toInt() shl 24) or rgb
            c.drawCircle(motor.ledX, motor.ledY, r * 0.9f, ledP)
        }
    }
}
