package com.archivero

import android.graphics.Canvas
import kotlin.math.min

/*
 * Aspecto del amigo flotante (fuera de la app): la tableta 3D de Tableta3D.kt. Esta clase solo la coloca y la escala dentro de su
 * ventana; el giro lo mueve el controlador de Seguir.kt y la pantalla (reloj, carga de 3 s) la dibuja TabletaPantalla.kt.
 */
internal class AmigoArte {
    private val tableta = Tableta3D()
    private var escala = 1f

    fun size(w: Int, h: Int) {
        escala = min(w, h) / 2f / 2.55f          // la tableta mide ~4.2 unidades de alto; así cabe entera con margen
    }

    /** [carga] = ms desde que se tocó la tableta (-1 = reposo). */
    fun draw(c: Canvas, w: Int, h: Int, yaw: Float, pitch: Float, roll: Float, grow: Float, ahora: Long, carga: Long, glowK: Float) {
        tableta.draw(c, w / 2f, h / 2f, escala * grow, yaw, pitch, roll, ahora, carga, glowK)
    }

    /** Suelta los mapas de bits (al quitar la tableta de la pantalla). */
    fun liberar() = tableta.liberar()
}
