package com.archivero

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/*
 * La tableta digital en 3D (geometría y matemática de dibujo). Este archivo NO usa nada de Android: solo números,
 * así se puede probar fuera del teléfono. Tableta3D.kt es quien pinta lo que sale de aquí.
 *
 * Modelo (unidades arbitrarias, la pantalla mira a +Z, +X a la derecha, +Y arriba):
 *   - Cuerpo: placa de 3.2 × 4.2 × 0.46 con esquinas cortadas y biseles.
 *   - Frente: marco negro de la pantalla, vidrio (malla con la textura de la pantalla), capa de reflejo con transparencia,
 *     soportes blindados grises con ranuras de ventilación y LED, pestaña amarilla.
 *   - Lados: botón amarillo, dos botones negros, tiras azules de luz.
 *   - Espalda: placa con panel de hexágonos (malla con textura), cámara, esquineros amarillos, tornillos y ranuras.
 * Todas las piezas son prismas convexos con bisel; se dibujan de lejos a cerca por "paredes" (ver [TabletaMotor.calcular]).
 */

internal object TCol {
    const val CUERPO_FRENTE = 0x6A717B
    const val CUERPO_ATRAS = 0x24272D
    const val CUERPO_BISEL = 0xBFC6D0
    const val CUERPO_LADO = 0x3A3F47
    const val NEGRO = 0x14171C
    const val NEGRO_BISEL = 0x4A525C
    const val NEGRO_LADO = 0x0C0E11
    const val GRIS = 0x9CA3AD
    const val GRIS_BISEL = 0xDDE2E8
    const val GRIS_LADO = 0x4B5159
    const val AMARILLO = 0xFFB21E
    const val AMARILLO_BISEL = 0xFFE08A
    const val AMARILLO_LADO = 0xB86F08
    const val AZUL = 0x3A86FF
    const val TEAL = 0x3DF2DC
    const val RANURA = 0x0F1114
    const val PLATA = 0x7D848E
}

/** Una pieza dibujable: tipo 0 = triángulos de color, 1 = malla con textura (vidrio / espalda), 2 = reflejo (triángulos con transparencia). */
internal class TPieza(
    val tipo: Int,
    val pared: Int,          // -1 = cuerpo; 0..5 = pegada a la pared +X, -X, +Y, -Y, +Z (frente), -Z (espalda)
    val v0: Int, val nvv: Int,
    val t0: Int, val nt: Int,
    val tex: Int,            // 0 = pantalla, 1 = espalda (solo tipo 1)
    val mw: Int, val mh: Int // celdas de la malla (solo tipo 1 y 2)
)

internal class TabletaModelo(
    val nv: Int,
    val px: FloatArray, val py: FloatArray, val pz: FloatArray,
    val nx: FloatArray, val ny: FloatArray, val nz: FloatArray,
    val col: IntArray, val brillo: FloatArray, val emis: FloatArray,
    val nt: Int, val tri: ShortArray,
    val piezas: Array<TPieza>
) {
    companion object {
        const val PARED_CUERPO = -1
        const val PX = 0; const val NX = 1; const val PY = 2; const val NY = 3; const val PZ = 4; const val NZ = 5
        // Tamaño de la tableta.
        const val ANCHO = 3.2f
        const val ALTO = 4.2f
        const val GROSOR = 0.46f
        // Vidrio de la pantalla.
        const val PAN_X0 = -1.30f; const val PAN_X1 = 1.30f
        const val PAN_Y0 = -1.86f; const val PAN_Y1 = 1.78f
        const val PAN_Z = 0.253f
        const val MALLA_W = 8
        const val MALLA_H = 10
        // Panel de hexágonos de la espalda (en coordenadas locales de la espalda).
        const val ESP_X = 0.92f
        const val ESP_Y = 1.36f
        // LED del soporte de arriba (para el resplandor).
        const val LED_X = 1.30f
        const val LED_Y = 1.83f
        const val LED_Z = 0.31f

        @Volatile private var cache: TabletaModelo? = null

        fun obtener(): TabletaModelo {
            cache?.let { return it }
            synchronized(this) {
                cache?.let { return it }
                val m = Constructor().construir()
                cache = m
                return m
            }
        }
    }
}

// ───────────────────────── Construcción ─────────────────────────

private class Constructor {
    private var n = 0
    private var X = FloatArray(2048); private var Y = FloatArray(2048); private var Z = FloatArray(2048)
    private var NX = FloatArray(2048); private var NY = FloatArray(2048); private var NZ = FloatArray(2048)
    private var C = IntArray(2048); private var BR = FloatArray(2048); private var EM = FloatArray(2048)
    private var nt = 0
    private var T = ShortArray(3 * 4096)
    private val piezas = ArrayList<TPieza>()

    // Lugar actual: punto local (x, y, z) → origen + x·ex + y·ey + z·ez.
    private var ox = 0f; private var oy = 0f; private var oz = 0f
    private var ex = floatArrayOf(1f, 0f, 0f)
    private var ey = floatArrayOf(0f, 1f, 0f)
    private var ez = floatArrayOf(0f, 0f, 1f)

    private fun lugar(x: Float, y: Float, z: Float, a: FloatArray, b: FloatArray, c: FloatArray) {
        ox = x; oy = y; oz = z; ex = a; ey = b; ez = c
    }

    private fun crecer() {
        val s = X.size * 2
        X = X.copyOf(s); Y = Y.copyOf(s); Z = Z.copyOf(s)
        NX = NX.copyOf(s); NY = NY.copyOf(s); NZ = NZ.copyOf(s)
        C = C.copyOf(s); BR = BR.copyOf(s); EM = EM.copyOf(s)
    }

    /** Vértice en coordenadas locales, con su normal local. */
    private fun v(lx: Float, ly: Float, lz: Float, nlx: Float, nly: Float, nlz: Float, color: Int, brillo: Float, emis: Float): Int {
        if (n >= X.size) crecer()
        val i = n++
        X[i] = ox + lx * ex[0] + ly * ey[0] + lz * ez[0]
        Y[i] = oy + lx * ex[1] + ly * ey[1] + lz * ez[1]
        Z[i] = oz + lx * ex[2] + ly * ey[2] + lz * ez[2]
        val l = sqrt(nlx * nlx + nly * nly + nlz * nlz).let { if (it < 1e-6f) 1f else it }
        val ax = nlx / l; val ay = nly / l; val az = nlz / l
        NX[i] = ax * ex[0] + ay * ey[0] + az * ez[0]
        NY[i] = ax * ex[1] + ay * ey[1] + az * ez[1]
        NZ[i] = ax * ex[2] + ay * ey[2] + az * ez[2]
        C[i] = color; BR[i] = brillo; EM[i] = emis
        return i
    }

    /** Triángulo orientado para que su cara mire hacia donde apunta la normal del primer vértice. */
    private fun tri(a: Int, b: Int, c: Int) {
        if ((nt + 1) * 3 > T.size) T = T.copyOf(T.size * 2)
        val ux = X[b] - X[a]; val uy = Y[b] - Y[a]; val uz = Z[b] - Z[a]
        val wx = X[c] - X[a]; val wy = Y[c] - Y[a]; val wz = Z[c] - Z[a]
        val cx = uy * wz - uz * wy; val cy = uz * wx - ux * wz; val cz = ux * wy - uy * wx
        val flip = cx * NX[a] + cy * NY[a] + cz * NZ[a] < 0f
        T[nt * 3] = a.toShort()
        T[nt * 3 + 1] = (if (flip) c else b).toShort()
        T[nt * 3 + 2] = (if (flip) b else c).toShort()
        nt++
    }

    private fun quad(a: Int, b: Int, c: Int, d: Int) { tri(a, b, c); tri(a, c, d) }

    // ───── Polígonos ─────

    /** Rectángulo con esquinas cortadas (sentido antihorario). Esquinas: arriba-izq, arriba-der, abajo-der, abajo-izq. */
    private fun rect(cx: Float, cy: Float, w: Float, h: Float, tl: Float, tr: Float, br: Float, bl: Float): FloatArray {
        val x0 = cx - w / 2f; val x1 = cx + w / 2f; val y0 = cy - h / 2f; val y1 = cy + h / 2f
        val p = ArrayList<Float>(16)
        fun add(x: Float, y: Float) {
            val k = p.size
            if (k >= 2 && abs(p[k - 2] - x) < 1e-5f && abs(p[k - 1] - y) < 1e-5f) return
            p.add(x); p.add(y)
        }
        add(x0 + bl, y0); add(x1 - br, y0)
        add(x1, y0 + br); add(x1, y1 - tr)
        add(x1 - tr, y1); add(x0 + tl, y1)
        add(x0, y1 - tl); add(x0, y0 + bl)
        // el último puede repetir al primero
        if (p.size >= 4 && abs(p[p.size - 2] - p[0]) < 1e-5f && abs(p[p.size - 1] - p[1]) < 1e-5f) { p.removeAt(p.size - 1); p.removeAt(p.size - 1) }
        return p.toFloatArray()
    }

    private fun rect(cx: Float, cy: Float, w: Float, h: Float, c: Float): FloatArray = rect(cx, cy, w, h, c, c, c, c)

    private fun poli(cx: Float, cy: Float, r: Float, lados: Int, rot: Float): FloatArray {
        val p = FloatArray(lados * 2)
        for (i in 0 until lados) {
            val a = rot + i * 6.2831855f / lados
            p[2 * i] = cx + r * kotlin.math.cos(a)
            p[2 * i + 1] = cy + r * kotlin.math.sin(a)
        }
        return p
    }

    /** Polígono convexo encogido [d] hacia adentro. */
    private fun inset(p: FloatArray, d: Float): FloatArray {
        val k = p.size / 2
        val o = FloatArray(p.size)
        for (i in 0 until k) {
            val a = (i + k - 1) % k; val b = (i + 1) % k
            // normales salientes de la arista anterior y la siguiente
            var n1x = p[2 * i + 1] - p[2 * a + 1]; var n1y = -(p[2 * i] - p[2 * a])
            var l = sqrt(n1x * n1x + n1y * n1y); n1x /= l; n1y /= l
            var n2x = p[2 * b + 1] - p[2 * i + 1]; var n2y = -(p[2 * b] - p[2 * i])
            l = sqrt(n2x * n2x + n2y * n2y); n2x /= l; n2y /= l
            val den = 1f + n1x * n2x + n1y * n2y
            o[2 * i] = p[2 * i] - d * (n1x + n2x) / den
            o[2 * i + 1] = p[2 * i + 1] - d * (n1y + n2y) / den
        }
        return o
    }

    /**
     * Prisma convexo con bisel: tapa de arriba (z1) encogida [b], anillo de bisel, pared hasta z0 (o hasta z0+b y otro bisel
     * si [abajo]) y, si [abajo], la tapa de abajo. [p] va en sentido antihorario.
     */
    private fun prisma(
        p: FloatArray, z0: Float, z1: Float, b: Float,
        cCap: Int, cBis: Int, cPared: Int, brBis: Float, abajo: Boolean, cAbajo: Int = cCap
    ) {
        val k = p.size / 2
        val q = inset(p, b)
        // tapa de arriba
        val top = IntArray(k) { v(q[2 * it], q[2 * it + 1], z1, 0f, 0f, 1f, cCap, 0.18f, 0f) }
        for (i in 1 until k - 1) tri(top[0], top[i], top[i + 1])
        val zb = z1 - b
        val zw = if (abajo) z0 + b else z0
        for (i in 0 until k) {
            val j = (i + 1) % k
            var nx = p[2 * j + 1] - p[2 * i + 1]; var ny = -(p[2 * j] - p[2 * i])
            val l = sqrt(nx * nx + ny * ny); nx /= l; ny /= l
            // bisel de arriba
            val a = v(q[2 * i], q[2 * i + 1], z1, nx, ny, 1f, cBis, brBis, 0f)
            val bb = v(q[2 * j], q[2 * j + 1], z1, nx, ny, 1f, cBis, brBis, 0f)
            val c = v(p[2 * j], p[2 * j + 1], zb, nx, ny, 1f, cBis, brBis, 0f)
            val d = v(p[2 * i], p[2 * i + 1], zb, nx, ny, 1f, cBis, brBis, 0f)
            quad(a, bb, c, d)
            // pared
            if (zb - zw > 1e-4f) {
                val w0 = v(p[2 * i], p[2 * i + 1], zb, nx, ny, 0f, cPared, 0.30f, 0f)
                val w1 = v(p[2 * j], p[2 * j + 1], zb, nx, ny, 0f, cPared, 0.30f, 0f)
                val w2 = v(p[2 * j], p[2 * j + 1], zw, nx, ny, 0f, cPared, 0.30f, 0f)
                val w3 = v(p[2 * i], p[2 * i + 1], zw, nx, ny, 0f, cPared, 0.30f, 0f)
                quad(w0, w1, w2, w3)
            }
            if (abajo) {
                val e0 = v(p[2 * i], p[2 * i + 1], zw, nx, ny, -1f, cBis, brBis * 0.6f, 0f)
                val e1 = v(p[2 * j], p[2 * j + 1], zw, nx, ny, -1f, cBis, brBis * 0.6f, 0f)
                val e2 = v(q[2 * j], q[2 * j + 1], z0, nx, ny, -1f, cBis, brBis * 0.6f, 0f)
                val e3 = v(q[2 * i], q[2 * i + 1], z0, nx, ny, -1f, cBis, brBis * 0.6f, 0f)
                quad(e0, e1, e2, e3)
            }
        }
        if (abajo) {
            val bot = IntArray(k) { v(q[2 * it], q[2 * it + 1], z0, 0f, 0f, -1f, cAbajo, 0.12f, 0f) }
            for (i in 1 until k - 1) tri(bot[0], bot[i], bot[i + 1])
        }
    }

    /** Polígono convexo plano a la altura [z] (ranuras, LED, calcomanías). */
    private fun plano(p: FloatArray, z: Float, color: Int, brillo: Float, emis: Float) {
        val k = p.size / 2
        val ids = IntArray(k) { v(p[2 * it], p[2 * it + 1], z, 0f, 0f, 1f, color, brillo, emis) }
        for (i in 1 until k - 1) tri(ids[0], ids[i], ids[i + 1])
    }

    /** Paralelogramo (ranura inclinada). */
    private fun ranura(cx: Float, cy: Float, w: Float, h: Float, inclina: Float, z: Float, color: Int = TCol.RANURA) {
        val hw = w / 2f; val hh = h / 2f
        plano(floatArrayOf(cx - hw - inclina, cy - hh, cx + hw - inclina, cy - hh, cx + hw + inclina, cy + hh, cx - hw + inclina, cy + hh), z, color, 0.05f, 0f)
    }

    /** Rejilla (malla) de (mw+1)·(mh+1) vértices en el plano z, fila 0 = arriba. Con [triangulos] también se arman sus triángulos. */
    private fun rejilla(x0: Float, y0: Float, x1: Float, y1: Float, z: Float, mw: Int, mh: Int, color: Int, brillo: Float, emis: Float, triangulos: Boolean) {
        val base = n
        for (j in 0..mh) for (i in 0..mw) {
            val x = x0 + (x1 - x0) * i / mw
            val y = y1 - (y1 - y0) * j / mh
            v(x, y, z, 0f, 0f, 1f, color, brillo, emis)
        }
        if (triangulos) {
            for (j in 0 until mh) for (i in 0 until mw) {
                val a = base + j * (mw + 1) + i
                quad(a, a + 1, a + mw + 2, a + mw + 1)
            }
        }
    }

    private inline fun pieza(tipo: Int, pared: Int, tex: Int = 0, mw: Int = 0, mh: Int = 0, bloque: () -> Unit) {
        val v0 = n; val t0 = nt
        bloque()
        piezas.add(TPieza(tipo, pared, v0, n - v0, t0, nt - t0, tex, mw, mh))
    }

    // ───── El modelo ─────

    fun construir(): TabletaModelo {
        val id = Triple(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f))
        val hz = TabletaModelo.GROSOR / 2f          // 0.23
        val ancho = TabletaModelo.ANCHO; val alto = TabletaModelo.ALTO
        val mw = TabletaModelo.MALLA_W; val mh = TabletaModelo.MALLA_H

        // ── Cuerpo ──
        lugar(0f, 0f, 0f, id.first, id.second, id.third)
        pieza(0, TabletaModelo.PARED_CUERPO) {
            prisma(
                rect(0f, 0f, ancho, alto, 0.34f), -hz, hz, 0.06f,
                TCol.CUERPO_FRENTE, TCol.CUERPO_BISEL, TCol.CUERPO_LADO, 0.95f, true, TCol.CUERPO_ATRAS
            )
        }

        // ── Frente (pared +Z) ──
        val zf = hz - 0.005f
        pieza(0, TabletaModelo.PZ) {
            // marco negro de la pantalla
            prisma(rect(0f, -0.04f, 2.86f, 3.90f, 0.18f), zf, 0.25f, 0.012f, TCol.NEGRO, TCol.NEGRO_BISEL, TCol.NEGRO_LADO, 0.55f, false)
        }
        // vidrio (malla con la textura de la pantalla) y su reflejo
        val sx0 = TabletaModelo.PAN_X0; val sx1 = TabletaModelo.PAN_X1; val sy0 = TabletaModelo.PAN_Y0; val sy1 = TabletaModelo.PAN_Y1
        pieza(1, TabletaModelo.PZ, 0, mw, mh) { rejilla(sx0, sy0, sx1, sy1, TabletaModelo.PAN_Z, mw, mh, 0xFFFFFF, 0f, 1f, false) }
        pieza(2, TabletaModelo.PZ, 0, mw, mh) { rejilla(sx0, sy0, sx1, sy1, TabletaModelo.PAN_Z + 0.0015f, mw, mh, 0xFFFFFF, 0f, 1f, true) }
        // soportes blindados y detalles
        val zt = 0.305f
        val bis = 0.022f
        pieza(0, TabletaModelo.PZ) {
            fun placa(p: FloatArray) = prisma(p, zf, zt, bis, TCol.GRIS, TCol.GRIS_BISEL, TCol.GRIS_LADO, 0.9f, false)
            // arriba a la derecha: barra con ranuras y LED + brazo vertical
            placa(rect(0.80f, 1.83f, 1.46f, 0.44f, 0.12f, 0.30f, 0f, 0.12f))
            placa(rect(1.365f, 1.11f, 0.33f, 0.98f, 0f, 0f, 0.10f, 0.10f))
            // abajo a la derecha
            placa(rect(0.715f, -1.85f, 1.63f, 0.40f, 0.12f, 0f, 0.30f, 0f))
            placa(rect(1.365f, -1.12f, 0.33f, 1.04f, 0.10f, 0.10f, 0f, 0f))
            // arriba a la izquierda
            placa(rect(-0.54f, 1.855f, 0.92f, 0.39f, 0.12f, 0.12f, 0f, 0.12f))
            placa(rect(-1.33f, -1.675f, 0.40f, 0.75f, 0.10f, 0f, 0f, 0.30f))
            placa(rect(-0.60f, -1.885f, 0.80f, 0.33f, 0.10f, 0.10f, 0f, 0f))
            // pestaña amarilla de la esquina
            prisma(rect(-1.325f, 1.895f, 0.42f, 0.31f, 0.25f, 0f, 0f, 0f), zf, 0.295f, 0.018f, TCol.AMARILLO, TCol.AMARILLO_BISEL, TCol.AMARILLO_LADO, 0.9f, false)
            val zr = zt + 0.002f
            // ranuras de ventilación (///)
            for (k in 0 until 3) ranura(0.22f + k * 0.14f, 1.83f, 0.045f, 0.22f, 0.05f, zr)
            // ranuras horizontales del soporte de abajo
            for (k in 0 until 3) ranura(1.365f, -0.80f - k * 0.15f, 0.20f, 0.034f, 0f, zr)
            // ranuras del soporte de arriba a la izquierda
            for (k in 0 until 2) ranura(-0.78f + k * 0.16f, 1.855f, 0.05f, 0.20f, 0.04f, zr)
            // triangulito de marca abajo
            plano(floatArrayOf(0.35f, -1.93f, 0.50f, -1.93f, 0.425f, -1.80f), zr, TCol.RANURA, 0.05f, 0f)
            // LED teal (octágono) con aro oscuro
            plano(poli(1.30f, 1.83f, 0.062f, 8, 0.3927f), zr, TCol.RANURA, 0.05f, 0f)
            plano(poli(1.30f, 1.83f, 0.042f, 8, 0.3927f), zr + 0.001f, TCol.TEAL, 0f, 1f)
            // tornillos del marco (dos por lado, hexágonos chiquitos)
            for (sxs in floatArrayOf(-1f, 1f)) for (sys in floatArrayOf(-0.35f, 0.35f)) {
                plano(poli(sxs * 1.475f, sys, 0.028f, 6, 0f), 0.2315f, TCol.PLATA, 0.7f, 0f)
            }
        }

        // ── Lado derecho (pared +X): botón amarillo ──
        lugar(ancho / 2f, 0f, 0f, floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(1f, 0f, 0f))
        pieza(0, TabletaModelo.PX) {
            prisma(rect(1.03f, 0f, 0.58f, 0.20f, 0.05f), -0.03f, 0.075f, 0.02f, TCol.AMARILLO, TCol.AMARILLO_BISEL, TCol.AMARILLO_LADO, 0.9f, false)
            // segundo botón más chico, gris
            prisma(rect(0.30f, 0f, 0.26f, 0.15f, 0.04f), -0.03f, 0.05f, 0.015f, TCol.GRIS, TCol.GRIS_BISEL, TCol.GRIS_LADO, 0.9f, false)
        }

        // ── Lado izquierdo (pared -X): dos botones negros y una tira azul de luz ──
        lugar(-ancho / 2f, 0f, 0f, floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 1f, 0f), floatArrayOf(-1f, 0f, 0f))
        pieza(0, TabletaModelo.NX) {
            for (y in floatArrayOf(0.74f, 0.48f)) {
                prisma(rect(0f, y, 0.22f, 0.13f, 0.03f), -0.03f, 0.21f, 0.025f, 0x2B2F36, 0x666E79, TCol.NEGRO, 0.8f, false)
            }
            // tira azul emisiva (un poco salida de la pared)
            plano(rect(0f, -0.28f, 0.20f, 0.95f, 0.04f), 0.004f, TCol.AZUL, 0.3f, 1f)
        }

        // ── Lado de abajo (pared -Y): tira azul ──
        lugar(0f, -alto / 2f, 0f, floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, -1f, 0f))
        pieza(0, TabletaModelo.NY) {
            plano(rect(-0.3f, 0f, 1.5f, 0.20f, 0.04f), 0.004f, TCol.AZUL, 0.3f, 1f)
        }

        // ── Lado de arriba (pared +Y): dos ranuras ──
        lugar(0f, alto / 2f, 0f, floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 0f, -1f), floatArrayOf(0f, 1f, 0f))
        pieza(0, TabletaModelo.PY) {
            plano(rect(-0.55f, 0f, 0.5f, 0.07f, 0.02f), 0.004f, TCol.RANURA, 0.05f, 0f)
            plano(rect(0.25f, 0f, 0.5f, 0.07f, 0.02f), 0.004f, TCol.RANURA, 0.05f, 0f)
        }

        // ── Espalda (pared -Z) ── (x mirando a la izquierda del modelo para que se lea sin espejo al darle la vuelta)
        lugar(0f, 0f, -hz, floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, -1f))
        val zb = -0.005f
        pieza(0, TabletaModelo.NZ) {
            // placa trasera con borde plateado
            prisma(rect(0f, 0f, 2.72f, 3.72f, 0.26f), zb, 0.045f, 0.02f, 0x30343B, 0xAFB6C0, 0x1B1D22, 0.9f, false)
            // marco interior del panel de hexágonos
            prisma(rect(0f, 0f, 2.0f, 2.84f, 0.30f), 0.04f, 0.062f, 0.01f, 0x1D2025, 0x8D949E, 0x15171B, 0.8f, false)
        }
        pieza(1, TabletaModelo.NZ, 1, 4, 4) {
            rejilla(-TabletaModelo.ESP_X, -TabletaModelo.ESP_Y, TabletaModelo.ESP_X, TabletaModelo.ESP_Y, 0.0635f, 4, 4, 0xFFFFFF, 0.35f, 0f, false)
        }
        pieza(0, TabletaModelo.NZ) {
            // esquineros amarillos
            for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) {
                val tl = if (sx < 0f && sy > 0f) 0.20f else 0f
                val tr = if (sx > 0f && sy > 0f) 0.20f else 0f
                val br = if (sx > 0f && sy < 0f) 0.20f else 0f
                val bl = if (sx < 0f && sy < 0f) 0.20f else 0f
                prisma(rect(sx * 1.17f, sy * 1.72f, 0.56f, 0.42f, tl, tr, br, bl), zb, 0.085f, 0.022f, TCol.AMARILLO, TCol.AMARILLO_BISEL, TCol.AMARILLO_LADO, 0.9f, false)
            }
            // cámara: aro con vidrio oscuro
            prisma(poli(0.55f, 1.62f, 0.17f, 8, 0.3927f), 0.04f, 0.10f, 0.02f, 0x20242A, 0xB5BCC6, 0x12141A, 0.95f, false)
            plano(poli(0.55f, 1.62f, 0.095f, 8, 0.3927f), 0.1015f, 0x0A1E55, 0.9f, 0.55f)
            plano(poli(0.52f, 1.65f, 0.025f, 6, 0f), 0.1025f, 0xBFD8FF, 0f, 1f)
            // flash
            prisma(poli(0.05f, 1.62f, 0.07f, 8, 0.3927f), 0.04f, 0.075f, 0.012f, 0xE9E3C8, 0xFFFFFF, 0x6D6A5A, 0.8f, false)
            // ranuras de ventilación a los lados de arriba y abajo
            for (k in 0 until 3) {
                ranura(-0.95f + k * 0.12f, 1.62f, 0.04f, 0.2f, 0.04f, 0.0475f)
                ranura(0.95f - k * 0.12f, -1.62f, 0.04f, 0.2f, 0.04f, 0.0475f)
            }
            // tornillos
            for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) {
                prisma(poli(sx * 1.08f, sy * 1.45f, 0.04f, 6, 0f), 0.04f, 0.062f, 0.006f, TCol.PLATA, 0xDCE0E6, 0x2A2D33, 0.9f, false)
                prisma(poli(sx * 1.08f, sy * 0.00f, 0.04f, 6, 0f), 0.04f, 0.062f, 0.006f, TCol.PLATA, 0xDCE0E6, 0x2A2D33, 0.9f, false)
            }
        }

        return TabletaModelo(
            n, X.copyOf(n), Y.copyOf(n), Z.copyOf(n), NX.copyOf(n), NY.copyOf(n), NZ.copyOf(n),
            C.copyOf(n), BR.copyOf(n), EM.copyOf(n), nt, T.copyOf(nt * 3), piezas.toTypedArray()
        )
    }
}

// ───────────────────────── Motor de dibujo ─────────────────────────

/**
 * Gira la tableta, la proyecta, la ilumina y arma el "plan de dibujo": una lista de órdenes ([cmd]) que Tableta3D.kt ejecuta tal cual.
 *  - orden 0 = triángulos de color: (0, primerIndice, cantidad) sobre [sidx]
 *  - orden 1 = malla con textura: (1, indiceDePieza, textura)
 * Orden de dibujo: primero lo pegado a paredes que miran hacia atrás, luego el cuerpo y al final lo pegado a paredes que miran
 * a la cámara (en el orden en que está en el modelo: marco, vidrio, reflejo, soportes…). Con piezas convexas esto evita ordenar triángulos.
 */
internal class TabletaMotor(val m: TabletaModelo) {
    companion object {
        const val FOCAL = 9f
        // Luces (en el espacio de la cámara; +Z hacia quien mira).
        private const val L1X = -0.5163f; private const val L1Y = 0.7112f; private const val L1Z = 0.4731f   // principal: arriba a la izquierda
        private const val L2X = 0.7390f; private const val L2Y = -0.2842f; private const val L2Z = 0.6125f   // relleno: abajo a la derecha
    }

    val scr = FloatArray(m.nv * 2)
    val col = IntArray(m.nv)
    val sidx = ShortArray(m.nt * 3)
    val cmd = IntArray(3 * (m.piezas.size + 8))
    var ncmd = 0
    var nidx = 0
    /** Contorno (casco convexo) del cuerpo en pantalla, para la sombra/borde suave. */
    val hull = FloatArray(2 * 64)
    var nhull = 0

    private val wx = FloatArray(m.nv); private val wy = FloatArray(m.nv); private val wz = FloatArray(m.nv)
    private val g = FloatArray(9)
    private val a = FloatArray(9); private val b = FloatArray(9); private val c = FloatArray(9)
    private val caraCamara = BooleanArray(6)
    private val hx = FloatArray(m.nv.coerceAtMost(512)); private val hy = FloatArray(m.nv.coerceAtMost(512))
    /** Normal del vidrio ya girada (la usa el reflejo y la pantalla). */
    var normalVidrioZ = 1f; private set
    /** Color (RGB) del LED del soporte; Tableta3D lo cambia según el modo de luces. */
    var ledRgb = TCol.TEAL
    /** Dónde cae el LED en pantalla y si se ve (mira a la cámara). */
    var ledX = 0f; var ledY = 0f; var ledVisible = false; private set

    private fun rotX(t: Float, o: FloatArray) { val cs = kotlin.math.cos(t); val sn = kotlin.math.sin(t); o[0] = 1f; o[1] = 0f; o[2] = 0f; o[3] = 0f; o[4] = cs; o[5] = -sn; o[6] = 0f; o[7] = sn; o[8] = cs }
    private fun rotY(t: Float, o: FloatArray) { val cs = kotlin.math.cos(t); val sn = kotlin.math.sin(t); o[0] = cs; o[1] = 0f; o[2] = sn; o[3] = 0f; o[4] = 1f; o[5] = 0f; o[6] = -sn; o[7] = 0f; o[8] = cs }
    private fun rotZ(t: Float, o: FloatArray) { val cs = kotlin.math.cos(t); val sn = kotlin.math.sin(t); o[0] = cs; o[1] = -sn; o[2] = 0f; o[3] = sn; o[4] = cs; o[5] = 0f; o[6] = 0f; o[7] = 0f; o[8] = 1f }
    private fun mul(p: FloatArray, q: FloatArray, o: FloatArray) {
        for (i in 0 until 3) for (j in 0 until 3) o[i * 3 + j] = p[i * 3] * q[j] + p[i * 3 + 1] * q[3 + j] + p[i * 3 + 2] * q[6 + j]
    }

    /**
     * @param cx,cy centro en pantalla (px); @param scale px por unidad del modelo
     * @param yaw,pitch,roll radianes (sin tope)
     * @param brilloK brillo de las partes que emiten luz (LED, tiras) — 1 = normal
     */
    fun calcular(cx: Float, cy: Float, scale: Float, yaw: Float, pitch: Float, roll: Float, brilloK: Float) {
        // giro global = Rz(roll) · Rx(pitch) · Ry(yaw)
        rotY(yaw, a); rotX(pitch, b); mul(b, a, c)
        rotZ(roll, a); mul(a, c, g)

        val k = m.nv
        for (i in 0 until k) {
            val x = m.px[i]; val y = m.py[i]; val z = m.pz[i]
            val X = g[0] * x + g[1] * y + g[2] * z
            val Y = g[3] * x + g[4] * y + g[5] * z
            val Z = g[6] * x + g[7] * y + g[8] * z
            wx[i] = X; wy[i] = Y; wz[i] = Z
            val pr = FOCAL / (FOCAL - Z)
            scr[2 * i] = cx + X * scale * pr
            scr[2 * i + 1] = cy - Y * scale * pr
        }
        normalVidrioZ = g[8]
        run {
            val lx = TabletaModelo.LED_X; val ly = TabletaModelo.LED_Y; val lz = TabletaModelo.LED_Z
            val X = g[0] * lx + g[1] * ly + g[2] * lz
            val Y = g[3] * lx + g[4] * ly + g[5] * lz
            val Z = g[6] * lx + g[7] * ly + g[8] * lz
            val pr = FOCAL / (FOCAL - Z)
            ledX = cx + X * scale * pr; ledY = cy - Y * scale * pr
            ledVisible = g[8] > 0.12f
        }

        // ¿Qué paredes miran a la cámara? (normales: +X, -X, +Y, -Y, +Z, -Z ya giradas → su componente Z)
        caraCamara[0] = g[6] > 0.02f; caraCamara[1] = g[6] < -0.02f
        caraCamara[2] = g[7] > 0.02f; caraCamara[3] = g[7] < -0.02f
        caraCamara[4] = g[8] > 0.02f; caraCamara[5] = g[8] < -0.02f

        // Colores por vértice
        for (p in m.piezas) {
            when (p.tipo) {
                2 -> reflejo(p)
                else -> for (i in p.v0 until p.v0 + p.nvv) col[i] = iluminar(i, brilloK)
            }
        }

        // Plan de dibujo
        ncmd = 0; nidx = 0; corridaIni = -1
        // 1) pegado a paredes que miran hacia atrás (solo sus partes sólidas: el vidrio y los reflejos ahí no se ven)
        for (pi in m.piezas.indices) { val p = m.piezas[pi]; if (p.pared >= 0 && !caraCamara[p.pared] && p.tipo == 0) pieza(pi) }
        // 2) cuerpo
        for (pi in m.piezas.indices) if (m.piezas[pi].pared < 0) pieza(pi)
        // 3) pegado a paredes que miran a la cámara
        for (pi in m.piezas.indices) { val p = m.piezas[pi]; if (p.pared >= 0 && caraCamara[p.pared]) pieza(pi) }
        cerrarCorrida()

        // Casco convexo del cuerpo (cadena monótona), para el borde suave
        val cuerpo = m.piezas[0]
        var nh = 0
        for (i in cuerpo.v0 until cuerpo.v0 + cuerpo.nvv) {
            if (nh >= hx.size) break
            hx[nh] = scr[2 * i]; hy[nh] = scr[2 * i + 1]; nh++
        }
        nhull = casco(nh)
    }

    private var corridaIni = -1

    private fun cerrarCorrida() {
        if (corridaIni >= 0 && nidx > corridaIni) {
            cmd[3 * ncmd] = 0; cmd[3 * ncmd + 1] = corridaIni; cmd[3 * ncmd + 2] = nidx - corridaIni; ncmd++
        }
        corridaIni = -1
    }

    private fun pieza(pi: Int) {
        val p = m.piezas[pi]
        if (p.tipo == 1) {
            cerrarCorrida()
            cmd[3 * ncmd] = 1; cmd[3 * ncmd + 1] = pi; cmd[3 * ncmd + 2] = p.tex; ncmd++
        } else {
            if (corridaIni < 0) corridaIni = nidx
            for (t in p.t0 until p.t0 + p.nt) {
                val ia = m.tri[3 * t].toInt(); val ib = m.tri[3 * t + 1].toInt(); val id = m.tri[3 * t + 2].toInt()
                // visible si, en pantalla (eje y hacia abajo), el triángulo (antihorario visto de frente) queda en sentido horario
                val cr = (scr[2 * ib] - scr[2 * ia]) * (scr[2 * id + 1] - scr[2 * ia + 1]) - (scr[2 * ib + 1] - scr[2 * ia + 1]) * (scr[2 * id] - scr[2 * ia])
                if (cr < 0f) { sidx[nidx++] = ia.toShort(); sidx[nidx++] = ib.toShort(); sidx[nidx++] = id.toShort() }
            }
        }
    }

    // ───── Luz ─────

    private fun iluminar(i: Int, brilloK: Float): Int {
        val base = m.col[i]
        val r0 = (base shr 16 and 0xFF); val g0 = (base shr 8 and 0xFF); val b0 = (base and 0xFF)
        val e = m.emis[i]
        // normal girada
        val ax = m.nx[i]; val ay = m.ny[i]; val az = m.nz[i]
        val nx = g[0] * ax + g[1] * ay + g[2] * az
        val ny = g[3] * ax + g[4] * ay + g[5] * az
        val nz = g[6] * ax + g[7] * ay + g[8] * az
        if (e >= 0.99f) {
            // pantalla / LED: emiten luz propia; la pantalla se atenúa un poco al mirarla de lado
            if (base == TCol.TEAL) return pack(((ledRgb shr 16) and 0xFF) * brilloK, ((ledRgb shr 8) and 0xFF) * brilloK, (ledRgb and 0xFF) * brilloK)
            val k = if (base == 0xFFFFFF) (0.84f + 0.16f * max(0f, nz)) else brilloK
            return pack(r0 * k, g0 * k, b0 * k)
        }
        val d1 = max(0f, nx * L1X + ny * L1Y + nz * L1Z)
        val d2 = max(0f, nx * L2X + ny * L2Y + nz * L2Z)
        val rim = (1f - min(1f, max(0f, nz))).let { it * it }
        var sh = 0.36f + 0.58f * d1 + 0.20f * d2 + 0.06f * rim
        // brillo especular (Blinn-Phong con la cámara en (0,0,FOCAL))
        var spec = 0f
        val br = m.brillo[i]
        if (br > 0.01f) {
            var vx = -wx[i]; var vy = -wy[i]; var vz = FOCAL - wz[i]
            val vl = sqrt(vx * vx + vy * vy + vz * vz); vx /= vl; vy /= vl; vz /= vl
            var qx = L1X + vx; var qy = L1Y + vy; var qz = L1Z + vz
            val ql = sqrt(qx * qx + qy * qy + qz * qz); qx /= ql; qy /= ql; qz /= ql
            var ndh = max(0f, nx * qx + ny * qy + nz * qz)
            ndh *= ndh; ndh *= ndh; ndh *= ndh; ndh *= ndh          // ^16
            spec = ndh * br * 0.85f
        }
        if (e > 0f) sh = sh * (1f - e) + e * brilloK
        val s = 255f * spec
        return pack(r0 * sh + s, g0 * sh + s, b0 * sh + s)
    }

    private fun pack(r: Float, g: Float, b: Float): Int {
        val ri = if (r > 255f) 255 else if (r < 0f) 0 else r.toInt()
        val gi = if (g > 255f) 255 else if (g < 0f) 0 else g.toInt()
        val bi = if (b > 255f) 255 else if (b < 0f) 0 else b.toInt()
        return (255 shl 24) or (ri shl 16) or (gi shl 8) or bi
    }

    /**
     * Reflejo en el vidrio: blanco con transparencia que cambia con el ángulo. Se mezcla
     *   - una franja diagonal suave y otra fina (como el brillo de una ventana),
     *   - el cielo (más claro hacia arriba),
     *   - el destello de la lámpara (aparece solo en ciertos ángulos),
     *   - y más brillo al mirar de lado (Fresnel).
     */
    private fun reflejo(p: TPieza) {
        val nx = g[2]; val ny = g[5]; val nz = g[8]
        for (i in p.v0 until p.v0 + p.nvv) {
            var vx = -wx[i]; var vy = -wy[i]; var vz = FOCAL - wz[i]
            val vl = sqrt(vx * vx + vy * vy + vz * vz); vx /= vl; vy /= vl; vz /= vl
            // dirección reflejada de la mirada: r = d - 2(d·n)n con d = -v
            val dn = -(vx * nx + vy * ny + vz * nz)
            val rx = -vx - 2f * dn * nx
            val ry = -vy - 2f * dn * ny
            val s1 = rx * 0.72f + ry * 0.69f
            val suave = gauss((s1 - 0.075f) / 0.085f)
            val fino = gauss((s1 - 0.20f) / 0.018f)
            val cielo = smooth(-0.35f, 0.65f, ry)
            val cosv = max(0f, vx * nx + vy * ny + vz * nz)
            val fres = (1f - cosv).let { it * it * it }
            var qx = L1X + vx; var qy = L1Y + vy; var qz = L1Z + vz
            val ql = sqrt(qx * qx + qy * qy + qz * qz); qx /= ql; qy /= ql; qz /= ql
            var ndh = max(0f, nx * qx + ny * qy + nz * qz)
            ndh *= ndh; ndh *= ndh; ndh *= ndh; ndh *= ndh; ndh *= ndh      // ^32
            // el reflejo desaparece si la pantalla no mira a la cámara
            val cara = if (nz > 0.02f) 1f else 0f
            var al = 0.05f * cielo + 0.21f * suave + 0.30f * fino + 0.70f * ndh + 0.30f * fres
            if (al > 0.82f) al = 0.82f
            al *= cara
            col[i] = ((al * 255f).toInt().coerceIn(0, 255) shl 24) or 0x00F2F8FF
        }
    }

    private fun gauss(x: Float): Float { val e = x * x; return if (e > 9f) 0f else kotlin.math.exp(-e) }
    private fun smooth(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    // ───── Casco convexo ─────

    private val ord = IntArray(512)
    private val pila = IntArray(1024)

    private fun casco(nPts: Int): Int {
        if (nPts < 3) return 0
        for (i in 0 until nPts) ord[i] = i
        // orden por x (luego y): inserción (pocos puntos y casi ordenados de un cuadro al siguiente)
        for (i in 1 until nPts) {
            val v = ord[i]; var j = i - 1
            while (j >= 0 && (hx[ord[j]] > hx[v] || (hx[ord[j]] == hx[v] && hy[ord[j]] > hy[v]))) { ord[j + 1] = ord[j]; j-- }
            ord[j + 1] = v
        }
        var k = 0
        for (i in 0 until nPts) {
            while (k >= 2 && cruz(pila[k - 2], pila[k - 1], ord[i]) <= 0f) k--
            pila[k++] = ord[i]
        }
        val t = k + 1
        for (i in nPts - 2 downTo 0) {
            while (k >= t && cruz(pila[k - 2], pila[k - 1], ord[i]) <= 0f) k--
            pila[k++] = ord[i]
        }
        val cnt = (k - 1).coerceAtMost(64)
        for (i in 0 until cnt) { hull[2 * i] = hx[pila[i]]; hull[2 * i + 1] = hy[pila[i]] }
        return cnt
    }

    private fun cruz(o: Int, p: Int, q: Int): Float = (hx[p] - hx[o]) * (hy[q] - hy[o]) - (hy[p] - hy[o]) * (hx[q] - hx[o])
}
