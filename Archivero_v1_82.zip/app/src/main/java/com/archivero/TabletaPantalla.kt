package com.archivero

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tiempos de la animación de carga de la pantalla de la tableta (los usan la app, el amigo flotante y la pantalla misma).
 * Al tocar la tableta: 3 segundos de «Cargando…» (tiempo de sobra para que los mini paneles terminen de prepararse),
 * un visto bueno corto y un fundido de vuelta a la pantalla de inicio.
 */
internal object TabletaCarga {
    const val DURACION_MS = 3000L
    const val EXITO_MS = 700L
    const val FUNDIDO_MS = 320L
}

/**
 * La pantalla AMOLED de la tableta: un mapa de bits (240×336) que se redibuja con el reloj y la animación de carga, y que
 * Tableta3D estira sobre el vidrio en 3D. Todo se dibuja con código, sin imágenes.
 *  - Reposo: fondo azul con luces que flotan despacio, esquinas negras (AMOLED), cámara, reloj, tres íconos (música, optimizar, teclado) y barra.
 *  - Carga: anillo cian que se llena, % en el centro, «Cargando…» con puntitos, barra fina y un brillo que cruza.
 *  - Listo: anillo verde y visto bueno.
 */
internal class TabletaPantalla {
    companion object {
        const val W = 240
        const val H = 336
        private const val CX = W / 2f
        private const val RING_CY = 140f
        private const val RING_R = 54f
        private const val TAU = 6.2831855f
    }

    val bitmap: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val cv = Canvas(bitmap)

    private var ultimoMs = -10_000L
    private var ultimoModo = -9          // -1 reposo, 0 carga, 1 listo, 2 fundido
    private var liberada = false

    // ── Pinceles y sombreadores (todo se crea una vez) ──
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER }
    private val txtL = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.LEFT }
    private val box = RectF()
    private val arco = RectF()
    private val path = Path()
    private val m = Matrix()

    private val fondoReposo = LinearGradient(
        W.toFloat(), 0f, 0f, H.toFloat(),
        intArrayOf(0xFF081046.toInt(), 0xFF1B44B4.toInt(), 0xFF2D8BE6.toInt(), 0xFF59E0F6.toInt()), floatArrayOf(0f, 0.40f, 0.76f, 1f), Shader.TileMode.CLAMP
    )
    private val fondoCarga = LinearGradient(
        W * 0.85f, 0f, W * 0.05f, H.toFloat(),
        intArrayOf(0xFF040824.toInt(), 0xFF0A2792.toInt(), 0xFF1B6DD8.toInt(), 0xFF3CCDEC.toInt()), floatArrayOf(0f, 0.38f, 0.76f, 1f), Shader.TileMode.CLAMP
    )
    private val mancha = RadialGradient(0f, 0f, 1f, intArrayOf(0x66B4EBFF, 0x00B4EBFF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
    private val manchaP = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = mancha }
    private val vineta = RadialGradient(
        CX, H * 0.5f, H * 0.78f,
        intArrayOf(0x00000000, 0x00000000, 0xCC000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
    )
    private val vinetaP = Paint().apply { shader = vineta }
    private val rayoP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x18FFFFFF }

    // Texto que no se vuelve a armar cada cuadro.
    private val porcentajes = Array(101) { "$it%" }
    private var horaTxt = "--:--"
    private var horaMin = -1
    private var anchoCargando = 0f

    init {
        txtL.textSize = 27f
        anchoCargando = txtL.measureText("Cargando...")
        dibujarReposo(0L, 0f)
    }

    /** Pone la pantalla al día. [carga] = ms desde que se tocó la tableta (-1 = no se ha tocado). */
    fun actualizar(ahora: Long, carga: Long) {
        if (liberada) return
        val d = TabletaCarga.DURACION_MS
        val e = d + TabletaCarga.EXITO_MS
        val f = e + TabletaCarga.FUNDIDO_MS
        when {
            carga in 0 until d -> { ultimoModo = 0; ultimoMs = ahora; dibujarCarga(carga) }
            carga in d until e -> { ultimoModo = 1; ultimoMs = ahora; dibujarListo(carga - d) }
            carga in e until f -> { ultimoModo = 2; ultimoMs = ahora; dibujarReposo(ahora, 1f - (carga - e).toFloat() / TabletaCarga.FUNDIDO_MS) }
            else -> {
                // en reposo se redibuja unas 11 veces por segundo (las luces se mueven despacio)
                if (ultimoModo != -1 || ahora - ultimoMs >= 90L) { ultimoModo = -1; ultimoMs = ahora; dibujarReposo(ahora, 0f) }
            }
        }
    }

    fun liberar() {
        liberada = true
        if (!bitmap.isRecycled) bitmap.recycle()
    }

    // ───────────── Reposo ─────────────

    private fun hora(ahora: Long): String {
        val min = (System.currentTimeMillis() / 60_000L).toInt()
        if (min != horaMin) {
            horaMin = min
            val c = Calendar.getInstance()
            val h = c.get(Calendar.HOUR_OF_DAY); val mi = c.get(Calendar.MINUTE)
            horaTxt = (if (h < 10) "0" else "") + h + ":" + (if (mi < 10) "0" else "") + mi
        }
        return horaTxt
    }

    /** [velo] > 0 oscurece (fundido de entrada desde la carga). */
    private fun dibujarReposo(ahora: Long, velo: Float) {
        fill.shader = fondoReposo; fill.color = 0xFFFFFFFF.toInt()
        cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill)
        fill.shader = null
        val t = ahora.toFloat()
        dibujarMancha(W * (0.28f + 0.12f * sin(t / 2300f)), H * (0.26f + 0.06f * cos(t / 1900f)), 150f)
        dibujarMancha(W * (0.78f + 0.10f * cos(t / 2700f)), H * (0.74f + 0.07f * sin(t / 2100f)), 130f)

        // cámara frontal (un punto en la parte de arriba)
        fill.color = 0xFF020410.toInt(); cv.drawCircle(CX, 17f, 6.5f, fill)
        line.strokeWidth = 1.4f; line.color = 0x553F6BFF; cv.drawCircle(CX, 17f, 6.5f, line)
        fill.color = 0xAA3F6BFF.toInt(); cv.drawCircle(CX - 1.5f, 15.5f, 1.4f, fill)

        // reloj
        txt.textSize = 74f; txt.color = 0xF2FFFFFF.toInt()
        cv.drawText(hora(ahora), CX, 112f, txt)
        fill.color = 0x66FFFFFF; box.set(CX - 28f, 128f, CX + 28f, 131f); cv.drawRoundRect(box, 1.5f, 1.5f, fill)
        txt.textSize = 15f; txt.color = 0xB3FFFFFF.toInt()
        cv.drawText("ARCHIVERO", CX, 156f, txt)

        // tres íconos: música, optimizar, teclado (lo que abre la tableta)
        val lado = 54f; val sep = 17f
        val x0 = (W - (3 * lado + 2 * sep)) / 2f
        val y0 = H - 112f
        for (i in 0 until 3) {
            val x = x0 + i * (lado + sep)
            box.set(x, y0, x + lado, y0 + lado)
            fill.color = 0x24FFFFFF; cv.drawRoundRect(box, 14f, 14f, fill)
            line.strokeWidth = 1.5f; line.color = 0x44FFFFFF; cv.drawRoundRect(box, 14f, 14f, line)
            fill.color = 0xFFFFFFFF.toInt()
            val d = when (i) { 0 -> FIco.NOTE; 1 -> FIco.BOLT; else -> FIco.KEYBOARD }
            FIco.draw(cv, d, x + lado * 0.24f, y0 + lado * 0.24f, lado * 0.52f, fill)
        }
        // barra de inicio
        fill.color = 0x99FFFFFF.toInt(); box.set(CX - 34f, H - 20f, CX + 34f, H - 15f); cv.drawRoundRect(box, 2.5f, 2.5f, fill)

        // esquinas negras (AMOLED) y fundido de entrada
        cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), vinetaP)
        if (velo > 0f) {
            fill.color = ((velo.coerceIn(0f, 1f) * 235f).toInt() shl 24) or 0x00041030
            cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill)
        }
    }

    private fun dibujarMancha(x: Float, y: Float, r: Float) {
        m.setScale(r, r); m.postTranslate(x, y)
        mancha.setLocalMatrix(m)
        cv.drawCircle(x, y, r, manchaP)
    }

    // ───────────── Carga ─────────────

    private fun pintarFondoCarga(t: Long) {
        fill.shader = fondoCarga; fill.color = 0xFFFFFFFF.toInt()
        cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill)
        fill.shader = null
        val s = t.toFloat()
        dibujarMancha(CX + 18f * sin(s / 900f), RING_CY + 10f * cos(s / 700f), 118f)
        cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), vinetaP)
    }

    private fun suave(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    private fun dibujarCarga(t: Long) {
        pintarFondoCarga(t)
        val u = t.toFloat() / TabletaCarga.DURACION_MS
        // progreso con ritmo de carga de verdad: arranca, se detiene un poquito a mitad y remata
        val p = (suave(u) * 0.82f + u * 0.18f).coerceIn(0f, 1f)
        val s = t.toFloat()

        // anillo
        arco.set(CX - RING_R, RING_CY - RING_R, CX + RING_R, RING_CY + RING_R)
        line.color = 0x1A7FE9FF; line.strokeWidth = 24f; cv.drawOval(arco, line)        // resplandor
        line.color = 0x2B7FE9FF; line.strokeWidth = 14f; cv.drawOval(arco, line)
        line.color = 0x2AFFFFFF; line.strokeWidth = 6f; cv.drawOval(arco, line)          // pista
        val barrido = 360f * p
        line.color = 0x405CE6FF; line.strokeWidth = 14f; cv.drawArc(arco, -90f, barrido, false, line)
        line.color = 0xFF5CE6FF.toInt(); line.strokeWidth = 7f; cv.drawArc(arco, -90f, barrido, false, line)
        line.color = 0xE6FFFFFF.toInt(); line.strokeWidth = 2.6f; cv.drawArc(arco, -90f, barrido, false, line)
        // punta brillante
        val ang = (-90f + barrido) * (PI.toFloat() / 180f)
        val hx = CX + RING_R * cos(ang); val hy = RING_CY + RING_R * sin(ang)
        fill.color = 0x405CE6FF; cv.drawCircle(hx, hy, 13f, fill)
        fill.color = 0xFFFFFFFF.toInt(); cv.drawCircle(hx, hy, 5f, fill)

        // marcas que giran alrededor
        line.strokeWidth = 3f
        val giro = s * 0.0034f
        for (i in 0 until 12) {
            val a = giro + i * TAU / 12f
            val k = 0.25f + 0.75f * (((i + (s / 110f).toInt()) % 12) / 11f)
            line.color = ((k * 150f).toInt() shl 24) or 0x007FE9FF
            val c = cos(a); val sn = sin(a)
            cv.drawLine(CX + (RING_R + 17f) * c, RING_CY + (RING_R + 17f) * sn, CX + (RING_R + 23f) * c, RING_CY + (RING_R + 23f) * sn, line)
        }

        // porcentaje
        txt.textSize = 32f; txt.color = 0xFFFFFFFF.toInt()
        cv.drawText(porcentajes[(p * 100f).toInt().coerceIn(0, 100)], CX, RING_CY + 11f, txt)

        // «Cargando...» con puntitos
        val puntos = ((t / 330L) % 4L).toInt()
        txtL.textSize = 27f; txtL.color = 0xF2FFFFFF.toInt()
        cv.drawText("Cargando...", 0, 8 + puntos, CX - anchoCargando / 2f, RING_CY + RING_R + 56f, txtL)

        // barra fina
        val bx0 = CX - 66f; val bx1 = CX + 66f; val yb = RING_CY + RING_R + 80f
        fill.color = 0x30FFFFFF; box.set(bx0, yb, bx1, yb + 5f); cv.drawRoundRect(box, 2.5f, 2.5f, fill)
        fill.color = 0xFF5CE6FF.toInt(); box.set(bx0, yb, bx0 + (bx1 - bx0) * p, yb + 5f); cv.drawRoundRect(box, 2.5f, 2.5f, fill)

        // brillo diagonal que cruza la pantalla
        val x = ((s * 0.35f) % (W + H + 120f)) - 120f
        cv.save()
        cv.rotate(20f, CX, H / 2f)
        cv.drawRect(x, -80f, x + 34f, H + 80f, rayoP)
        cv.restore()
    }

    // ───────────── Listo ─────────────

    private fun dibujarListo(t: Long) {
        pintarFondoCarga(t)
        val u = (t.toFloat() / TabletaCarga.EXITO_MS).coerceIn(0f, 1f)
        val pop = 1f + 0.10f * sin(u * PI.toFloat())
        arco.set(CX - RING_R * pop, RING_CY - RING_R * pop, CX + RING_R * pop, RING_CY + RING_R * pop)
        line.color = 0x2A6BFFC0; line.strokeWidth = 24f; cv.drawOval(arco, line)
        line.color = 0xFF5BF5B8.toInt(); line.strokeWidth = 7f; cv.drawOval(arco, line)
        line.color = 0xE6FFFFFF.toInt(); line.strokeWidth = 2.6f; cv.drawOval(arco, line)
        // visto bueno que se dibuja solo
        val k = suave(u / 0.7f)
        path.reset()
        val ax = CX - 22f; val ay = RING_CY + 2f
        val px = CX - 7f; val py = RING_CY + 17f
        val qx = CX + 24f; val qy = RING_CY - 16f
        path.moveTo(ax, ay)
        if (k <= 0.4f) {
            val f = k / 0.4f
            path.lineTo(ax + (px - ax) * f, ay + (py - ay) * f)
        } else {
            val f = (k - 0.4f) / 0.6f
            path.lineTo(px, py)
            path.lineTo(px + (qx - px) * f, py + (qy - py) * f)
        }
        line.color = 0xFFFFFFFF.toInt(); line.strokeWidth = 9f
        cv.drawPath(path, line)
        txt.textSize = 27f; txt.color = 0xF2FFFFFF.toInt()
        cv.drawText("¡Listo!", CX, RING_CY + RING_R + 56f, txt)
    }
}

/** Dibuja la espalda de la tableta (panel de hexágonos) una sola vez. */
internal object TabletaEspalda {
    private const val W = 192
    private const val H = 284

    fun crear(): Bitmap {
        val b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // forma del panel: rectángulo con esquinas cortadas
        val k = 24f
        val forma = Path().apply {
            moveTo(k, 0f); lineTo(W - k, 0f); lineTo(W.toFloat(), k); lineTo(W.toFloat(), H - k)
            lineTo(W - k, H.toFloat()); lineTo(k, H.toFloat()); lineTo(0f, H - k); lineTo(0f, k); close()
        }
        c.save()
        c.clipPath(forma)
        p.shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), 0xFF2A2E35.toInt(), 0xFF121418.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
        p.shader = null
        // hexágonos (punta arriba)
        val r = 13f
        val dx = r * 1.7320508f
        val dy = r * 1.5f
        val hex = Path()
        val celda = Paint(Paint.ANTI_ALIAS_FLAG)
        val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.7f; color = 0xFF565D68.toInt() }
        val luz = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f; color = 0x66AEB6C2 }
        var fila = 0
        var y = 0f
        while (y < H + r) {
            var x = if (fila % 2 == 0) 0f else dx / 2f
            while (x < W + r) {
                hex.reset()
                for (i in 0 until 6) {
                    val a = (PI / 3.0 * i - PI / 2.0).toFloat()
                    val px = x + (r - 1.2f) * cos(a); val py = y + (r - 1.2f) * sin(a)
                    if (i == 0) hex.moveTo(px, py) else hex.lineTo(px, py)
                }
                hex.close()
                // cada celda con un tono un poquito distinto
                val v = 0x1C + ((fila * 7 + (x / dx).toInt() * 13) % 5) * 3
                celda.color = (0xFF shl 24) or (v shl 16) or ((v + 2) shl 8) or (v + 6)
                c.drawPath(hex, celda)
                c.drawPath(hex, borde)
                // filo de luz en los dos bordes de arriba
                path2.reset()
                path2.moveTo(x - (r - 1.2f) * 0.866f, y - (r - 1.2f) * 0.5f)
                path2.lineTo(x, y - (r - 1.2f))
                path2.lineTo(x + (r - 1.2f) * 0.866f, y - (r - 1.2f) * 0.5f)
                c.drawPath(path2, luz)
                x += dx
            }
            y += dy
            fila++
        }
        c.restore()
        // filo del panel
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0xFF6A717C.toInt()
        c.drawPath(forma, p)
        return b
    }

    private val path2 = Path()
}
