package com.archivero

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * Las animaciones del amigo flotante. Cada una dura unos segundos y, en cada cuadro, le dice a [Pose] qué hacer
 * (mover, girar, estirar, cambiar el ojo, mostrar objetos). Grupos:
 *   0 = quieto · 1 = andando por la pantalla · 2 = suena música · 3 = lo tienes agarrado.
 * Entran y salen con suavidad (el movimiento y los objetos se desvanecen al principio y al final).
 */

private const val TAU2 = 6.2831855f
private const val PI2 = 3.1415927f

private fun s(t: Float, ciclos: Float): Float = sin(TAU2 * t * ciclos)
private fun env(t: Float): Float = sin(PI2 * t)
private fun hop(t: Float, n: Float): Float = abs(sin(PI2 * t * n))

internal class Gesto(val nombre: String, val grupo: Int, val ms: Int, val fx: (Float, Pose) -> Unit)

internal val GESTOS: List<Gesto> = listOf(
    // ───── Suena música (grupo 2): auriculares, cabeceo con el ojo cerrado, notas… ─────
    Gesto("Cabeceo con auriculares", 2, 5000) { t, p -> p.props = P_HEAD or P_NOTES; p.eye = E_DOWN; p.dy = s(t, 12f) * 0.09f; p.rot = s(t, 6f) * 7f },
    Gesto("Cabeceo lento", 2, 4500) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.rot = s(t, 2f) * 14f; p.dy = s(t, 2f) * 0.05f },
    Gesto("Balanceo feliz", 2, 4200) { t, p -> p.props = P_HEAD or P_NOTES; p.eye = E_UP; p.dx = s(t, 3f) * 0.3f; p.rot = s(t, 3f) * 10f },
    Gesto("Salto al ritmo", 2, 3600) { t, p ->
        val h = hop(t, 8f)
        p.props = P_HEAD or P_NOTES; p.eye = E_UP; p.dy = -h * 0.35f; p.sy = 1f - 0.08f * (1f - h); p.sx = 1f + 0.06f * (1f - h)
    },
    Gesto("Giro musical", 2, 2400) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.rot = t * 360f },
    Gesto("Corazones por la canción", 2, 4500) { t, p -> p.props = P_HEAD or P_HEARTS; p.eye = E_HEART; p.rot = s(t, 3f) * 6f; p.dy = s(t, 6f) * 0.05f },
    Gesto("Lluvia de estrellitas", 2, 4500) { t, p -> p.props = P_HEAD or P_SPARK; p.eye = E_STAR; p.dy = s(t, 4f) * 0.07f },
    Gesto("Alas de escudo", 2, 3800) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.shL = s(t, 6f) * 18f; p.shR = -s(t, 6f) * 18f; p.dy = s(t, 6f) * 0.05f },
    Gesto("Ola de cola", 2, 4600) { t, p -> p.props = P_HEAD or P_NOTES; p.eye = E_DOWN; p.tail = 2.3f; p.dx = s(t, 2f) * 0.15f },
    Gesto("Rebote pulsante", 2, 3600) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.sx = 1f + 0.12f * s(t, 8f); p.sy = 1f - 0.12f * s(t, 8f); p.aura = 1.6f },
    Gesto("DJ con gafas", 2, 4800) { t, p -> p.props = P_HEAD or P_SHADES or P_NOTES; p.eye = E_LINE; p.rot = s(t, 4f) * 8f; p.dy = s(t, 8f) * 0.06f },
    Gesto("Trance", 2, 5200) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.aura = 2.4f; p.dy = s(t, 1f) * 0.14f },
    Gesto("Moonwalk", 2, 4000) { t, p -> p.props = P_HEAD or P_NOTES; p.eye = E_UP; p.dx = (t - 0.5f) * 1.0f; p.rot = s(t, 8f) * 4f },
    Gesto("Tarareo", 2, 4200) { t, p -> p.props = P_NOTES; p.eye = E_DOWN; p.dy = s(t, 5f) * 0.06f; p.rot = s(t, 2.5f) * 5f },
    Gesto("Meneo de cuerno", 2, 3800) { t, p -> p.props = P_HEAD; p.eye = E_DOWN; p.horn = s(t, 5f) * 22f; p.rot = s(t, 2.5f) * 5f },

    // ───── Andando por la pantalla (grupo 1) ─────
    Gesto("Trote", 1, 2400) { t, p -> p.dy = -hop(t, 6f) * 0.12f },
    Gesto("Vuelo ondulante", 1, 3000) { t, p -> p.dy = s(t, 2f) * 0.16f; p.tail = 1.7f; p.rot = s(t, 2f) * 5f },
    Gesto("Hélice", 1, 1500) { t, p -> p.rot = t * 720f },
    Gesto("Cola de cometa", 1, 3000) { _, p -> p.tail = 2.6f; p.aura = 2f; p.props = P_SPARK },
    Gesto("Zigzag", 1, 2600) { t, p -> p.dx = s(t, 3f) * 0.2f; p.rot = s(t, 3f) * 9f },
    Gesto("Prisa", 1, 2200) { t, p -> p.eye = E_WIDE; p.props = P_SWEAT; p.dx = s(t, 10f) * 0.04f },
    Gesto("Paseo con flor", 1, 3600) { t, p -> p.props = P_FLOWER; p.eye = E_UP; p.dy = s(t, 2f) * 0.07f },
    Gesto("Ojo de halcón", 1, 2800) { _, p -> p.aura = 1.7f; p.horn = -12f; p.pupil = 0.8f },
    Gesto("Aleteo de escudos", 1, 2200) { t, p -> p.shL = s(t, 7f) * 25f; p.shR = -s(t, 7f) * 25f; p.dy = s(t, 7f) * 0.06f },
    Gesto("Rueda", 1, 1300) { t, p -> p.rot = t * 360f; p.sx = 1f + 0.1f * s(t, 3f); p.sy = 1f - 0.1f * s(t, 3f) },
    Gesto("Rayo", 1, 2600) { _, p -> p.props = P_BOLT; p.aura = 2.2f; p.tail = 2.2f },
    Gesto("Silbido", 1, 3000) { t, p -> p.props = P_NOTES; p.eye = E_UP; p.dy = s(t, 3f) * 0.05f },

    // ───── Quieto (grupo 0) ─────
    Gesto("Mirar alrededor", 0, 3600) { t, p -> p.lookW = 1f; p.lx = s(t, 1.5f) * 0.95f; p.ly = s(t, 0.75f) * 0.3f },
    Gesto("Bostezo", 0, 2600) { t, p -> p.eye = E_DOWN; p.sy = 1f + 0.16f * env(t); p.sx = 1f - 0.08f * env(t) },
    Gesto("Dormir", 0, 6000) { _, p -> p.eye = E_LINE; p.props = P_ZZZ; p.dy = 0.10f; p.rot = 8f; p.aura = 0.4f; p.tail = 0.5f },
    Gesto("Pensar", 0, 4200) { t, p -> p.props = P_THINK; p.lookW = 1f; p.lx = -0.5f; p.ly = -0.9f; p.rot = s(t, 1f) * 4f },
    Gesto("Idea", 0, 2200) { t, p -> p.props = P_EXC; p.eye = E_WIDE; p.dy = -env(t) * 0.28f; p.aura = 2f },
    Gesto("Duda", 0, 2800) { t, p -> p.props = P_Q; p.rot = env(t) * 12f; p.lookW = 1f; p.lx = 0.7f; p.ly = -0.2f },
    Gesto("Susto", 0, 2200) { t, p -> p.props = P_EXC or P_SWEAT; p.eye = E_WIDE; p.sx = 0.92f; p.dx = s(t, 14f) * 0.04f; p.pupil = 0.4f },
    Gesto("Estornudo", 0, 2000) { t, p -> p.eye = E_DOWN; p.props = P_SPARK; p.sy = 1f + 0.18f * s(t, 1f); p.dy = -env(t) * 0.1f },
    Gesto("Saludo con escudo", 0, 3000) { t, p -> p.eye = E_UP; p.shR = -35f + s(t, 4f) * 22f },
    Gesto("Danza del cuerno", 0, 3000) { t, p -> p.horn = s(t, 4f) * 28f },
    Gesto("Guiño", 0, 1200) { _, p -> p.eye = E_DOWN; p.props = P_SPARK },
    Gesto("Enamorado", 0, 3800) { t, p -> p.eye = E_HEART; p.props = P_HEARTS; p.dy = s(t, 1f) * 0.08f },
    Gesto("Ojos de estrella", 0, 3400) { t, p -> p.eye = E_STAR; p.props = P_SPARK; p.rot = s(t, 2f) * 5f },
    Gesto("Mareado", 0, 3800) { t, p -> p.eye = E_SPIRAL; p.props = P_STARS; p.rot = s(t, 3f) * 14f; p.dx = s(t, 1.5f) * 0.15f },
    Gesto("Escalofrío", 0, 2400) { t, p -> p.props = P_SWEAT; p.dx = s(t, 20f) * 0.05f; p.aura = 0.6f; p.pupil = 0.7f },
    Gesto("Salto curioso", 0, 2200) { t, p -> p.eye = E_WIDE; p.dy = -hop(t, 2f) * 0.26f },
    Gesto("Estiramiento", 0, 2800) { t, p -> p.sy = 1f + 0.2f * env(t); p.sx = 1f - 0.1f * env(t); p.tail = 1.8f },
    Gesto("Gafas de sol", 0, 4200) { t, p -> p.props = P_SHADES; p.eye = E_LINE; p.aura = 1.5f; p.rot = -5f * env(t) },
    Gesto("Fiesta", 0, 4000) { t, p -> p.props = P_HAT or P_SPARK; p.eye = E_UP; p.dy = -hop(t, 4f) * 0.14f },
    Gesto("Rascarse", 0, 2400) { t, p -> p.eye = E_DOWN; p.rot = s(t, 6f) * 9f; p.shL = s(t, 6f) * 20f },
    Gesto("Desvanecer", 0, 3600) { t, p -> p.alpha = 1f - 0.65f * env(t); p.aura = 2.2f },
    Gesto("Hipo", 0, 2800) { t, p -> val h = max(0f, s(t, 3f)); p.eye = E_WIDE; p.dy = -h * h * h * 0.14f },
    Gesto("Respiración profunda", 0, 5000) { t, p -> p.eye = E_DOWN; p.sx = 1f + 0.08f * s(t, 1f); p.sy = 1f + 0.08f * s(t, 1f); p.aura = 1.4f },
    Gesto("Mirada fija", 0, 2600) { _, p -> p.lookW = 1f; p.lx = 0f; p.ly = 0f; p.aura = 1.8f; p.pupil = 1.25f },
    Gesto("Pupila diminuta", 0, 2000) { _, p -> p.pupil = 0.25f; p.eye = E_WIDE },
    Gesto("Mirar arriba", 0, 2800) { _, p -> p.lookW = 1f; p.lx = 0.2f; p.ly = -1f; p.rot = -6f },
    Gesto("Rebote suave", 0, 3000) { t, p -> p.dy = s(t, 1.5f) * 0.1f; p.tail = 1.4f },
    Gesto("Quietito con brillo", 0, 3200) { _, p -> p.aura = 2.6f; p.props = P_SPARK },
    Gesto("Pirueta", 0, 1800) { t, p -> p.rot = t * 360f; p.dy = -env(t) * 0.25f; p.eye = E_UP },

    // ───── Lo tienes agarrado (grupo 3) ─────
    Gesto("Pataleo", 3, 1600) { t, p -> p.shL = s(t, 8f) * 25f; p.shR = -s(t, 8f) * 25f; p.eye = E_WIDE; p.props = P_SWEAT; p.rot = s(t, 6f) * 10f },
    Gesto("Estirado", 3, 1600) { _, p -> p.sy = 1.15f; p.sx = 0.9f; p.props = P_EXC; p.eye = E_WIDE },
    Gesto("Vuelo feliz", 3, 2000) { _, p -> p.eye = E_UP; p.props = P_HEARTS; p.dy = -0.08f },
    Gesto("Cosquillas", 3, 1800) { t, p -> p.eye = E_DOWN; p.props = P_SPARK; p.dx = s(t, 12f) * 0.06f },
    Gesto("Protesta", 3, 1800) { t, p -> p.props = P_EXC; p.rot = s(t, 10f) * 8f; p.pupil = 0.5f },
    Gesto("Mareo", 3, 2000) { t, p -> p.eye = E_SPIRAL; p.props = P_STARS; p.rot = s(t, 2f) * 10f }
)

/** Elige y reproduce las animaciones: una a la vez, según lo que esté pasando (grupo). */
internal class Gestos {
    private val rnd = java.util.Random()
    private val pool: Array<List<Gesto>> = Array(4) { gi -> GESTOS.filter { it.grupo == gi } }
    private var cur: Gesto? = null
    private var start = 0L
    private var nextAt = 0L
    private var last: Gesto? = null

    /** Llamar en cada cuadro: deja en [p] lo que hay que dibujar ahora. */
    fun update(p: Pose, now: Long, grupo: Int) {
        p.reset()
        val g0 = cur
        if (g0 != null && g0.grupo != grupo) {
            cur = null
            nextAt = now + (if (grupo == 3) 0L else 250L)
        }
        var g = cur
        if (g == null) {
            if (now < nextAt) return
            val lista = pool[grupo.coerceIn(0, 3)]
            if (lista.isEmpty()) return
            var pick = lista[rnd.nextInt(lista.size)]
            if (lista.size > 1 && pick === last) pick = lista[(lista.indexOf(pick) + 1) % lista.size]
            cur = pick
            last = pick
            start = now
            g = pick
        }
        val t = ((now - start).toFloat() / g.ms).coerceIn(0f, 1f)
        g.fx(t, p)
        fade(p, min(1f, min(t, 1f - t) * 6f))
        if (now - start >= g.ms) {
            cur = null
            nextAt = now + when (grupo) {
                2 -> 150L + rnd.nextInt(400)
                1 -> 300L + rnd.nextInt(1200)
                3 -> 0L
                else -> 700L + rnd.nextInt(2300)
            }
        }
    }

    /** Al empezar y al terminar cada animación todo se atenúa (w = 0..1): nada aparece ni desaparece de golpe. */
    private fun fade(p: Pose, w: Float) {
        p.dx *= w; p.dy *= w; p.rot *= w
        p.sx = 1f + (p.sx - 1f) * w
        p.sy = 1f + (p.sy - 1f) * w
        p.horn *= w; p.shL *= w; p.shR *= w
        p.tail = 1f + (p.tail - 1f) * w
        p.aura = 1f + (p.aura - 1f) * w
        p.alpha = 1f - (1f - p.alpha) * w
        p.pupil = 1f + (p.pupil - 1f) * w
        p.lookW *= w
        p.pw = w
        if (w < 0.25f) p.eye = E_NORMAL
    }
}
