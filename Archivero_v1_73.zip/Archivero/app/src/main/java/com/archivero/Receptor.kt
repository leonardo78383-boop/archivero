package com.archivero

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.clip
import androidx.core.content.ContextCompat
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

enum class RxEstado { PARADO, CONECTANDO, ACTIVO, ERROR }

/**
 * Receptor de conexión Wi-Fi: nosotros somos el que RECIBE la conexión de la zona portátil de otro teléfono.
 * 1) Si se escribe el nombre de la red, se une a esa zona portátil con su contraseña (WifiNetworkSpecifier; Android pide confirmar).
 * 2) Comprueba que la IP y el puerto del proxy del otro teléfono responden y, si responden, manda por ahí el tráfico DE ARCHIVERO.
 * Límite de Android: una app normal no puede cambiar el proxy de todo el sistema; para las demás apps hay que ponerlo en Ajustes Wi-Fi.
 */
object Receptor {
    var estado by mutableStateOf(RxEstado.PARADO)
        private set
    var mensaje by mutableStateOf("Listo para recibir")
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var cm: ConnectivityManager? = null
    private var cb: ConnectivityManager.NetworkCallback? = null

    fun iniciar(ctx: Context, ssid: String, clave: String, ip: String, puerto: Int, seguro: Boolean = true, wpa3: Boolean = false) {
        detener()
        val c = ctx.applicationContext.getSystemService(ConnectivityManager::class.java)
        cm = c
        estado = RxEstado.CONECTANDO
        if (ssid.isBlank()) { probar(null, ip, puerto); return }
        mensaje = "Uniéndose a «$ssid»…"
        try {
            val b = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (seguro) { if (wpa3) b.setWpa3Passphrase(clave) else b.setWpa2Passphrase(clave) }
            val spec = b.build()
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build()
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    try { c.bindProcessToNetwork(network) } catch (e: Exception) { }
                    scope.launch { probar(network, ip, puerto) }
                }
                override fun onUnavailable() {
                    scope.launch { fallo("No se pudo unir a la red. Revisa el nombre y la contraseña.") }
                }
                override fun onLost(network: Network) {
                    scope.launch { if (estado == RxEstado.ACTIVO) fallo("Se perdió la conexión con la zona portátil.") }
                }
            }
            cb = callback
            c.requestNetwork(req, callback, 30_000)
        } catch (e: Exception) {
            fallo("No se pudo iniciar la conexión: ${e.message ?: "error"}")
        }
    }

    private fun probar(net: Network?, ip: String, puerto: Int) {
        mensaje = "Comprobando $ip:$puerto…"
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val s: Socket = if (net != null) net.socketFactory.createSocket() else Socket()
                    s.use { it.connect(InetSocketAddress(ip, puerto), 5000) }
                    true
                } catch (e: Exception) { false }
            }
            if (!ok) { fallo("No responde $ip:$puerto. Revisa la IP, el puerto y que el otro teléfono tenga el Wi-Fi Shared en ON."); return@launch }
            for (k in listOf("http", "https")) {
                System.setProperty("$k.proxyHost", ip)
                System.setProperty("$k.proxyPort", puerto.toString())
            }
            estado = RxEstado.ACTIVO
            mensaje = "Recibiendo por $ip:$puerto"
        }
    }

    private fun limpiar() {
        for (k in listOf("http", "https")) {
            System.clearProperty("$k.proxyHost")
            System.clearProperty("$k.proxyPort")
        }
        try { cm?.bindProcessToNetwork(null) } catch (e: Exception) { }
        try { cb?.let { cm?.unregisterNetworkCallback(it) } } catch (e: Exception) { }
        cb = null
    }

    private fun fallo(msg: String) {
        limpiar()
        estado = RxEstado.ERROR
        mensaje = msg
    }

    fun detener() {
        limpiar()
        estado = RxEstado.PARADO
        mensaje = "Listo para recibir"
    }
}

/** Ícono de Wi-Fi: tres arcos y un punto, dibujados en línea fina como el resto de íconos. */
@Composable
fun WifiIcon(w: Dp = 24.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w)) {
        val cx = size.width / 2f
        val cy = size.height * 0.84f
        val st = Stroke(width = size.width * 0.085f, cap = StrokeCap.Round)
        for (f in listOf(0.26f, 0.5f, 0.74f)) {
            val r = size.width * f
            drawArc(color, -135f, 90f, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = st)
        }
        drawCircle(color, size.width * 0.07f, Offset(cx, cy))
    }
}

/** Una red Wi-Fi cercana: nombre, intensidad (0 a 1), si tiene contraseña y si es WPA3. */
class Red(val ssid: String, val fuerza: Float, val seguro: Boolean, val wpa3: Boolean)

@Suppress("DEPRECATION")
private fun leerRedes(wm: WifiManager?): List<Red> {
    val w = wm ?: return emptyList()
    return try {
        val max = w.maxSignalLevel.coerceAtLeast(1)
        w.scanResults.orEmpty()
            .filter { !it.SSID.isNullOrBlank() }
            .groupBy { it.SSID }
            .map { (n, l) ->
                val m = l.maxByOrNull { it.level }!!
                val caps = m.capabilities ?: ""
                val seg = caps.contains("WPA") || caps.contains("WEP") || caps.contains("SAE") || caps.contains("PSK")
                Red(n, w.calculateSignalLevel(m.level).toFloat() / max, seg, caps.contains("SAE") && !caps.contains("PSK"))
            }
            .sortedByDescending { it.fuerza }
    } catch (e: Exception) { emptyList() }
}

/**
 * Pantalla completa del receptor: lista de redes cercanas (como el Wi-Fi del teléfono), y solo se rellena
 * contraseña, IP y puerto. Tocar una red la elige; el botón empieza a recibir.
 */
@Composable
fun ReceptorScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("archivero", Context.MODE_PRIVATE) }
    val wm = remember { ctx.applicationContext.getSystemService(WifiManager::class.java) }
    var ssid by remember { mutableStateOf(prefs.getString("rx_ssid", "") ?: "") }
    var clave by remember { mutableStateOf("") }
    var ip by remember { mutableStateOf(prefs.getString("rx_ip", "") ?: "") }
    var puerto by remember { mutableStateOf(prefs.getString("rx_puerto", "8080") ?: "8080") }
    var ver by remember { mutableStateOf(false) }
    var redes by remember { mutableStateOf<List<Red>>(emptyList()) }
    var permiso by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) }

    @Suppress("DEPRECATION")
    fun escanear() {
        try { wm?.startScan() } catch (e: Exception) { }
        redes = leerRedes(wm)
    }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        permiso = ok
        if (ok) escanear()
    }
    LaunchedEffect(permiso) { if (permiso) escanear() }
    DisposableEffect(permiso) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { if (permiso) redes = leerRedes(wm) }
        }
        ContextCompat.registerReceiver(ctx, rx, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(rx) } catch (e: Exception) { } }
    }

    val st = Receptor.estado
    val ocupado = st == RxEstado.ACTIVO || st == RxEstado.CONECTANDO
    val color = when (st) {
        RxEstado.ACTIVO -> Color(0xFF3DDC97)
        RxEstado.ERROR -> Color(0xFFFF5C5C)
        RxEstado.CONECTANDO -> Pal.Accent
        RxEstado.PARADO -> Pal.Muted
    }
    val shape = CutShape(tl = 14.dp, br = 14.dp)
    val campo = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Pal.Accent, unfocusedBorderColor = Pal.Line,
        focusedLabelColor = Pal.Accent, unfocusedLabelColor = Pal.Muted,
        cursorColor = Pal.White, focusedTextColor = Pal.White, unfocusedTextColor = Pal.White,
        disabledBorderColor = Pal.Line, disabledTextColor = Pal.Muted, disabledLabelColor = Pal.Muted
    )
    val fshape = CutShape(tl = 12.dp, br = 12.dp)
    val sel = redes.firstOrNull { it.ssid == ssid }
    val seguro = sel?.seguro ?: true
    val wpa3 = sel?.wpa3 ?: false

    Box(Modifier.fillMaxSize().background(Pal.Black)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            // Estado
            Column(
                Modifier.fillMaxWidth().vidrio3D(shape, 8.dp).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                WifiIcon(48.dp, color)
                Spacer(Modifier.height(8.dp))
                Text("RECEPTOR WI-FI", color = Pal.White, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(4.dp))
                Text(Receptor.mensaje, color = color, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))

            // Redes cercanas
            Column(Modifier.fillMaxWidth().vidrio3D(shape, 8.dp).padding(vertical = 12.dp, horizontal = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("REDES CERCANAS", color = Pal.Muted, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                    TextButton(
                        onClick = { if (permiso) escanear() else pedir.launch(Manifest.permission.ACCESS_FINE_LOCATION) },
                        enabled = !ocupado
                    ) { Text("BUSCAR", color = Pal.Accent, fontSize = 12.sp, letterSpacing = 1.sp) }
                }
                when {
                    !permiso -> Text(
                        "Para ver las redes cercanas Android pide el permiso de ubicación. Toca BUSCAR.",
                        color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp)
                    )
                    redes.isEmpty() -> Text(
                        "No hay redes a la vista. Revisa que el Wi-Fi y la ubicación del teléfono estén activados y toca BUSCAR.",
                        color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp)
                    )
                    else -> Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                        redes.forEach { r ->
                            val elegida = r.ssid == ssid
                            Row(
                                Modifier.fillMaxWidth().clip(fshape)
                                    .background(if (elegida) Pal.Sel else Color.Transparent)
                                    .clickable(enabled = !ocupado) { ssid = r.ssid }
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                WifiIcon(22.dp, Pal.White.copy(alpha = 0.35f + 0.65f * r.fuerza))
                                Spacer(Modifier.width(14.dp))
                                Text(r.ssid, color = if (elegida) Pal.Accent else Pal.White, fontWeight = if (elegida) FontWeight.Bold else FontWeight.Normal, maxLines = 1, modifier = Modifier.weight(1f))
                                if (r.seguro) Text("🔒", fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            // Lo único que se rellena
            Column(Modifier.fillMaxWidth().vidrio3D(shape, 8.dp).padding(16.dp)) {
                OutlinedTextField(
                    value = ssid, onValueChange = { ssid = it }, enabled = !ocupado, singleLine = true,
                    label = { Text("Red (toca una de la lista)") }, shape = fshape, colors = campo,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                if (seguro) {
                    OutlinedTextField(
                        value = clave, onValueChange = { clave = it }, enabled = !ocupado, singleLine = true,
                        label = { Text("Contraseña Wi-Fi de la zona portátil") }, shape = fshape, colors = campo,
                        visualTransformation = if (ver) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = { TextButton(onClick = { ver = !ver }) { Text(if (ver) "OCULTAR" else "VER", color = Pal.Accent, fontSize = 11.sp) } },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = ip, onValueChange = { ip = it.filter { c -> c.isDigit() || c == '.' } }, enabled = !ocupado, singleLine = true,
                        label = { Text("IP") }, shape = fshape, colors = campo,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = puerto, onValueChange = { puerto = it.filter { c -> c.isDigit() }.take(5) }, enabled = !ocupado, singleLine = true,
                        label = { Text("Puerto") }, shape = fshape, colors = campo,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(110.dp)
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (ocupado) { Receptor.detener(); return@Button }
                    val ipOk = ip.trim().split('.').let { p -> p.size == 4 && p.all { x -> x.toIntOrNull()?.let { n -> n in 0..255 } == true } }
                    val pn = puerto.trim().toIntOrNull()
                    when {
                        !ipOk -> Toast.makeText(ctx, "Escribe una IP válida (por ejemplo 100.89.137.132)", Toast.LENGTH_SHORT).show()
                        pn == null || pn !in 1..65535 -> Toast.makeText(ctx, "Escribe un puerto válido (1 a 65535)", Toast.LENGTH_SHORT).show()
                        ssid.isNotBlank() && seguro && clave.length < 8 -> Toast.makeText(ctx, "La contraseña Wi-Fi tiene al menos 8 caracteres", Toast.LENGTH_SHORT).show()
                        else -> {
                            prefs.edit().putString("rx_ssid", ssid.trim()).putString("rx_ip", ip.trim()).putString("rx_puerto", pn.toString()).apply()
                            Receptor.iniciar(ctx, ssid.trim(), clave, ip.trim(), pn, seguro, wpa3)
                        }
                    }
                },
                shape = CutShape(tl = 14.dp, br = 14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (ocupado) Pal.Card else Pal.White, contentColor = if (ocupado) Pal.White else Pal.Black),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Text(if (ocupado) "DETENER" else "ESTAR PARA RECIBIR", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(
                onClick = { try { ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("ABRIR AJUSTES WI-FI", color = Pal.Muted, letterSpacing = 1.5.sp, fontSize = 12.sp) }
            Text(
                "Archivero envía su tráfico por el proxy del otro teléfono. Para que las demás apps también lo usen, en Ajustes Wi-Fi elige la red, Proxy > Manual y pon la misma IP y puerto.",
                color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}
