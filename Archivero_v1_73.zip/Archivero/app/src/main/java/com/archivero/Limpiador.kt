package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random

enum class CleanPhase { IDLE, CLEANING, DONE }

private val MASCOT = 72.dp
/** Lleva un ángulo al rango -π..π (mismo aspecto, número pequeño). */
private fun wrapPi(a: Float): Float {
    val t = 6.2831855f
    return ((a + 3.1415927f) % t + t) % t - 3.1415927f
}

private val MASCOT_SKIN = 76.dp     // con una forma de foto se ve un poco más grande para que se reconozca

/** Burbujita de la estela del amigo (posición y velocidad en px; vida en segundos). */
class Bubble(var x: Float, var y: Float, val vx: Float, val vy: Float, val r: Float, val life: Float, val phase: Float, val pink: Boolean) {
    var age = 0f
}

/**
 * El amigo: una esfera de gelatina negra, medio transparente y en 3D, con ojitos. Borra los residuos de la propia app (se le toca):
 *  - archivos temporales en la caché (interna y externa) de Archivero,
 *  - miniaturas y carpetas leídas que la app guarda en memoria para ir más rápido.
 * NO toca tus archivos, ni la papelera, ni otras apps.
 * Vive en el mini panel de las 3 rayitas; se puede arrastrar fuera para que acompañe mientras navegas.
 */
class CleanerState(context: Context, private val store: Store) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("limpiador", Context.MODE_PRIVATE)

    /** true = anda suelto por la pantalla; false = guardado en el panel. */
    var out by mutableStateOf(prefs.getBoolean("out", false))
    /** Esquina superior izquierda (px) cuando anda suelto. */
    var pos by mutableStateOf(Offset(prefs.getFloat("x", 0f), prefs.getFloat("y", 0f)))
    var junk by mutableLongStateOf(-1L)           // -1 = midiendo
    var phase by mutableStateOf(CleanPhase.IDLE)
    var say by mutableStateOf<String?>(null)
    var sayId by mutableIntStateOf(0)
    var dragging by mutableStateOf(false)
    var pressed by mutableStateOf(false)          // dedo encima: se queda quieto para poder tocarlo/agarrarlo
    var look by mutableStateOf(Offset.Zero)       // hacia dónde mira (-1..1)
    // Giro 3D de la cara (radianes): yaw = izquierda/derecha (±π/2 de perfil, π de espaldas), pitch = arriba/abajo.
    // Lanzamiento: velocidad (px/s) al soltarlo y mientras vuela rebotando.
    var flyVel = Offset.Zero
    var dragVel = Offset.Zero
    var dragLastMs = 0L
    var yaw by mutableFloatStateOf(0f)
    var pitch by mutableFloatStateOf(0f)
    var roll by mutableFloatStateOf(0f)           // ladeo (de costado); como yaw y pitch, sin límite de giro
    var spinYaw = 0f                              // velocidades de giro libre (rad/s) al lanzarlo o tocarlo
    var spinPitch = 0f
    var spinRoll = 0f
    var spinning = false
    var settingsOpen by mutableStateOf(false)     // pantalla de Ajustes abierta
    var hint by mutableStateOf("")                // título de la pantalla actual (lo pone App)
    var sayMs = 2800L                             // cuánto dura el globito
    var sayTappable by mutableStateOf(false)      // true = tocar el globito abre el chat

    // Gelatina: se estira hacia donde va y rebota al parar (se actualiza en cada cuadro).
    var stretch by mutableFloatStateOf(0f)        // >0 estirada, <0 aplastada
    var moveAngle by mutableFloatStateOf(0f)      // grados: hacia dónde se mueve
    var stretchVel = 0f
    val bubbles = ArrayList<Bubble>()             // estela de burbujitas
    var tick by mutableIntStateOf(0)              // avisa al dibujo de que hay que repintar las burbujas

    /** Un golpecito: se aplasta y rebota. */
    fun poke() {
        stretchVel -= 5f
        spinYaw += if (Random.nextBoolean()) 9f else -9f      // un toque lo hace girar en el aire
        spinRoll += (Random.nextFloat() - 0.5f) * 4f
    }

    // ── Change shape: la forma de una foto de la galería ──
    var body by mutableStateOf(BodyType.SPHERE)        // SPHERE = la esfera de siempre
    var skin by mutableStateOf<ImageBitmap?>(null)     // la figura recortada
    var gait by mutableFloatStateOf(0f)                // 0 = parado, 1 = caminando a buen paso
    var walk by mutableFloatStateOf(0f)                // fase del paso (ciclos)
    var faceX by mutableFloatStateOf(1f)               // 1 = mira a la derecha, -1 = a la izquierda

    private val shapeFile get() = File(ctx.filesDir, "forma_amigo.png")

    /** Al abrir la app: vuelve a ponerse la última forma elegida. */
    suspend fun loadShape() {
        val t = BodyType.from(prefs.getString("body", null))
        if (t == BodyType.SPHERE) return
        val bmp = withContext(Dispatchers.IO) { shapeFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) } }
        if (bmp != null) { skin = bmp.asImageBitmap(); body = t }
    }

    /** Guarda la forma elegida y el amigo la toma. */
    suspend fun applyShape(bmp: Bitmap, type: BodyType) {
        withContext(Dispatchers.IO) {
            runCatching { shapeFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        }
        prefs.edit().putString("body", type.name).apply()
        gait = 0f
        faceX = 1f
        skin = bmp.asImageBitmap()
        body = type
    }

    /** Vuelve a ser la esfera de gelatina. */
    fun resetShape() {
        runCatching { shapeFile.delete() }
        prefs.edit().remove("body").apply()
        skin = null
        body = BodyType.SPHERE
        gait = 0f
        faceX = 1f
    }

    fun save() { prefs.edit().putBoolean("out", out).putFloat("x", pos.x).putFloat("y", pos.y).apply() }
    fun talk(msg: String?, ms: Long = 2800L, tappable: Boolean = false) { say = msg; sayMs = ms; sayTappable = tappable; sayId++ }

    private fun sizeOf(f: File?): Long =
        if (f == null || !f.exists()) 0L else if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun wipe(d: File?) {
        d?.listFiles()?.forEach { runCatching { if (it.isDirectory) it.deleteRecursively() else it.delete() } }
    }

    /** Residuos actuales en bytes: caché en disco + miniaturas en memoria. */
    suspend fun measure(): Long = withContext(Dispatchers.IO) {
        sizeOf(ctx.cacheDir) + sizeOf(ctx.externalCacheDir) + Thumbs.sizeBytes()
    }

    suspend fun refresh() { junk = measure() }

    suspend fun clean() {
        if (phase == CleanPhase.CLEANING) return
        phase = CleanPhase.CLEANING
        try {
            talk("Limpiando…")
            val before = measure()
            withContext(Dispatchers.IO) { wipe(ctx.cacheDir); wipe(ctx.externalCacheDir) }
            store.clearMemoryCaches()
            delay(900)                                   // para que se vea la animación
            val after = measure()
            junk = after
            val freed = (before - after).coerceAtLeast(0L)
            phase = CleanPhase.DONE
            talk(if (freed > 0) "¡Listo! ${fmtSize(freed)} liberados" else "Todo estaba limpio")
            delay(2200)
        } finally {
            phase = CleanPhase.IDLE      // si se cancela a mitad (sales de la pantalla), el amigo no queda «limpiando» para siempre
        }
    }
}

// ───────────── El dron ─────────────

/** El amigo dentro de la app: el dron 3D (Dron3D.kt). Sólido en reposo, gelatina al tocarlo, gira a cualquier ángulo. */
@Composable
fun Mascot(c: CleanerState, boxSize: Dp) {
    val t = rememberInfiniteTransition(label = "mascota")
    val bob by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    val blink by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3800, easing = LinearEasing), RepeatMode.Restart), label = "blink"
    )
    val cleaning = c.phase == CleanPhase.CLEANING
    val happy = c.phase == CleanPhase.DONE
    val spin by animateFloatAsState(
        if (cleaning) 720f else 0f,
        if (cleaning) tween<Float>(900, easing = FastOutSlowInEasing) else snap<Float>(), label = "spin"
    )
    val grow by animateFloatAsState(if (c.dragging) 1.12f else if (cleaning) 0.92f else 1f, tween(160), label = "grow")
    // Sólido en reposo; al tocarlo o agarrarlo se vuelve gelatina (0 = sólido, 1 = blandito).
    val soft by animateFloatAsState(if (c.pressed || c.dragging) 1f else 0f, tween(220), label = "soft")
    val dron = remember { Dron3D() }
    val lx by animateFloatAsState(c.look.x, tween(220), label = "lx")
    val ly by animateFloatAsState(c.look.y, tween(220), label = "ly")

    // De vez en cuando echa un vistazo a un lado.
    LaunchedEffect(Unit) {
        while (true) {
            delay(3200L + Random.nextLong(1500))
            if (!c.dragging) {
                c.look = Offset(if (Random.nextBoolean()) -1f else 1f, 0f)
                delay(900)
                if (!c.dragging) c.look = Offset.Zero
            }
        }
    }

    Canvas(
        Modifier
            .size(boxSize)
            .graphicsLayer {
                translationY = if (c.dragging || (c.skin != null && c.body != BodyType.SPHERE)) 0f else (bob - 0.5f) * 5.dp.toPx()
                rotationZ = spin
                scaleX = grow
                scaleY = grow
            }
    ) {
        val skin = c.skin
        if (skin != null && c.body != BodyType.SPHERE) {
            drawSkin(c, skin, bob)       // la figura de la foto (Forma.kt)
            return@Canvas
        }
        val d = this.size.minDimension
        val st = c.stretch.coerceIn(-0.4f, 0.5f)
        val ang = c.moveAngle * (kotlin.math.PI.toFloat() / 180f)
        val tt = (SystemClock.uptimeMillis() % 100000L) / 1000f
        val rip = soft * 0.045f + kotlin.math.abs(st) * 0.07f           // 0 = sólido
        val wob = soft * 0.6f * kotlin.math.sin(tt * 14f)                // aleta y alas tiemblan mientras lo tocan
        val open = if (blink > 0.945f && blink < 0.985f) 0.12f else if (cleaning) 0.5f else 1f
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            dron.draw(
                nc, d / 2f, d / 2f, d / 2f / 1.7f,
                c.yaw + lx * 0.22f, c.pitch + ly * 0.14f, c.roll,
                st, ang, rip, tt * 9f,
                st * kotlin.math.cos(ang) * 4f + wob, st * kotlin.math.sin(ang) * 4f + wob * 0.7f,
                if (cleaning) 1.6f else 1f
            )
            dron.drawIris(nc, open, lx, ly, happy)
        }
    }
}

// ───────────── Capa que flota sobre toda la app ─────────────

@Composable
fun CleanerLayer(c: CleanerState, store: Store, panelOpen: Boolean, onClosePanel: () -> Unit) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val mDp = if (c.skin != null && c.body != BodyType.SPHERE) MASCOT_SKIN else MASCOT
    val dPx = with(density) { mDp.toPx() }
    val dens = density.density
    var root by remember { mutableStateOf(IntSize.Zero) }
    var slot by remember { mutableStateOf(Rect.Zero) }
    val panelNow by rememberUpdatedState(panelOpen)
    LaunchedEffect(Unit) { c.resetShape() }      // Change shape ya no existe: el amigo vuelve a ser la esfera

    fun clamp(p: Offset) = Offset(
        p.x.coerceIn(0f, max(0f, root.width - dPx)),
        p.y.coerceIn(0f, max(0f, root.height - dPx))
    )
    fun current(): Offset = if (c.out) clamp(c.pos) else slot.center - Offset(dPx / 2, dPx / 2)

    fun randomTarget(from: Offset): Offset {
        val margin = 8f * dens
        val maxX = max(margin, root.width - dPx - margin)
        val maxY = max(margin, root.height - dPx - margin)
        var best = Offset(margin, margin)
        for (i in 0 until 5) {
            val cand = Offset(margin + Random.nextFloat() * (maxX - margin), margin + Random.nextFloat() * (maxY - margin))
            best = cand
            if (kotlin.math.hypot(cand.x - from.x, cand.y - from.y) > 140f * dens) break
        }
        return best
    }

    LaunchedEffect(panelOpen) { c.refresh() }
    LaunchedEffect(c.sayId) {
        if (c.say != null) { delay(c.sayMs); c.say = null }
    }

    // Cada cuadro: anda libre por la app cuando está fuera, se estira como gelatina y deja burbujitas.
    val visible = c.out || panelOpen
    LaunchedEffect(visible, dPx) {
        if (!visible) {
            c.bubbles.clear()
            c.tick = c.tick + 1
            return@LaunchedEffect
        }
        var last = 0L
        var prev = if (c.out) clamp(c.pos) else current()
        var target: Offset? = null
        var vel = Offset.Zero
        var idleUntil = 0L
        var dir = Offset(1f, 0f)
        var spd = 0f
        var spawn = 0f
        var wasDragging = false
        var gazeYaw = 0f
        var gazePitch = 0f
        var gazeAtMs = 0L
        var tripSpeed = 85f
        var hadBubbles = false
        while (true) {
            val now = withFrameNanos { it }
            if (last == 0L) { last = now; continue }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            last = now
            val nowMs = now / 1_000_000L

            if (c.dragging) {
                wasDragging = true
                target = null
                vel = Offset.Zero
            } else if (wasDragging) {
                wasDragging = false
                idleUntil = nowMs + 2500L            // al soltarlo, espera un poco antes de seguir paseando
            }

            // 0) Lanzado: sigue volando, rebota en los bordes (se aplasta al chocar) y se frena poco a poco.
            if (c.out && !c.dragging && root.width > 0 && (c.flyVel.x != 0f || c.flyVel.y != 0f)) {
                var fv = c.flyVel
                var fp = c.pos + Offset(fv.x * dt, fv.y * dt)
                val maxX = max(0f, root.width - dPx)
                val maxY = max(0f, root.height - dPx)
                var hit = 0f
                if (fp.x < 0f) { fp = Offset(0f, fp.y); hit = max(hit, kotlin.math.abs(fv.x)); fv = Offset(kotlin.math.abs(fv.x) * 0.82f, fv.y) }
                else if (fp.x > maxX) { fp = Offset(maxX, fp.y); hit = max(hit, kotlin.math.abs(fv.x)); fv = Offset(-kotlin.math.abs(fv.x) * 0.82f, fv.y) }
                if (fp.y < 0f) { fp = Offset(fp.x, 0f); hit = max(hit, kotlin.math.abs(fv.y)); fv = Offset(fv.x, kotlin.math.abs(fv.y) * 0.82f) }
                else if (fp.y > maxY) { fp = Offset(fp.x, maxY); hit = max(hit, kotlin.math.abs(fv.y)); fv = Offset(fv.x, -kotlin.math.abs(fv.y) * 0.82f) }
                val fr = (1f - 1.1f * dt).coerceAtLeast(0f)
                fv = Offset(fv.x * fr, fv.y * fr)
                c.pos = fp
                if (hit > 60f * dens) c.stretchVel -= (hit / dens / 260f).coerceAtMost(9f)   // ¡chof! se aplasta
                if (kotlin.math.hypot(fv.x, fv.y) < 30f * dens) {
                    fv = Offset.Zero
                    idleUntil = nowMs + 1500L
                    c.save()
                }
                c.flyVel = fv
            }
            val flying = c.flyVel.x != 0f || c.flyVel.y != 0f

            // 1) Pasea solo, sin prisa, por cualquier parte de la app.
            if (c.out && !c.dragging && !c.pressed && !panelNow && !c.settingsOpen && c.body != BodyType.OBJECT && root.width > 0 && !flying && nowMs >= idleUntil) {
                val p0 = clamp(c.pos)
                val tg: Offset = target ?: randomTarget(p0).also { target = it }
                val delta = tg - p0
                val dist = kotlin.math.hypot(delta.x, delta.y)
                if (dist < 6f * dens) {
                    target = null
                    vel = Offset.Zero
                    c.look = Offset.Zero
                    idleUntil = nowMs + 1200L + Random.nextLong(3200)
                    tripSpeed = 60f + Random.nextFloat() * 90f      // cada paseo a su ritmo
                    c.save()
                } else {
                    val maxSp = tripSpeed * dens
                    val slow = (dist / (70f * dens)).coerceIn(0.25f, 1f)
                    val k = (dt * 3f).coerceAtMost(1f)
                    // Camino curvo: se desvía a los lados mientras está lejos y se endereza al llegar.
                    val bend = kotlin.math.sin(nowMs / 650f) * 0.7f * (dist / (160f * dens)).coerceIn(0f, 1f)
                    val ux = delta.x / dist
                    val uy = delta.y / dist
                    val cb = kotlin.math.cos(bend)
                    val sb = kotlin.math.sin(bend)
                    val dx = ux * cb - uy * sb
                    val dy = ux * sb + uy * cb
                    vel = Offset(
                        vel.x + (dx * maxSp * slow - vel.x) * k,
                        vel.y + (dy * maxSp * slow - vel.y) * k
                    )
                    c.pos = clamp(Offset(p0.x + vel.x * dt, p0.y + vel.y * dt))
                    c.look = Offset(delta.x / dist, delta.y / dist)
                }
            }

            // 2) Velocidad y dirección reales de este cuadro.
            val cur = if (c.out) clamp(c.pos) else prev
            val mvx = cur.x - prev.x
            val mvy = cur.y - prev.y
            prev = cur
            val len = kotlin.math.hypot(mvx, mvy)
            spd += (len / dt - spd) * (dt * 12f).coerceAtMost(1f)
            if (len > 0.01f) {
                val kk = (dt * 10f).coerceAtMost(1f)
                dir = Offset(dir.x + (mvx / len - dir.x) * kk, dir.y + (mvy / len - dir.y) * kk)
            }
            c.moveAngle = kotlin.math.atan2(dir.y, dir.x) * 57.29578f

            // 2a) Caminar (forma de dos o cuatro patas): el paso avanza con la distancia recorrida y mira hacia donde va.
            if (c.body == BodyType.TWO_LEGS || c.body == BodyType.FOUR_LEGS) {
                val g = if (c.dragging || flying) 0f else (spd / dens / 60f).coerceIn(0f, 1f)
                c.gait += (g - c.gait) * (dt * 8f).coerceAtMost(1f)
                c.walk = (c.walk + spd / dens * dt / (if (c.body == BodyType.FOUR_LEGS) 34f else 42f)) % 1000f
                if (kotlin.math.abs(dir.x) > 0.25f && spd > 12f * dens) {
                    val want = if (dir.x >= 0f) 1f else -1f
                    c.faceX += (want - c.faceX) * (dt * 9f).coerceAtMost(1f)
                }
            } else if (c.gait != 0f || c.faceX != 1f) {
                c.gait = 0f
                c.faceX = 1f
            }

            // 2b) Giro 3D de la cara: mira hacia donde va; quieto, curiosea en todas direcciones y a veces da una vuelta entera.
            val moving = c.out && !c.dragging && spd > 12f * dens
            if (c.dragging) {
                gazeYaw = c.look.x * 1.2f
                gazePitch = c.look.y * 0.6f
            } else if (moving) {
                gazeYaw = dir.x * 1.25f
                gazePitch = dir.y * 0.7f
                gazeAtMs = nowMs + 600L
            } else if (nowMs >= gazeAtMs) {
                val twoPi = 6.2831855f
                val pi = 3.1415927f
                c.yaw = ((c.yaw + pi) % twoPi + twoPi) % twoPi - pi      // mismo aspecto, número pequeño
                gazeYaw = if (Random.nextInt(8) == 0) c.yaw + (if (Random.nextBoolean()) twoPi else -twoPi)
                          else (Random.nextFloat() * 2f - 1f) * 1.45f
                gazePitch = Random.nextFloat() * 1.1f - 0.55f
                gazeAtMs = nowMs + 1400L + Random.nextLong(2800)
            }
            // Lanzado, vuela dando vueltas en 3D (sin tope de giro); al frenar, vuelve por el camino corto a mirar de frente.
            if (flying) {
                val fvx = c.flyVel.x / dens
                val fvy = c.flyVel.y / dens
                val ks = (dt * 6f).coerceAtMost(1f)
                c.spinYaw += (fvx / 140f - c.spinYaw) * ks
                c.spinPitch += (-fvy / 140f - c.spinPitch) * ks
                c.spinRoll += (fvx / 420f - c.spinRoll) * ks
            }
            val spin3 = kotlin.math.abs(c.spinYaw) + kotlin.math.abs(c.spinPitch) + kotlin.math.abs(c.spinRoll)
            val kg = (dt * 4.5f).coerceAtMost(1f)
            if (spin3 > 0.35f) {
                c.spinYaw = c.spinYaw.coerceIn(-14f, 14f)
                c.spinPitch = c.spinPitch.coerceIn(-14f, 14f)
                c.spinRoll = c.spinRoll.coerceIn(-14f, 14f)
                c.yaw += c.spinYaw * dt
                c.pitch += c.spinPitch * dt
                c.roll += c.spinRoll * dt
                val damp = (1f - (if (flying) 0.4f else 2.2f) * dt).coerceAtLeast(0f)
                c.spinYaw *= damp; c.spinPitch *= damp; c.spinRoll *= damp
                c.spinning = true
                gazeAtMs = nowMs + 700L
            } else {
                if (c.spinning) {
                    c.spinning = false
                    c.spinYaw = 0f; c.spinPitch = 0f; c.spinRoll = 0f
                    c.yaw = wrapPi(c.yaw); c.pitch = wrapPi(c.pitch); c.roll = wrapPi(c.roll)
                }
                c.yaw += (gazeYaw - c.yaw) * kg
                c.pitch += (gazePitch - c.pitch) * kg
                // Se inclina hacia donde lo arrastran o hacia donde va.
                val bank = if (c.dragging) (-c.dragVel.x / dens / 1500f).coerceIn(-0.5f, 0.5f)
                           else if (moving) (-dir.x * (spd / dens / 140f).coerceIn(0f, 1f) * 0.4f) else 0f
                c.roll += (bank - c.roll) * kg
            }

            // 3) Gelatina: un resorte que estira al ir rápido y rebota al parar.
            val tgt = (spd / dens / 900f).coerceIn(0f, 0.30f)
            c.stretchVel += ((tgt - c.stretch) * 220f - c.stretchVel * 13f) * dt
            c.stretch = (c.stretch + c.stretchVel * dt).coerceIn(-0.45f, 0.5f)

            // 4) Burbujitas detrás, más cuanto más rápido va.
            if (c.out) {
                val rate = (spd / dens / 8f).coerceIn(0f, 38f)
                spawn += rate * dt
                while (spawn >= 1f && c.bubbles.size < 90) {
                    spawn -= 1f
                    val bx = cur.x + dPx / 2 - dir.x * dPx * 0.30f + (Random.nextFloat() - 0.5f) * dPx * 0.45f
                    val by = cur.y + dPx / 2 - dir.y * dPx * 0.30f + (Random.nextFloat() - 0.5f) * dPx * 0.45f
                    c.bubbles.add(
                        Bubble(
                            bx, by,
                            (Random.nextFloat() - 0.5f) * 10f * dens,
                            -(6f + Random.nextFloat() * 20f) * dens,
                            (1.2f + Random.nextFloat() * 2.6f) * dens,
                            0.9f + Random.nextFloat() * 0.9f,
                            Random.nextFloat() * 6.28f,
                            Random.nextInt(6) == 0
                        )
                    )
                }
                if (spawn > 1f) spawn = 1f
            }
            var i = c.bubbles.size - 1
            while (i >= 0) {
                val b = c.bubbles[i]
                b.age += dt
                if (b.age >= b.life) {
                    c.bubbles.removeAt(i)
                } else {
                    b.x += (b.vx + kotlin.math.sin(b.age * 4.5f + b.phase) * 7f * dens) * dt
                    b.y += b.vy * dt
                }
                i--
            }
            // Solo se repinta la estela mientras hay burbujitas: sin ellas, el lienzo de pantalla completa no se redibuja en cada cuadro.
            val hasBubbles = c.bubbles.isNotEmpty()
            if (hasBubbles || hadBubbles) c.tick = c.tick + 1
            hadBubbles = hasBubbles
        }
    }

    Box(Modifier.fillMaxSize().onSizeChanged { root = it }) {
        if (panelOpen) {
            CleanerPanel(
                c,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 66.dp, end = 8.dp),
                onSlot = { slot = it },
                onSettings = { c.settingsOpen = true; onClosePanel() }
            )
        }
        // Estela de burbujitas (debajo del amigo, sin recibir toques).
        if (c.out) {
            Canvas(Modifier.fillMaxSize()) {
                val redraw = c.tick                         // leerlo hace que se repinte en cada cuadro
                if (redraw >= 0) {
                    for (b in c.bubbles) {
                        val k = (1f - b.age / b.life).coerceIn(0f, 1f)
                        val col = if (b.pink) Pal.Pink else Color.White
                        val r = b.r * (1f + 0.35f * (1f - k))
                        val pos = Offset(b.x, b.y)
                        drawCircle(col.copy(alpha = 0.07f * k), r, pos)
                        drawCircle(col.copy(alpha = 0.55f * k), r, pos, style = Stroke(0.9.dp.toPx()))
                        drawCircle(Color.White.copy(alpha = 0.8f * k), r * 0.22f, Offset(b.x - r * 0.35f, b.y - r * 0.35f))
                    }
                }
            }
        }
        // No dibujarlo hasta saber el tamaño de la pantalla (y dónde está el hueco del panel): antes aparecía un instante en la esquina de arriba a la izquierda.
        val placed = root.width > 0 && (c.out || slot != Rect.Zero)
        if ((c.out || panelOpen) && placed) {
            // La posición se lee dentro de los bloques de layout (no al componer): mientras el amigo se mueve no se recompone toda la capa.
            val onRight by remember(dPx) { derivedStateOf { current().x + dPx / 2 > root.width / 2f } }
            Box(
                Modifier
                    .offset { val q = current(); IntOffset(q.x.roundToInt(), q.y.roundToInt()) }
                    .size(mDp)
                    .pointerInput(dPx) {
                        detectDragGestures(
                            onDragStart = {
                                if (!c.out) { c.pos = current(); c.out = true }   // sale del panel
                                c.dragging = true
                                c.flyVel = Offset.Zero
                                c.dragVel = Offset.Zero
                            },
                            onDragEnd = {
                                c.dragging = false
                                c.look = Offset.Zero
                                // Soltado sobre el hueco del panel (con el panel abierto): se guarda.
                                if (panelNow && slot.inflate(dPx * 0.15f).contains(clamp(c.pos) + Offset(dPx / 2, dPx / 2))) {
                                    c.out = false
                                    c.talk("Guardado")
                                }
                                // Si lo soltó en movimiento, sale lanzado (con tope de velocidad).
                                val sp = kotlin.math.hypot(c.dragVel.x, c.dragVel.y)
                                if (c.out && SystemClock.uptimeMillis() - c.dragLastMs < 90L && sp > 280f * dens) {
                                    val capK = (3400f * dens / sp).coerceAtMost(1f)
                                    c.flyVel = Offset(c.dragVel.x * capK, c.dragVel.y * capK)
                                }
                                c.dragVel = Offset.Zero
                                c.save()
                            },
                            onDragCancel = { c.dragging = false; c.look = Offset.Zero; c.dragVel = Offset.Zero; c.save() },
                            onDrag = { change, amount ->
                                change.consume()
                                val dtMs = (change.uptimeMillis - change.previousUptimeMillis).coerceAtLeast(1L)
                                c.dragVel = Offset(
                                    c.dragVel.x * 0.55f + amount.x * 1000f / dtMs * 0.45f,
                                    c.dragVel.y * 0.55f + amount.y * 1000f / dtMs * 0.45f
                                )
                                c.dragLastMs = change.uptimeMillis
                                c.pos = clamp(c.pos + amount)
                                val len = kotlin.math.hypot(amount.x, amount.y)
                                if (len > 0.5f) c.look = Offset(amount.x / len, amount.y / len)
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                c.pressed = true
                                c.flyVel = Offset.Zero            // si iba volando, el dedo lo atrapa
                                try { tryAwaitRelease() } finally { c.pressed = false }
                            },
                            onTap = { c.poke(); scope.launch { c.clean() } }
                        )
                    }
            ) { Mascot(c, mDp) }

            // Globito de texto al lado.
            val msg = c.say
            if (msg != null) {
                val bw = with(density) { 170.dp.toPx() }
                val gap = with(density) { 8.dp.toPx() }
                Box(
                    Modifier.offset {
                        val q = current()
                        val bx = if (onRight) q.x - bw - gap else q.x + dPx + gap
                        val by = q.y + dPx / 2 - 18.dp.toPx()
                        IntOffset(bx.roundToInt(), by.roundToInt())
                    }.width(170.dp),
                    contentAlignment = if (onRight) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    val shape = ChamferShape(8.dp)
                    Text(
                        msg, color = Pal.White, fontSize = 12.sp,
                        modifier = Modifier.clip(shape).background(Pal.Ink).border(1.dp, if (c.sayTappable) Pal.Pink else Pal.Line, shape)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
        // El "papel grande" de Ajustes, por encima de todo.
        if (c.settingsOpen) AjustesSheet(store) { c.settingsOpen = false }
    }
}

// ───────────── Mini panel ─────────────

@Composable
private fun CleanerPanel(c: CleanerState, modifier: Modifier, onSlot: (Rect) -> Unit, onSettings: () -> Unit) {
    val shape = ChamferShape(14.dp)
    Column(
        modifier
            .width(224.dp)
            .vidrio3D(shape, 16.dp, glow = true)
            .esquinasLuz()
            .clip(shape)
            .pointerInput(Unit) { detectTapGestures { } }       // que los toques no pasen a lo de abajo
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(12.dp).background(Pal.Accent))
            Spacer(Modifier.width(8.dp))
            Text("TU AMIGO", color = Pal.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(10.dp))
        // Hueco donde vive la esfera. Aquí se suelta para guardarla.
        Box(
            Modifier
                .fillMaxWidth()
                .height(104.dp)
                .onGloballyPositioned { onSlot(it.boundsInRoot()) }
                .drawBehind {
                    drawRoundRect(Pal.Accent.copy(alpha = 0.05f), cornerRadius = CornerRadius(10.dp.toPx()))
                    drawRoundRect(
                        Pal.Accent.copy(alpha = 0.45f), cornerRadius = CornerRadius(10.dp.toPx()),
                        style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                    )
                },
            contentAlignment = Alignment.BottomCenter
        ) {
            Text(
                if (c.out) "Suéltalo aquí\npara guardarlo" else "Arrástralo para sacarlo",
                color = Pal.Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 6.dp).then(if (c.out) Modifier.align(Alignment.Center) else Modifier)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Residuos", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(if (c.junk < 0) "…" else fmtSize(c.junk), color = Pal.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(6.dp))
        SegBar((c.junk.coerceAtLeast(0L) / (30f * 1024 * 1024)).coerceIn(0f, 1f), Modifier.fillMaxWidth(), segments = 20, height = 3.dp)
        Spacer(Modifier.height(6.dp))
        Text("Tócalo y limpia los residuos", color = Pal.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        // Ajustes, como enlace debajo.
        Text(
            "Ajustes", color = Pal.Muted, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(ChamferShape(6.dp)).clickable(onClick = onSettings).padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}
