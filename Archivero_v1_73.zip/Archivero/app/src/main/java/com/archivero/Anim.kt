package com.archivero

import android.app.ActivityManager
import android.content.Context
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Animaciones adaptativas: un solo sitio decide cuánto duran.
 * - [reduced] (interruptor del panel lateral, se recuerda): sin animaciones de transición.
 * - Teléfono de poca RAM: duran un 35 % menos (menos cuadros que dibujar).
 * - La escala de animaciones del sistema (Opciones de desarrollador / Accesibilidad) ya la respeta Compose por su cuenta.
 */
object Anim {
    var reduced by mutableStateOf(false)
        private set
    private var lowEnd = false
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("archivero", Context.MODE_PRIVATE)
        reduced = false      // ya no hay interruptor: las animaciones siempre están activas (solo se acortan en teléfonos de poca RAM)
        lowEnd = try { app.getSystemService(ActivityManager::class.java)?.isLowRamDevice == true } catch (e: Exception) { false }
    }

    fun alternar() {
        reduced = !reduced
        prefs?.edit()?.putBoolean("anim_reduced", reduced)?.apply()
    }

    /** Duración final en ms de una animación que normalmente dura [base] ms. */
    fun ms(base: Int): Int = when {
        reduced -> 0
        lowEnd -> base * 65 / 100
        else -> base
    }

    /** Curva "enfática" (entra rápido y se asienta despacio): la sensación de las transiciones de la referencia. */
    val enfatica = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    /** Curva de salida: arranca despacio y se va rápido, para que lo que sale no estorbe. */
    val salida = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    /** Resorte suave para movimientos con contacto (pulsar, soltar, asomar la hoja de la carpeta). */
    fun <T> resorte() = spring<T>(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
}
