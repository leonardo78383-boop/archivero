package com.archivero

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/*
 * Aspecto del amigo flotante (fuera de la app): esfera negra con un ojo grande de aro blanco brillante, un cuerno y dos escudos
 * plateados, cola de humo y volutas celestes. Todo se dibuja con código (sin imágenes), así queda nítido a cualquier resolución.
 * [Pose] es lo que una animación (ver Gestos.kt) le pide al dibujo en cada cuadro.
 */

private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f

// Objetos que pueden aparecer junto al amigo (se combinan con «or»).
internal const val P_HEAD = 1        // auriculares
internal const val P_NOTES = 2       // notas musicales que suben
internal const val P_HEARTS = 4
internal const val P_SPARK = 8       // destellos que giran
internal const val P_ZZZ = 16
internal const val P_Q = 32          // ?
internal const val P_EXC = 64        // !
internal const val P_SWEAT = 128     // gota de sudor
internal const val P_SHADES = 256    // gafas de sol
internal const val P_HAT = 512       // gorro de fiesta
internal const val P_STARS = 1024    // estrellitas de mareo
internal const val P_THINK = 2048    // burbuja de pensamiento
internal const val P_FLOWER = 4096
internal const val P_BOLT = 8192     // rayo

// Formas del ojo.
internal const val E_NORMAL = 0
internal const val E_DOWN = 1        // ojo cerrado feliz ‿
internal const val E_UP = 2          // ojo contento ⌒
internal const val E_HEART = 3
internal const val E_STAR = 4
internal const val E_SPIRAL = 5
internal const val E_LINE = 6        // ojo cerrado (dormido)
internal const val E_WIDE = 7        // ojo muy abierto

/** Lo que una animación le pide al dibujo en este cuadro (los desplazamientos van en «radios» del cuerpo). */
internal class Pose {
    var dx = 0f
    var dy = 0f
    var rot = 0f
    var sx = 1f
    var sy = 1f
    var eye = E_NORMAL
    var pupil = 1f
    var lookW = 0f          // 0 = mira como siempre; 1 = mira hacia (lx, ly)
    var lx = 0f
    var ly = 0f
    var props = 0
    var pw = 1f             // opacidad de los objetos (para que entren y salgan con suavidad)
    var horn = 0f
    var shL = 0f
    var shR = 0f
    var tail = 1f
    var aura = 1f
    var alpha = 1f

    fun reset() {
        dx = 0f; dy = 0f; rot = 0f; sx = 1f; sy = 1f
        eye = E_NORMAL; pupil = 1f; lookW = 0f; lx = 0f; ly = 0f
        props = 0; pw = 1f; horn = 0f; shL = 0f; shR = 0f
        tail = 1f; aura = 1f; alpha = 1f
    }
}

private fun has(m: Int, f: Int): Boolean = (m and f) != 0

private fun al(color: Int, a: Float): Int {
    val aa = (((color ushr 24) and 0xFF) * a.coerceIn(0f, 1f)).toInt()
    return (aa shl 24) or (color and 0xFFFFFF)
}

internal class AmigoArte(private val dens: Float) {
    private val aa = Paint.ANTI_ALIAS_FLAG
    private val body = Path()
    private val tailP = Path()
    private val wispP = Path()
    private val tmp = Path()
    private val box = RectF()
    private var baseR = 1f
    private val dron = Dron3D()           // el dron en 3D (Dron3D.kt): casco, lente, aleta y alas

    private val bodyFill = Paint(aa)
    private val rim = Paint(aa).apply { style = Paint.Style.STROKE; strokeWidth = 1.3f * dens; color = 0x883EC7E8.toInt() }
    private val hi = Paint(aa).apply { color = 0x2EFFFFFF }
    private val tailFill = Paint(aa)
    private val wispPaint = Paint(aa).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val silver = Paint(aa)
    private val silverEdge = Paint(aa).apply { style = Paint.Style.STROKE; strokeWidth = 0.045f; color = 0xFF6C7380.toInt(); strokeJoin = Paint.Join.ROUND }
    private val facet = Paint(aa).apply { color = 0xFFEAF6FA.toInt() }
    private val eyeGlow = Paint(aa)
    private val eyeRing = Paint(aa).apply { color = 0xFFFFFFFF.toInt() }
    private val pupilP = Paint(aa).apply { color = 0xFF030305.toInt() }
    private val lineP = Paint(aa).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt() }
    private val lineGlow = Paint(aa).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0x553EC7E8 }
    private val fillP = Paint(aa)
    private val band = Paint(aa).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val cupFill = Paint(aa)
    private val cupEdge = Paint(aa).apply { style = Paint.Style.STROKE }
    private val note = Paint(aa).apply { textAlign = Paint.Align.CENTER }
    private val txt = Paint(aa).apply { textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }

    // Formas en «unidades» (1 = el radio del cuerpo); se dibujan escaladas.
    private val horn = Path().apply {
        moveTo(-0.45f, 0.30f); quadTo(-0.20f, -0.55f, 0.62f, -0.78f); quadTo(0.12f, -0.30f, 0.20f, 0.30f); close()
    }
    private val hornFacet = Path().apply {
        moveTo(-0.14f, 0.06f); lineTo(0.0f, -0.12f); lineTo(0.14f, 0.06f); lineTo(0.0f, 0.22f); close()
    }
    private val shield = Path().apply {
        moveTo(-0.15f, -0.62f); quadTo(0.62f, -0.35f, 0.52f, 0.25f); quadTo(0.42f, 0.75f, -0.20f, 0.95f); quadTo(-0.05f, 0.20f, -0.15f, -0.62f); close()
    }
    private val shieldFacet = Path().apply {
        moveTo(0.12f, 0.08f); lineTo(0.30f, -0.12f); lineTo(0.38f, 0.14f); lineTo(0.20f, 0.30f); close()
    }
    private val claw = Path().apply {
        moveTo(0.35f, -0.55f); quadTo(-0.55f, -0.25f, -0.30f, 0.62f); quadTo(-0.12f, 0.05f, 0.35f, -0.55f); close()
    }
    private val clawFacet = Path().apply {
        moveTo(-0.05f, 0.05f); lineTo(0.05f, -0.12f); lineTo(0.12f, 0.08f); lineTo(0.0f, 0.2f); close()
    }
    private val heart = Path().apply {
        moveTo(0f, 0.9f); cubicTo(-1.3f, 0.1f, -0.9f, -0.9f, 0f, -0.35f); cubicTo(0.9f, -0.9f, 1.3f, 0.1f, 0f, 0.9f); close()
    }
    private val star = Path().apply {
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 1f else 0.45f
            val a = (-90f + i * 36f) * PI_F / 180f
            if (i == 0) moveTo(r * cos(a), r * sin(a)) else lineTo(r * cos(a), r * sin(a))
        }
        close()
    }
    private val spark = Path().apply {
        moveTo(0f, -1f); quadTo(0.12f, -0.12f, 1f, 0f); quadTo(0.12f, 0.12f, 0f, 1f); quadTo(-0.12f, 0.12f, -1f, 0f); quadTo(-0.12f, -0.12f, 0f, -1f); close()
    }
    private val drop = Path().apply {
        moveTo(0f, -1f); quadTo(0.95f, 0.1f, 0f, 0.95f); quadTo(-0.95f, 0.1f, 0f, -1f); close()
    }
    private val bolt = Path().apply {
        moveTo(0.2f, -1f); lineTo(-0.5f, 0.1f); lineTo(-0.05f, 0.1f); lineTo(-0.25f, 1f); lineTo(0.5f, -0.15f); lineTo(0.05f, -0.15f); close()
    }

    init {
        silver.shader = LinearGradient(
            -0.6f, -0.7f, 0.6f, 0.9f,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFB9C0CC.toInt(), 0xFFF2F5F9.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        eyeGlow.shader = RadialGradient(
            0f, 0f, 1.6f,
            intArrayOf(0x993EC7E8.toInt(), 0x003EC7E8), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    fun size(w: Int, h: Int) {
        val m = min(w, h).toFloat()
        baseR = m / 2f * 0.50f
        val r = baseR
        bodyFill.shader = RadialGradient(
            w / 2f - r * 0.30f, h / 2f - r * 0.40f, r * 1.7f,
            intArrayOf(0xFF30323C.toInt(), 0xFF0C0D12.toInt(), 0xFF020203.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        tailFill.shader = LinearGradient(
            0f, h / 2f + r * 0.5f, 0f, h / 2f + r * 2.1f,
            0xF0101218.toInt(), 0x00101218, Shader.TileMode.CLAMP
        )
        note.textSize = m * 0.16f
    }

    private fun buildBody(cx: Float, cy: Float, rad: Float, stretch: Float, angle: Float, bob: Float, playing: Boolean) {
        val st = stretch.coerceIn(-0.4f, 0.4f)
        val breathe = bob * (if (playing) 0.10f else 0.05f)
        val sx = (1f + st) * (1f + breathe)
        val sy = (1f / (1f + st)) * (1f - breathe)
        val ripple = 0.012f + abs(st) * 0.07f
        val phase = bob * TAU
        val ca = cos(angle)
        val sa = sin(angle)
        body.reset()
        val n = 48
        for (i in 0 until n) {
            val th = i * TAU / n
            val r = rad * (1f + ripple * sin(3f * th + phase))
            val x0 = r * cos(th)
            val y0 = r * sin(th)
            val xa = x0 * ca + y0 * sa
            val ya = -x0 * sa + y0 * ca
            val xs = xa * sx
            val ys = ya * sy
            val x = cx + xs * ca - ys * sa
            val y = cy + xs * sa + ys * ca
            if (i == 0) body.moveTo(x, y) else body.lineTo(x, y)
        }
        body.close()
    }

    private fun part(c: Canvas, path: Path, fac: Path, x: Float, y: Float, s: Float, deg: Float) {
        c.save()
        c.translate(x, y)
        c.rotate(deg)
        c.scale(s, s)
        c.drawPath(path, silver)
        c.drawPath(path, silverEdge)
        c.drawPath(fac, facet)
        c.restore()
    }

    private fun unit(c: Canvas, path: Path, x: Float, y: Float, s: Float, paint: Paint) {
        c.save()
        c.translate(x, y)
        c.scale(s, s)
        c.drawPath(path, paint)
        c.restore()
    }

    private fun wisp(c: Canvas, cx: Float, cy: Float, r: Float, tt: Float, side: Int, k: Int, aura: Float) {
        val x0 = cx + side * r * (1.45f + 0.12f * k)
        val y0 = cy + r * (0.75f - 0.45f * k)
        val y1 = y0 - r * 1.5f
        val s1 = sin(tt * 2f + k * 1.7f)
        val s2 = sin(tt * 1.7f + k + 1f)
        wispP.reset()
        wispP.moveTo(x0, y0)
        wispP.cubicTo(x0 + side * r * 0.45f * s1, y0 - r * 0.5f, x0 - side * r * 0.40f * s2, y0 - r * 1.0f, x0 + side * r * 0.12f * s1, y1)
        c.drawPath(wispP, wispPaint)
    }

    private fun tail(c: Canvas, cx: Float, cy: Float, r: Float, tt: Float, amp: Float) {
        val n = 10
        val len = r * 1.55f
        tailP.reset()
        for (i in 0..n) {
            val s = i / n.toFloat()
            val x = cx + sin(tt * 3f - s * 4f) * r * 0.28f * s * amp
            val y = cy + r * 0.55f + s * len
            val half = r * 0.30f * (1f - s) + 0.5f
            if (i == 0) tailP.moveTo(x - half, y) else tailP.lineTo(x - half, y)
        }
        for (i in n downTo 0) {
            val s = i / n.toFloat()
            val x = cx + sin(tt * 3f - s * 4f) * r * 0.28f * s * amp
            val y = cy + r * 0.55f + s * len
            val half = r * 0.30f * (1f - s) + 0.5f
            tailP.lineTo(x + half, y)
        }
        tailP.close()
        c.drawPath(tailP, tailFill)
    }

    fun draw(
        c: Canvas, w: Int, h: Int, p: Pose,
        stretch: Float, angle: Float, lookX: Float, lookY: Float, open: Float, bob: Float,
        grow: Float, playing: Boolean, noteT: Float, frozen: Boolean,
        yaw: Float = 0f, pitch: Float = 0f, roll: Float = 0f, soft: Float = 0f
    ) {
        val cx = w / 2f
        val cy = h / 2f
        val r = baseR
        val tt = (SystemClock.uptimeMillis() % 100000L) / 1000f
        val layer = p.alpha < 0.98f
        if (layer) c.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), (p.alpha * 255f).toInt().coerceIn(0, 255))
        c.save()
        c.translate(p.dx * r, p.dy * r)
        c.rotate(p.rot, cx, cy)
        c.scale(grow * p.sx, grow * p.sy, cx, cy)

        // El dron en 3D: gira a cualquier ángulo, es sólido en reposo y gelatina al tocarlo (soft = 0..1).
        val st = stretch.coerceIn(-0.4f, 0.5f)
        val rip = soft * 0.045f + abs(st) * 0.07f
        val wob = soft * 0.6f * sin(tt * 14f)
        val dance = if (playing) 0.20f * sin(tt * 6f) else 0f            // con música, se balancea
        val gx = (p.lx - lookX) * p.lookW                                // las animaciones también lo hacen mirar
        val gy = (p.ly - lookY) * p.lookW
        dron.draw(
            c, cx, cy, r * 1.18f,
            yaw + gx * 0.7f, pitch + gy * 0.5f, roll + dance,
            st, angle, rip, tt * 9f,
            st * cos(angle) * 4f + wob, st * sin(angle) * 4f + wob * 0.7f,
            0.7f + 0.3f * p.aura
        )

        // ojo: vive sobre el lente y gira con él (se estrecha de perfil y se esconde de espaldas)
        val lx = lookX + (p.lx - lookX) * p.lookW
        val ly = lookY + (p.ly - lookY) * p.lookW
        val facing = dron.lensFacing
        val ex = dron.lensCx
        val ey = dron.lensCy
        if (facing > 0.04f) {
            val lr = dron.lensRpx
            val ro = lr * 0.62f * (if (p.eye == E_WIDE) 1.12f else 1f)
            val rl = lr / 0.46f                                          // escala de los trazos del ojo
            val fade = facing < 0.3f
            c.save()
            c.concat(dron.lensMat)
            if (fade) c.saveLayerAlpha(-lr * 2f, -lr * 2f, lr * 2f, lr * 2f, (facing / 0.3f * 255f).toInt().coerceIn(0, 255))
            run {
                val ex = lx * lr * 0.08f
                val ey = ly * lr * 0.06f
            when (p.eye) {
                E_DOWN, E_UP -> {
                    lineP.strokeWidth = rl * 0.16f
                    lineGlow.strokeWidth = rl * 0.34f
                    if (p.eye == E_DOWN) box.set(ex - ro, ey - ro * 0.55f, ex + ro, ey + ro * 0.55f)
                    else box.set(ex - ro, ey - ro * 0.35f, ex + ro, ey + ro * 0.75f)
                    val a0 = if (p.eye == E_DOWN) 15f else 195f
                    c.drawArc(box, a0, 150f, false, lineGlow)
                    c.drawArc(box, a0, 150f, false, lineP)
                }
                E_HEART -> {
                    fillP.color = 0xFFFF6FA5.toInt()
                    unit(c, heart, ex, ey, ro * (1f + 0.08f * sin(tt * 8f)), fillP)
                }
                E_STAR -> {
                    fillP.color = 0xFFFFE27A.toInt()
                    unit(c, star, ex, ey, ro * 1.1f, fillP)
                }
                E_LINE -> {
                    lineP.strokeWidth = rl * 0.14f
                    c.drawLine(ex - ro, ey, ex + ro, ey, lineP)
                }
                E_SPIRAL -> {
                    c.drawCircle(ex, ey, ro, eyeRing)
                    tmp.reset()
                    for (k in 0..48) {
                        val a = k * 0.45f + tt * 8f
                        val rr = ro * 0.85f * k / 48f
                        val x = ex + rr * cos(a)
                        val y = ey + rr * sin(a)
                        if (k == 0) tmp.moveTo(x, y) else tmp.lineTo(x, y)
                    }
                    lineP.color = 0xFF030305.toInt()
                    lineP.strokeWidth = ro * 0.14f
                    c.drawPath(tmp, lineP)
                    lineP.color = 0xFFFFFFFF.toInt()
                }
                else -> {
                    c.save()
                    c.translate(ex, ey)
                    c.scale(ro, ro * open.coerceIn(0.08f, 1f))
                    c.drawCircle(0f, 0f, 1.6f, eyeGlow)
                    c.drawCircle(0f, 0f, 1f, eyeRing)
                    val pr = (if (p.eye == E_WIDE) 0.40f else 0.58f) * p.pupil
                    c.drawCircle(lx * 0.10f, ly * 0.10f, pr, pupilP)
                    c.restore()
                }
            }
            }
            if (fade) c.restore()
            c.restore()
        }

        props(c, cx, cy, ex, ey, r, p, tt, noteT)
        c.restore()
        if (layer) c.restore()
    }

    private fun props(c: Canvas, cx: Float, cy: Float, ex: Float, ey: Float, r: Float, p: Pose, tt: Float, noteT: Float) {
        val m = p.props
        if (m == 0) return
        val a = p.pw.coerceIn(0f, 1f)

        if (has(m, P_HEAD)) {
            band.color = al(0xFFDCE1E8.toInt(), a)
            band.strokeWidth = r * 0.17f
            box.set(cx - r * 1.12f, cy - r * 1.12f, cx + r * 1.12f, cy + r * 1.12f)
            c.drawArc(box, 190f, 160f, false, band)
            cupFill.color = al(0xFF22252C.toInt(), a)
            cupEdge.color = al(0xFF4FD6F0.toInt(), a)
            cupEdge.strokeWidth = r * 0.05f
            for (s in -1..1 step 2) {
                val x = cx + s * r * 1.10f
                val y = cy - r * 0.19f
                box.set(x - r * 0.17f, y - r * 0.30f, x + r * 0.17f, y + r * 0.30f)
                c.drawRoundRect(box, r * 0.12f, r * 0.12f, cupFill)
                c.drawRoundRect(box, r * 0.12f, r * 0.12f, cupEdge)
            }
        }
        if (has(m, P_NOTES)) {
            val t2 = (noteT + 0.5f) % 1f
            note.color = al(0xFFBFF3FF.toInt(), a * (1f - noteT))
            c.drawText("♪", cx + r * 1.25f, cy - r * 0.3f - noteT * r * 1.0f, note)
            note.color = al(0xFFBFF3FF.toInt(), a * (1f - t2))
            c.drawText("♫", cx - r * 1.3f, cy - r * 0.5f - t2 * r * 1.0f, note)
        }
        if (has(m, P_HEARTS)) {
            fillP.color = 0xFFFF6FA5.toInt()
            for (k in 0..2) {
                val ph = (noteT + k / 3f) % 1f
                fillP.color = al(0xFFFF6FA5.toInt(), a * (1f - ph))
                unit(c, heart, cx + (k - 1) * r * 0.55f + sin(ph * TAU) * r * 0.12f, cy - r * 0.9f - ph * r * 0.8f, r * 0.2f * (1f - ph * 0.3f), fillP)
            }
        }
        if (has(m, P_SPARK)) {
            for (k in 0..3) {
                val ang = tt * 2f + k * TAU / 4f
                fillP.color = al(0xFFE8FBFF.toInt(), a)
                unit(c, spark, cx + cos(ang) * r * 1.3f, cy + sin(ang) * r * 1.2f, r * (0.10f + 0.08f * abs(sin(tt * 5f + k))), fillP)
            }
        }
        if (has(m, P_ZZZ)) {
            for (k in 0..2) {
                val ph = (tt * 0.5f + k / 3f) % 1f
                txt.textSize = r * (0.35f + 0.5f * ph)
                txt.color = al(0xFFBFF3FF.toInt(), a * (1f - ph))
                c.drawText(if (k == 1) "Z" else "z", cx + r * 0.7f + ph * r * 0.6f, cy - r * 0.6f - ph * r * 0.9f, txt)
            }
        }
        if (has(m, P_Q) || has(m, P_EXC)) {
            txt.textSize = r * 1.0f
            txt.color = al(0xFFFFE27A.toInt(), a)
            c.drawText(if (has(m, P_Q)) "?" else "!", cx + r * 0.8f, cy - r * 0.95f + sin(tt * 6f) * r * 0.06f, txt)
        }
        if (has(m, P_SWEAT)) {
            val f = (tt * 1.2f) % 1f
            fillP.color = al(0xFF9FE8F7.toInt(), a * (1f - f))
            unit(c, drop, cx + r * 1.0f, cy - r * 0.5f + f * r * 0.5f, r * 0.17f, fillP)
        }
        if (has(m, P_SHADES)) {
            fillP.color = al(0xFF0A0A0F.toInt(), a)
            lineP.color = al(0xFF0A0A0F.toInt(), a)
            lineP.strokeWidth = r * 0.06f
            box.set(ex - r * 0.72f, ey - r * 0.25f, ex - r * 0.06f, ey + r * 0.25f)
            c.drawRoundRect(box, r * 0.14f, r * 0.14f, fillP)
            box.set(ex + r * 0.06f, ey - r * 0.25f, ex + r * 0.72f, ey + r * 0.25f)
            c.drawRoundRect(box, r * 0.14f, r * 0.14f, fillP)
            c.drawLine(ex - r * 0.08f, ey - r * 0.1f, ex + r * 0.08f, ey - r * 0.1f, lineP)
            lineP.color = al(0xAAFFFFFF.toInt(), a)
            c.drawLine(ex - r * 0.55f, ey - r * 0.15f, ex - r * 0.35f, ey + r * 0.05f, lineP)
            c.drawLine(ex + r * 0.25f, ey - r * 0.15f, ex + r * 0.45f, ey + r * 0.05f, lineP)
            lineP.color = 0xFFFFFFFF.toInt()
        }
        if (has(m, P_HAT)) {
            val bx = cx + r * 0.35f
            val by = cy - r * 0.92f
            c.save()
            c.rotate(14f, bx, by)
            tmp.reset()
            tmp.moveTo(bx - r * 0.28f, by); tmp.lineTo(bx + r * 0.28f, by); tmp.lineTo(bx, by - r * 0.8f); tmp.close()
            fillP.color = al(0xFFFF5FA2.toInt(), a)
            c.drawPath(tmp, fillP)
            fillP.color = al(0xFFFFE27A.toInt(), a)
            c.drawCircle(bx, by - r * 0.8f, r * 0.09f, fillP)
            c.restore()
        }
        if (has(m, P_STARS)) {
            for (k in 0..2) {
                val ang = tt * 4f + k * TAU / 3f
                fillP.color = al(0xFFFFE27A.toInt(), a)
                unit(c, star, cx + cos(ang) * r * 0.85f, cy - r * 1.15f + sin(ang) * r * 0.22f, r * 0.14f, fillP)
            }
        }
        if (has(m, P_THINK)) {
            fillP.color = al(0xAAE8FBFF.toInt(), a)
            c.drawCircle(cx + r * 0.9f, cy - r * 0.8f, r * 0.06f, fillP)
            c.drawCircle(cx + r * 1.08f, cy - r * 1.02f, r * 0.10f, fillP)
            c.drawCircle(cx + r * 1.32f, cy - r * 1.35f, r * (0.22f + 0.02f * sin(tt * 3f)), fillP)
        }
        if (has(m, P_FLOWER)) {
            val fx = cx + r * 0.5f
            val fy = cy - r * 1.0f
            fillP.color = al(0xFFFF8FC0.toInt(), a)
            for (k in 0..4) {
                val ang = k * TAU / 5f + tt
                c.drawCircle(fx + cos(ang) * r * 0.13f, fy + sin(ang) * r * 0.13f, r * 0.09f, fillP)
            }
            fillP.color = al(0xFFFFE27A.toInt(), a)
            c.drawCircle(fx, fy, r * 0.07f, fillP)
        }
        if (has(m, P_BOLT)) {
            fillP.color = al(0xFFFFE27A.toInt(), a * (0.6f + 0.4f * abs(sin(tt * 10f))))
            unit(c, bolt, cx - r * 1.3f, cy - r * 0.7f, r * 0.35f, fillP)
        }
    }
}
