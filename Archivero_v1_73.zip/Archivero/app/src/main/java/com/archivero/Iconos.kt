package com.archivero

import androidx.compose.animation.core.LinearEasing
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil

/** Rectángulo con la esquina superior derecha cortada en diagonal: el "sello" de la app (tarjetas, fichas, botón). */
class ChamferShape(private val cut: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { cut.toPx() }.coerceAtMost(minOf(size.width, size.height) / 2f)
        return Outline.Generic(Path().apply {
            moveTo(0f, 0f); lineTo(size.width - c, 0f); lineTo(size.width, c)
            lineTo(size.width, size.height); lineTo(0f, size.height); close()
        })
    }
}

/**
 * Rectángulo con cada esquina cortada en diagonal por separado ([tl] arriba-izq., [tr] arriba-der., [br] abajo-der., [bl] abajo-izq.).
 * Con 0.dp esa esquina queda recta. Es el "sello" del diseño nuevo (paneles de las referencias).
 */
class CutShape(
    private val tl: Dp = 0.dp, private val tr: Dp = 0.dp,
    private val br: Dp = 0.dp, private val bl: Dp = 0.dp
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val m = minOf(size.width, size.height) / 2f
        val a = with(density) { tl.toPx() }.coerceAtMost(m)
        val b = with(density) { tr.toPx() }.coerceAtMost(m)
        val c = with(density) { br.toPx() }.coerceAtMost(m)
        val d = with(density) { bl.toPx() }.coerceAtMost(m)
        val w = size.width
        val h = size.height
        return Outline.Generic(Path().apply {
            moveTo(a, 0f); lineTo(w - b, 0f); lineTo(w, b)
            lineTo(w, h - c); lineTo(w - c, h); lineTo(d, h)
            lineTo(0f, h - d); lineTo(0f, a); close()
        })
    }
}

/** Ruedita de carga: un arco fino que gira sobre un aro tenue. */
@Composable
fun ThinSpinner(d: Dp = 32.dp, color: Color = Pal.White) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart), label = "angle"
    )
    Canvas(Modifier.size(d)) {
        val sw = 2.dp.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(Pal.Line, 0f, 360f, false, tl, sz, style = Stroke(sw))
        drawArc(color, angle - 90f, 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
    }
}

/** Línea de carga fina (indeterminada). */
@Composable
fun ThinLoading(modifier: Modifier = Modifier.fillMaxWidth()) {
    LinearProgressIndicator(modifier = modifier.height(2.dp), color = Pal.White, trackColor = Pal.Line)
}

/** Barrita digital de puntos: se encienden uno tras otro hasta llegar a [frac] (0..1). */
@Composable
fun SegBar(frac: Float, modifier: Modifier = Modifier, segments: Int = 14, height: Dp = 4.dp) {
    val target = if (frac <= 0f) 0 else ceil(frac * segments).toInt().coerceIn(1, segments)
    val shown = remember { Animatable(0f) }
    LaunchedEffect(target) {
        shown.animateTo(target.toFloat(), tween(300 + 35 * target, easing = FastOutSlowInEasing))
    }
    Canvas(modifier.height(maxOf(height, 6.dp))) {
        val step = size.width / segments
        val r = minOf(size.height / 2f, step * 0.36f)
        val cy = size.height / 2f
        val on = shown.value
        for (i in 0 until segments) {
            val cx = step * (i + 0.5f)
            drawCircle(Pal.Line, r, Offset(cx, cy))
            val k = (on - i).coerceIn(0f, 1f)
            if (k > 0f) drawCircle(Pal.Accent, r * (0.6f + 0.4f * k), Offset(cx, cy), alpha = k)
        }
    }
}

/**
 * Carpeta con volumen: fondo con pestaña redondeada, una hoja que asoma y la tapa de adelante con degradado y brillo en el borde.
 * Se dibuja en una cuadrícula de 44 × 35,2 y se escala, así se ve nítida desde 26 dp hasta 60 dp.
 */
@Composable
fun FolderIcon(w: Dp = 44.dp, pressed: Boolean = false) {
    // Al pulsar: la carpeta se inclina un poco en 3D (como el video de referencia), se hunde un pelín y la hoja asoma hacia arriba.
    val t by animateFloatAsState(if (pressed) 1f else 0f, Anim.resorte(), label = "folderPress")
    Canvas(
        Modifier
            .size(w, w * 0.8f)
            .graphicsLayer {
                cameraDistance = 14f * density
                rotationY = -9f * t
                rotationX = 5f * t
                val k = 1f - 0.04f * t
                scaleX = k; scaleY = k
            }
    ) {
        val sx = size.width / 44f
        val sy = size.height / 35.2f
        val lift = 5.2f * t
        // Sombra de contacto: da la sensación de que la carpeta flota sobre el fondo AMOLED.
        drawOval(
            Brush.radialGradient(listOf(Color(0x66000000), Color.Transparent), Offset(size.width / 2f, size.height * 0.985f), size.width * 0.46f),
            Offset(size.width * 0.06f, size.height * 0.93f), Size(size.width * 0.88f, size.height * 0.14f)
        )
        val back = Path().apply {
            moveTo(3.1f * sx, 1.4f * sy); lineTo(15.2f * sx, 1.4f * sy)
            quadraticBezierTo(17f * sx, 1.4f * sy, 18f * sx, 2.8f * sy)
            lineTo(19.6f * sx, 5f * sy)
            quadraticBezierTo(20.4f * sx, 6.2f * sy, 21.9f * sx, 6.2f * sy)
            lineTo(40.9f * sx, 6.2f * sy)
            quadraticBezierTo(44f * sx, 6.2f * sy, 44f * sx, 9.3f * sy)
            lineTo(44f * sx, 32.1f * sy)
            quadraticBezierTo(44f * sx, 35.2f * sy, 40.9f * sx, 35.2f * sy)
            lineTo(3.1f * sx, 35.2f * sy)
            quadraticBezierTo(0f, 35.2f * sy, 0f, 32.1f * sy)
            lineTo(0f, 4.5f * sy)
            quadraticBezierTo(0f, 1.4f * sy, 3.1f * sx, 1.4f * sy)
            close()
        }
        drawPath(back, Brush.verticalGradient(listOf(Pal.FolderBack, Pal.FolderBackDark), 0f, size.height))
        // Brillo en el borde de la pestaña (volumen de la parte de atrás).
        drawLine(
            Color.White.copy(alpha = 0.35f), Offset(4f * sx, 2.1f * sy), Offset(15f * sx, 2.1f * sy),
            strokeWidth = (0.7f * sx).coerceAtLeast(1f), cap = StrokeCap.Round
        )
        // Hoja que asoma por detrás de la tapa (sube cuando se pulsa).
        drawRoundRect(
            Brush.verticalGradient(listOf(Pal.FolderPaper, Pal.FolderPaper.copy(alpha = 0.82f)), (8.4f - lift) * sy, (17.4f - lift) * sy),
            Offset(3.5f * sx, (8.4f - lift) * sy), Size(37f * sx, 9f * sy), CornerRadius(1.2f * sx)
        )
        // Sombra de la tapa sobre la hoja.
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color(0x55000000)), 8.6f * sy, 12.2f * sy),
            Offset(3.5f * sx, 8.6f * sy), Size(37f * sx, 3.6f * sy)
        )
        val front = Path().apply {
            moveTo(3.4f * sx, 12.2f * sy); lineTo(40.6f * sx, 12.2f * sy)
            quadraticBezierTo(44f * sx, 12.2f * sy, 44f * sx, 15.6f * sy)
            lineTo(44f * sx, 32f * sy)
            quadraticBezierTo(44f * sx, 35.2f * sy, 40.8f * sx, 35.2f * sy)
            lineTo(3.2f * sx, 35.2f * sy)
            quadraticBezierTo(0f, 35.2f * sy, 0f, 32f * sy)
            lineTo(0f, 15.6f * sy)
            quadraticBezierTo(0f, 12.2f * sy, 3.4f * sx, 12.2f * sy)
            close()
        }
        drawPath(front, Brush.verticalGradient(listOf(Pal.FolderFront, Pal.FolderFrontDark), 12.2f * sy, size.height))
        // Reflejo diagonal suave sobre la tapa (le da el aspecto de material pulido).
        drawPath(
            front,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.32f), Color.Transparent, Color.Black.copy(alpha = 0.18f)),
                Offset(0f, 12.2f * sy), Offset(size.width, size.height)
            )
        )
        drawLine(
            Pal.FolderEdge.copy(alpha = 0.9f), Offset(3.6f * sx, 12.9f * sy), Offset(40.4f * sx, 12.9f * sy),
            strokeWidth = (0.7f * sx).coerceAtLeast(1f), cap = StrokeCap.Round
        )
        // Canto fino inferior oscuro: separa la carpeta del fondo negro y le da grosor.
        drawLine(
            Color.Black.copy(alpha = 0.45f), Offset(3.2f * sx, 34.7f * sy), Offset(40.8f * sx, 34.7f * sy),
            strokeWidth = (0.9f * sx).coerceAtLeast(1f), cap = StrokeCap.Round
        )
    }
}

/**
 * Archivo: hoja con esquinas suaves y la esquina doblada, un dibujo de línea fina según el tipo
 * y la extensión en una pastilla plateada debajo.
 */
@Composable
fun FileIcon(isDir: Boolean, kind: Kind, ext: String, pressed: Boolean = false) {
    if (isDir) { FolderIcon(42.dp, pressed); return }
    Box(Modifier.size(34.dp, 42.dp), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 1.2.dp.toPx()
            val l = sw / 2; val t = sw / 2
            val r = size.width - sw / 2; val b = size.height - sw / 2
            val c = size.width * 0.29f           // tamaño de la esquina doblada
            val k = size.width * 0.09f           // redondeo de las esquinas
            val sheet = Path().apply {
                moveTo(l + k, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b - k)
                quadraticBezierTo(r, b, r - k, b); lineTo(l + k, b)
                quadraticBezierTo(l, b, l, b - k); lineTo(l, t + k)
                quadraticBezierTo(l, t, l + k, t); close()
            }
            drawPath(sheet, Brush.verticalGradient(if (Pal.light) listOf(Color(0xFFFFFFFF), Color(0xFFE6E6EC)) else listOf(Color(0xFF26262C), Color(0xFF101013)), 0f, size.height))
            val rim = Brush.linearGradient(
                listOf(Pal.White.copy(alpha = 0.85f), Pal.White.copy(alpha = 0.35f)),
                Offset(0f, 0f), Offset(size.width, size.height)
            )
            val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(sheet, rim, style = st)
            // Esquina doblada: un triangulito más claro.
            val fold = Path().apply {
                moveTo(r - c, t); lineTo(r - c, t + c - k * 0.8f)
                quadraticBezierTo(r - c, t + c, r - c + k * 0.8f, t + c); lineTo(r, t + c); close()
            }
            drawPath(fold, if (Pal.light) Color(0xFFD2D2DA) else Color(0xFF3A3A42))
            drawPath(fold, rim, style = st)
            glyph(kind, size.width / 2f, size.height * 0.40f, size.width * 0.15f, Pal.White.copy(alpha = 0.92f), st)
        }
        if (ext.isNotEmpty()) {
            val pill = RoundedCornerShape(50)
            Text(
                ext.take(4).uppercase(), color = Pal.Accent, fontSize = 7.sp, lineHeight = 9.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp, maxLines = 1,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .background(Pal.Accent.copy(alpha = 0.16f), pill)
                    .border(0.8.dp, Pal.Accent.copy(alpha = 0.75f), pill)
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
    }
}

private fun poly(p: List<Offset>, close: Boolean = false) = Path().apply {
    moveTo(p[0].x, p[0].y)
    for (i in 1 until p.size) lineTo(p[i].x, p[i].y)
    if (close) close()
}

/** Dibujo de línea de cada tipo; [u] es la unidad de medida (el dibujo mide unas 4,5 u de ancho). */
private fun DrawScope.glyph(kind: Kind, cx: Float, cy: Float, u: Float, color: Color, st: Stroke) {
    fun o(x: Float, y: Float) = Offset(cx + x * u, cy + y * u)
    when (kind) {
        Kind.IMG -> {
            drawPath(poly(listOf(o(-2.2f, 1.4f), o(-0.6f, -0.6f), o(0.4f, 0.6f), o(1.2f, -0.2f), o(2.2f, 1.4f))), color, style = st)
            drawCircle(color, u * 0.5f, o(-1.2f, -1.5f), style = st)
        }
        Kind.VID -> drawPath(poly(listOf(o(-1f, -1.6f), o(1.7f, 0f), o(-1f, 1.6f)), close = true), color, style = st)
        Kind.AUD -> {
            drawLine(color, o(0.9f, 1f), o(0.9f, -1.8f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawCircle(color, u * 1f, o(-0.2f, 1.2f), style = st)
            drawLine(color, o(0.9f, -1.8f), o(2.1f, -1f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
        Kind.APK -> {
            drawPath(poly(listOf(o(0f, -1.9f), o(1.7f, -0.95f), o(1.7f, 0.95f), o(0f, 1.9f), o(-1.7f, 0.95f), o(-1.7f, -0.95f)), close = true), color, style = st)
            drawPath(poly(listOf(o(-1.7f, -0.95f), o(0f, 0f), o(1.7f, -0.95f))), color, style = st)
            drawLine(color, o(0f, 0f), o(0f, 1.9f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
        else -> {
            drawLine(color, o(-1.8f, -1.2f), o(1.8f, -1.2f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(color, o(-1.8f, 0f), o(1.8f, 0f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(color, o(-1.8f, 1.2f), o(0.6f, 1.2f), strokeWidth = st.width, cap = StrokeCap.Round)
        }
    }
}


// ───────────── Íconos del panel lateral (línea fina, esquinas cortadas, un toque rosa) ─────────────

/** Casita: techo en ángulo, esquinas cortadas y la puerta en rosa. */
@Composable
fun HomeIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val body = Path().apply {
            moveTo(s * 0.5f, s * 0.08f)
            lineTo(s * 0.94f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.48f)
            lineTo(s * 0.06f, s * 0.48f)
            close()
        }
        drawPath(body, Pal.Card)
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        val door = Path().apply {
            moveTo(s * 0.42f, s * 0.92f); lineTo(s * 0.42f, s * 0.64f); lineTo(s * 0.58f, s * 0.64f); lineTo(s * 0.58f, s * 0.92f)
        }
        drawPath(door, Pal.Accent, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Papelera de reciclaje: tres flechas formando un triángulo (rosa) sobre línea blanca. */
@Composable
fun RecycleIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val cx = s * 0.5f
        val cy = s * 0.56f
        val r = s * 0.4f
        val pts = listOf(
            Offset(cx, cy - r),
            Offset(cx + r * 0.866f, cy + r * 0.5f),
            Offset(cx - r * 0.866f, cy + r * 0.5f)
        )
        for (i in 0 until 3) {
            val a = pts[i]
            val b = pts[(i + 1) % 3]
            val p0 = Offset(a.x + (b.x - a.x) * 0.16f, a.y + (b.y - a.y) * 0.16f)
            val p1 = Offset(a.x + (b.x - a.x) * 0.7f, a.y + (b.y - a.y) * 0.7f)
            drawLine(line, p0, p1, strokeWidth = sw, cap = StrokeCap.Round)
            // Punta de flecha: la dirección girada +150° y -150°.
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len = kotlin.math.sqrt(dx * dx + dy * dy)
            val ux = dx / len
            val uy = dy / len
            val h = s * 0.15f
            val lx = ux * (-0.866f) - uy * 0.5f
            val ly = ux * 0.5f + uy * (-0.866f)
            val rx = ux * (-0.866f) + uy * 0.5f
            val ry = -ux * 0.5f + uy * (-0.866f)
            drawLine(Pal.Accent, p1, Offset(p1.x + lx * h, p1.y + ly * h), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(Pal.Accent, p1, Offset(p1.x + rx * h, p1.y + ry * h), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Tacho de basura: tapa con asa, cuerpo con esquinas inferiores cortadas y rayitas en rosa. */
@Composable
fun TrashIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        drawLine(line, Offset(s * 0.12f, s * 0.26f), Offset(s * 0.88f, s * 0.26f), strokeWidth = sw, cap = StrokeCap.Round)
        val handle = Path().apply {
            moveTo(s * 0.38f, s * 0.26f); lineTo(s * 0.38f, s * 0.1f); lineTo(s * 0.62f, s * 0.1f); lineTo(s * 0.62f, s * 0.26f)
        }
        drawPath(handle, line, style = Stroke(sw, join = StrokeJoin.Round))
        val body = Path().apply {
            moveTo(s * 0.2f, s * 0.26f); lineTo(s * 0.2f, s * 0.82f); lineTo(s * 0.3f, s * 0.92f)
            lineTo(s * 0.7f, s * 0.92f); lineTo(s * 0.8f, s * 0.82f); lineTo(s * 0.8f, s * 0.26f)
        }
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        for (x in listOf(0.4f, 0.5f, 0.6f)) {
            drawLine(Pal.Accent, Offset(s * x, s * 0.42f), Offset(s * x, s * 0.78f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Candado de línea fina: cerrado o abierto, con el ojo de la cerradura en rosa. */
@Composable
fun LockIcon(open: Boolean = false, w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val shackle = Path().apply {
            if (open) {
                moveTo(s * 0.34f, s * 0.46f); lineTo(s * 0.34f, s * 0.28f)
                quadraticBezierTo(s * 0.34f, s * 0.1f, s * 0.52f, s * 0.1f)
                quadraticBezierTo(s * 0.68f, s * 0.1f, s * 0.7f, s * 0.24f)
            } else {
                moveTo(s * 0.32f, s * 0.46f); lineTo(s * 0.32f, s * 0.3f)
                quadraticBezierTo(s * 0.32f, s * 0.1f, s * 0.5f, s * 0.1f)
                quadraticBezierTo(s * 0.68f, s * 0.1f, s * 0.68f, s * 0.3f); lineTo(s * 0.68f, s * 0.46f)
            }
        }
        drawPath(shackle, line, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val body = Path().apply {
            moveTo(s * 0.2f, s * 0.46f); lineTo(s * 0.8f, s * 0.46f); lineTo(s * 0.8f, s * 0.84f)
            lineTo(s * 0.72f, s * 0.92f); lineTo(s * 0.28f, s * 0.92f); lineTo(s * 0.2f, s * 0.84f); close()
        }
        drawPath(body, Pal.Card)
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        drawCircle(Pal.Accent, s * 0.055f, Offset(s * 0.5f, s * 0.64f))
        drawLine(Pal.Accent, Offset(s * 0.5f, s * 0.64f), Offset(s * 0.5f, s * 0.76f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

/** Llave de línea fina: argolla con el centro rosa y dientes. */
@Composable
fun KeyIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        drawCircle(line, s * 0.19f, Offset(s * 0.29f, s * 0.35f), style = Stroke(sw))
        drawCircle(Pal.Accent, s * 0.05f, Offset(s * 0.29f, s * 0.35f))
        drawLine(line, Offset(s * 0.42f, s * 0.48f), Offset(s * 0.9f, s * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(s * 0.7f, s * 0.71f), Offset(s * 0.58f, s * 0.84f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(s * 0.82f, s * 0.82f), Offset(s * 0.72f, s * 0.93f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}
