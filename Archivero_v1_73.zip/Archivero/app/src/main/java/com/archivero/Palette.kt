package com.archivero

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Paleta de la app: grafito, plata y blanco (referencias: paneles negro/plata). Tiene dos temas (oscuro y claro).
 * Los colores se leen de [light], que es un estado: al cambiarlo, toda la app se repinta sola.
 * En el tema claro, White y Black se intercambian (White = tinta del texto, Black = fondo), así todo lo que ya existe se adapta.
 */
object Pal {
    var light by mutableStateOf(false)

    // Acento: plata fría (tema oscuro) / grafito (tema claro). Se mantiene el nombre Pink para no tocar el resto del código.
    val Pink: Color get() = if (light) Color(0xFF2B2F36) else Color(0xFFC9CED6)
    val AccentHi: Color get() = if (light) Color(0xFF4A505A) else Color(0xFFFFFFFF)   // parte alta del degradado del acento
    val Accent: Color get() = Pink
    val Sel: Color get() = if (light) Color(0xFFE4E6EA) else Color(0xFF1E2126)       // fondo de lo seleccionado

    // Carpeta: acero en dos tonos (tapa clara, fondo oscuro), como los íconos planos de la referencia.
    val FolderBack: Color get() = if (light) Color(0xFF6E747E) else Color(0xFF7A808A)
    val FolderBackDark: Color get() = if (light) Color(0xFF4C525B) else Color(0xFF565B63)
    val FolderFront: Color get() = if (light) Color(0xFFAEB4BE) else Color(0xFFE6E9EE)
    val FolderFrontDark: Color get() = if (light) Color(0xFF878E99) else Color(0xFFB4BAC4)
    val FolderEdge: Color get() = if (light) Color(0xFFD6DAE0) else Color(0xFFFFFFFF)
    val FolderPaper: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFFF4F6F8)
    val Black: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF000000)
    val Ink: Color get() = if (light) Color(0xFFF2F3F5) else Color(0xFF050607)     // superficies
    val Card: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF15171B)    // tarjetas / menús
    val Line: Color get() = if (light) Color(0xFFD5D8DD) else Color(0xFF2A2D33)    // líneas finas
    val White: Color get() = if (light) Color(0xFF0E1013) else Color(0xFFFFFFFF)
    val Muted: Color get() = if (light) Color(0xFF646A73) else Color(0xFF8D939C)   // texto secundario
}

/** Lee el tema guardado (al abrir la app). */
fun cargarTema(ctx: Context) {
    Pal.light = ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).getBoolean("claro", false)
}

/** Cambia entre tema claro y oscuro y lo recuerda. */
fun cambiarTema(ctx: Context, claro: Boolean) {
    Pal.light = claro
    ctx.getSharedPreferences("tema", Context.MODE_PRIVATE).edit().putBoolean("claro", claro).apply()
}
