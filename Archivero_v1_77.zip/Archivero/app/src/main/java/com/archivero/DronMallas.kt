package com.archivero

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Piezas del dron (revamp "blindado industrial"): casco de aleación grafito con textura de metal cepillado y rayones, banda
 * inferior de fibra de carbono, pods laterales con anillo neón cian, antena, aleta dorsal, base ventilada y placas con
 * rendijas luminosas. La paleta sale del explorador (grafito #2E3138 / #1A1C20 / #0E0F12, plata #8D939C / #C9CED6) y el cian
 * viene del diseño de referencia. Todo se dibuja con código (sin imágenes), igual que antes.
 */

internal const val DR_PI = 3.1415927f
internal const val DR_TAU = 6.2831855f

// Medidas del casco (elipsoide base).
internal const val DR_HA = 0.90f
internal const val DR_HB = 0.84f
internal const val DR_HC = 0.92f

// Cian de los detalles luminosos.
internal const val DR_CYR = 0.16f
internal const val DR_CYG = 0.88f
internal const val DR_CYB = 0.97f

// Eje de los pods laterales (centro en Y y Z) y cuánto salen hacia afuera.
internal const val DR_PCY = -0.02f
internal const val DR_PCZ = 0.02f
internal const val DR_PODX = 0.10f

// Casco partido en dos mallas: arriba el blindaje, abajo la banda de carbono. HULL_CUT es la fila de la costura.
internal const val DR_NLON = 48
internal const val DR_NLAT = 32
internal const val DR_CUT = 21

/** Una pieza del dron: vértices, normales, color base, brillo propio (em), cuánto se dobla (flex) y triángulos. */
internal class DronMesh(
    val n: Int,
    val px: FloatArray, val py: FloatArray, val pz: FloatArray,
    val nx: FloatArray, val ny: FloatArray, val nz: FloatArray,
    val br: FloatArray, val bg: FloatArray, val bb: FloatArray,
    val em: FloatArray, val flex: FloatArray,
    val tri: ShortArray
) {
    // Cuadro actual: posición 3D ya girada y deformada, posición en pantalla y color con luz.
    val vx = FloatArray(n)
    val vy = FloatArray(n)
    val vz = FloatArray(n)
    val scr = FloatArray(n * 2)
    val col = IntArray(n)
    val nzr = FloatArray(n)          // componente Z de la normal ya girada (>0 = mira a la cámara)
    val cx = px.average().toFloat()
    val cy = py.average().toFloat()
    val cz = pz.average().toFloat()

    /** Coordenadas de textura (en píxeles de la textura), si la pieza lleva textura. */
    var tex: FloatArray? = null
    /** Veces que se eleva al cuadrado el brillo especular (5 = ^32, 3 = ^8, 7 = ^128). */
    var gloss = 5
    var specK = 0.55f
    var envK = 0.55f
    /** Color del neón de esta pieza (por defecto cian) y su intensidad (pk): los aros de los pods los mueven cada cuadro. */
    var tr = DR_CYR
    var tg = DR_CYG
    var tb = DR_CYB
    var pk = 1f
}

internal fun dClamp(v: Float): Float = if (v < 0f) 0f else if (v > 1f) 1f else v

private fun spow(v: Float, e: Float): Float = sign(v) * Math.pow(abs(v).toDouble(), e.toDouble()).toFloat()

/** Punto del casco en (th = ángulo desde el polo de arriba, ph = giro; 0 = el frente +Z). Casi una esfera, un poco achatada. */
internal fun hullPos(th: Float, ph: Float, o: FloatArray) {
    val y = spow(cos(th), 0.96f)
    val ring = Math.pow(abs(sin(th)).toDouble(), 0.94).toFloat()
    val taper = 0.92f + 0.08f * (1f - abs(y))
    val x = spow(sin(ph), 0.95f) * ring * taper
    val z = spow(cos(ph), 0.95f) * ring * 1.02f
    o[0] = DR_HA * x; o[1] = DR_HB * y; o[2] = DR_HC * z
}

/** Normal aproximada (la del elipsoide) de un punto del casco. */
internal fun hullNormal(x: Float, y: Float, z: Float, o: FloatArray) {
    val ax = x / (DR_HA * DR_HA); val ay = y / (DR_HB * DR_HB); val az = z / (DR_HC * DR_HC)
    val l = max(1e-5f, sqrt(ax * ax + ay * ay + az * az))
    o[0] = ax / l; o[1] = ay / l; o[2] = az / l
}

/** Punto del casco en la dirección (dx, dy, dz) desde el centro, elevado [lift] sobre la superficie. Deja posición y normal. */
internal fun surfDir(dx: Float, dy: Float, dz: Float, lift: Float, pos: FloatArray, nrm: FloatArray) {
    val l = max(1e-5f, sqrt(dx * dx + dy * dy + dz * dz))
    val th = acos((dy / l).coerceIn(-1f, 1f))
    val ph = atan2(dx, dz)
    hullPos(th, ph, pos)
    hullNormal(pos[0], pos[1], pos[2], nrm)
    pos[0] += nrm[0] * lift; pos[1] += nrm[1] * lift; pos[2] += nrm[2] * lift
}

// ───────────── Texturas procedurales (se hacen una sola vez y las comparten todos los dron) ─────────────

internal object DronTex {
    const val BRUSH = 128
    const val CARBON = 32

    /** Metal cepillado con micro-rayones y algunas manchas de uso (gris claro, se multiplica con la luz). */
    val brush: Bitmap by lazy { makeBrush() }

    /** Tejido de fibra de carbono 2x2 (sarga). */
    val carbon: Bitmap by lazy { makeCarbon() }

    fun brushShader(): BitmapShader = BitmapShader(brush, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    fun carbonShader(): BitmapShader = BitmapShader(carbon, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

    private fun makeBrush(): Bitmap {
        val w = BRUSH
        val h = BRUSH
        val v = FloatArray(w * h)
        val rnd = java.util.Random(7L)
        for (i in v.indices) v[i] = 0.90f + (rnd.nextFloat() - 0.5f) * 0.07f
        // Vetas horizontales finas del cepillado.
        for (y in 0 until h) {
            val bias = (rnd.nextFloat() - 0.5f) * 0.06f
            for (x in 0 until w) v[y * w + x] += bias
        }
        // Rayones claros y oscuros.
        for (s in 0 until 150) {
            var x = rnd.nextInt(w).toFloat()
            var y = rnd.nextInt(h).toFloat()
            val len = 8 + rnd.nextInt(40)
            val ang = (rnd.nextFloat() - 0.5f) * 0.5f + (if (rnd.nextInt(6) == 0) 1.25f else 0f)
            val dx = cos(ang)
            val dy = sin(ang)
            val amt = if (rnd.nextInt(3) != 0) 0.075f else -0.11f
            for (t in 0 until len) {
                val xi = ((x.toInt() % w) + w) % w
                val yi = ((y.toInt() % h) + h) % h
                v[yi * w + xi] += amt * (1f - t.toFloat() / len)
                x += dx; y += dy
            }
        }
        // Manchas de desgaste.
        for (s in 0 until 12) {
            val cx = rnd.nextInt(w)
            val cy = rnd.nextInt(h)
            val rad = 3 + rnd.nextInt(5)
            for (yy in -rad..rad) for (xx in -rad..rad) {
                val d = sqrt((xx * xx + yy * yy).toFloat()) / rad
                if (d >= 1f) continue
                val xi = ((cx + xx) % w + w) % w
                val yi = ((cy + yy) % h + h) % h
                v[yi * w + xi] *= 1f - 0.07f * (1f - d)
            }
        }
        val px = IntArray(w * h)
        for (i in px.indices) {
            val g = (v[i].coerceIn(0.55f, 1f) * 255f).toInt()
            px[i] = (255 shl 24) or (g shl 16) or (g shl 8) or g
        }
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bm.setPixels(px, 0, w, 0, 0, w, h)
        bm.setHasMipMap(true)
        return bm
    }

    private fun makeCarbon(): Bitmap {
        val w = CARBON
        val h = CARBON
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val bx = x / 4
            val by = y / 4
            val horiz = ((bx + by) and 1) == 0
            val t = if (horiz) (y % 4) else (x % 4)
            val bump = 0.5f + 0.5f * sin((t + 0.5f) / 4f * DR_PI)          // el hilo es más claro en el lomo
            var g = 0.42f + 0.58f * bump
            if (!horiz) g *= 0.80f                                          // los hilos verticales pierden brillo
            g += 0.04f * sin((x + y) * 0.35f)
            val gi = (g.coerceIn(0.30f, 1f) * 255f).toInt()
            px[y * w + x] = (255 shl 24) or (gi shl 16) or (gi shl 8) or gi
        }
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bm.setPixels(px, 0, w, 0, 0, w, h)
        bm.setHasMipMap(true)
        return bm
    }
}

// ───────────── Casco ─────────────

/** Un tramo del casco entre las filas [i0] e [i1] (de [nlat]). Arriba: blindaje de aleación; abajo ([carbon]): fibra de carbono. */
internal fun buildHullPart(i0: Int, i1: Int, nlat: Int, nlon: Int, carbon: Boolean): DronMesh {
    val rows = i1 - i0 + 1
    val n = rows * (nlon + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val tex = FloatArray(n * 2)
    val p = FloatArray(3)
    val nn = FloatArray(3)
    val repU = if (carbon) 18f else 4f
    val repV = if (carbon) 9f else 2f
    val tw = (if (carbon) DronTex.CARBON else DronTex.BRUSH).toFloat()
    var k = 0
    for (ii in 0 until rows) {
        val i = i0 + ii
        val th = DR_PI * i / nlat
        for (j in 0..nlon) {
            val ph = DR_TAU * j / nlon
            hullPos(th, ph, p)
            hullNormal(p[0], p[1], p[2], nn)
            px[k] = p[0]; py[k] = p[1]; pz[k] = p[2]
            nx[k] = nn[0]; ny[k] = nn[1]; nz[k] = nn[2]
            val y = p[1] / DR_HB
            // Rebote del neón: el casco se tiñe de cian cerca de los pods y alrededor del lente.
            val spillX = dClamp((abs(p[0]) / DR_HA - 0.55f) / 0.35f)
            val dl = sqrt(p[0] * p[0] + p[1] * p[1])
            val spillL = if (p[2] > 0f) dClamp((0.80f - dl) / 0.35f) else 0f
            val sp = max(spillX * 0.6f, spillL * 0.5f)
            val base = if (carbon) 0.115f else 0.190f + 0.035f * y
            br[k] = base * 0.96f + sp * 0.008f
            bg[k] = base * 1.00f + sp * 0.035f
            bb[k] = base * 1.13f + sp * 0.045f
            tex[2 * k] = j.toFloat() / nlon * repU * tw
            tex[2 * k + 1] = i.toFloat() / nlat * repV * tw
            k++
        }
    }
    val tri = ShortArray((rows - 1) * nlon * 6)
    var t = 0
    for (i in 0 until rows - 1) for (j in 0 until nlon) {
        val a = i * (nlon + 1) + j
        val b = a + 1
        val c = a + nlon + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
    m.tex = tex
    if (carbon) { m.gloss = 3; m.specK = 0.34f; m.envK = 0.80f } else { m.gloss = 5; m.specK = 0.50f; m.envK = 0.62f }
    return m
}

// ───────────── Placas blindadas pegadas al casco (capó de arriba y cresta de atrás) ─────────────

/** Zona rectangular del casco (centro th0/ph0, medio ancho dth/dph en radianes) que se eleva [lift] como una placa con bisel. */
internal class DronCap(val th0: Float, val dth: Float, val ph0: Float, val dph: Float, val lift: Float)

/** Punto de la placa en (u, v) de -1 a 1, con la elevación ya aplicada. Deja posición y normal. */
internal fun capPoint(cp: DronCap, u: Float, v: Float, extra: Float, pos: FloatArray, nrm: FloatArray) {
    hullPos(cp.th0 + cp.dth * v, cp.ph0 + cp.dph * u, pos)
    hullNormal(pos[0], pos[1], pos[2], nrm)
    val edge = max(abs(u), abs(v))
    val l = cp.lift * (1f - 0.85f * dClamp((edge - 0.78f) / 0.22f)) + extra
    pos[0] += nrm[0] * l; pos[1] += nrm[1] * l; pos[2] += nrm[2] * l
}

internal fun buildCap(cp: DronCap, ni: Int, nj: Int, fr: Float, fg: Float, fb: Float, er: Float, eg: Float, eb: Float): DronMesh {
    val n = (ni + 1) * (nj + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val p = FloatArray(3)
    val nn = FloatArray(3)
    var k = 0
    for (i in 0..ni) {
        val v = -1f + 2f * i / ni
        for (j in 0..nj) {
            val u = -1f + 2f * j / nj
            capPoint(cp, u, v, 0f, p, nn)
            px[k] = p[0]; py[k] = p[1]; pz[k] = p[2]
            // La normal se inclina hacia afuera en el bisel para que el borde atrape luz.
            val edge = max(abs(u), abs(v))
            val bevel = dClamp((edge - 0.78f) / 0.22f)
            hullNormal(p[0], p[1], p[2], nn)
            nx[k] = nn[0]; ny[k] = nn[1]; nz[k] = nn[2]
            val m = bevel * bevel
            br[k] = fr + (er - fr) * m; bg[k] = fg + (eg - fg) * m; bb[k] = fb + (eb - fb) * m
            k++
        }
    }
    val tri = ShortArray(ni * nj * 6)
    var t = 0
    for (i in 0 until ni) for (j in 0 until nj) {
        val a = i * (nj + 1) + j
        val b = a + 1
        val c = a + nj + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
    m.gloss = 5; m.specK = 0.45f; m.envK = 0.60f
    return m
}

// ───────────── Aleta dorsal ─────────────

/** Triángulos de un tubo de [nv] caras con (ns + 1) anillos; cada cara son dos triángulos seguidos (a,c,b) y (b,c,d). */
internal fun ringTrisN(ns: Int, nv: Int): ShortArray {
    val tri = ShortArray(ns * nv * 6)
    var t = 0
    for (i in 0 until ns) for (q in 0 until nv) {
        val a = i * nv + q
        val b = i * nv + (q + 1) % nv
        val c = (i + 1) * nv + q
        val d = (i + 1) * nv + (q + 1) % nv
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    return tri
}

/** Aleta dorsal de aleación oscura: hoja gruesa y afilada que sube y se curva hacia atrás, con el filo del frente biselado. */
internal fun buildBlade(ns: Int): DronMesh {
    val n = (ns + 1) * 4
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val y0 = 0.42f; val z0 = -0.50f
    val y1 = 0.88f; val z1 = -0.62f
    val y2 = 1.12f; val z2 = -1.12f
    var k = 0
    for (i in 0..ns) {
        val s = i.toFloat() / ns
        val a = (1f - s) * (1f - s)
        val b = 2f * (1f - s) * s
        val c = s * s
        val sy = a * y0 + b * y1 + c * y2
        val sz = a * z0 + b * z1 + c * z2
        var ty = -2f * (1f - s) * y0 + 2f * (1f - 2f * s) * y1 + 2f * s * y2
        var tz = -2f * (1f - s) * z0 + 2f * (1f - 2f * s) * z1 + 2f * s * z2
        val tl = sqrt(ty * ty + tz * tz)
        ty /= tl; tz /= tl
        val ny0 = -tz
        val nz0 = ty
        val w = 0.42f * Math.pow((1f - s).toDouble(), 0.7).toFloat() + 0.015f
        val t = 0.17f * Math.pow((1f - s).toDouble(), 0.85).toFloat() + 0.014f
        for (q in 0 until 4) {
            when (q) {
                0 -> { px[k] = -w; py[k] = sy; pz[k] = sz; nx[k] = -1f; ny[k] = 0f; nz[k] = 0f }
                1 -> { px[k] = 0f; py[k] = sy + ny0 * t; pz[k] = sz + nz0 * t; nx[k] = 0f; ny[k] = ny0; nz[k] = nz0 }
                2 -> { px[k] = w; py[k] = sy; pz[k] = sz; nx[k] = 1f; ny[k] = 0f; nz[k] = 0f }
                else -> { px[k] = 0f; py[k] = sy - ny0 * t; pz[k] = sz - nz0 * t; nx[k] = 0f; ny[k] = -ny0; nz[k] = -nz0 }
            }
            if (q == 1) { br[k] = 0.22f; bg[k] = 0.235f; bb[k] = 0.27f } else { br[k] = 0.13f; bg[k] = 0.14f; bb[k] = 0.165f }
            fl[k] = s
            k++
        }
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, ringTrisN(ns, 4))
    m.gloss = 4; m.specK = 0.50f; m.envK = 0.60f
    return m
}

// ───────────── Antena ─────────────

/** Antena fina que sale de arriba-atrás de un costado; la punta brilla en cian y se dobla con la inercia. */
internal fun buildAntenna(bx: Float, by: Float, bz: Float, tx: Float, ty: Float, tz: Float, ns: Int, nv: Int): DronMesh {
    val n = (ns + 1) * nv
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    var dx = tx - bx; var dy = ty - by; var dz = tz - bz
    val dl = sqrt(dx * dx + dy * dy + dz * dz)
    dx /= dl; dy /= dl; dz /= dl
    // Base ortonormal perpendicular al eje (el eje va casi vertical).
    var e1x = dy * 1f - dz * 0f
    var e1y = dz * 0f - dx * 1f
    var e1z = dx * 0f - dy * 0f
    val e1l = sqrt(e1x * e1x + e1y * e1y + e1z * e1z)
    e1x /= e1l; e1y /= e1l; e1z /= e1l
    val e2x = dy * e1z - dz * e1y
    val e2y = dz * e1x - dx * e1z
    val e2z = dx * e1y - dy * e1x
    var k = 0
    for (i in 0..ns) {
        val s = i.toFloat() / ns
        val cx = bx + (tx - bx) * s
        val cy = by + (ty - by) * s
        val cz = bz + (tz - bz) * s
        val rad = if (i == 0) 0.060f else if (i == 1) 0.040f else 0.034f - 0.017f * s
        for (q in 0 until nv) {
            val a = DR_TAU * q / nv
            val ca = cos(a); val sa = sin(a)
            val ux = ca * e1x + sa * e2x
            val uy = ca * e1y + sa * e2y
            val uz = ca * e1z + sa * e2z
            px[k] = cx + ux * rad; py[k] = cy + uy * rad; pz[k] = cz + uz * rad
            nx[k] = ux; ny[k] = uy; nz[k] = uz
            if (i <= 1) { br[k] = 0.24f; bg[k] = 0.25f; bb[k] = 0.28f } else { br[k] = 0.13f; bg[k] = 0.14f; bb[k] = 0.165f }
            em[k] = if (i == ns) 1f else 0f
            fl[k] = s * 0.85f
            k++
        }
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, ringTrisN(ns, nv))
    m.gloss = 4; m.specK = 0.55f; m.envK = 0.55f
    return m
}

// ───────────── Pods laterales ─────────────

/** Cuerpo del pod (torno alrededor del eje X): pared de aleación, bisel, cara con aro hundido, recámara negra y bocina central. */
internal fun buildPod(side: Float, nu: Int = 32): DronMesh {
    val d = DR_PODX
    val sh = floatArrayOf(0.205f, 0.220f, 0.255f)
    val lt = floatArrayOf(0.290f, 0.305f, 0.345f)
    val dk = floatArrayOf(0.095f, 0.100f, 0.115f)
    val bk = floatArrayOf(0.030f, 0.034f, 0.042f)
    // Perfil: x, radio, normal axial, normal radial, emisión, color base (r, g, b).
    val prof = arrayOf(
        floatArrayOf(0.62f, 0.50f, 0f, 1f, 0f, sh[0], sh[1], sh[2]),
        floatArrayOf(0.94f + d, 0.50f, 0f, 1f, 0f, sh[0], sh[1], sh[2]),
        floatArrayOf(0.94f + d, 0.50f, 0.6f, 0.8f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.99f + d, 0.455f, 0.6f, 0.8f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.99f + d, 0.455f, 1f, 0f, 0f, dk[0], dk[1], dk[2]),
        floatArrayOf(0.99f + d, 0.360f, 1f, 0f, 0f, dk[0], dk[1], dk[2]),
        floatArrayOf(0.99f + d, 0.360f, 0.3f, -0.95f, 0f, sh[0], sh[1], sh[2]),
        floatArrayOf(0.93f + d, 0.335f, 0.3f, -0.95f, 0f, sh[0], sh[1], sh[2]),
        floatArrayOf(0.93f + d, 0.335f, 1f, 0f, 0f, bk[0], bk[1], bk[2]),
        floatArrayOf(0.93f + d, 0.240f, 1f, 0f, 0f, bk[0], bk[1], bk[2]),
        floatArrayOf(0.93f + d, 0.240f, 0f, 1f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.97f + d, 0.230f, 0f, 1f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.97f + d, 0.230f, 0.7f, 0.7f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.985f + d, 0.200f, 0.7f, 0.7f, 0f, lt[0], lt[1], lt[2]),
        floatArrayOf(0.985f + d, 0.200f, 1f, 0f, 0f, bk[0], bk[1], bk[2]),
        floatArrayOf(0.985f + d, 0.000f, 1f, 0f, 0f, bk[0], bk[1], bk[2])
    )
    val np = prof.size
    val n = np * (nu + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    var k = 0
    for (i in 0 until np) {
        val q = prof[i]
        for (j in 0..nu) {
            val u = DR_TAU * j / nu
            val cu = cos(u); val su = sin(u)
            px[k] = side * q[0]
            py[k] = DR_PCY + q[1] * cu
            pz[k] = DR_PCZ + q[1] * su
            nx[k] = side * q[2]; ny[k] = q[3] * cu; nz[k] = q[3] * su
            em[k] = q[4]
            br[k] = q[5]; bg[k] = q[6]; bb[k] = q[7]
            k++
        }
    }
    val tri = ShortArray((np - 1) * nu * 6)
    var t = 0
    for (i in 0 until np - 1) for (j in 0 until nu) {
        val a = i * (nu + 1) + j
        val b = a + 1
        val c = a + nu + 1
        val dd = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = dd.toShort()
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
    m.gloss = 5; m.specK = 0.55f; m.envK = 0.65f
    return m
}

/** Aro neón del pod: tubo cian que brilla (centro casi blanco, bordes cian), asentado en la cara del pod. */
internal fun buildNeonRing(side: Float, major: Float, minor: Float, nu: Int = 40, nv: Int = 8): DronMesh {
    val n = (nu + 1) * (nv + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    val xc = 0.99f + DR_PODX
    var k = 0
    for (i in 0..nu) {
        val u = DR_TAU * i / nu
        val cu = cos(u); val su = sin(u)
        for (j in 0..nv) {
            val v = DR_TAU * j / nv
            val cv = cos(v); val sv = sin(v)
            px[k] = side * (xc + minor * sv * 0.9f)
            py[k] = DR_PCY + (major + minor * cv) * cu
            pz[k] = DR_PCZ + (major + minor * cv) * su
            nx[k] = side * sv; ny[k] = cv * cu; nz[k] = cv * su
            br[k] = DR_CYR; bg[k] = DR_CYG; bb[k] = DR_CYB
            em[k] = 1f
            k++
        }
    }
    val tri = ShortArray(nu * nv * 6)
    var t = 0
    for (i in 0 until nu) for (j in 0 until nv) {
        val a = i * (nv + 1) + j
        val b = a + 1
        val c = a + nv + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    return DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
}

// ───────────── Base ventilada ─────────────

/** Chasis de abajo (torno alrededor del eje Y): collar, escalón, rejilla de ventilación y tira neón cian en el fondo. */
internal fun buildBase(nu: Int = 28): DronMesh {
    val sh = floatArrayOf(0.205f, 0.220f, 0.255f)
    val lt = floatArrayOf(0.290f, 0.305f, 0.345f)
    val dk = floatArrayOf(0.060f, 0.065f, 0.078f)
    val cy = floatArrayOf(DR_CYR, DR_CYG, DR_CYB)
    // Perfil: radio, y, normal radial, normal Y, emisión, color base.
    val rows = ArrayList<FloatArray>()
    fun row(r: Float, y: Float, nr: Float, ny: Float, e: Float, c: FloatArray) {
        rows.add(floatArrayOf(r, y, nr, ny, e, c[0], c[1], c[2]))
    }
    row(0.50f, -0.72f, 1f, 0f, 0f, sh)
    row(0.57f, -0.90f, 0.95f, -0.3f, 0f, sh)
    row(0.57f, -0.97f, 1f, 0f, 0f, sh)
    row(0.57f, -0.97f, 0.6f, -0.8f, 0f, lt)
    row(0.52f, -1.00f, 0.6f, -0.8f, 0f, lt)
    // Rejilla: franjas alternadas claro/oscuro (cada franja lleva sus propios vértices para que el corte sea nítido).
    var y = -1.00f
    for (s in 0 until 6) {
        val c = if (s % 2 == 0) sh else dk
        row(0.52f, y, 1f, 0f, 0f, c)
        y -= 0.0165f
        row(0.52f, y, 1f, 0f, 0f, c)
    }
    row(0.52f, y, 0.6f, -0.8f, 0f, lt)
    row(0.40f, y - 0.03f, 0.6f, -0.8f, 0f, lt)
    row(0.40f, y - 0.03f, 1f, 0f, 0f, sh)
    row(0.40f, y - 0.05f, 1f, 0f, 0f, sh)
    row(0.40f, y - 0.05f, 1f, 0f, 1f, cy)           // tira neón del fondo
    row(0.40f, y - 0.075f, 1f, 0f, 1f, cy)
    row(0.40f, y - 0.075f, 0f, -1f, 0f, dk)
    row(0.00f, y - 0.075f, 0f, -1f, 0f, dk)
    val np = rows.size
    val n = np * (nu + 1)
    val px = FloatArray(n); val py = FloatArray(n); val pz = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val br = FloatArray(n); val bg = FloatArray(n); val bb = FloatArray(n)
    val em = FloatArray(n); val fl = FloatArray(n)
    var k = 0
    for (i in 0 until np) {
        val q = rows[i]
        for (j in 0..nu) {
            val u = DR_TAU * j / nu
            val cu = cos(u); val su = sin(u)
            px[k] = q[0] * cu; py[k] = q[1]; pz[k] = q[0] * su
            nx[k] = q[2] * cu; ny[k] = q[3]; nz[k] = q[2] * su
            em[k] = q[4]
            br[k] = q[5]; bg[k] = q[6]; bb[k] = q[7]
            k++
        }
    }
    val tri = ShortArray((np - 1) * nu * 6)
    var t = 0
    for (i in 0 until np - 1) for (j in 0 until nu) {
        val a = i * (nu + 1) + j
        val b = a + 1
        val c = a + nu + 1
        val d = c + 1
        tri[t++] = a.toShort(); tri[t++] = c.toShort(); tri[t++] = b.toShort()
        tri[t++] = b.toShort(); tri[t++] = c.toShort(); tri[t++] = d.toShort()
    }
    val m = DronMesh(n, px, py, pz, nx, ny, nz, br, bg, bb, em, fl, tri)
    m.gloss = 4; m.specK = 0.50f; m.envK = 0.60f
    return m
}
