package com.archivero

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * El dron (amigo flotante) en 3D de verdad, dibujado con código. Revamp "blindado industrial" según el diseño de referencia:
 *  - Casco esférico de aleación grafito (metal cepillado con rayones y desgaste) y banda inferior de fibra de carbono tejida.
 *  - Un gran lente de cristal negro con aro neón cian y bisel atornillado; fila de 4 LEDs bajo el lente.
 *  - Dos pods laterales tipo audífono (aro neón cian + bocina central), antena con punta luminosa y aleta dorsal.
 *  - Capó superior con rejilla de barras cian, cresta trasera con barras cian, panel de carbono atrás y base ventilada con
 *    tira neón en el fondo.
 *  - Colores de metal sacados del explorador (grafito #2E3138 / #1A1C20 / #0E0F12 y plata #C9CED6); el cian, de la referencia.
 *  - Gira a CUALQUIER ángulo sin límites, es sólido en reposo y gelatina al tocarlo (la antena y la aleta se doblan con la inercia).
 *  - Se pinta sobre fondo transparente (AMOLED). La API pública no cambió: draw(), drawIris(), lensFacing/lensCx/lensCy/lensRpx/lensMat.
 * Las mallas y texturas viven en DronMallas.kt. Lo usan la mascota de dentro de la app (Limpiador.kt) y la esfera flotante (Aspecto.kt).
 */

// Cámara y luz.
private const val FOCAL = 7f
private const val LX = -0.40f
private const val LY = 0.55f
private const val LZ = 0.73f
private const val HXV = -0.25f
private const val HYV = 0.33f
private const val HZV = 0.91f
// Luz de relleno fría (abajo a la derecha), para que el lado sombreado no quede plano.
private const val FX = 0.62f
private const val FY = -0.35f
private const val FZ = 0.70f

/** Línea o panel pegado al casco: puntos con su normal, para saber cuándo se ven. */
private class Belt(val n: Int, val x: FloatArray, val y: FloatArray, val z: FloatArray, val nx: FloatArray, val ny: FloatArray, val nz: FloatArray)

/** Línea sobre el casco que sigue puntos (th, ph) de control, con [steps] pasos entre cada par. */
private fun beltFromParams(ctrl: FloatArray, steps: Int): Belt {
    val legs = ctrl.size / 2 - 1
    val n = legs * steps + 1
    val x = FloatArray(n); val y = FloatArray(n); val z = FloatArray(n)
    val nx = FloatArray(n); val ny = FloatArray(n); val nz = FloatArray(n)
    val p = FloatArray(3)
    val nn = FloatArray(3)
    for (i in 0 until n) {
        val leg = if (i == n - 1) legs - 1 else i / steps
        val u = if (i == n - 1) 1f else (i % steps).toFloat() / steps
        val t0 = ctrl[2 * leg]; val f0 = ctrl[2 * leg + 1]
        val t1 = ctrl[2 * leg + 2]; val f1 = ctrl[2 * leg + 3]
        hullPos(t0 + (t1 - t0) * u, f0 + (f1 - f0) * u, p)
        hullNormal(p[0], p[1], p[2], nn)
        x[i] = p[0]; y[i] = p[1]; z[i] = p[2]
        nx[i] = nn[0]; ny[i] = nn[1]; nz[i] = nn[2]
    }
    return Belt(n, x, y, z, nx, ny, nz)
}

/** Anillo completo del casco en la fila [row] (la costura entre el blindaje y la fibra de carbono). */
private fun rowBelt(row: Int): Belt {
    val th = DR_PI * row / DR_NLAT
    val n = 72
    val ctrl = FloatArray((n + 1) * 2)
    for (i in 0..n) { ctrl[2 * i] = th; ctrl[2 * i + 1] = DR_TAU * i / n }
    return beltFromParams(ctrl, 1)
}

private fun deg(a: Float): Float = a * 0.017453292f

internal class Dron3D {
    private val hullTop = buildHullPart(0, DR_CUT, DR_NLAT, DR_NLON, false)
    private val hullBot = buildHullPart(DR_CUT, DR_NLAT, DR_NLAT, DR_NLON, true)
    private val blade = buildBlade(9)
    private val antenna = buildAntenna(0.48f, 0.59f, -0.39f, 0.56f, 1.38f, -0.56f, 7, 6)
    private val podL = buildPod(-1f)
    private val podR = buildPod(1f)
    private val ringL = buildNeonRing(-1f, 0.41f, 0.05f)
    private val ringR = buildNeonRing(1f, 0.41f, 0.05f)
    private val base = buildBase()

    // Capó de arriba (con rejilla de barras cian). Las barras de atrás van en la cara de abajo de la aleta.
    private val hoodCap = DronCap(deg(38f), deg(15f), 0f, deg(30f), 0.05f)
    private val hood = buildCap(hoodCap, 6, 10, 0.25f, 0.265f, 0.30f, 0.10f, 0.11f, 0.125f)

    // Líneas de panel.
    private val seamBelt = rowBelt(DR_CUT)
    private val frameBelt = beltFromParams(
        floatArrayOf(deg(112f), deg(-52f), deg(36f), deg(-52f), deg(36f), deg(52f), deg(112f), deg(52f)), 14
    )
    private val sideBeltL = beltFromParams(floatArrayOf(deg(34f), deg(-104f), deg(116f), deg(-104f)), 20)
    private val sideBeltR = beltFromParams(floatArrayOf(deg(34f), deg(104f), deg(116f), deg(104f)), 20)
    private val rearPanel = beltFromParams(
        floatArrayOf(
            deg(124f), deg(138f), deg(124f), deg(222f), deg(145f), deg(222f), deg(152f), deg(212f),
            deg(152f), deg(148f), deg(145f), deg(138f), deg(124f), deg(138f)
        ), 8
    )

    // Marcadores sobre el casco: cada uno son 6 números (x, y, z, nx, ny, nz).
    private val dotsP: FloatArray
    private val screwsP: FloatArray
    private val ledA = FloatArray(6)
    private val ledB = FloatArray(6)

    private val box = RectF()

    // Rotación actual (3x3, por filas).
    private val r = FloatArray(9)
    private var cs = 1f
    private var sn = 0f
    private var sxs = 1f
    private var sys = 1f
    private var rip = 0f
    private var ph = 0f
    private var fx = 0f
    private var fy = 0f
    private var s = 1f
    private var cx0 = 0f
    private var cy0 = 0f
    private var glow = 1f
    private var neonK = 1f        // intensidad del neón de los aros (pulso)
    private var neonG = 1f        // fuerza del resplandor de los aros (pulso)
    private var neonRgb = 0x0030E6FF

    // Salida del último cuadro: dónde quedó el lente, qué tan de frente está y su matriz (1 unidad = 1 px de frente).
    var lensFacing = 0f
        private set
    var lensCx = 0f
        private set
    var lensCy = 0f
        private set
    var lensRpx = 1f
        private set
    val lensMat = Matrix()

    private var ox = 0f
    private var oy = 0f
    private var oz = 0f
    private val m9 = FloatArray(9)
    private val tmpPath = Path()
    private val silPath = Path()
    private val ringPath = Path()
    private val binX = FloatArray(BINS)
    private val binY = FloatArray(BINS)
    private val binR = FloatArray(BINS)
    private val tp = FloatArray(3)
    private val tn = FloatArray(3)
    private val tp2 = FloatArray(3)
    private val tn2 = FloatArray(3)

    // Búferes para ordenar triángulos (del tamaño de la malla con MÁS triángulos).
    private val maxTris = maxOf(
        blade.tri.size, antenna.tri.size, podL.tri.size, podR.tri.size, ringL.tri.size, ringR.tri.size,
        base.tri.size, hood.tri.size, hullTop.tri.size, hullBot.tri.size
    ) / 3
    private val keyZ = FloatArray(maxTris)
    private val ord = IntArray(maxTris)
    private val ord2 = IntArray(maxTris)
    private val keyB = IntArray(maxTris)
    private val bucket = IntArray(NB + 1)
    private val sidx = ShortArray(maxTris * 3)

    private val vertPaint = Paint()
    private val brushPaint = Paint().apply { shader = DronTex.brushShader(); isFilterBitmap = true }
    private val carbonPaint = Paint().apply { shader = DronTex.carbonShader(); isFilterBitmap = true }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloMat = Matrix()
    private val haloShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(0x2236E0F5, 0x1236E0F5, 0x0636E0F5, 0x0036E0F5),
        floatArrayOf(0f, 0.45f, 0.75f, 1f), Shader.TileMode.CLAMP
    )
    private val irisGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val irisRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val irisFill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        val dl = ArrayList<Float>()
        fun addMarker(list: ArrayList<Float>, dx: Float, dy: Float, dz: Float, lift: Float) {
            surfDir(dx, dy, dz, lift, tp, tn)
            list.add(tp[0]); list.add(tp[1]); list.add(tp[2]); list.add(tn[0]); list.add(tn[1]); list.add(tn[2])
        }
        // Fila de 4 LEDs bajo el lente.
        for (cl in 0 until 4) addMarker(dl, -0.12f + 0.08f * cl, -0.60f, 0.80f, 0.012f)
        // Dos racimos triangulares en los costados de arriba (como puntos braille).
        for (side in intArrayOf(-1, 1)) for (rw in 0 until 4) for (cl in 0 until 4 - rw) {
            addMarker(dl, side * 0.56f, 0.46f + 0.07f * rw, 0.22f - 0.07f * cl, 0.010f)
        }
        dotsP = dl.toFloatArray()
        val sl = ArrayList<Float>()
        // Cuatro tornillos del bisel del lente.
        for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) addMarker(sl, sx * 0.38f, sy * 0.38f, 0.78f, 0.016f)
        // Tornillos de las esquinas del capó.
        addMarker(sl, -0.30f, 0.74f, 0.45f, 0.052f); addMarker(sl, 0.30f, 0.74f, 0.45f, 0.052f)
        screwsP = sl.toFloatArray()
        surfDir(-0.15f, -0.60f, 0.80f, 0.010f, tp, tn)
        for (i in 0 until 3) { ledA[i] = tp[i]; ledA[3 + i] = tn[i] }
        surfDir(0.15f, -0.60f, 0.80f, 0.010f, tp, tn)
        for (i in 0 until 3) { ledB[i] = tp[i]; ledB[3 + i] = tn[i] }
    }

    /** Matriz de giro de Euler: primero yaw (izquierda/derecha), luego pitch (arriba/abajo) y roll (de lado). Los ángulos no tienen tope. */
    private fun setEuler(yaw: Float, pitch: Float, roll: Float) {
        val cy = cos(yaw); val sy = sin(yaw)
        val cp = cos(pitch); val sp = sin(pitch)
        val cr = cos(roll); val sr = sin(roll)
        val a0 = cy; val a1 = 0f; val a2 = sy
        val b0 = sp * sy; val b1 = cp; val b2 = -sp * cy
        val c0 = -cp * sy; val c1 = sp; val c2 = cp * cy
        r[0] = cr * a0 - sr * b0; r[1] = cr * a1 - sr * b1; r[2] = cr * a2 - sr * b2
        r[3] = sr * a0 + cr * b0; r[4] = sr * a1 + cr * b1; r[5] = sr * a2 + cr * b2
        r[6] = c0; r[7] = c1; r[8] = c2
    }

    /** Pasa un punto del modelo a pantalla con el mismo giro y la misma gelatina que el cuerpo. Deja el resultado en ox, oy, oz. */
    private fun pt(mx: Float, my: Float, mz: Float) {
        val x = r[0] * mx + r[1] * my + r[2] * mz
        val y = r[3] * mx + r[4] * my + r[5] * mz
        val z = r[6] * mx + r[7] * my + r[8] * mz
        var u = x * cs + y * sn
        var v = -x * sn + y * cs
        u *= sxs; v *= sys
        var xx = u * cs - v * sn
        var yy = u * sn + v * cs
        var zz = z
        if (rip > 0.0005f) {
            val k = 1f + rip * sin(4.2f * (xx * 0.7f + yy * 0.7f + zz * 0.4f) + ph)
            xx *= k; yy *= k; zz *= k
        }
        val p = FOCAL / (FOCAL - zz)
        ox = cx0 + xx * s * p
        oy = cy0 - yy * s * p
        oz = zz
    }

    private fun transform(m: DronMesh) {
        for (i in 0 until m.n) {
            val mx = m.px[i]; val my = m.py[i]; val mz = m.pz[i]
            val x = r[0] * mx + r[1] * my + r[2] * mz
            val y = r[3] * mx + r[4] * my + r[5] * mz
            val z = r[6] * mx + r[7] * my + r[8] * mz
            var u = x * cs + y * sn
            var v = -x * sn + y * cs
            u *= sxs; v *= sys
            var xx = u * cs - v * sn
            var yy = u * sn + v * cs
            var zz = z
            if (rip > 0.0005f) {
                val k = 1f + rip * sin(4.2f * (xx * 0.7f + yy * 0.7f + zz * 0.4f) + ph)
                xx *= k; yy *= k; zz *= k
            }
            val fl = m.flex[i]
            if (fl > 0f) { xx -= fx * fl * 0.25f; yy -= fy * fl * 0.25f }
            m.vx[i] = xx; m.vy[i] = yy; m.vz[i] = zz
            val p = FOCAL / (FOCAL - zz)
            m.scr[2 * i] = cx0 + xx * s * p
            m.scr[2 * i + 1] = cy0 - yy * s * p
        }
    }

    /**
     * Luz por vértice: Lambert + reflejo de "cielo" (arriba claro, abajo oscuro, como metal pulido en estudio) + brillo
     * especular + luz de relleno fría + borde cian por Fresnel. Lo que brilla (em) se mezcla con el cian neón.
     */
    private fun light(m: DronMesh) {
        val g = m.gloss
        val specK = m.specK
        val envK = m.envK
        for (i in 0 until m.n) {
            val ax = m.nx[i]; val ay = m.ny[i]; val az = m.nz[i]
            val nx = r[0] * ax + r[1] * ay + r[2] * az
            val ny = r[3] * ax + r[4] * ay + r[5] * az
            val nz = r[6] * ax + r[7] * ay + r[8] * az
            m.nzr[i] = nz
            val lam = max(0f, nx * LX + ny * LY + nz * LZ)
            val lam2 = max(0f, nx * FX + ny * FY + nz * FZ)
            var sp = max(0f, nx * HXV + ny * HYV + nz * HZV)
            for (q in 0 until g) sp *= sp
            val env = dClamp(0.5f + nz * ny)                      // 0.5 + 0.5 * (2 * nz * ny): el reflejo mira al cielo o al suelo
            val fr0 = 1f - dClamp(nz)
            val fres = fr0 * fr0
            val k = 0.32f + 0.70f * lam + 0.16f * lam2 + envK * env * env
            var rr = m.br[i] * k + sp * specK + fres * DR_CYR * 0.22f
            var gg = m.bg[i] * k + sp * specK + fres * DR_CYG * 0.22f
            var bl = m.bb[i] * k + sp * specK + fres * DR_CYB * 0.22f
            val em = m.em[i]
            val e = dClamp(em * glow)
            if (e > 0f) {
                if (em >= 0.85f) {
                    // Tubo de neón: centro casi blanco (del mismo tono), bordes del color del neón; pk = pulso.
                    val c1 = dClamp(nz)
                    val core = c1 * c1
                    val wr = m.tr + (1f - m.tr) * 0.78f
                    val wg = m.tg + (1f - m.tg) * 0.78f
                    val wb = m.tb + (1f - m.tb) * 0.78f
                    val tr = (m.tr + (wr - m.tr) * core) * m.pk
                    val tg = (m.tg + (wg - m.tg) * core) * m.pk
                    val tb = (m.tb + (wb - m.tb) * core) * m.pk
                    rr = rr * (1f - e) + tr * e
                    gg = gg * (1f - e) + tg * e
                    bl = bl * (1f - e) + tb * e
                } else {
                    val ke = 0.55f + 0.45f * lam
                    rr = rr * (1f - e) + DR_CYR * ke * e
                    gg = gg * (1f - e) + DR_CYG * ke * e
                    bl = bl * (1f - e) + DR_CYB * ke * e
                }
            }
            val ir = (dClamp(rr) * 255f).toInt()
            val ig = (dClamp(gg) * 255f).toInt()
            val ib = (dClamp(bl) * 255f).toInt()
            m.col[i] = (255 shl 24) or (ir shl 16) or (ig shl 8) or ib
        }
    }

    /**
     * Dibuja el dron centrado en (cx, cy); [scale] = píxeles por unidad del modelo (el casco mide ~0.9 unidades de radio).
     * [yaw]/[pitch]/[roll]: orientación en radianes, sin límites.
     * [st] y [ang]: estiramiento de gelatina (>0 estirado, <0 aplastado) y hacia dónde (radianes).
     * [rip]: ondulación (0 = sólido), [phase]: fase de la onda, [flexX]/[flexY]: cuánto se doblan aleta y antena.
     * [glowK]: 1 = brillo normal.
     */
    fun draw(
        c: Canvas, cx: Float, cy: Float, scale: Float,
        yaw: Float, pitch: Float, roll: Float,
        st: Float, ang: Float, ripple: Float, phase: Float, flexX: Float, flexY: Float, glowK: Float
    ) {
        setEuler(yaw, pitch, roll)
        val stc = st.coerceIn(-0.4f, 0.5f)
        cs = cos(ang); sn = sin(ang)
        sxs = 1f + stc; sys = 1f / (1f + stc)
        rip = ripple; ph = phase
        fx = flexX; fy = flexY
        s = scale; cx0 = cx; cy0 = cy
        glow = glowK

        // Halo AMOLED: resplandor cian suave detrás (negro puro alrededor).
        val hr = scale * 1.75f
        haloMat.setScale(hr, hr)
        haloMat.postTranslate(cx, cy)
        haloShader.setLocalMatrix(haloMat)
        haloP.shader = haloShader
        c.drawCircle(cx, cy, hr, haloP)

        // Neón de los aros laterales: color elegido y pulso al ritmo (solo estos aros; el resto del cian no cambia).
        val nm = DronNeon.modo
        val pul = DronNeon.pulso()
        neonK = if (pul < 0f) 1f else 0.38f + 0.80f * pul
        neonG = if (pul < 0f) 1f else 0.40f + 1.10f * pul
        val nr = DronNeon.r(nm); val ng = DronNeon.g(nm); val nb = DronNeon.b(nm)
        ringL.tr = nr; ringL.tg = ng; ringL.tb = nb; ringL.pk = neonK
        ringR.tr = nr; ringR.tg = ng; ringR.tb = nb; ringR.pk = neonK
        neonRgb = ((nr * 255f).toInt() shl 16) or ((ng * 255f).toInt() shl 8) or (nb * 255f).toInt()

        transform(hullTop); transform(hullBot); transform(blade); transform(antenna)
        transform(podL); transform(podR); transform(ringL); transform(ringR)
        transform(base); transform(hood)
        light(hullTop); light(hullBot); light(blade); light(antenna)
        light(podL); light(podR); light(ringL); light(ringR)
        light(base); light(hood)

        // Piezas que quedan detrás del casco se pintan primero; las de delante, al final.
        val zBlade = r[6] * blade.cx + r[7] * blade.cy + r[8] * blade.cz
        val zAnt = r[6] * antenna.cx + r[7] * antenna.cy + r[8] * antenna.cz
        val zBase = r[7] * -1.05f
        // Un pod pasa al frente solo cuando su cara mira bastante a la cámara; si no, el casco lo tapa por dentro.
        val podLFront = -r[6] > 0.35f
        val podRFront = r[6] > 0.35f

        if (zBase < 0f) drawBase(c)
        if (zBlade < 0f) drawBlade(c)
        if (zAnt < 0f) drawAntenna(c)
        if (!podLFront) drawPod(c, podL, ringL, -1f)
        if (!podRFront) drawPod(c, podR, ringR, 1f)

        drawHull(c)
        drawSeams(c)
        drawCap(c, hood, hoodCap, 6, 0.62f, -0.62f, 0.62f, 0.014f)
        drawLedPlate(c)
        drawMarkers(c, screwsP, 0.019f, true)
        drawMarkers(c, dotsP, 0.018f, false)
        drawLens(c)

        if (zBase >= 0f) drawBase(c)
        if (zBlade >= 0f) drawBlade(c)
        if (zAnt >= 0f) drawAntenna(c)
        if (podLFront) drawPod(c, podL, ringL, -1f)
        if (podRFront) drawPod(c, podR, ringR, 1f)
    }

    // ───────────── Ordenar y pintar mallas ─────────────

    /** Pinta una pieza (pods, antena, base, placas) con sombreado suave: triángulos de lejos a cerca en una sola llamada. */
    private fun drawSorted(c: Canvas, m: DronMesh, cut: Float) {
        val nt = m.tri.size / 3
        var cnt = 0
        var zmin = Float.MAX_VALUE
        var zmax = -Float.MAX_VALUE
        for (t in 0 until nt) {
            val a = m.tri[3 * t].toInt(); val b = m.tri[3 * t + 1].toInt(); val d = m.tri[3 * t + 2].toInt()
            if ((m.nzr[a] + m.nzr[b] + m.nzr[d]) / 3f < cut) continue       // da la espalda: no se ve
            val z = (m.vz[a] + m.vz[b] + m.vz[d]) / 3f
            keyZ[cnt] = z
            ord[cnt] = t
            if (z < zmin) zmin = z
            if (z > zmax) zmax = z
            cnt++
        }
        if (cnt == 0) return
        val span = max(zmax - zmin, 1e-4f)
        java.util.Arrays.fill(bucket, 0)
        for (i in 0 until cnt) {
            var bk = ((keyZ[i] - zmin) / span * (NB - 1)).toInt()
            if (bk < 0) bk = 0 else if (bk > NB - 1) bk = NB - 1
            keyB[i] = bk
            bucket[bk + 1]++
        }
        for (b in 1..NB) bucket[b] += bucket[b - 1]
        for (i in 0 until cnt) ord2[bucket[keyB[i]]++] = ord[i]
        var w = 0
        for (o in 0 until cnt) {
            val t = ord2[o]
            sidx[w++] = m.tri[3 * t]; sidx[w++] = m.tri[3 * t + 1]; sidx[w++] = m.tri[3 * t + 2]
        }
        c.drawVertices(Canvas.VertexMode.TRIANGLES, m.n * 2, m.scr, 0, null, 0, m.col, 0, sidx, 0, w, vertPaint)
    }

    /** Pinta un tramo del casco (convexo: basta quedarse con los triángulos de cara) con su textura de material. */
    private fun drawHullPart(c: Canvas, m: DronMesh, paint: Paint) {
        var cnt = 0
        val t = m.tri
        var k = 0
        while (k < t.size) {
            val a = t[k].toInt(); val b = t[k + 1].toInt(); val d = t[k + 2].toInt()
            val cross = (m.vx[b] - m.vx[a]) * (m.vy[d] - m.vy[a]) - (m.vy[b] - m.vy[a]) * (m.vx[d] - m.vx[a])
            if (cross > 0f) { sidx[cnt++] = t[k]; sidx[cnt++] = t[k + 1]; sidx[cnt++] = t[k + 2] }
            k += 3
        }
        if (cnt > 0) {
            c.drawVertices(Canvas.VertexMode.TRIANGLES, m.n * 2, m.scr, 0, m.tex, 0, m.col, 0, sidx, 0, cnt, paint)
        }
    }

    private fun binMesh(m: DronMesh, mx: Float, my: Float) {
        for (i in 0 until m.n) {
            val dx = m.scr[2 * i] - mx
            val dy = m.scr[2 * i + 1] - my
            val a = atan2(dy, dx)
            var b = ((a + DR_PI) / DR_TAU * BINS).toInt()
            if (b >= BINS) b = BINS - 1
            if (b < 0) b = 0
            val d = dx * dx + dy * dy
            if (d > binR[b]) { binR[b] = d; binX[b] = m.scr[2 * i]; binY[b] = m.scr[2 * i + 1] }
        }
    }

    private fun drawHull(c: Canvas) {
        // Silueta: el punto más lejano del centro en cada rebanada de ángulo (el casco es convexo).
        var mx = 0f
        var my = 0f
        for (i in 0 until hullTop.n) { mx += hullTop.scr[2 * i]; my += hullTop.scr[2 * i + 1] }
        for (i in 0 until hullBot.n) { mx += hullBot.scr[2 * i]; my += hullBot.scr[2 * i + 1] }
        val tot = hullTop.n + hullBot.n
        mx /= tot; my /= tot
        for (b in 0 until BINS) binR[b] = -1f
        binMesh(hullTop, mx, my)
        binMesh(hullBot, mx, my)
        silPath.reset()
        var started = false
        for (b in 0 until BINS) {
            if (binR[b] < 0f) continue
            if (!started) { silPath.moveTo(binX[b], binY[b]); started = true } else silPath.lineTo(binX[b], binY[b])
        }
        silPath.close()
        // Relleno oscuro (quita los dientes de la malla en el contorno).
        fillP.color = 0xFF121418.toInt()
        c.drawPath(silPath, fillP)

        drawHullPart(c, hullTop, brushPaint)
        drawHullPart(c, hullBot, carbonPaint)

        // Borde: un halo cian tenue y un filo plateado fino (luz de borde).
        strokeP.strokeWidth = max(1.2f, s * 0.034f)
        strokeP.color = 0x2236E0F5
        c.drawPath(silPath, strokeP)
        strokeP.strokeWidth = max(0.8f, s * 0.010f)
        strokeP.color = 0x88AEB6C0.toInt()
        c.drawPath(silPath, strokeP)
    }

    // ───────────── Líneas de panel, placas y marcadores ─────────────

    /** Surco oscuro con un hilo de luz al lado (borde biselado), solo en los tramos que miran a la cámara. */
    private fun drawBelt(c: Canvas, b: Belt, groove: Int, gw: Float, light: Int, lw: Float, closed: Boolean) {
        ringPath.reset()
        var pen = false
        for (i in 0 until b.n) {
            val nzv = r[6] * b.nx[i] + r[7] * b.ny[i] + r[8] * b.nz[i]
            if (nzv <= 0.06f) { pen = false; continue }
            pt(b.x[i] * 1.006f, b.y[i] * 1.006f, b.z[i] * 1.006f)
            if (!pen) { ringPath.moveTo(ox, oy); pen = true } else ringPath.lineTo(ox, oy)
        }
        val off = max(0.6f, s * 0.008f)
        c.save()
        c.translate(off, off)
        strokeP.strokeWidth = lw
        strokeP.color = light
        c.drawPath(ringPath, strokeP)
        c.restore()
        strokeP.strokeWidth = gw
        strokeP.color = groove
        c.drawPath(ringPath, strokeP)
    }

    private fun drawSeams(c: Canvas) {
        val gw = max(1f, s * 0.020f)
        val lw = max(0.7f, s * 0.010f)
        drawBelt(c, seamBelt, 0xDD050607.toInt(), max(1.2f, s * 0.028f), 0x55C9CED6, lw, true)
        drawBelt(c, frameBelt, 0xCC060708.toInt(), gw, 0x38C9CED6, lw, false)
        drawBelt(c, sideBeltL, 0xAA060708.toInt(), gw * 0.85f, 0x2EC9CED6, lw, false)
        drawBelt(c, sideBeltR, 0xAA060708.toInt(), gw * 0.85f, 0x2EC9CED6, lw, false)
        drawBelt(c, rearPanel, 0xDD050607.toInt(), gw, 0x40C9CED6, lw, true)
    }

    /** Placa blindada del casco y sus barras cian (rejilla del capó / cresta trasera). */
    private fun drawCap(c: Canvas, m: DronMesh, cp: DronCap, bars: Int, uSpan: Float, vFrom: Float, vTo: Float, barW: Float) {
        capPoint(cp, 0f, 0f, 0f, tp, tn)
        val vis = r[6] * tn[0] + r[7] * tn[1] + r[8] * tn[2]
        if (vis <= 0.04f) return
        drawSorted(c, m, 0.02f)
        // Borde de la placa: línea plateada fina (se ve el bisel).
        val a = dClamp((vis - 0.04f) / 0.30f)
        ringPath.reset()
        val steps = 10
        for (side in 0 until 4) {
            for (i in 0 until steps) {
                val q = -1f + 2f * i / steps
                val u: Float; val v: Float
                when (side) {
                    0 -> { u = q; v = -1f }
                    1 -> { u = 1f; v = q }
                    2 -> { u = -q; v = 1f }
                    else -> { u = -1f; v = -q }
                }
                capPoint(cp, u, v, 0.004f, tp, tn)
                pt(tp[0], tp[1], tp[2])
                if (side == 0 && i == 0) ringPath.moveTo(ox, oy) else ringPath.lineTo(ox, oy)
            }
        }
        ringPath.close()
        strokeP.strokeWidth = max(0.8f, s * 0.010f)
        strokeP.color = (((0x66 * a).toInt()) shl 24) or 0x00C9CED6
        c.drawPath(ringPath, strokeP)
        strokeP.color = (((0xAA * a).toInt()) shl 24) or 0x00050607
        strokeP.strokeWidth = max(1f, s * 0.018f)
        c.save()
        c.translate(-max(0.5f, s * 0.006f), -max(0.5f, s * 0.006f))
        c.drawPath(ringPath, strokeP)
        c.restore()
        // Barras cian.
        for (k in 0 until bars) {
            val v = vFrom + (vTo - vFrom) * k / (bars - 1).toFloat()
            ringPath.reset()
            for (q in 0..4) {
                val u = -uSpan + 2f * uSpan * q / 4f
                capPoint(cp, u, v, 0.012f, tp, tn)
                pt(tp[0], tp[1], tp[2])
                if (q == 0) ringPath.moveTo(ox, oy) else ringPath.lineTo(ox, oy)
            }
            neonStroke(c, ringPath, max(1f, s * barW), a)
        }
    }

    /** Trazo de neón: resplandor ancho y tenue, cuerpo cian y hilo casi blanco al centro. [a] es la visibilidad (0..1). */
    private fun neonStroke(c: Canvas, p: Path, w: Float, a: Float) {
        strokeP.strokeWidth = w * 3.6f
        strokeP.color = (((0x26 * a).toInt()) shl 24) or 0x0030E6FF
        c.drawPath(p, strokeP)
        strokeP.strokeWidth = w * 1.9f
        strokeP.color = (((0x55 * a).toInt()) shl 24) or 0x0030E6FF
        c.drawPath(p, strokeP)
        strokeP.strokeWidth = w
        strokeP.color = (((0xFF * a).toInt()) shl 24) or 0x0022D8EE
        c.drawPath(p, strokeP)
        strokeP.strokeWidth = w * 0.38f
        strokeP.color = (((0xFF * a).toInt()) shl 24) or 0x00D6FFFF
        c.drawPath(p, strokeP)
    }

    /** Pastilla oscura bajo el lente que aloja la fila de 4 LEDs. */
    private fun drawLedPlate(c: Canvas) {
        val vis = (r[6] * ledA[3] + r[7] * ledA[4] + r[8] * ledA[5] + r[6] * ledB[3] + r[7] * ledB[4] + r[8] * ledB[5]) * 0.5f
        if (vis <= 0.12f) return
        val a = dClamp((vis - 0.12f) / 0.35f)
        ringPath.reset()
        pt(ledA[0], ledA[1], ledA[2]); ringPath.moveTo(ox, oy)
        pt(ledB[0], ledB[1], ledB[2]); ringPath.lineTo(ox, oy)
        strokeP.strokeWidth = max(2f, s * 0.088f)
        strokeP.color = (((0x55 * a).toInt()) shl 24) or 0x00C9CED6
        c.drawPath(ringPath, strokeP)
        strokeP.strokeWidth = max(1.6f, s * 0.076f)
        strokeP.color = (((0xFF * a).toInt()) shl 24) or 0x000C0E11
        c.drawPath(ringPath, strokeP)
    }

    /** Puntitos del casco: LEDs cian con resplandor, o tornillos (oscuros con un brillo plateado). Solo los que miran a la cámara. */
    private fun drawMarkers(c: Canvas, arr: FloatArray, radK: Float, screws: Boolean) {
        val rad = max(0.8f, s * radK)
        var i = 0
        while (i < arr.size) {
            val x = arr[i]; val y = arr[i + 1]; val z = arr[i + 2]
            val vis = r[6] * arr[i + 3] + r[7] * arr[i + 4] + r[8] * arr[i + 5]
            i += 6
            if (vis <= 0.12f) continue
            pt(x, y, z)
            val a = dClamp(vis / 0.6f)
            val rr = rad * (0.6f + 0.4f * vis)
            if (screws) {
                fillP.color = (((0xFF * a).toInt()) shl 24) or 0x000A0B0D
                c.drawCircle(ox, oy, rr, fillP)
                fillP.color = (((0x99 * a).toInt()) shl 24) or 0x00C9CED6
                c.drawCircle(ox - rr * 0.28f, oy - rr * 0.28f, rr * 0.38f, fillP)
            } else {
                fillP.color = (((0x30 * a).toInt()) shl 24) or 0x0030E6FF
                c.drawCircle(ox, oy, rr * 2.5f, fillP)
                fillP.color = (((0xFF * a).toInt()) shl 24) or 0x0022D8EE
                c.drawCircle(ox, oy, rr, fillP)
                fillP.color = (((0xDD * a).toInt()) shl 24) or 0x00D6FFFF
                c.drawCircle(ox, oy, rr * 0.45f, fillP)
            }
        }
    }

    // ───────────── Pods, antena y base ─────────────

    private fun podRing(p: Path, side: Float, x: Float, rad: Float) {
        p.reset()
        val n = 40
        for (i in 0 until n) {
            val a = DR_TAU * i / n
            pt(side * x, DR_PCY + rad * cos(a), DR_PCZ + rad * sin(a))
            if (i == 0) p.moveTo(ox, oy) else p.lineTo(ox, oy)
        }
        p.close()
    }

    /** Pod lateral: cuerpo de aleación + aro neón con resplandor + detalles de la cara (bocina, anillos y borde plateado). */
    private fun drawPod(c: Canvas, pod: DronMesh, ring: DronMesh, side: Float) {
        drawSorted(c, pod, -0.12f)
        val vis = side * r[6]                      // >0: la cara exterior mira a la cámara
        if (vis < -0.10f) return
        val face = DR_PODX + 0.99f
        val av = dClamp((vis + 0.10f) / 0.5f)
        // Resplandor del aro (se ve aunque el pod esté de canto, como en la referencia).
        podRing(ringPath, side, face + 0.03f, 0.41f)
        val gw = 0.85f + 0.30f * neonG
        strokeP.strokeWidth = max(2f, s * 0.20f * gw)
        strokeP.color = (min(255f, 0x16 * av * neonG).toInt() shl 24) or neonRgb
        c.drawPath(ringPath, strokeP)
        strokeP.strokeWidth = max(1.5f, s * 0.12f * gw)
        strokeP.color = (min(255f, 0x26 * av * neonG).toInt() shl 24) or neonRgb
        c.drawPath(ringPath, strokeP)
        drawSorted(c, ring, -0.30f)
        if (vis <= 0.08f) return
        val a = dClamp((vis - 0.08f) / 0.35f)
        // Borde plateado del pod.
        podRing(tmpPath, side, face + 0.002f, 0.455f)
        strokeP.strokeWidth = max(0.8f, s * 0.010f)
        strokeP.color = (((0x77 * a).toInt()) shl 24) or 0x00C9CED6
        c.drawPath(tmpPath, strokeP)
        // Bocina central: aros y botón.
        podRing(tmpPath, side, face - 0.006f, 0.145f)
        strokeP.strokeWidth = max(0.8f, s * 0.013f)
        strokeP.color = (((0x66 * a).toInt()) shl 24) or 0x00C9CED6
        c.drawPath(tmpPath, strokeP)
        podRing(tmpPath, side, face - 0.006f, 0.085f)
        strokeP.color = (((0x99 * a).toInt()) shl 24) or 0x00000000
        c.drawPath(tmpPath, strokeP)
        pt(side * (face - 0.006f), DR_PCY, DR_PCZ)
        fillP.color = (((0xFF * a).toInt()) shl 24) or 0x00101216
        c.drawCircle(ox, oy, max(1f, s * 0.045f), fillP)
        fillP.color = (((0x88 * a).toInt()) shl 24) or 0x00C9CED6
        c.drawCircle(ox - s * 0.014f, oy - s * 0.014f, max(0.6f, s * 0.014f), fillP)
    }

    /** Aleta dorsal: hoja de aleación; en su cara de abajo (la que se ve desde atrás) lleva barras cian como en la referencia. */
    private fun drawBlade(c: Canvas) {
        drawSorted(c, blade, -2f)
        for (i in 2..7) {
            val u = i * 4 + 3                      // vértice de la cara de abajo
            val vis = blade.nzr[u]
            if (vis <= 0.08f) continue
            val a = dClamp((vis - 0.08f) / 0.30f)
            ringPath.reset()
            val l = i * 4
            ringPath.moveTo(blade.scr[2 * l], blade.scr[2 * l + 1])
            ringPath.lineTo(blade.scr[2 * u], blade.scr[2 * u + 1])
            ringPath.lineTo(blade.scr[2 * (l + 2)], blade.scr[2 * (l + 2) + 1])
            neonStroke(c, ringPath, max(1f, s * 0.016f), a)
        }
    }

    /** Antena: tubo oscuro con la punta cian luminosa. */
    private fun drawAntenna(c: Canvas) {
        drawSorted(c, antenna, -2f)
        val nv = 6
        val t0 = antenna.n - nv
        var sx = 0f
        var sy = 0f
        for (q in 0 until nv) { sx += antenna.scr[2 * (t0 + q)]; sy += antenna.scr[2 * (t0 + q) + 1] }
        sx /= nv; sy /= nv
        val g = dClamp(glow * 0.9f)
        fillP.color = (((0x2E * g).toInt()) shl 24) or 0x0030E6FF
        c.drawCircle(sx, sy, max(2f, s * 0.11f), fillP)
        fillP.color = (((0x66 * g).toInt()) shl 24) or 0x0030E6FF
        c.drawCircle(sx, sy, max(1.4f, s * 0.062f), fillP)
        fillP.color = (((0xFF * g).toInt()) shl 24) or 0x00D6FFFF
        c.drawCircle(sx, sy, max(0.9f, s * 0.028f), fillP)
    }

    /** Base ventilada y el resplandor del neón de abajo. */
    private fun drawBase(c: Canvas) {
        drawSorted(c, base, -0.10f)
        pt(0f, -1.16f, 0f)
        val k = 0.25f + 0.75f * abs(r[7])
        val hh = s * (0.05f + 0.22f * k)
        val g = dClamp(glow * 0.9f)
        for (q in 0 until 3) {
            val w = s * (0.70f - 0.17f * q)
            val h = hh * (1f - 0.22f * q)
            fillP.color = ((((0x10 + 0x10 * q) * g).toInt()) shl 24) or 0x0030E6FF
            box.set(ox - w, oy - h, ox + w, oy + h)
            c.drawOval(box, fillP)
        }
    }

    // ───────────── Lente ─────────────

    /** Polígono de un círculo pegado al casco, en el plano de la cara delantera (+1) o trasera (-1). */
    private fun discPath(p: Path, face: Float, rad: Float, lift: Float) {
        p.reset()
        val n = 48
        for (i in 0 until n) {
            val a = DR_TAU * i / n
            var qx = rad * cos(a)
            var qy = rad * sin(a)
            var qz = face * DR_HC
            val k = 1f / sqrt((qx / DR_HA) * (qx / DR_HA) + (qy / DR_HB) * (qy / DR_HB) + (qz / DR_HC) * (qz / DR_HC))
            qx *= k; qy *= k; qz *= k
            qz += face * lift
            pt(qx, qy, qz)
            if (i == 0) p.moveTo(ox, oy) else p.lineTo(ox, oy)
        }
        p.close()
    }

    /** Matriz que pone un dibujo plano (unidades = píxeles vistos de frente) sobre la cara delantera o trasera. */
    private fun faceMat(m: Matrix, face: Float, lift: Float) {
        val z = face * (DR_HC + lift)
        val h = 0.1f
        pt(0f, 0f, z); val x0 = ox; val y0 = oy
        pt(h, 0f, z); val ax = (ox - x0) / (h * s); val ay = (oy - y0) / (h * s)
        pt(0f, h, z); val bx = -(ox - x0) / (h * s); val by = -(oy - y0) / (h * s)
        m9[0] = ax; m9[1] = bx; m9[2] = x0
        m9[3] = ay; m9[4] = by; m9[5] = y0
        m9[6] = 0f; m9[7] = 0f; m9[8] = 1f
        m.setValues(m9)
    }

    /** Lente: bisel atornillado, aro neón cian con resplandor y cristal negro con reflejos. */
    private fun drawLens(c: Canvas) {
        val facing = r[8]
        lensFacing = if (facing > 0f) facing else 0f
        lensRpx = 0.39f * s
        // Centro del lente en pantalla (se calcula siempre, para que los gestos y accesorios sepan dónde está).
        pt(0f, 0f, DR_HC + 0.08f)
        lensCx = ox; lensCy = oy
        faceMat(lensMat, 1f, 0.08f)
        if (facing <= 0.03f) return
        // Placa del bisel (plata oscura con filo claro) y anillo interior más negro.
        discPath(tmpPath, 1f, 0.60f, 0.012f)
        fillP.color = 0xFF1F2227.toInt()
        c.drawPath(tmpPath, fillP)
        strokeP.strokeWidth = max(0.8f, s * 0.012f)
        strokeP.color = 0x66C9CED6
        c.drawPath(tmpPath, strokeP)
        discPath(tmpPath, 1f, 0.525f, 0.030f)
        fillP.color = 0xFF0B0D10.toInt()
        c.drawPath(tmpPath, fillP)
        // Aro neón.
        discPath(tmpPath, 1f, 0.435f, 0.050f)
        neonStroke(c, tmpPath, max(1.6f, s * 0.050f), 1f)
        // Cristal negro.
        discPath(tmpPath, 1f, 0.395f, 0.060f)
        fillP.color = 0xFF020407.toInt()
        c.drawPath(tmpPath, fillP)
        // Reflejos del cristal (planos: se ven bien solo de frente).
        val fa = dClamp((facing - 0.30f) / 0.45f)
        if (fa > 0f) {
            val rr = 0.39f * s
            c.save()
            c.concat(lensMat)
            strokeP.strokeCap = Paint.Cap.ROUND
            box.set(-rr * 0.80f, -rr * 0.80f, rr * 0.80f, rr * 0.80f)
            strokeP.strokeWidth = rr * 0.075f
            strokeP.color = (((0x40 * fa).toInt()) shl 24) or 0x00FFFFFF
            c.drawArc(box, 198f, 58f, false, strokeP)
            strokeP.strokeWidth = rr * 0.045f
            strokeP.color = (((0x22 * fa).toInt()) shl 24) or 0x0030E6FF
            c.drawArc(box, 18f, 46f, false, strokeP)
            fillP.color = (((0x66 * fa).toInt()) shl 24) or 0x00FFFFFF
            c.drawCircle(-rr * 0.50f, -rr * 0.54f, rr * 0.055f, fillP)
            c.restore()
        }
    }

    /**
     * Ojo del lente para la mascota de dentro de la app: aro blanco brillante con pupila; parpadea ([open]),
     * mira ([lookX], [lookY]) y, si está contento ([happy]), se hace un arquito. Va pegado al lente y gira con él.
     */
    fun drawIris(c: Canvas, open: Float, lookX: Float, lookY: Float, happy: Boolean) {
        if (lensFacing <= 0.04f) return
        val fade = dClamp(lensFacing * 4f)
        val rr = lensRpx * 0.74f
        c.save()
        c.concat(lensMat)
        irisGlow.color = ((0x55 * fade).toInt() shl 24) or 0x003EC7E8
        c.drawCircle(lookX * rr * 0.16f, lookY * rr * 0.12f, rr * 1.05f, irisGlow)
        if (happy) {
            irisRing.strokeCap = Paint.Cap.ROUND
            irisRing.strokeWidth = rr * 0.22f
            irisRing.color = ((255 * fade).toInt() shl 24) or 0x00FFFFFF
            tmpPath.reset()
            tmpPath.moveTo(-rr * 0.55f, rr * 0.18f)
            tmpPath.quadTo(0f, -rr * 0.60f, rr * 0.55f, rr * 0.18f)
            c.drawPath(tmpPath, irisRing)
        } else {
            c.save()
            c.scale(1f, open.coerceIn(0.08f, 1f))
            val ex = lookX * rr * 0.16f
            val ey = lookY * rr * 0.12f
            irisRing.strokeWidth = rr * 0.20f
            irisRing.color = ((255 * fade).toInt() shl 24) or 0x00FFFFFF
            c.drawCircle(ex, ey, rr * 0.62f, irisRing)
            irisFill.color = ((255 * fade).toInt() shl 24) or 0x00030305
            c.drawCircle(ex + lookX * rr * 0.06f, ey + lookY * rr * 0.05f, rr * 0.36f, irisFill)
            irisFill.color = ((220 * fade).toInt() shl 24) or 0x00FFFFFF
            c.drawCircle(ex - rr * 0.20f, ey - rr * 0.24f, rr * 0.09f, irisFill)
            c.restore()
        }
        c.restore()
    }

    private companion object {
        const val BINS = 120
        const val NB = 160           // cubetas para ordenar los triángulos de las piezas
    }
}
