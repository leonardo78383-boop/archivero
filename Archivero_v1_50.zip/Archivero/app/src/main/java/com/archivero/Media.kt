package com.archivero

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Qué se está viendo a pantalla completa. */
sealed interface Viewer {
    class Images(val files: List<File>, val index: Int) : Viewer
    class Video(val files: List<File>, val index: Int) : Viewer
}

/** Abre un archivo con el visor/reproductor interno si es foto, vídeo o música; si no, con otra app. */
fun openEntry(store: Store, ctx: Context, e: Entry, siblings: List<Entry>) {
    when (e.kind) {
        Kind.IMG -> {
            val imgs = siblings.filter { !it.isDir && it.kind == Kind.IMG }.map { it.file }
            val i = imgs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.viewer = Viewer.Images(imgs, i) else openFile(ctx, e.file)
        }
        Kind.VID -> {
            val vids = siblings.filter { !it.isDir && it.kind == Kind.VID }.map { it.file }
            val i = vids.indexOfFirst { it.path == e.file.path }
            store.viewer = if (i >= 0) Viewer.Video(vids, i) else Viewer.Video(listOf(e.file), 0)
        }
        Kind.AUD -> {
            val songs = siblings.filter { !it.isDir && it.kind == Kind.AUD }.map { it.file }
            val i = songs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.music.start(songs, i) else openFile(ctx, e.file)
        }
        else -> openFile(ctx, e.file)
    }
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ───────────────────────── Capa a pantalla completa ─────────────────────────

@Composable
fun MediaOverlay(v: Viewer, onClose: () -> Unit) {
    // El pointerInput vacío hace que los toques no "atraviesen" hacia la pantalla de abajo.
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }) {
        when (v) {
            is Viewer.Images -> ImageViewer(v, onClose)
            is Viewer.Video -> VideoViewer(v, onClose)
        }
    }
}

@Composable
private fun TopBar(title: String, onClose: () -> Unit, extra: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onClose) { Text("✕", color = Color.White, fontSize = 20.sp) }
        Text(title, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        extra()
    }
}

// ───────────────────────── Visor de imágenes ─────────────────────────

/** Lee la imagen reducida (máx. ~2048 px) y ya girada según su orientación. */
suspend fun loadBitmap(f: File, maxDim: Int = 2048): Bitmap? = withContext(Dispatchers.IO) {
    try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { decoder, info, _ ->
            val s = maxOf(info.size.width, info.size.height) / maxDim
            if (s > 1) decoder.setTargetSampleSize(s)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }
}

@Composable
fun ImageViewer(v: Viewer.Images, onClose: () -> Unit) {
    BackHandler { onClose() }
    val pager = rememberPagerState(initialPage = v.index, pageCount = { v.files.size })
    var zoomed by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = !zoomed,
            beyondViewportPageCount = 1,   // la foto siguiente/anterior ya está cargada al deslizar
            key = { v.files[it].path }
        ) { page ->
            ImagePage(v.files[page]) { zoomed = it }
        }
        val cur = pager.currentPage.coerceIn(0, v.files.size - 1)
        TopBar("${cur + 1}/${v.files.size}  ${v.files[cur].name}", onClose)
    }
}

@Composable
private fun ImagePage(f: File, onZoom: (Boolean) -> Unit) {
    val res by produceState(false to (null as ImageBitmap?), f) {
        value = true to loadBitmap(f)?.asImageBitmap()
    }
    val (done, img) = res
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            !done -> ThinSpinner()
            img == null -> Text("No se pudo mostrar esta imagen", color = Color.White, textAlign = TextAlign.Center)
            else -> ZoomImage(img, onZoom)
        }
    }
}

/** Zoom con dos dedos, arrastrar cuando está ampliada y doble toque para ampliar o volver. */
@Composable
private fun ZoomImage(img: ImageBitmap, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                    } else {
                        scale = 2.5f
                    }
                    onZoom(scale > 1f)
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val fingers = ev.changes.count { it.pressed }
                        // Con un dedo y sin zoom no se toca nada: así el deslizar pasa a la foto siguiente.
                        if (fingers >= 2 || scale > 1f) {
                            val ns = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                            val mx = box.width * (ns - 1f) / 2f
                            val my = box.height * (ns - 1f) / 2f
                            val o = if (ns > 1f) offset + ev.calculatePan() else Offset.Zero
                            offset = Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
                            scale = ns
                            onZoom(ns > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        Image(
            bitmap = img,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )
    }
}

// ───────────────────────── Reproductor de vídeo ─────────────────────────

@Composable
fun VideoViewer(v: Viewer.Video, onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = LocalContext.current
    val vv = remember { VideoView(ctx) }
    var idx by remember { mutableIntStateOf(v.index.coerceIn(0, v.files.size - 1)) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showUi by remember { mutableStateOf(true) }
    var landscape by remember { mutableStateOf(false) }
    val file = v.files[idx]

    DisposableEffect(vv) {
        onDispose {
            vv.stopPlayback()
            ctx.findActivity()?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Cada vez que cambia el vídeo (⏮ ⏭ o fin del anterior) se carga el nuevo en el mismo reproductor.
    LaunchedEffect(idx) {
        pos = 0
        dur = 0
        playing = false
        vv.setVideoURI(Uri.fromFile(v.files[idx]))
    }

    // Barra de progreso propia (sin MediaController): se actualiza cada 300 ms mientras reproduce.
    LaunchedEffect(playing, idx) {
        while (playing) {
            if (drag == null) pos = try { vv.currentPosition } catch (e: Exception) { pos }
            delay(300)
        }
    }

    // Los controles se esconden solos a los 4 segundos mientras reproduce.
    LaunchedEffect(showUi, playing, idx, drag) {
        if (showUi && playing && drag == null) {
            delay(4000)
            showUi = false
        }
    }

    fun next() { if (idx + 1 < v.files.size) idx++ }
    fun prev() { if (pos > 3000 || idx == 0) { vv.seekTo(0); pos = 0 } else idx-- }
    fun toggle() {
        if (vv.isPlaying) { vv.pause(); playing = false } else { vv.start(); playing = true }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                vv.apply {
                    setOnPreparedListener { mp ->
                        dur = mp.duration
                        start()
                        playing = true
                    }
                    setOnCompletionListener {
                        if (idx + 1 < v.files.size) idx++ else { playing = false; showUi = true }
                    }
                    setOnErrorListener { _, _, _ ->
                        playing = false
                        showUi = true
                        toast(ctx, "No se puede reproducir este vídeo")
                        true
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        // Capa transparente: un toque muestra u oculta los controles.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showUi = !showUi } }
        )
        if (showUi) {
            Box(Modifier.align(Alignment.TopCenter)) {
                TopBar("${idx + 1}/${v.files.size}  ${file.name}", onClose) {
                    TextButton(onClick = {
                        landscape = !landscape
                        ctx.findActivity()?.requestedOrientation =
                            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }) { Text("⟳ Girar", color = Color.White) }
                }
            }
            val max = maxOf(1, dur).toFloat()
            val shown = (drag ?: pos.toFloat()).coerceIn(0f, max)
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Slider(
                    value = shown,
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let { vv.seekTo(it.toInt()); pos = it.toInt() }
                        drag = null
                    },
                    valueRange = 0f..max
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        fmtTime(shown.toInt()) + " / " + fmtTime(dur),
                        Modifier.padding(start = 8.dp).weight(1f),
                        color = Color.White, style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { prev() }) { Text("⏮", fontSize = 22.sp) }
                    TextButton(onClick = { toggle() }) { Text(if (playing) "⏸" else "▶", fontSize = 22.sp) }
                    TextButton(onClick = { next() }, enabled = idx + 1 < v.files.size) { Text("⏭", fontSize = 22.sp) }
                }
            }
        }
    }
}

// ───────────────────────── Reproductor de música ─────────────────────────

class MusicPlayer(private val appCtx: Context? = null) {
    private var mp: MediaPlayer? = null

    // Foco de audio: si entra una llamada o suena otra app, la música se pausa sola (y sigue cuando se libera).
    private val audioManager: android.media.AudioManager? = appCtx?.getSystemService(android.media.AudioManager::class.java)
    private var focusReq: android.media.AudioFocusRequest? = null
    private var resumeOnFocus = false
    private val audioAttrs: android.media.AudioAttributes = android.media.AudioAttributes.Builder()
        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private val focusListener = android.media.AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            android.media.AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                if (playing) toggle()
            }
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (playing) { resumeOnFocus = true; toggle() }
            }
            android.media.AudioManager.AUDIOFOCUS_GAIN -> {
                if (resumeOnFocus) { resumeOnFocus = false; if (!playing) toggle() }
            }
        }
    }

    private fun requestFocus() {
        val am = audioManager ?: return
        try {
            val req = focusReq ?: android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(audioAttrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build().also { focusReq = it }
            am.requestAudioFocus(req)
        } catch (ignored: Exception) { }
    }

    private fun abandonFocus() {
        resumeOnFocus = false
        try { focusReq?.let { audioManager?.abandonAudioFocusRequest(it) } } catch (ignored: Exception) { }
    }

    var queue by mutableStateOf<List<File>>(emptyList())
    var index by mutableIntStateOf(0)
    var playing by mutableStateOf(false)
    var position by mutableIntStateOf(0)
    var duration by mutableIntStateOf(0)

    val current: File? get() = queue.getOrNull(index)
    val active: Boolean get() = queue.isNotEmpty()

    /** true = la canción que suena se repite sin parar al terminar; false = sigue con la siguiente como siempre. */
    var repeatOne by mutableStateOf(false)
        private set

    fun setRepeat(on: Boolean) {
        repeatOne = on
        try { mp?.isLooping = on } catch (ignored: Exception) { }
    }

    fun start(files: List<File>, i: Int) {
        queue = files
        play(i)
    }

    private fun play(i: Int) {
        if (i !in queue.indices) return
        index = i
        position = 0
        duration = 0
        releasePlayer()
        val m = MediaPlayer()
        try {
            // Con la pantalla apagada o fuera de la app, que la música no se corte.
            appCtx?.let { m.setWakeMode(it, android.os.PowerManager.PARTIAL_WAKE_LOCK) }
            m.setAudioAttributes(audioAttrs)
            m.setDataSource(queue[i].path)
            m.isLooping = repeatOne            // si "repetir" está activo, también se repite la canción que se elija después
            m.setOnPreparedListener {
                it.start()
                duration = it.duration
                playing = true
            }
            m.setOnCompletionListener { next() }
            m.setOnErrorListener { _, _, _ ->
                playing = false
                true
            }
            mp = m
            requestFocus()
            m.prepareAsync()
        } catch (e: Exception) {
            mp = null
            try { m.release() } catch (ignored: Exception) { }
            playing = false
        }
    }

    fun toggle() {
        val m = mp ?: return
        try {
            if (m.isPlaying) {
                m.pause()
                playing = false
            } else {
                m.start()
                playing = true
            }
        } catch (e: Exception) {
            playing = false
        }
    }

    fun next() {
        if (index + 1 < queue.size) play(index + 1) else { playing = false; position = 0; abandonFocus() }
    }

    fun prev() {
        if (position > 3000 || index == 0) seek(0) else play(index - 1)
    }

    fun seek(ms: Int) {
        try { mp?.seekTo(ms) } catch (ignored: Exception) { }
        position = ms
    }

    /** Lo llama la pantalla cada medio segundo para mover la barra de progreso. */
    fun tick() {
        val m = mp ?: return
        try { if (m.isPlaying) position = m.currentPosition } catch (ignored: Exception) { }
    }

    private fun releasePlayer() {
        mp?.let { try { it.release() } catch (ignored: Exception) { } }
        mp = null
    }

    fun stop() {
        releasePlayer()
        abandonFocus()
        queue = emptyList()
        playing = false
        position = 0
        duration = 0
    }

    fun release() = releasePlayer()
}

fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

// ── Íconos vectoriales del reproductor (no son emojis: se dibujan igual en cualquier teléfono) ──
private object PIco {
    const val PLAY = "M8 5v14l11-7z"
    const val PAUSE = "M6 19h4V5H6v14zm8-14v14h4V5h-4z"
    const val PREV = "M6 6h2v12H6zm3.5 6l8.5 6V6z"
    const val NEXT = "M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"
    const val CLOSE = "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
    const val NOTE = "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"
    private val cache = HashMap<String, androidx.compose.ui.graphics.Path>()
    fun path(d: String): androidx.compose.ui.graphics.Path =
        cache.getOrPut(d) { androidx.compose.ui.graphics.vector.PathParser().parsePathString(d).toPath() }
}

@Composable
private fun PIcon(d: String, tint: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(Modifier.size(size)) {
        val k = this.size.width / 24f
        withTransform({ scale(k, k, androidx.compose.ui.geometry.Offset.Zero) }) {
            drawPath(PIco.path(d), tint)
        }
    }
}

/** Botón redondo con ícono. [filled] = círculo rosa (el de reproducir/pausa). */
@Composable
private fun PBtn(d: String, size: androidx.compose.ui.unit.Dp, icon: androidx.compose.ui.unit.Dp, filled: Boolean = false, tint: androidx.compose.ui.graphics.Color = Pal.White, onClick: () -> Unit) {
    val bg = if (filled) Modifier.background(
        androidx.compose.ui.graphics.Brush.verticalGradient(listOf(androidx.compose.ui.graphics.Color(0xFFFF4DB8), Pal.Pink)),
        androidx.compose.foundation.shape.CircleShape
    ) else Modifier
    Box(
        Modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape).then(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { PIcon(d, if (filled) Pal.White else tint, icon) }
}

/** Carátula de la canción (o una nota si no tiene). */
@Composable
private fun PCover(f: java.io.File, size: androidx.compose.ui.unit.Dp, radius: androidx.compose.ui.unit.Dp) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<Bitmap?>(Thumbs.cached(f.path), f.path) {
        value = Thumbs.cached(f.path) ?: Thumbs.load(ctx, f, Kind.AUD)
    }
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(radius)
    Box(
        Modifier.size(size).shadow(8.dp, shape).clip(shape).background(Pal.Sel),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        else PIcon(PIco.NOTE, Pal.Muted, size * 0.45f)
    }
}

/** Barra de progreso: pista fina, relleno rosa con degradado y perilla blanca. Se toca o se arrastra para saltar. */
@Composable
private fun PBar(shown: Float, max: Float, onDrag: (Float) -> Unit, onDone: () -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val frac = (shown / max).coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().height(28.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(max) {
                detectTapGestures { o -> onDrag((o.x / w).coerceIn(0f, 1f) * max); onDone() }
            }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> onDrag((o.x / w).coerceIn(0f, 1f) * max) },
                    onDragEnd = { onDone() },
                    onDragCancel = { onDone() },
                    onHorizontalDrag = { ch, _ -> onDrag((ch.position.x / w).coerceIn(0f, 1f) * max) }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(28.dp)) {
            val h = 5.dp.toPx()
            val cy = size.height / 2f
            val r = androidx.compose.ui.geometry.CornerRadius(h / 2f, h / 2f)
            drawRoundRect(Pal.Line, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(size.width, h), r)
            val x = size.width * frac
            if (x > 0f) drawRoundRect(
                androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(androidx.compose.ui.graphics.Color(0xFFFF4DB8), Pal.Pink)),
                androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(x, h), r
            )
            drawCircle(Pal.Pink.copy(alpha = 0.30f), 11.dp.toPx(), androidx.compose.ui.geometry.Offset(x.coerceIn(8.dp.toPx(), size.width - 8.dp.toPx()), cy))
            drawCircle(Pal.White, 6.dp.toPx(), androidx.compose.ui.geometry.Offset(x.coerceIn(8.dp.toPx(), size.width - 8.dp.toPx()), cy))
        }
    }
}

/**
 * Reproductor de música de abajo.
 * [big] = true (Inicio): panel alto con carátula grande, título, barra y botones.
 * [big] = false (carpetas): versión baja para no tapar la lista.
 */
@Composable
fun MiniPlayer(m: MusicPlayer, big: Boolean = false) {
    val f = m.current ?: return
    LaunchedEffect(m.playing, m.index) {
        while (m.playing) {
            m.tick()
            delay(500)
        }
    }
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = maxOf(1, m.duration).toFloat()
    val shown = (drag ?: m.position.toFloat()).coerceIn(0f, max)
    val top = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    val panel = Modifier.fillMaxWidth()
        .clip(top)
        .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Glass.Top, Glass.Mid, Glass.Bottom)))
        .navigationBarsPadding()

    if (big) {
        Column(panel.padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PCover(f, 112.dp, 16.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        f.nameWithoutExtension, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Pal.White
                    )
                    Spacer(Modifier.height(6.dp))
                    PBar(shown, max, { drag = it }, { drag?.let { m.seek(it.toInt()) }; drag = null })
                    Row(Modifier.fillMaxWidth()) {
                        Text(fmtTime(shown.toInt()), fontSize = 12.sp, color = Pal.Muted)
                        Spacer(Modifier.weight(1f))
                        Text(fmtTime(m.duration), fontSize = 12.sp, color = Pal.Muted)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                PBtn(PIco.PREV, 48.dp, 26.dp) { m.prev() }
                Spacer(Modifier.width(18.dp))
                PBtn(if (m.playing) PIco.PAUSE else PIco.PLAY, 58.dp, 30.dp, filled = true) { m.toggle() }
                Spacer(Modifier.width(18.dp))
                PBtn(PIco.NEXT, 48.dp, 26.dp) { m.next() }
                Spacer(Modifier.width(18.dp))
                PBtn(PIco.CLOSE, 40.dp, 20.dp, tint = Pal.Muted) { m.stop() }
            }
        }
    } else {
        Row(panel.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            PCover(f, 46.dp, 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.nameWithoutExtension, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = Pal.White)
                PBar(shown, max, { drag = it }, { drag?.let { m.seek(it.toInt()) }; drag = null })
            }
            PBtn(PIco.PREV, 38.dp, 20.dp) { m.prev() }
            PBtn(if (m.playing) PIco.PAUSE else PIco.PLAY, 42.dp, 22.dp, filled = true) { m.toggle() }
            PBtn(PIco.NEXT, 38.dp, 20.dp) { m.next() }
            PBtn(PIco.CLOSE, 34.dp, 18.dp, tint = Pal.Muted) { m.stop() }
        }
    }
}
