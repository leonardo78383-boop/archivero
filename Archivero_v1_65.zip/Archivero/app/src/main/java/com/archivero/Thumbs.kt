package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.ThumbnailUtils
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.asCoroutineDispatcher
import java.io.File
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** Cola "el último en llegar sale primero": al desplazarse rápido, se cargan antes las miniaturas que están a la vista. */
private class LifoQueue : LinkedBlockingDeque<Runnable>() {
    override fun offer(e: Runnable): Boolean = offerFirst(e)
    override fun add(e: Runnable): Boolean { addFirst(e); return true }
}

/**
 * Miniaturas de fotos, vídeos, música (carátula), PDF (primera página) y APK (ícono de la app).
 * - Guarda las ya generadas en memoria, así volver a verlas es instantáneo.
 * - Dos carriles: las fotos, carátulas e íconos (rápidos) no esperan detrás de los vídeos y PDF (lentos).
 * - En cada carril, las más recientes primero; si una miniatura ya no la espera nadie (te desplazaste), ni se genera.
 * - Si dos filas piden la misma miniatura a la vez, se genera una sola vez.
 * - Menos hilos y menos memoria en teléfonos con poca RAM; se vacía por partes cuando el sistema lo pide.
 * - Las que fallan se recuerdan: no se reintentan en cada desplazamiento.
 */
object Thumbs {
    private const val PX = 224

    /** Teléfono con poca memoria para la app (heap chico). */
    private val lowRam = Runtime.getRuntime().maxMemory() < 200L * 1024 * 1024
    private val cores = Runtime.getRuntime().availableProcessors()

    private val cache = object : LruCache<String, Bitmap>(
        minOf(Runtime.getRuntime().maxMemory() / 1024 / (if (lowRam) 10 else 8), 64L * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    // Las que fallan se recuerdan, pero con tope: en carpetas enormes con miles de archivos sin miniatura la lista crecía sin límite.
    private const val MAX_FAILED = 3000
    private val failed = object : LinkedHashMap<String, Boolean>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > MAX_FAILED
    }

    // Los hilos de miniaturas van en segundo plano de verdad: cuando el teléfono va justo, la pantalla (desplazamiento,
    // animaciones) tiene prioridad sobre generar miniaturas.
    private fun lane(threads: Int, name: String) = ThreadPoolExecutor(
        threads, threads, 0L, TimeUnit.MILLISECONDS, LifoQueue(),
        { r ->
            Thread({
                try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (e: Exception) { }
                r.run()
            }, name).apply { isDaemon = true }
        }
    ).asCoroutineDispatcher()

    private val light = lane(if (lowRam || cores <= 4) 2 else 3, "thumbs-l")      // fotos, carátulas, íconos de APK
    private val heavy = lane(if (lowRam || cores <= 4) 1 else 2, "thumbs-h")      // vídeos y PDF

    private class Pending { var waiters = 1; lateinit var job: Deferred<Bitmap?> }
    private val inflight = HashMap<String, Pending>()
    private val scope = CoroutineScope(SupervisorJob())

    /** ¿Este tipo de archivo puede tener miniatura? */
    fun supports(kind: Kind): Boolean =
        kind == Kind.IMG || kind == Kind.VID || kind == Kind.AUD || kind == Kind.PDF || kind == Kind.APK

    fun cached(path: String): Bitmap? = cache.get(path)

    fun hasFailed(path: String): Boolean = synchronized(failed) { path in failed }

    /** Memoria que ocupan las miniaturas guardadas (bytes). */
    fun sizeBytes(): Long = cache.size().toLong() * 1024L

    fun clear() {
        cache.evictAll()
        synchronized(failed) { failed.clear() }
    }

    /** El sistema pide memoria: se suelta una parte de las miniaturas (o todas si el aprieto es grave). */
    fun trim(severe: Boolean) {
        if (severe) cache.evictAll() else cache.trimToSize(cache.size() / 2)
    }

    suspend fun load(ctx: Context, f: File, kind: Kind): Bitmap? {
        cache.get(f.path)?.let { return it }
        if (hasFailed(f.path)) return null
        val app = ctx.applicationContext
        var created: Pending? = null
        val pending = synchronized(inflight) {
            val ex = inflight[f.path]
            if (ex != null) { ex.waiters++; ex }
            else {
                val p = Pending()
                p.job = scope.async(if (kind == Kind.VID || kind == Kind.PDF) heavy else light, start = CoroutineStart.LAZY) { make(app, f, kind, p) }
                inflight[f.path] = p
                created = p
                p
            }
        }
        created?.job?.start()
        try {
            return pending.job.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return null
        } finally {
            synchronized(inflight) { pending.waiters-- }
        }
    }

    private fun make(app: Context, f: File, kind: Kind, p: Pending): Bitmap? {
        // Si ya nadie la espera (la fila salió de pantalla), no se gasta tiempo ni memoria.
        val abandoned = synchronized(inflight) {
            if (p.waiters <= 0) { inflight.remove(f.path); true } else false
        }
        if (abandoned) return null
        val b = try {
            when (kind) {
                Kind.VID -> ThumbnailUtils.createVideoThumbnail(f, Size(PX, PX), null)
                Kind.IMG -> ThumbnailUtils.createImageThumbnail(f, Size(PX, PX), null)
                Kind.AUD -> ThumbnailUtils.createAudioThumbnail(f, Size(PX, PX), null)
                Kind.PDF -> pdfFirstPage(f)
                Kind.APK -> apkIcon(app, f)
                else -> null
            }
        } catch (e: Exception) {
            null   // archivo dañado, sin carátula o formato no soportado: se muestra el ícono normal
        } catch (e: OutOfMemoryError) {
            cache.trimToSize(cache.size() / 2)       // poca memoria: se suelta la mitad y este archivo se reintenta otro día
            synchronized(inflight) { inflight.remove(f.path) }
            return null
        }
        if (b != null) cache.put(f.path, b) else synchronized(failed) { failed[f.path] = true }
        synchronized(inflight) { inflight.remove(f.path) }
        return b
    }

    /** Primera página del PDF sobre fondo blanco. */
    private fun pdfFirstPage(f: File): Bitmap? {
        val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        // Un PDF con contraseña o dañado lanza error al abrirse: sin esto el descriptor quedaba abierto para siempre (se acababan al listar muchos PDF).
        val r = try { PdfRenderer(fd) } catch (e: Exception) {
            try { fd.close() } catch (ignored: Exception) { }
            throw e
        }
        try {
            if (r.pageCount == 0) return null
            val p = r.openPage(0)
            try {
                val w = PX
                val h = (PX * p.height.toFloat() / p.width.toFloat()).toInt().coerceIn(PX / 2, PX * 2)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                Canvas(bmp).drawColor(Color.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                p.close()
            }
        } finally {
            r.close()
        }
    }

    /** Ícono de la app que está dentro del APK (sin instalarlo). */
    private fun apkIcon(ctx: Context, f: File): Bitmap? {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(f.path, 0) ?: return null
        val ai = info.applicationInfo ?: return null
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        return ai.loadIcon(pm).toBitmap(PX, PX)
    }
}
