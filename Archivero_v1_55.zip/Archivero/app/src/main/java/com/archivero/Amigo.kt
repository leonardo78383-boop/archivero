package com.archivero

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────── Íconos de Ajustes (línea fina) ─────────────

/** Esfera con un puntito rosa (ícono de "seguirte"). */
@Composable
fun BubbleIcon(w: Dp = 38.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        drawCircle(color.copy(alpha = 0.92f), s * 0.34f, Offset(s * 0.5f, s * 0.5f), style = Stroke(1.6.dp.toPx()))
        drawCircle(Pal.Accent, s * 0.06f, Offset(s * 0.62f, s * 0.6f))
    }
}

// ───────────── Pantalla de Ajustes del amigo ─────────────

/** Casilla de Ajustes: ícono, título, estado y (opcional) una acción pequeña debajo. */
@Composable
private fun SettingTile(
    modifier: Modifier,
    title: String,
    status: String,
    on: Boolean,
    locked: Boolean,
    icon: @Composable () -> Unit,
    action: String? = null,
    onAction: () -> Unit = {},
    onClick: (() -> Unit)? = null
) {
    val shape = ChamferShape(12.dp)
    Column(
        modifier
            .height(148.dp)
            .clip(shape)
            .background(if (on) Pal.Sel else Pal.Card)
            .border(1.dp, if (on) Pal.Accent else Pal.Line, shape)
            .then(if (locked || onClick == null) Modifier else Modifier.clickable(onClick = onClick))
            .padding(12.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
    ) {
        Box(Modifier.alpha(if (locked) 0.45f else 1f)) { icon() }
        Column {
            Text(title, color = if (locked) Pal.Muted else Pal.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(status, color = if (on) Pal.White else Pal.Muted, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2)
            if (action != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    action, color = Pal.Pink, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(onClick = onAction)
                )
            }
        }
    }
}

/** El "papel grande" de Ajustes: por ahora solo el permiso para que el amigo te siga fuera de la app. */
@Composable
fun AjustesSheet(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var canDraw by remember { mutableStateOf(FriendLink.canDraw(ctx)) }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        canDraw = FriendLink.canDraw(ctx)
        FriendLink.sync(ctx)          // si ya estaba suelto, empieza a seguirte
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.74f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
    ) {
        val shape = ChamferShape(18.dp)
        Column(
            Modifier
                .align(Alignment.Center)
                .padding(16.dp)
                .fillMaxWidth()
                .vidrio3D(shape, 18.dp)
                .clip(shape)
                .pointerInput(Unit) { detectTapGestures { } }       // tocar dentro no cierra
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AJUSTES", color = Pal.Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(2.dp))
                    Text("Tu amigo", color = Pal.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                }
                Text(
                    "Cerrar", color = Pal.Muted, fontSize = 13.sp,
                    modifier = Modifier.clickable(onClick = onClose).padding(8.dp)
                )
            }
            Spacer(Modifier.height(14.dp))

            SettingTile(
                Modifier.fillMaxWidth(), "Seguirte fuera de la app",
                if (canDraw) "Activo · si lo sacas y sales de la app, te sigue" else "Falta el permiso · toca para darlo",
                on = canDraw, locked = false,
                icon = { BubbleIcon() },
                onClick = if (canDraw) null else ({
                    try {
                        overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                    } catch (e: Exception) {
                        toast(ctx, "No se pudo abrir el permiso")
                    }
                })
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "El amigo limpia los residuos de la app (caché y miniaturas) cuando lo tocas. Fuera de la app tiene un mini reproductor de música.",
                color = Pal.Muted, fontSize = 11.sp, lineHeight = 15.sp
            )
        }
    }
}
