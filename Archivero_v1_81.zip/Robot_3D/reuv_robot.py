#!/usr/bin/env python3
"""
reuv_robot.py — Recalcula las UV de robot.bin para que NINGUNA cara quede estirada.

Por qué existe: el robot.bin de la 1.80 tenía caras con la textura estirada hasta 17x
(antenas), 3x (laterales del torso), 2x (laterales y nuca de la cabeza) y la espalda del
torso mostraba los LED del pecho. Este script NO toca la geometría ni el atlas: solo
reescribe u,v de cada vértice con una proyección plana por cara y escala uniforme
(sin deformar; si la cara y la isla del atlas no tienen la misma proporción, se recorta
el sobrante en vez de estirar).

Uso (desde la raíz del proyecto):
    python Robot_3D/reuv_robot.py
NOTA: build_robot.py es un generador antiguo y distinto del robot.bin actual: no lo ejecutes
(sobrescribiría el atlas con uno de relleno).
"""
import struct, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BIN = ROOT / "app/src/main/assets/robot/robot.bin"
A = 1254.0          # lado del atlas en px
INSET = 6.0         # margen interior de cada isla (evita que los mips mezclen con la separación negra)

# ───── Islas del atlas (px: x0, y0, x1, y1) ─────
SIDE_TORSO = (151, 241, 357, 762)
TOP_TORSO  = (12, 122, 158, 232)
BOT_TORSO  = (166, 12, 337, 137)
HEAD_BACK  = (911, 1135, 1157, 1246)
HEAD_SIDE  = (328, 1107, 577, 1246)
ARM_SIDE   = (11, 453, 145, 749)
ARM_TB     = (10, 246, 147, 439)
LEG_SIDE   = (366, 801, 586, 1089)
LEG_TB     = (10, 246, 147, 439)
ANT        = (869, 959, 927, 1123)
NECK       = (251, 771, 376, 862)
HIPS       = (13, 1135, 289, 1246)

KEEP = "keep"   # conserva la isla que ya usaba esa cara (se re-proyecta sin estirar)

# (parte, bloque de 96 vértices) -> {(eje, signo): isla}
RULES = {
    ("torso", 0): {("x", 1): SIDE_TORSO, ("x", -1): SIDE_TORSO, ("y", 1): TOP_TORSO, ("y", -1): BOT_TORSO},
    ("head", 0):  {("z", -1): HEAD_BACK, ("x", 1): HEAD_SIDE, ("x", -1): HEAD_SIDE},
    ("armL", 0):  {("x", 1): ARM_SIDE, ("x", -1): ARM_SIDE, ("y", 1): ARM_TB, ("y", -1): ARM_TB},
    ("armR", 0):  {("x", 1): ARM_SIDE, ("x", -1): ARM_SIDE, ("y", 1): ARM_TB, ("y", -1): ARM_TB},
    ("legL", 0):  {("x", 1): LEG_SIDE, ("x", -1): LEG_SIDE, ("y", 1): LEG_TB, ("y", -1): LEG_TB},
    ("legR", 0):  {("x", 1): LEG_SIDE, ("x", -1): LEG_SIDE, ("y", 1): LEG_TB, ("y", -1): LEG_TB},
}
for side in ("antL", "antR"):
    for blk in (0, 1, 2):
        RULES[(side, blk)] = {(ax, s): ANT for ax in "xyz" for s in (1, -1)}
RULES[("neck", 0)] = {(ax, s): NECK for ax in "xyz" for s in (1, -1)}
RULES[("hips", 0)] = {(ax, s): HIPS for ax in "xyz" for s in (1, -1)}
RULES[("hips", 1)] = {(ax, s): HIPS for ax in "xyz" for s in (1, -1)}


def load(p):
    b = p.read_bytes(); assert b[:4] == b"RBT1"; o = 4
    n = struct.unpack_from("<H", b, o)[0]; o += 2
    parts = []
    for _ in range(n):
        ln = b[o]; o += 1; name = b[o:o + ln].decode(); o += ln
        parent = struct.unpack_from("<h", b, o)[0]; o += 2
        piv = struct.unpack_from("<fff", b, o); o += 12
        fl = b[o]; o += 1
        nv = struct.unpack_from("<H", b, o)[0]; o += 2
        ni = struct.unpack_from("<i", b, o)[0]; o += 4
        v = [list(struct.unpack_from("<8f", b, o + 32 * i)) for i in range(nv)]; o += 32 * nv
        idx = list(struct.unpack_from("<%dH" % ni, b, o)); o += 2 * ni
        parts.append(dict(name=name, parent=parent, pivot=piv, flags=fl, v=v, idx=idx))
    return parts


def save(parts, p):
    buf = bytearray(b"RBT1") + struct.pack("<H", len(parts))
    for q in parts:
        nm = q["name"].encode()
        buf += bytes([len(nm)]) + nm + struct.pack("<h", q["parent"]) + struct.pack("<fff", *q["pivot"])
        buf += bytes([q["flags"]]) + struct.pack("<H", len(q["v"])) + struct.pack("<i", len(q["idx"]))
        for v in q["v"]: buf += struct.pack("<8f", *v)
        for i in q["idx"]: buf += struct.pack("<H", i)
    p.write_bytes(bytes(buf))


def dominant(n):
    """Eje y signo dominantes de una normal. Empates (biseles): z, luego x, luego y."""
    ax, ay, az = abs(n[0]), abs(n[1]), abs(n[2])
    m = max(ax, ay, az)
    if az >= m - 0.05: return ("z", 1 if n[2] >= 0 else -1)
    if ax >= m - 0.05: return ("x", 1 if n[0] >= 0 else -1)
    return ("y", 1 if n[1] >= 0 else -1)


def plano(v, eje, s):
    """(a, b) = (derecha, arriba) de la cara vista desde fuera."""
    x, y, z = v[0], v[1], v[2]
    if eje == "z": return (s * x, y)
    if eje == "x": return (-s * z, y)
    return (x, -s * z)


def reuv(parts):
    for q in parts:
        nv = len(q["v"])
        bloques = [(i, min(i + 96, nv)) for i in range(0, nv, 96)] if nv >= 96 else [(0, nv)]
        for bi, (i0, i1) in enumerate(bloques):
            reglas = RULES.get((q["name"], bi), {})
            grupos = {}
            for i in range(i0, i1):
                grupos.setdefault(dominant(q["v"][i][3:6]), []).append(i)
            for g, idxs in grupos.items():
                # isla: la de la regla, o la que ya usaba la cara (bbox de sus UV actuales)
                if g in reglas:
                    x0, y0, x1, y1 = reglas[g]
                    isl = (x0 + INSET, y0 + INSET, x1 - INSET, y1 - INSET)
                else:
                    us = [q["v"][i][6] * A for i in idxs if True]; vs = [q["v"][i][7] * A for i in idxs]
                    isl = (min(us), min(vs), max(us), max(vs))
                    if isl[2] - isl[0] < 4 or isl[3] - isl[1] < 4:
                        continue
                ab = [plano(q["v"][i], *g) for i in idxs]
                amin = min(a for a, _ in ab); amax = max(a for a, _ in ab)
                bmin = min(b for _, b in ab); bmax = max(b for _, b in ab)
                fw = max(amax - amin, 1e-4); fh = max(bmax - bmin, 1e-4)
                iw = isl[2] - isl[0]; ih = isl[3] - isl[1]
                # escala UNIFORME: la cara usa una ventana de la isla con su misma proporción
                # (lo que sobra de la isla en el otro eje se recorta, nunca se estira)
                d = min(iw / fw, ih / fh)
                d = min(d, 260.0)
                # centrado
                offu = isl[0] + (iw - fw * d) / 2.0
                offv = isl[1] + (ih - fh * d) / 2.0
                for i, (a, b) in zip(idxs, ab):
                    u = offu + (a - amin) * d
                    v = offv + (bmax - b) * d
                    # nunca salir de la isla
                    u = min(max(u, isl[0]), isl[2]); v = min(max(v, isl[1]), isl[3])
                    q["v"][i][6] = u / A; q["v"][i][7] = v / A


if __name__ == "__main__":
    parts = load(BIN)
    reuv(parts)
    save(parts, BIN)
    print("UV recalculadas ->", BIN)
