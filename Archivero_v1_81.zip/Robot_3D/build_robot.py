#!/usr/bin/env python3
"""
build_robot.py — Genera el robot 3D de Archivero en formato RBT1 + atlas.

Uso:
    python build_robot.py

Produce:
    ../Archivero/app/src/main/assets/robot/robot.bin
    ../Archivero/app/src/main/res/drawable-nodpi/robot_atlas.png

Características:
  - 10 piezas con pivotes compatibles con Robot3D.kt / Animaciones.kt
  - Antenas firmes y gruesas (ya no son tiras)
  - Cuerpo cerrado, sin huecos
  - Atlas púrpura oscuro con franjas y bordes
"""
import math
import struct
import os
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("Necesitas Pillow: pip install Pillow")
    raise

ROOT = Path(__file__).resolve().parent.parent
OUT_BIN = ROOT / "Archivero" / "app" / "src" / "main" / "assets" / "robot" / "robot.bin"
OUT_ATLAS = ROOT / "Archivero" / "app" / "src" / "main" / "res" / "drawable-nodpi" / "robot_atlas.png"
ATLAS_SIZE = 1254

UV_METAL  = (0.05, 0.05, 0.45, 0.45)
UV_DARK   = (0.55, 0.05, 0.95, 0.45)
UV_STRIPE = (0.05, 0.55, 0.45, 0.95)
UV_ANT    = (0.55, 0.55, 0.95, 0.95)


def write_bin(parts, path: Path):
    buf = bytearray()
    buf += b"RBT1"
    buf += struct.pack("<H", len(parts))
    for p in parts:
        name = p["name"].encode("utf-8")
        buf += bytes([len(name)]) + name
        buf += struct.pack("<h", p["parent"])
        buf += struct.pack("<fff", *p["pivot"])
        buf += bytes([p.get("flags", 0)])
        nv = len(p["verts"])
        ni = len(p["indices"])
        buf += struct.pack("<H", nv)
        buf += struct.pack("<i", ni)
        for v in p["verts"]:
            buf += struct.pack("<ffffffff", *v)
        for i in p["indices"]:
            buf += struct.pack("<H", i)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(buf)
    print(f"  {path}  ({len(buf)} bytes, {len(parts)} partes)")


def box(cx, cy, cz, sx, sy, sz, u0, v0, u1, v1):
    hx, hy, hz = sx / 2, sy / 2, sz / 2
    corners = [
        (cx - hx, cy - hy, cz - hz), (cx + hx, cy - hy, cz - hz),
        (cx - hx, cy + hy, cz - hz), (cx + hx, cy + hy, cz - hz),
        (cx - hx, cy - hy, cz + hz), (cx + hx, cy - hy, cz + hz),
        (cx - hx, cy + hy, cz + hz), (cx + hx, cy + hy, cz + hz),
    ]
    faces = [
        ([0, 1, 3, 2], (0, 0, -1)),
        ([4, 6, 7, 5], (0, 0, 1)),
        ([0, 4, 5, 1], (0, -1, 0)),
        ([2, 3, 7, 6], (0, 1, 0)),
        ([0, 2, 6, 4], (-1, 0, 0)),
        ([1, 5, 7, 3], (1, 0, 0)),
    ]
    verts, idx = [], []
    for quads, nrm in faces:
        base = len(verts)
        us = [u0, u1, u1, u0]
        vs = [v0, v0, v1, v1]
        for oi, qi in enumerate(quads):
            x, y, z = corners[qi]
            verts.append((x, y, z, nrm[0], nrm[1], nrm[2], us[oi], vs[oi]))
        idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    return verts, idx


def cylinder(cx, cy, cz, radius, height, axis="y", seg=12, u0=0.1, v0=0.1, u1=0.3, v1=0.3):
    verts, idx = [], []
    h = height / 2
    for i in range(seg):
        a0 = 2 * math.pi * i / seg
        a1 = 2 * math.pi * (i + 1) / seg
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        if axis == "y":
            p0b = (cx + radius * c0, cy - h, cz + radius * s0)
            p0t = (cx + radius * c0, cy + h, cz + radius * s0)
            p1b = (cx + radius * c1, cy - h, cz + radius * s1)
            p1t = (cx + radius * c1, cy + h, cz + radius * s1)
            n0, n1 = (c0, 0, s0), (c1, 0, s1)
        else:
            p0b = (cx + radius * c0, cy + radius * s0, cz - h)
            p0t = (cx + radius * c0, cy + radius * s0, cz + h)
            p1b = (cx + radius * c1, cy + radius * s1, cz - h)
            p1t = (cx + radius * c1, cy + radius * s1, cz + h)
            n0, n1 = (c0, s0, 0), (c1, s1, 0)
        base = len(verts)
        uu0 = u0 + (u1 - u0) * i / seg
        uu1 = u0 + (u1 - u0) * (i + 1) / seg
        verts += [(*p0b, *n0, uu0, v0), (*p0t, *n0, uu0, v1),
                  (*p1b, *n1, uu1, v0), (*p1t, *n1, uu1, v1)]
        idx += [base, base + 2, base + 3, base, base + 3, base + 1]
    for sign in (-1, 1):
        base = len(verts)
        if axis == "y":
            center = (cx, cy + sign * h, cz)
            nrm = (0, sign, 0)
        else:
            center = (cx, cy, cz + sign * h)
            nrm = (0, 0, sign)
        verts.append((*center, *nrm, (u0 + u1) / 2, (v0 + v1) / 2))
        for i in range(seg):
            a = 2 * math.pi * i / seg
            c, s = math.cos(a), math.sin(a)
            if axis == "y":
                p = (cx + radius * c, cy + sign * h, cz + radius * s)
            else:
                p = (cx + radius * c, cy + radius * s, cz + sign * h)
            verts.append((*p, *nrm, u0 + (u1 - u0) * (0.5 + 0.5 * c),
                          v0 + (v1 - v0) * (0.5 + 0.5 * s)))
        for i in range(seg):
            i2 = (i + 1) % seg
            if sign > 0:
                idx += [base, base + 1 + i, base + 1 + i2]
            else:
                idx += [base, base + 1 + i2, base + 1 + i]
    return verts, idx


def merge(pieces):
    all_v, all_i = [], []
    for v, i in pieces:
        base = len(all_v)
        all_v.extend(v)
        all_i.extend(x + base for x in i)
    return all_v, all_i


def make_antenna(side):
    """Antena firme y gruesa (ya no es una tira)."""
    sx = side * 0.38
    a1, i1 = box(sx, 0.55, -0.05, 0.28, 0.55, 0.22, *UV_ANT)
    a2, i2 = box(sx * 1.05, 0.95, -0.08, 0.22, 0.45, 0.18, *UV_ANT)
    a3, i3 = box(sx * 1.08, 1.22, -0.10, 0.16, 0.18, 0.14, *UV_DARK)
    return merge([(a1, i1), (a2, i2), (a3, i3)])


def make_arm(side):
    a1, i1 = box(side * 0.15, -0.35, 0, 0.38, 0.85, 0.42, *UV_METAL)
    a2, i2 = box(side * 0.18, -1.05, 0.05, 0.32, 0.70, 0.36, *UV_METAL)
    a3, i3 = box(side * 0.18, -1.50, 0.05, 0.28, 0.28, 0.28, *UV_DARK)
    return merge([(a1, i1), (a2, i2), (a3, i3)])


def make_leg(side):
    a1, i1 = box(side * 0.05, -0.55, 0.05, 0.42, 1.00, 0.48, *UV_METAL)
    a2, i2 = box(side * 0.05, -1.30, 0.08, 0.38, 0.55, 0.52, *UV_DARK)
    return merge([(a1, i1), (a2, i2)])


def build_parts():
    parts = []
    tv, ti = box(0, 0.15, 0, 1.70, 1.55, 1.10, *UV_METAL)
    pv, pi = box(0, 0.25, 0.56, 1.20, 0.55, 0.08, *UV_STRIPE)
    tv, ti = merge([(tv, ti), (pv, pi)])
    parts.append({"name": "torso", "parent": -1, "pivot": (0, 0, 0), "flags": 0, "verts": tv, "indices": ti})

    hv, hi = box(0, 0.35, 0, 0.95, 0.75, 0.85, *UV_METAL)
    vv, vi = box(0, 0.38, 0.44, 0.70, 0.28, 0.06, *UV_DARK)
    hv, hi = merge([(hv, hi), (vv, vi)])
    parts.append({"name": "head", "parent": 0, "pivot": (0, 1.45, 0), "flags": 0, "verts": hv, "indices": hi})

    av, ai = make_antenna(-1)
    parts.append({"name": "antL", "parent": 1, "pivot": (0, 1.45, 0), "flags": 1, "verts": av, "indices": ai})
    av, ai = make_antenna(+1)
    parts.append({"name": "antR", "parent": 1, "pivot": (0, 1.45, 0), "flags": 1, "verts": av, "indices": ai})

    nv, ni = cylinder(0, 0.12, 0, 0.18, 0.28, axis="y", seg=10)
    parts.append({"name": "neck", "parent": 0, "pivot": (0, 1.27, 0), "flags": 0, "verts": nv, "indices": ni})

    av, ai = make_arm(-1)
    parts.append({"name": "armL", "parent": 0, "pivot": (-1.30, 1.22, 0), "flags": 0, "verts": av, "indices": ai})
    av, ai = make_arm(+1)
    parts.append({"name": "armR", "parent": 0, "pivot": (1.30, 1.22, 0), "flags": 0, "verts": av, "indices": ai})

    av, ai = make_leg(-1)
    parts.append({"name": "legL", "parent": 0, "pivot": (-0.55, -1.30, 0), "flags": 0, "verts": av, "indices": ai})
    av, ai = make_leg(+1)
    parts.append({"name": "legR", "parent": 0, "pivot": (0.55, -1.30, 0), "flags": 0, "verts": av, "indices": ai})

    hv, hi = box(0, 0.15, 0, 1.10, 0.40, 0.70, *UV_DARK)
    parts.append({"name": "hips", "parent": 0, "pivot": (0, -1.30, 0), "flags": 0, "verts": hv, "indices": hi})
    return parts


def build_atlas(path: Path):
    img = Image.new("RGB", (ATLAS_SIZE, ATLAS_SIZE), (12, 8, 18))
    draw = ImageDraw.Draw(img)
    def rect(u0, v0, u1, v1, color):
        x0, y0 = int(u0 * ATLAS_SIZE), int(v0 * ATLAS_SIZE)
        x1, y1 = int(u1 * ATLAS_SIZE), int(v1 * ATLAS_SIZE)
        draw.rectangle([x0, y0, x1, y1], fill=color)
    rect(0.05, 0.05, 0.45, 0.45, (55, 35, 78))
    rect(0.55, 0.05, 0.95, 0.45, (28, 18, 42))
    rect(0.05, 0.55, 0.45, 0.95, (70, 50, 110))
    rect(0.55, 0.55, 0.95, 0.95, (40, 25, 60))
    for i in range(-20, 40):
        x = int(0.05 * ATLAS_SIZE) + i * 18
        draw.line([(x, int(0.05 * ATLAS_SIZE)), (x + 80, int(0.45 * ATLAS_SIZE))],
                  fill=(75, 55, 105), width=3)
    for region in [(0.05, 0.05, 0.45, 0.45), (0.55, 0.05, 0.95, 0.45)]:
        x0 = int(region[0] * ATLAS_SIZE) + 4
        y0 = int(region[1] * ATLAS_SIZE) + 4
        x1 = int(region[2] * ATLAS_SIZE) - 4
        y1 = int(region[3] * ATLAS_SIZE) - 4
        draw.rectangle([x0, y0, x1, y1], outline=(120, 100, 160), width=2)
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path, "PNG")
    print(f"  {path}  ({ATLAS_SIZE}x{ATLAS_SIZE})")


def main():
    print("Generando robot 3D (antenas firmes, cuerpo solido)...")
    parts = build_parts()
    write_bin(parts, OUT_BIN)
    build_atlas(OUT_ATLAS)
    print("Listo.")


if __name__ == "__main__":
    main()
