package com.archivero

import android.content.Context
import android.graphics.Canvas
import kotlin.math.min

/*
 * Aspecto del amigo flotante (fuera de la app): el robot 3D de Robot3D.kt. Esta clase solo lo coloca y lo escala dentro de su
 * ventana; la pose (brazos, cabeza, ojo) la calcula Animaciones.kt y el giro lo mueve el controlador de Seguir.kt.
 */
internal class AmigoArte(ctx: Context) {
    private val robot = Robot3D(ctx)
    private var escala = 1f

    fun size(w: Int, h: Int) {
        escala = min(w, h) / 2f / 2.9f          // el robot mide ~5.3 unidades de alto; así cabe entero con margen
    }

    fun draw(c: Canvas, w: Int, h: Int, p: Pose, yaw: Float, pitch: Float, roll: Float, grow: Float, glowK: Float) {
        robot.draw(c, w / 2f, h / 2f, escala * grow, yaw, pitch, roll, p, glowK)
    }

    /** Suelta el atlas de texturas (al quitar la esfera de la pantalla). */
    fun liberar() = robot.liberar()
}
