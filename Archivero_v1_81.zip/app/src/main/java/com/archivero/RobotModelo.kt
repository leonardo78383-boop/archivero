package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Shader
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Modelo 3D del robot (assets/robot/robot.bin, generado por build_robot.py) y su atlas de texturas.
 * El modelo se lee una sola vez (pesa ~46 KB). El atlas (1254×1254) se carga solo mientras haya un robot en pantalla
 * ([RobotTex.adquirir] / [RobotTex.liberar]) y se guarda en 5 tamaños (cadena de mips) para que se vea nítido y sin brillos/parpadeos a cualquier escala.
 */

internal class RobotParte(
    val nombre: String, val padre: Int, val pivote: FloatArray, val flags: Int,
    val nv: Int, val v: FloatArray, val idx: ShortArray
)

internal class RobotModelo(val partes: Array<RobotParte>) {
    val nv: Int = partes.sumOf { it.nv }
    val nt: Int = partes.sumOf { it.idx.size } / 3
    /** Posición absoluta (en reposo), normal y uv (0..1) de todos los vértices, partes una detrás de otra. */
    val px = FloatArray(nv); val py = FloatArray(nv); val pz = FloatArray(nv)
    val nx = FloatArray(nv); val ny = FloatArray(nv); val nz = FloatArray(nv)
    val u = FloatArray(nv); val v = FloatArray(nv)
    val parteDe = IntArray(nv)
    val tri = ShortArray(nt * 3)
    val primero = IntArray(partes.size)         // índice del primer vértice de cada parte

    init {
        var o = 0
        var t = 0
        for ((pi, p) in partes.withIndex()) {
            primero[pi] = o
            for (i in 0 until p.nv) {
                val b = i * 8
                px[o + i] = p.v[b] + p.pivote[0]; py[o + i] = p.v[b + 1] + p.pivote[1]; pz[o + i] = p.v[b + 2] + p.pivote[2]
                nx[o + i] = p.v[b + 3]; ny[o + i] = p.v[b + 4]; nz[o + i] = p.v[b + 5]
                u[o + i] = p.v[b + 6]; v[o + i] = p.v[b + 7]
                parteDe[o + i] = pi
            }
            for (k in p.idx.indices) tri[t++] = (p.idx[k] + o).toShort()
            o += p.nv
        }
    }

    fun indice(nombre: String): Int = partes.indexOfFirst { it.nombre == nombre }

    companion object {
        @Volatile private var cache: RobotModelo? = null

        fun cargar(ctx: Context): RobotModelo {
            cache?.let { return it }
            synchronized(this) {
                cache?.let { return it }
                val bytes = ctx.applicationContext.assets.open("robot/robot.bin").use { it.readBytes() }
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                val magic = ByteArray(4); bb.get(magic)
                require(String(magic) == "RBT1") { "robot.bin inválido" }
                val n = bb.short.toInt() and 0xFFFF
                val lista = ArrayList<RobotParte>(n)
                for (i in 0 until n) {
                    val ln = bb.get().toInt() and 0xFF
                    val nb = ByteArray(ln); bb.get(nb)
                    val padre = bb.short.toInt()
                    val piv = floatArrayOf(bb.float, bb.float, bb.float)
                    val flags = bb.get().toInt() and 0xFF
                    val nv = bb.short.toInt() and 0xFFFF
                    val ni = bb.int
                    val v = FloatArray(nv * 8)
                    bb.asFloatBuffer().get(v)
                    bb.position(bb.position() + nv * 32)
                    val idx = ShortArray(ni)
                    bb.asShortBuffer().get(idx)
                    bb.position(bb.position() + ni * 2)
                    lista.add(RobotParte(String(nb), padre, piv, flags, nv, v, idx))
                }
                val m = RobotModelo(lista.toTypedArray())
                cache = m
                return m
            }
        }
    }
}

internal object RobotTex {
    const val BASE = 1254
    /** Niveles de la cadena de mips (1254, 627, 313, 156, 78 px). Cada uno sale del anterior con filtro, sin saltarse ninguno. */
    const val NIVELES = 5
    private var refs = 0
    private var niveles: Array<Bitmap>? = null
    private var shaders: Array<BitmapShader>? = null

    val tamano: IntArray = IntArray(NIVELES) { BASE shr it }

    /** Pide el atlas (lo carga si nadie lo tenía). Cada [adquirir] debe acabar con su [liberar]. */
    @Synchronized
    fun adquirir(ctx: Context) {
        refs++
        if (niveles != null) return
        try {
            val opts = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b0 = BitmapFactory.decodeResource(ctx.applicationContext.resources, R.drawable.robot_atlas, opts) ?: return
            val lista = ArrayList<Bitmap>(NIVELES)
            lista.add(b0)
            for (i in 1 until NIVELES) {
                // reducción a la mitad exacta con filtro (promedia 2x2): sin aliasing y sin perder nitidez de más
                lista.add(Bitmap.createScaledBitmap(lista[i - 1], tamano[i], tamano[i], true))
            }
            niveles = lista.toTypedArray()
            shaders = Array(NIVELES) { BitmapShader(niveles!![it], Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        } catch (e: Throwable) {
            niveles = null; shaders = null
        }
    }

    @Synchronized
    fun liberar() {
        refs = (refs - 1).coerceAtLeast(0)
        if (refs > 0) return
        shaders = null
        niveles?.forEach { if (!it.isRecycled) it.recycle() }
        niveles = null
    }

    @Synchronized
    fun shader(nivel: Int): BitmapShader? = shaders?.get(nivel.coerceIn(0, NIVELES - 1))
}
