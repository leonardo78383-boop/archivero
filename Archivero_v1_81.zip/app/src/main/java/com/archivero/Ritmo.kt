package com.archivero

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Luces LED del pecho del robot: color elegido (normal = rojo del diseño / verde / violeta) y pulso al ritmo de la música.
 * El color se recuerda. El pulso solo existe mientras suena música; sin música las luces brillan fijas con el color elegido.
 */
object DronNeon {
    const val NORMAL = 0       // el rojo del diseño
    const val VERDE = 1
    const val VIOLETA = 2

    /** Modo de color actual. Es un estado de Compose: al cambiarlo, lo que lo lea se repinta. */
    var modo by mutableIntStateOf(NORMAL)
        private set

    private var cargado = false
    @Volatile private var golpe = 0f
    @Volatile private var golpeMs = 0L
    /** true = el pulso sale del audio real (Visualizer); false = respiración suave de reserva (sin permiso o sin soporte). */
    @Volatile var analisisReal = false

    fun cargar(ctx: Context) {
        if (cargado) return
        cargado = true
        modo = ctx.applicationContext.getSharedPreferences("dron", Context.MODE_PRIVATE).getInt("neon_robot", NORMAL).coerceIn(0, 2)
    }

    fun fijar(ctx: Context, m: Int) {
        modo = m.coerceIn(0, 2)
        ctx.applicationContext.getSharedPreferences("dron", Context.MODE_PRIVATE).edit().putInt("neon_robot", modo).apply()
    }

    /** Componentes (0..1) del color del modo [m]. */
    fun r(m: Int): Float = when (m) { VERDE -> 0.25f; VIOLETA -> 0.62f; else -> 1.00f }
    fun g(m: Int): Float = when (m) { VERDE -> 1.00f; VIOLETA -> 0.30f; else -> 0.13f }
    fun b(m: Int): Float = when (m) { VERDE -> 0.35f; VIOLETA -> 1.00f; else -> 0.20f }

    /** Lo llama el análisis de audio con la fuerza del golpe de graves (0..1). */
    fun golpe(v: Float) {
        val ahora = SystemClock.uptimeMillis()
        val actual = golpeAhora(ahora)
        golpe = max(v, actual)
        golpeMs = ahora
    }

    private fun golpeAhora(ahora: Long): Float {
        val dt = (ahora - golpeMs).coerceIn(0L, 2000L).toFloat()
        return golpe * exp(-dt / 110f)             // cae rápido entre golpes: se nota el ritmo
    }

    /** Pulso actual 0..1 si suena música; -1 si no suena (los aros quedan fijos). */
    fun pulso(): Float {
        if (Musica.actual()?.playing != true) return -1f
        val ahora = SystemClock.uptimeMillis()
        if (analisisReal) return golpeAhora(ahora).coerceIn(0f, 1f)
        return 0.40f + 0.25f * sin(ahora / 300.0).toFloat()
    }

    fun permisoMic(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}

/** Escucha los graves de la canción que suena (Visualizer sobre la sesión del reproductor) para mover el neón. Necesita permiso de micrófono. */
internal object RitmoAudio {
    private var viz: Visualizer? = null
    private var techo = 8f

    fun adjuntar(ctx: Context, sesion: Int) {
        soltar()
        if (sesion == 0 || !DronNeon.permisoMic(ctx)) { DronNeon.analisisReal = false; return }
        try {
            val v = Visualizer(sesion)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) { }
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) analizar(fft)
                }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            viz = v
            DronNeon.analisisReal = true
        } catch (e: Exception) {
            viz = null
            DronNeon.analisisReal = false
        }
    }

    fun soltar() {
        val v = viz ?: return
        viz = null
        try { v.setEnabled(false) } catch (e: Exception) { }
        try { v.release() } catch (e: Exception) { }
        DronNeon.analisisReal = false
    }

    /** Energía de graves (~40–220 Hz) frente a su propio techo móvil: el golpe es lo que pasa del 55 % del máximo reciente. */
    private fun analizar(fft: ByteArray) {
        val bins = fft.size / 2
        var e = 0f
        var n = 0
        for (k in 1..5) {
            if (k >= bins) break
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            e += sqrt((re * re + im * im).toFloat())
            n++
        }
        if (n == 0) return
        e /= n
        techo = max(e, techo * 0.993f)
        if (techo < 8f) techo = 8f
        val x = e / techo
        val golpe = ((x - 0.55f) / 0.45f).coerceIn(0f, 1f)
        DronNeon.golpe(golpe * golpe)
    }
}
