package com.archivero

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Animaciones del robot (estilo Minecraft: piezas rígidas que giran en articulaciones).
 * Nunca deforma el mesh: solo rotaciones de head / armL / armR / legL / legR.
 *
 * 1. Abrazo suave
 * 2. Bostezo
 * 3. Señalar
 * 4. Caminata (mientras se mueve por la pantalla)
 * 5. Parpadeo del ojo
 * + micro-movimientos en idle para que no quede congelado
 */

internal class Pose {
    var lax = 0f; var lay = 0f; var laz = 0f        // brazo izquierdo
    var rax = 0f; var ray = 0f; var raz = 0f        // brazo derecho
    var llx = 0f; var lly = 0f; var llz = 0f        // pierna izquierda
    var rlx = 0f; var rly = 0f; var rlz = 0f        // pierna derecha
    var headP = 0f; var headY = 0f; var headR = 0f  // cabeza
    var bodyYaw = 0f                                 // rad
    var bodyPitch = 0f                               // rad
    var eyeOpen = 1f

    fun reset() {
        lax = 0f; lay = 0f; laz = 0f; rax = 0f; ray = 0f; raz = 0f
        llx = 0f; lly = 0f; llz = 0f; rlx = 0f; rly = 0f; rlz = 0f
        headP = 0f; headY = 0f; headR = 0f; bodyYaw = 0f; bodyPitch = 0f; eyeOpen = 1f
    }
}

/** Smoothstep clásico */
private fun sm(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/** Smoothstep más suave (entrada y salida lentas) */
private fun smoother(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * t * (t * (t * 6f - 15f) + 10f)
}

internal class Animaciones {
    private val rnd = java.util.Random()
    private var cur = -1
    private var last = -1
    private var start = 0L
    private var nextAt = 0L
    private var lado = 1f
    private var cortando = false
    private var cortaDesde = 0L
    private var blinkAt = 0L
    private var blinkStart = -1L

    fun reiniciar() {
        cur = -1; cortando = false; nextAt = 0L; blinkStart = -1L
    }

    /**
     * @param quieto true si no lo tocan y no está caminando → puede hacer gestos
     * @param spdNorm velocidad 0..1 para la caminata de extremidades
     */
    fun update(p: Pose, now: Long, quieto: Boolean, spdNorm: Float = 0f) {
        p.reset()
        updateBlink(p, now)

        // ── Caminata (siempre que se mueva): extremidades rígidas en articulación ──
        if (spdNorm > 0.04f) {
            walk(p, now, spdNorm)
        } else if (quieto) {
            // micro-idle: respiración muy suave para que no quede muerto
            idle(p, now)
        }

        // ── Gestos ocasionales solo cuando está quieto ──
        if (nextAt == 0L) nextAt = now + 3000L + rnd.nextInt(2000)
        if (cur >= 0 && !quieto && !cortando) {
            cortando = true
            cortaDesde = now
        }
        if (cur < 0) {
            if (!quieto || now < nextAt) return
            var pick = rnd.nextInt(3)
            if (pick == last) pick = (pick + 1 + rnd.nextInt(2)) % 3
            cur = pick; last = pick; start = now; cortando = false
            lado = if (rnd.nextBoolean()) 1f else -1f
        }

        val dur = when (cur) { 0 -> 4800f; 1 -> 3800f; else -> 4000f }
        val t = ((now - start) / dur).coerceIn(0f, 1f)
        // fundido de salida más largo y suave
        var w = 1f
        if (cortando) w = 1f - smoother((now - cortaDesde) / 480f)

        when (cur) {
            0 -> abrazo(p, t, w)
            1 -> bostezo(p, t, w)
            else -> senalar(p, t, w)
        }

        if (t >= 1f || w <= 0.01f) {
            cur = -1; cortando = false
            nextAt = now + 5000L + rnd.nextInt(8000)
        }
    }

    // ───────── Caminata estilo Minecraft (oscilación limpia en articulaciones) ─────────
    private fun walk(p: Pose, now: Long, spd: Float) {
        // fase lenta y constante → no brusca
        val fase = (now / 320.0).toFloat() * (2f * PI.toFloat())
        val k = spd.coerceIn(0f, 1f)
        val ampLeg = 22f * k          // grados de swing de pierna
        val ampArm = 16f * k          // brazos en contrapeso
        val swing = sin(fase)

        // piernas: adelante / atrás
        p.llx =  swing * ampLeg
        p.rlx = -swing * ampLeg
        // ligera apertura lateral
        p.llz =  sin(fase + 0.8f) * ampLeg * 0.18f
        p.rlz = -sin(fase + 0.8f) * ampLeg * 0.18f

        // brazos: contrapeso natural
        p.lax = -swing * ampArm
        p.rax =  swing * ampArm
        p.laz = -sin(fase * 0.5f) * 6f * k
        p.raz =  sin(fase * 0.5f) * 6f * k

        // cabeza y cuerpo: balanceo muy suave
        p.headP = sin(fase * 0.5f) * 3f * k
        p.headR = cos(fase) * 2f * k
        p.bodyPitch = -0.04f * k * cos(fase * 0.5f)
        p.bodyYaw   =  0.03f * k * sin(fase * 0.5f)
    }

    // ───────── Idle: respiración mínima ─────────
    private fun idle(p: Pose, now: Long) {
        val f = (now / 1800.0).toFloat() * (2f * PI.toFloat())
        p.bodyPitch = sin(f) * 0.012f
        p.headP = sin(f * 0.7f) * 1.5f
        // brazos caídos con leve balanceo
        p.lax = sin(f * 0.5f) * 2f
        p.rax = -sin(f * 0.5f) * 2f
    }

    // ───────── Gestos ─────────

    /** Abrazo: abre y cierra con curvas suaves, sin forzar extremos */
    private fun abrazo(p: Pose, t: Float, w: Float) {
        val s1 = smoother(t / 0.32f)
        val s2 = smoother((t - 0.38f) / 0.28f)
        val s3 = smoother((t - 0.78f) / 0.22f)
        val abre = s1 * (1f - s2 * 0.5f) * (1f - s3)
        val cierra = s2 * (1f - s3)

        val open = 42f * abre * w
        val front = 32f * cierra * w

        p.laz = -open
        p.raz =  open
        p.lay =  front
        p.ray = -front
        p.headP = 5f * cierra * w
        p.bodyPitch = 0.05f * (abre + cierra) * w
    }

    /** Bostezo: brazo sube despacio, cabeza se echa atrás */
    private fun bostezo(p: Pose, t: Float, w: Float) {
        val a = smoother(t / 0.35f) * (1f - smoother((t - 0.72f) / 0.28f))
        p.rax = -55f * a * w
        p.raz = -12f * a * w
        p.headP = (-10f + 2f * sin(2f * PI.toFloat() * t * 1.5f)) * a * w
        p.headR = 5f * a * w
        p.bodyPitch = -0.03f * a * w
    }

    /** Señalar: gira cuerpo y levanta un brazo con suavidad */
    private fun senalar(p: Pose, t: Float, w: Float) {
        val a = smoother(t / 0.30f) * (1f - smoother((t - 0.75f) / 0.25f))
        val pulso = 4f * a * sin(2f * PI.toFloat() * 2.5f * t)
        val ax = -18f * a
        val az = (48f * a + pulso) * lado
        if (lado > 0f) {
            p.rax = ax * w; p.raz = az * w
        } else {
            p.lax = ax * w; p.laz = az * w
        }
        p.bodyYaw = 0.35f * lado * a * w
        p.headY = 10f * lado * a * w
    }

    // ───────── Parpadeo ─────────
    private fun updateBlink(p: Pose, now: Long) {
        if (blinkStart < 0L) {
            if (blinkAt == 0L) blinkAt = now + 2200L + rnd.nextInt(3500)
            if (now >= blinkAt) {
                blinkStart = now
                blinkAt = now + 2800L + rnd.nextInt(5000)
            }
        }
        if (blinkStart >= 0L) {
            val bt = ((now - blinkStart) / 140f).coerceIn(0f, 1f)
            // cierra y abre rápido pero suave
            p.eyeOpen = if (bt < 0.45f) {
                1f - smoother(bt / 0.45f) * 0.92f
            } else {
                0.08f + smoother((bt - 0.45f) / 0.55f) * 0.92f
            }
            if (bt >= 1f) blinkStart = -1L
        }
    }
}
