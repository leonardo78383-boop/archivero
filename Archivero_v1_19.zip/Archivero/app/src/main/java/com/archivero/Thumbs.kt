package com.archivero

import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

/**
 * Miniaturas de fotos y vídeos para la galería.
 * - Usa el generador de miniaturas de Android (rápido: aprovecha la miniatura incrustada en la foto y respeta la rotación).
 * - Guarda las ya generadas en memoria, así volver a verlas es instantáneo.
 * - Solo 3 a la vez, para que desplazarse rápido no sature el teléfono.
 */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

    fun cached(path: String): Bitmap? = cache.get(path)

    /** Memoria que ocupan las miniaturas guardadas (bytes). */
    fun sizeBytes(): Long = cache.size().toLong() * 1024L

    fun clear() = cache.evictAll()

    suspend fun load(f: File, video: Boolean): Bitmap? {
        cache.get(f.path)?.let { return it }
        return withContext(pool) {
            try {
                val size = Size(256, 256)
                val b = if (video) ThumbnailUtils.createVideoThumbnail(f, size, null)
                        else ThumbnailUtils.createImageThumbnail(f, size, null)
                cache.put(f.path, b)
                b
            } catch (e: Exception) {
                null   // archivo dañado o formato no soportado: se muestra un cuadro gris
            }
        }
    }
}
