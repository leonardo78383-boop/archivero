package com.archivero

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Mini panel de "Herramientas" del amigo: tres fichas con el mismo estilo que las del explorador
 * (esquina cortada, canto con volumen, ícono de línea fina). Por ahora solo son el panel y los íconos;
 * las herramientas funcionales vienen después.
 */
@Composable
fun ToolsPanel(onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        ToolTile("EDITOR", "FOTOS", R.drawable.ic_tool_photo, Modifier.weight(1f)) { onPick("Editor de fotos") }
        Spacer(Modifier.width(8.dp))
        ToolTile("EDITOR", "VÍDEOS", R.drawable.ic_tool_video, Modifier.weight(1f)) { onPick("Editor de vídeos") }
        Spacer(Modifier.width(8.dp))
        ToolTile("EDITOR", "MÚSICA", R.drawable.ic_tool_music, Modifier.weight(1f)) { onPick("Editor de música") }
    }
}

@Composable
private fun ToolTile(line1: String, line2: String, icon: Int, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(82.dp)
            .drawBehind {
                val w = size.width
                val h = size.height - 4.dp.toPx()
                val cut = w * 0.26f
                val rad = 8.dp.toPx()
                val sw = 1.5.dp.toPx()
                val lip = 3.dp.toPx()
                // Forma de ficha: esquina superior izquierda cortada en diagonal.
                val poly = Path().apply {
                    moveTo(0f, cut); lineTo(cut, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(0f, h); close()
                }
                val cap = Brush.verticalGradient(listOf(Color(0xFF2E2E36), Color(0xFF15151A)))
                val rim = Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x12FFFFFF)))
                translate(0f, lip) {
                    clipPath(poly) { drawRoundRect(Color(0xFF050507), cornerRadius = CornerRadius(rad)) }
                }
                clipPath(poly) {
                    drawRoundRect(cap, cornerRadius = CornerRadius(rad))
                    drawRoundRect(rim, cornerRadius = CornerRadius(rad), style = Stroke(width = sw))
                }
                drawLine(Color(0x66FFFFFF), Offset(0f, cut), Offset(cut, 0f), strokeWidth = sw)
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    ) {
        Column(
            Modifier.fillMaxSize().padding(top = 12.dp, bottom = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(icon),
                contentDescription = "$line1 $line2",
                modifier = Modifier.size(30.dp),
                colorFilter = ColorFilter.tint(Pal.White)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                line1, color = Pal.Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                line2, color = Pal.White, fontSize = 10.sp, fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
