package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * "Change shape": el amigo toma la forma de una foto de la galería.
 *  - SPHERE: la esfera de gelatina de siempre.
 *  - TWO_LEGS: camina en dos patas (personas, personajes).
 *  - FOUR_LEGS: camina en cuatro patas (animales).
 *  - OBJECT: se queda quieto (cosas). Se le puede arrastrar y lanzar como siempre.
 */
enum class BodyType {
    SPHERE, TWO_LEGS, FOUR_LEGS, OBJECT;

    companion object {
        fun from(s: String?): BodyType = values().firstOrNull { it.name == s } ?: SPHERE
    }
}

/** La foto ya recortada (sin fondo), el tipo de cuerpo que se sugiere y un aviso si el recorte no salió limpio. */
class CutoutResult(val bitmap: Bitmap, val suggested: BodyType, val note: String?)

// ───────────── Recorte de la foto (sin internet ni modelos: se hace con los colores de la propia foto) ─────────────

private fun dist(a: Int, b: Int): Int =
    (abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
        abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
        abs((a and 255) - (b and 255))) / 3

/** Lee la foto (reducida a 320 px como máximo) y le quita el fondo. Devuelve null si no se pudo leer. */
fun makeCutout(ctx: Context, uri: Uri): CutoutResult? {
    return try {
        val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > 320) {
                val k = 320f / m
                dec.setTargetSize(max(1, (info.size.width * k).roundToInt()), max(1, (info.size.height * k).roundToInt()))
            }
        }
        cutoutOf(src)
    } catch (e: Exception) {
        null
    }
}

private fun cutoutOf(src: Bitmap): CutoutResult? {
    val w = src.width
    val h = src.height
    val n = w * h
    val px = IntArray(n)
    src.getPixels(px, 0, w, 0, 0, w, h)
    val mask = BooleanArray(n)          // true = es parte del cuerpo
    var note: String? = null

    var transparent = 0
    for (p in px) if ((p ushr 24) < 40) transparent++

    if (transparent > n * 0.04) {
        // La foto ya trae fondo transparente (PNG): se usa tal cual.
        for (i in 0 until n) mask[i] = (px[i] ushr 24) >= 40
    } else {
        // El fondo se calcula con el borde de la foto y se "come" desde afuera hacia adentro.
        val border = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) {
            if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) border.add(px[y * w + x])
        }
        var sr = 0L
        var sg = 0L
        var sb = 0L
        for (p in border) { sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255 }
        val cnt = border.size
        val bg = (0xFF shl 24) or ((sr / cnt).toInt() shl 16) or ((sg / cnt).toInt() shl 8) or (sb / cnt).toInt()
        var dev = 0L
        for (p in border) dev += dist(p, bg)
        val devAvg = (dev / cnt).toInt()
        val plain = devAvg < 22                   // fondo liso (o casi)
        val tol = 38 + 2 * devAvg

        val vis = BooleanArray(n)
        val org = IntArray(n)
        val q = IntArray(n)
        var qh = 0
        var qt = 0
        fun seed(i: Int) {
            if (vis[i]) return
            if (plain && dist(px[i], bg) > tol) return
            vis[i] = true
            org[i] = px[i]
            q[qt++] = i
        }
        for (x in 0 until w) { seed(x); seed((h - 1) * w + x) }
        for (y in 0 until h) { seed(y * w); seed(y * w + w - 1) }
        while (qh < qt) {
            val i = q[qh++]
            val x = i % w
            val y = i / w
            for (k in 0..3) {
                val nx = x + (if (k == 0) 1 else if (k == 1) -1 else 0)
                val ny = y + (if (k == 2) 1 else if (k == 3) -1 else 0)
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (vis[j]) continue
                val ok = if (plain) dist(px[j], bg) <= tol
                else dist(px[j], px[i]) <= 9 && dist(px[j], org[i]) <= 70
                if (ok) { vis[j] = true; org[j] = org[i]; q[qt++] = j }
            }
        }
        for (i in 0 until n) mask[i] = !vis[i]
        if (!plain) note = "El fondo de la foto no es liso: la forma puede traer algo del fondo."
    }

    // Se queda con la pieza más grande (y las que tengan buen tamaño); quita motitas sueltas.
    val lab = IntArray(n)
    val sizes = ArrayList<Int>()
    sizes.add(0)
    val q2 = IntArray(n)
    var nl = 0
    for (s in 0 until n) {
        if (!mask[s] || lab[s] != 0) continue
        nl++
        var count = 0
        var hd = 0
        var tl = 0
        lab[s] = nl
        q2[tl++] = s
        while (hd < tl) {
            val i = q2[hd++]
            count++
            val x = i % w
            val y = i / w
            if (x + 1 < w && mask[i + 1] && lab[i + 1] == 0) { lab[i + 1] = nl; q2[tl++] = i + 1 }
            if (x > 0 && mask[i - 1] && lab[i - 1] == 0) { lab[i - 1] = nl; q2[tl++] = i - 1 }
            if (y + 1 < h && mask[i + w] && lab[i + w] == 0) { lab[i + w] = nl; q2[tl++] = i + w }
            if (y > 0 && mask[i - w] && lab[i - w] == 0) { lab[i - w] = nl; q2[tl++] = i - w }
        }
        sizes.add(count)
    }
    if (nl == 0) return null
    var big = 0
    for (s in sizes) if (s > big) big = s
    for (i in 0 until n) mask[i] = lab[i] != 0 && sizes[lab[i]] >= big * 0.06

    var covered = 0
    for (m in mask) if (m) covered++
    val cov = covered.toFloat() / n
    if (cov < 0.03f || cov > 0.97f) {
        // No se pudo separar el fondo: se usa la foto completa con forma ovalada.
        val cx = w / 2f
        val cy = h / 2f
        for (y in 0 until h) for (x in 0 until w) {
            val dx = (x - cx) / (w * 0.5f)
            val dy = (y - cy) / (h * 0.5f)
            mask[y * w + x] = dx * dx + dy * dy <= 1f
        }
        note = "No pude separar el fondo de esa foto: se usó la foto completa."
    }

    // Borde suave: se encoge 1 px (quita el halo del fondo) y se difumina un poquito.
    val er = BooleanArray(n)
    var erCount = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        if (mask[i] && mask[i - 1] && mask[i + 1] && mask[i - w] && mask[i + w]) { er[i] = true; erCount++ }
    }
    val soft = if (erCount > 0) er else mask
    val alpha = FloatArray(n)
    for (y in 0 until h) for (x in 0 until w) {
        var s = 0
        var c2 = 0
        for (dy in -1..1) for (dx in -1..1) {
            val xx = x + dx
            val yy = y + dy
            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue
            c2++
            if (soft[yy * w + xx]) s++
        }
        alpha[y * w + x] = s.toFloat() / c2
    }

    // Recorte ajustado a la figura.
    var x0 = w
    var y0 = h
    var x1 = -1
    var y1 = -1
    for (y in 0 until h) for (x in 0 until w) {
        if (alpha[y * w + x] > 0.1f) {
            if (x < x0) x0 = x
            if (x > x1) x1 = x
            if (y < y0) y0 = y
            if (y > y1) y1 = y
        }
    }
    if (x1 < x0 || y1 < y0) return null
    val bw = x1 - x0 + 1
    val bh = y1 - y0 + 1
    val out = IntArray(bw * bh)
    for (y in 0 until bh) for (x in 0 until bw) {
        val i = (y + y0) * w + (x + x0)
        val a = (alpha[i] * 255f).roundToInt().coerceIn(0, 255)
        out[y * bw + x] = (a shl 24) or (px[i] and 0xFFFFFF)
    }
    val bmp = Bitmap.createBitmap(out, bw, bh, Bitmap.Config.ARGB_8888)
    return CutoutResult(bmp, suggestBody(mask, w, x0, y0, bw, bh), note)
}

/** Adivina el tipo de cuerpo mirando cuántas "patas" tiene la silueta abajo y qué tan ancha es. El usuario puede cambiarlo. */
private fun suggestBody(mask: BooleanArray, w: Int, x0: Int, y0: Int, bw: Int, bh: Int): BodyType {
    val aspect = bw.toFloat() / bh
    val counts = IntArray(6)
    for (k in 0..5) {
        val y = y0 + min(bh - 1, (bh * (0.86f + 0.02f * k)).toInt())
        var runs = 0
        var inRun = false
        var rw = 0
        for (x in x0 until x0 + bw) {
            if (mask[y * w + x]) {
                if (!inRun) { inRun = true; rw = 0 }
                rw++
            } else if (inRun) {
                inRun = false
                if (rw >= bw * 0.04f) runs++
            }
        }
        if (inRun && rw >= bw * 0.04f) runs++
        counts[k] = runs
    }
    counts.sort()
    val runs = counts[3]
    return when {
        (runs >= 3 && aspect >= 0.95f) || (aspect >= 1.15f && runs >= 2) -> BodyType.FOUR_LEGS
        runs == 2 || (runs <= 1 && aspect < 0.75f) || (runs >= 3 && aspect < 0.95f) -> BodyType.TWO_LEGS
        else -> BodyType.OBJECT
    }
}

// ───────────── Dibujo del amigo con su nueva forma ─────────────

/**
 * Dibuja la figura recortada con el mismo estiramiento de gelatina del amigo.
 * Si camina, la parte de abajo (las patas) se levanta de a poco, la figura rebota y se balancea,
 * y mira hacia donde va. Si es un objeto, queda quieto.
 */
internal fun DrawScope.drawSkin(c: CleanerState, img: ImageBitmap, bob: Float) {
    val d = size.minDimension
    val ctr = Offset(d / 2f, d / 2f)
    val two = c.body == BodyType.TWO_LEGS
    val four = c.body == BodyType.FOUR_LEGS
    val walker = two || four
    val gait = if (walker) c.gait.coerceIn(0f, 1f) else 0f
    val ph = c.walk
    val tau = 6.2831855f

    // La figura cabe en el cuadro conservando su proporción y se apoya abajo.
    val fit = d * 0.96f / max(img.width, img.height).toFloat()
    val w = img.width * fit
    val h = img.height * fit
    val left = (d - w) / 2f
    val top = d - h - d * 0.02f

    // Gelatina (más suave que en la esfera para no deformar demasiado a los personajes).
    val st = c.stretch.coerceIn(-0.4f, 0.5f) * 0.6f
    val breathe = (bob - 0.5f) * 0.03f
    val sx = (1f + st) * (1f + breathe)
    val sy = (1f / (1f + st)) * (1f - breathe)
    val base = Offset(d / 2f, d)                      // el aplastón se ancla en los pies

    val hop = -abs(kotlin.math.sin(tau * ph)) * d * (if (four) 0.035f else 0.05f) * gait
    val sway = (if (two) kotlin.math.sin(tau * ph) * 6f else if (four) kotlin.math.sin(tau * ph * 2f) * 3.5f else 0f) * gait

    withTransform({
        translate(0f, hop)
        rotate(sway, base)
        rotate(c.moveAngle, base)
        scale(sx, sy, base)
        rotate(-c.moveAngle, base)
        if (walker) scale(c.faceX, 1f, ctr)
    }) {
        val dLeft = left.roundToInt()
        val dTop = top.roundToInt()
        val dW = w.roundToInt()
        val dH = h.roundToInt()
        if (!walker || gait < 0.03f) {
            drawImage(
                img, dstOffset = IntOffset(dLeft, dTop), dstSize = IntSize(dW, dH),
                filterQuality = FilterQuality.Medium
            )
        } else {
            // Cuerpo arriba; abajo, tiras verticales (las patas) que se levantan una tras otra.
            val n = if (four) 4 else 2
            val legStart = (img.height * 0.72f).toInt()
            val legH = img.height - legStart
            val upperDst = (dH * legStart.toFloat() / img.height).roundToInt()
            drawImage(
                img, srcOffset = IntOffset(0, 0), srcSize = IntSize(img.width, legStart),
                dstOffset = IntOffset(dLeft, dTop), dstSize = IntSize(dW, upperDst),
                filterQuality = FilterQuality.Medium
            )
            val offs = if (four) floatArrayOf(0f, 0.5f, 0.25f, 0.75f) else floatArrayOf(0f, 0.5f)
            val lift = h * 0.07f
            for (i in 0 until n) {
                val s0 = img.width * i / n
                val s1 = img.width * (i + 1) / n
                val x0 = dLeft + dW * i / n
                val x1 = dLeft + dW * (i + 1) / n
                val s = kotlin.math.sin(tau * (ph + offs[i]))
                val up = max(0f, s) * lift * gait
                val swing = s * w * 0.02f * gait
                drawImage(
                    img, srcOffset = IntOffset(s0, legStart), srcSize = IntSize(s1 - s0, legH),
                    dstOffset = IntOffset((x0 + swing).roundToInt(), (dTop + upperDst - up).roundToInt()),
                    dstSize = IntSize(x1 - x0, dH - upperDst),
                    filterQuality = FilterQuality.Medium
                )
            }
        }
    }
}

// ───────────── Ventanas de "Change shape" ─────────────

/** Flujo completo: menú → elegir foto de la galería → vista previa y tipo de cuerpo → el amigo cambia de forma. */
@Composable
fun ShapeFlow(c: CleanerState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CutoutResult?>(null) }
    var choice by remember { mutableStateOf(BodyType.TWO_LEGS) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            failed = false
            busy = true
            scope.launch {
                val r = withContext(Dispatchers.Default) { makeCutout(ctx, uri) }
                busy = false
                if (r == null) {
                    failed = true
                } else {
                    result = r
                    choice = r.suggested
                }
            }
        }
    }

    val r = result
    when {
        busy -> AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text("Change shape") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ThinSpinner(28.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Preparando la forma…")
                }
            }
        )

        r != null -> AlertDialog(
            onDismissRequest = onClose,
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        c.applyShape(r.bitmap, choice)
                        c.talk("¡Ahora soy así!")
                        onClose()
                    }
                }) { Text("Usar esta forma") }
            },
            dismissButton = { TextButton(onClick = onClose) { Text("Cancelar") } },
            title = { Text("¿Cómo es?") },
            text = {
                Column {
                    val img = remember(r) { r.bitmap.asImageBitmap() }
                    Box(Modifier.fillMaxWidth().background(Pal.Ink).padding(8.dp), contentAlignment = Alignment.Center) {
                        Image(img, contentDescription = null, modifier = Modifier.height(130.dp))
                    }
                    if (r.note != null) {
                        Text(r.note, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    listOf(
                        BodyType.TWO_LEGS to "Dos patas (camina en dos)",
                        BodyType.FOUR_LEGS to "Cuatro patas (camina en cuatro)",
                        BodyType.OBJECT to "Objeto (se queda quieto)"
                    ).forEach { (t, label) ->
                        Row(Modifier.fillMaxWidth().clickable { choice = t }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = choice == t, onClick = { choice = t })
                            Text(label + if (t == r.suggested) "  ·  sugerido" else "")
                        }
                    }
                }
            }
        )

        else -> AlertDialog(
            onDismissRequest = onClose,
            confirmButton = {
                TextButton(onClick = {
                    failed = false
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Text("Elegir foto") }
            },
            dismissButton = { TextButton(onClick = onClose) { Text("Cerrar") } },
            title = { Text("Change shape") },
            text = {
                Column {
                    Text("Elige una foto de tu galería (un objeto, un animal, una persona o un personaje) y tu amigo tomará su forma.")
                    if (failed) {
                        Text("No pude leer esa foto. Prueba con otra.", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                    }
                    if (c.body != BodyType.SPHERE) {
                        TextButton(onClick = {
                            c.resetShape()
                            c.talk("Volví a ser esfera")
                            onClose()
                        }) { Text("Volver a ser esfera") }
                    }
                }
            }
        )
    }
}
