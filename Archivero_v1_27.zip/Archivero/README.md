# Archivero (Android, Kotlin + Jetpack Compose)

## Cómo obtener el APK
1. Instala Android Studio (versión reciente, Ladybug o superior).
2. File > Open > elige esta carpeta `Archivero` y espera a que termine "Gradle Sync".
3. Para la versión RÁPIDA (la que debes instalar): View > Tool Windows > Build Variants, cambia `app` a **release**,
   y luego Build > Build Bundle(s) / APK(s) > Build APK(s). O por terminal: `gradle assembleRelease` (Gradle 8.9).
4. El APK queda en `app/build/outputs/apk/release/app-release.apk`.
   (El de `debug` sirve para probar, pero va notablemente más lento: no lo uses de día a día.)

## Qué hace
- Pide UNA sola vez el permiso "Acceso a todos los archivos" (Ajustes del sistema). Android lo recuerda.
- Muestra la memoria principal y la tarjeta SD reales: carpetas, archivos, espacio libre / ocupado / total exacto.
- Categorías reales: Música, Fotos, Vídeos, Documentos, PDF y APKs (recorre ambos almacenamientos).
- Panel de las 3 rayitas: Inicio, almacenamientos con barra y espacio, papelera, accesos rápidos.
- Papelera: lo eliminado va a `.ArchiveroTrash` en el mismo almacenamiento; se puede restaurar o vaciar.
- Crear carpeta, renombrar, abrir archivos con la app correspondiente, buscar.
- Copiar, cortar y pegar (menú ⋮ de cada archivo; luego abrí otra carpeta y toca "Pegar aquí"). Avisa si no hay espacio.
- Información del archivo/carpeta: tipo, ubicación, tamaño, fecha y permisos.
- Compartir archivos con cualquier app, comprimir en ZIP y extraer ZIP (con protección contra ZIP maliciosos).
- Ordenar por nombre, fecha, tamaño o tipo (ascendente/descendente), botón "Ordenar" sobre la lista. Se recuerda.
- Selección múltiple: mantené presionado un archivo; después marcá más y usá Copiar, Cortar, ZIP o Eliminar.
- Galería: las categorías Fotos y Vídeos se ven en cuadrícula con miniaturas, agrupadas por día.
- Ver el contenido de un ZIP sin extraerlo (menú ⋮ del .zip). Información muestra también las dimensiones de las fotos.
- Candado con contraseña (menú ⋮ de arriba): se pide al abrir y tras 1 minuto fuera de la app; 5 intentos
  fallidos bloquean 5 minutos. Es un candado de comodidad, no cifra tus archivos.

## Notas
- Android 11 o superior (minSdk 30).
- Google Play restringe el permiso de "todos los archivos"; para uso personal o instalación directa no hay problema.
- Para instalar APKs desde la app, Android pedirá permitir "instalar apps desconocidas" a Archivero.
- No incluye ícono propio (usa el de Android por defecto); se agrega luego con File > New > Image Asset.

## Versión 1.3: ordenar, selección múltiple, galería y ver ZIP (ver "Qué hace")
## Versión 1.2: copiar/pegar, información, compartir, ZIP y candado

## Cambios de la versión 1.1 (rendimiento)
- Carpetas, categorías y papelera se leen en segundo plano; ya no se congela la pantalla.
- Cada fila ya no consulta el disco al dibujarse (antes lo hacía en cada desplazamiento).
- La app abre primero la pantalla y carga almacenamiento/papelera después.
- Categorías y búsquedas muestran resultados mientras siguen buscando, se pueden cancelar y se guardan 30 s.
- Build release con R8 y perfil de arranque.

## Versión 1.4: visor, vídeo y música internos
- Tocar una foto la abre en un visor propio: zoom con dos dedos, doble toque para ampliar, deslizar para pasar a la siguiente de la carpeta.
- Tocar un vídeo lo reproduce dentro de la app (pausa, barra de avance, botón "Girar" para pantalla horizontal).
- Tocar una canción abre la barra de música de abajo (anterior, pausa, siguiente, barra de progreso, cerrar) y sigue sonando mientras navegás.
- Los demás archivos (PDF, documentos, APK…) se abren con otra app, como antes.

## Versión 1.5: fondo animado
- 
- La app usa siempre colores oscuros para que el texto se lea sobre el fondo.

## Versión 1.6: carpetas blancas (íconos de carpeta en Inicio, listas y panel lateral)

## Versión 1.7: inicio nuevo con barra de 5 fichas
- La pantalla de inicio ya no tiene las 6 carpetas de arriba ni las 6 categorías de abajo. Queda: búsqueda, memoria interna/SD,
  el título "Categorías" y una barra abajo con 5 fichas: Descargas, Música, Fotos, Vídeos y APKs (mismo orden que el diseño).
- Primer toque en una ficha: se pone blanca, hace un pequeño zoom y muestra un globito rojo con la cantidad de carpetas
  (memoria interna + SD sumadas) y, abajo, el espacio total que ocupan.
- Segundo toque sobre la misma ficha: abre una ventana con esas carpetas en cuadrícula (Descargas = subcarpetas de Download;
  las demás = carpetas que tienen música / fotos / vídeos / APKs). Tocar una carpeta la abre como siempre.
- Los 3 puntitos de la derecha ahora son 3 rayitas. El menú que abren es el mismo de antes (Inicio, Actualizar, contraseña, vaciar papelera).
- Archivos nuevos/cambiados: `Categorias.kt` (nuevo), `HomeScreen` y `Screen.Cat` en `MainActivity.kt`, `catCache` y `homeTab` en `Store.kt`,
  y los íconos `res/drawable/ic_tab_*.xml`: dibujos vectoriales rehechos desde cero (nítidos a cualquier resolución, sin PNG). El texto de cada ficha es
  texto real (`HomeTab.text`); íconos y texto se pintan de gris o de oscuro por código.
- Para cambiar el orden de las fichas: reordena los valores de `enum class HomeTab` en `Categorias.kt`.
- Los accesos a Documentos y PDF ya no están en Inicio (siguen en el panel de las 3 rayitas > Accesos rápidos).

## Versión 1.8: optimización, fondo nuevo y corrección de errores
**Fondo animado**: (histórico) el GIF de la 1.7 ya no existe; desde la 1.17 se quitó del proyecto.

**Rapidez**
- Abrir: el GIF ya no se decodifica en el hilo principal al arrancar; color de ventana oscuro desde el primer cuadro; perfil de arranque
  (`app/src/main/baseline-prof.txt`, antes faltaba el archivo y el perfil no hacía nada).
- Carpetas: las ya visitadas se abren al instante (caché de las últimas 24) y se actualizan detrás; las grandes se leen en 4 hilos;
  el ordenado ya no corre en el hilo principal; si nada cambió, la lista no se redibuja; al volver atrás queda en la misma posición.
- Desplazamiento: el contador "N elementos" de cada carpeta se guarda en caché y se lee con 2 hilos (antes cada carpeta leía el disco
  cada vez que entraba en pantalla); el menú ⋮ de cada fila solo existe mientras está abierto; `contentType` para reutilizar filas;
  la galería agrupa por día sin crear una fecha por archivo; durante una búsqueda larga la lista se refresca menos seguido.
- Visor de fotos: precarga la foto vecina, así deslizar no muestra la ruedita.

**Errores corregidos**
- División por cero en el panel lateral si un almacenamiento reportaba 0 bytes.
- Al extraer un ZIP que declara un tamaño falso ya no puede llenar el almacenamiento: se corta si lo real no cabe.
- Carpeta recién abierta mostraba un área en blanco mientras cargaba; ahora muestra la ruedita.

## Versión 1.9: diseño rosa/blanco/negro y fichas rápidas
- Paleta nueva en `Palette.kt` (`Pal`): rosa rojizo `#FF0198`, blanco y negro. Se cambia todo desde ahí.
- Fondo negro liso (más limpio). El fondo GIF y su código se quitaron en la 1.17.
- Barra superior y panel lateral negros con línea fina rosa; ficha seleccionada en rosa; globito blanco con el número de carpetas.
- Íconos de archivo neutros (extensión en rosa) en vez de colores por tipo.
- **Fichas lentas (corregido)**: antes cada ficha recorría toda la memoria al tocarla (una pasada por tipo). Ahora una sola pasada
  calcula las 5 fichas a la vez, en paralelo por almacenamiento, y empieza en segundo plano al abrir la app
  (`Store.prefetchCats`). Al tocar una ficha el resultado ya está listo y, si se vuelve a actualizar, se sigue mostrando lo anterior sin ruedita.

### Fichas (1.9)
- Cada ficha muestra SOLO su tipo, con las carpetas de la memoria interna y de la SD que lo tienen:
  Música (mp3, m4a, wav, ogg, flac, aac, opus), Fotos (jpg, png, gif, webp, bmp, heic), Vídeos (mp4, mkv, 3gp, webm, avi, mov), APKs (apk).
  Cada carpeta cuenta solo archivos de ese tipo. Descargas muestra la carpeta Download entera (subcarpetas y archivos sueltos).
- Cada carpeta lleva una barrita (peso relativo) y debajo "peso · archivos". Si hay SD, también el almacenamiento donde está.
- Todo se calcula en segundo plano al abrir la app (`Store.prefetchCats`), en una sola pasada y en paralelo; no se mira `Android/`.

### Diseño limpio (1.9)
- Explorador en blanco y negro. Carpeta en amarillo opaco de dos tonos (`Pal.FolderBack/Front/Edge` en `Palette.kt`).
- `Iconos.kt`: carpeta, íconos de archivo (hoja con esquina cortada + dibujo de línea fina por tipo), ruedita de carga fina,
  barrita digital por segmentos (`SegBar`) y la forma con esquina cortada (`ChamferShape`) usada en tarjetas, fichas y botón.
- Íconos de las fichas redibujados como línea fina (`res/drawable/ic_tab_*.xml`).
- El único color de acento es `Pal.Accent` (rosa): barritas Pon `Pal.White` ahí para dejarlo todo blanco y negro.

### Limpiador (1.9)
- Las 3 rayitas de la derecha ya no tienen el menú viejo: abren el mini panel del **Limpiador** (esfera con ojitos).
  Las opciones que tenía (Actualizar, Vaciar papelera, contraseña) pasaron al final del panel lateral, en "Opciones".
- Toca la esfera o "Limpiar ahora": borra los residuos de la app (archivos temporales de la caché, miniaturas y carpetas
  guardadas en memoria) y dice cuánto liberó. No toca tus archivos, la papelera ni otras apps.
- Arrástrala fuera del panel: al cerrar el panel con las 3 rayitas, se queda flotando y te acompaña por todas las pantallas
  (se puede mover a cualquier lado; recuerda dónde la dejaste). Para guardarla: abre el panel y suéltala en el hueco punteado.
- Código: `Limpiador.kt` (estado, esfera animada, capa flotante y panel).

## Versión 1.10: fichas rápidas y barra arriba
- Música, Fotos, Vídeos y APKs se leen del índice del sistema (MediaStore, el mismo de la Galería): ya no recorren el disco, aparecen casi al instante (`mediaStoreCats` en `Categorias.kt`). Si el índice no devolviera nada, se usa el recorrido del disco como plan B.
- Descargas: las carpetas aparecen primero (`quickDownloads`) y el peso y la cantidad de archivos se completan enseguida detrás ("…" mientras tanto).
- El recorrido de disco usa pocos hilos a la vez, para no frenar la pantalla.
- La barra de 5 fichas ahora va justo debajo del título "Categorías".

## Versión 1.11: fichas más claras
- La ficha blanca de Inicio vuelve a su aspecto normal a los 5 segundos (`CategoryBar`, `LaunchedEffect`), y también al salir de su ventana de carpetas.
- Al abrir una carpeta desde Música / Fotos / Vídeos / APKs solo se ven archivos de ese tipo, sin subcarpetas ni otros archivos (`kindFilter` en `Categorias.kt`, `FolderScreen`). La cuenta de la ficha usa la misma regla (por extensión), así el número y lo que se ve coinciden. Descargas muestra todo.
- Botón atrás: carpeta abierta desde una ficha → vuelve a la lista de carpetas de la ficha → otro atrás → Inicio (`Screen.Folder(dir, tab, root)` y `BackHandler` en `App`).

## Versión 1.12: panel limpio, íconos digitales y fichas más rápidas
- Panel izquierdo: se quitaron "Accesos rápidos", "Actualizar" y "Poner contraseña". Quedan Inicio, los almacenamientos, Papelera de reciclaje y Vaciar papelera (más "Bloquear/Cambiar/Quitar contraseña" solo si ya hay una contraseña puesta, para no quedar atrapado).
- Íconos de línea fina dibujados con Canvas (`HomeIcon`, `RecycleIcon`, `TrashIcon` en `Iconos.kt`) en lugar de emojis.
- Fichas: las 4 del índice del sistema se consultan en paralelo (`mediaStoreTab`) pidiendo solo las extensiones de cada tipo, y cada una aparece apenas termina.
- Lo último calculado se guarda en `filesDir/cats.json` (`saveCatCache` / `loadCatCache`) y se muestra al instante al abrir la app, mientras se actualiza por detrás.

## Versión 1.13: el amigo en 3D, paseo libre, burbujitas y Ajustes
- El amigo (`Mascot` en `Limpiador.kt`) ahora es una esfera de gelatina en 3D: negro con un poco de transparencia, luz arriba a la izquierda, brillos y borde de cristal. Se estira hacia donde va y rebota al parar (resorte en el bucle de cuadros de `CleanerLayer`).
- Cuando se saca del panel, pasea solo por la app (se detiene un rato al soltarlo) y deja una estela suave de burbujitas (`Bubble`).
- Tocarlo limpia los residuos de la app, así que se quitó el botón "Limpiar ahora": en su lugar, la casilla blanca del panel ahora es "Ajustes".
- Ajustes (`AjustesSheet` en `Amigo.kt`): papel grande con 6 casillas. Ya funcionan 2:
  1. **Siempre activo**: servicio en primer plano (`FriendService`, aviso discreto) + permiso para que la batería no lo duerma. Se reactiva al abrir la app.
  2. **Memoria**: guarda en `Documents/Amigo` de la tarjeta SD (o del almacenamiento interno si no hay SD) `memoria.txt` (resumen legible) y `memoria.json` (contadores): carpetas, tipos de archivo y fichas que más usas y la hora más activa. Solo anota qué abres, nunca el contenido.
- Las otras 4 casillas son huecos para lo que sigue. Con "Ajustes" se quitaron del panel izquierdo las opciones que ya no hacían falta (versión 1.12).

## Versión 1.17: teclado 3D y charla con el amigo
- En el panel de las 3 rayitas, junto a "Ajustes", hay un ícono de teclado 3D (`KeyboardIcon`). Al tocarlo se abre el chat (`ChatSheet`) y sale el teclado del teléfono para hablar con el amigo.
- Si el amigo te habla solo (globito con borde rosa, dura 9 s), tocá el globito: se abre el chat con su pregunta para que le respondas.
- Código nuevo: `Charla.kt` (chat, `CerebroLocal`, iniciativa con límites, ícono y hoja de chat). Cambios pequeños en `Limpiador.kt`, `Amigo.kt`, `MainActivity.kt` y `AndroidManifest.xml` (`adjustResize`).
- Configuración: `assets/amigo_config.json` (límites de iniciativa: 90 s entre mensajes, 6 por hora, inactividad de 45 s, silencio de 30 min).
- Habla solo únicamente cuando anda suelto por la app, lleva un rato sin que toques nada y no está el panel/chat abierto. Órdenes por chat: "no hables solo", "podés hablar solo", "modo silencio", "borra el contexto", "sin insultos", "hablame sin filtro".
- Si la Memoria está encendida, la charla se guarda en `Documents/Amigo/conversaciones.txt` y se recupera al abrir el chat.
- El cerebro es LOCAL (reglas, sin internet). Para uno con IA real: crear otra clase que implemente `Cerebro` y asignarla a `AmigoChat.cerebro` (requiere permiso INTERNET y una clave).


## Versión 1.17: limpieza de lo que no funcionaba
- Se quitó `fondo.gif` (4.4 MB), `GifBackground`, `GIF_SCRIM` y `USE_GIF_BACKGROUND`: nunca se usaban.
- Se quitaron las 4 casillas "Próximamente" de Ajustes y `SlotIcon`. Quedan Siempre activo y Memoria.
- `assets/amigo_config.json` ahora trae solo lo que lee `AmigoConfig` (`autonomy`). El resto (modelo de IA, cámara, micrófono, etc.) está en `docs/amigo_config_ia_futura.json`, fuera del APK, para cuando exista un `Cerebro` con IA real.
- No se tocó el movimiento del amigo (`Limpiador.kt`) ni el explorador.
- Nota: el proyecto no trae `gradlew`; compila con el workflow de GitHub o con `gradle assembleRelease` si tienes Gradle 8.9 instalado.

## Versión 1.18: fichas en cuadrícula de 5 y vista/orden dentro de las carpetas
- Al entrar en una ficha (Música, Fotos, Vídeos, APKs, Descargas) las carpetas salen en cuadrícula de **5 por fila**, más pequeñas (`CatGridScreen` / `FolderTile` en `Categorias.kt`). Cada una muestra nombre, barrita, peso y cantidad de archivos.
- Dentro de una carpeta, en la esquina de la barra de resumen hay un botón (rayitas con perillas) que abre **Vista y orden**:
  - **Ver:** Filas (como antes), Cuadrícula (4 por fila, miniaturas) o Circular (miniaturas redondas). Se recuerda entre usos (`Store.viewMode`).
  - **Ordenar:** Nombre, Fecha, Tamaño o Tipo, ascendente o descendente (igual que antes).
- En cuadrícula y circular, el menú de cada elemento (renombrar, copiar, cortar, compartir, ZIP, información, eliminar) sale con el botón ⋮ de la esquina; mantener pulsado sigue seleccionando.
- No se tocó el amigo (`Limpiador.kt`).

## Versión 1.21: Herramientas

- Se quitó "Change shape" y el botón del teclado del panel del amigo (el amigo vuelve a ser la esfera). El código de la forma (Forma.kt, Cuerpo.kt) y del chat (Charla.kt) sigue en el proyecto pero ya no se usa desde la pantalla.
- Nuevo botón **Herramientas**: al tocarlo se abre un mini panel con tres fichas, del mismo estilo que las del explorador: Editor de fotos, Editor de vídeos y Editor de música (Herramientas.kt). Por ahora solo son el panel y los íconos; las herramientas funcionales vienen después.

## Versión 1.20: cuerpo con volumen y esqueleto (Cuerpo.kt)

- **Volumen:** de la silueta de la foto se calcula una "altura" y se pinta luz y sombra encima (se ve redondo, no plano). Se hace una vez, sin internet.
- **Esqueleto automático:** la figura se convierte en una malla con huesos (cabeza, 2 brazos, 2 piernas; o 4 patas). Al caminar las piernas y los brazos giran desde sus articulaciones, la cabeza se mece y el pecho respira. Al agarrarlo estira brazos y piernas.
- Los huesos se colocan según la silueta, así que sirve con cualquier foto (en fotos raras puede quedar aproximado).
- Pendiente: pelo/cola con resortes, parpadeo, y que invente las partes que no se ven (requiere IA).

## Versión 1.19: Change shape (el amigo toma la forma de una foto)
- En el panel del amigo, donde estaba el botón blanco "Ajustes", ahora dice **Change shape**. Ajustes sigue disponible como enlace debajo.
- Change shape: elegir una foto de la galería → se le quita el fondo → se elige cómo es (dos patas, cuatro patas u objeto; la app sugiere uno) → el amigo toma esa forma. También se puede **volver a ser esfera**.
- Dos patas: camina en dos (rebota, se balancea y levanta una pata y luego la otra). Cuatro patas: igual, con cuatro patas y un trote más rápido. Mira hacia donde va. Objeto: se queda quieto (se le puede arrastrar y lanzar como siempre).
- Sigue siendo blandito: se estira y rebota igual que la esfera. Tocarlo sigue limpiando los residuos.
- La forma se guarda (`filesDir/forma_amigo.png`) y se recupera al abrir la app.
- El recorte del fondo se hace sin internet ni modelos de IA (`Forma.kt`, `makeCutout`): funciona mejor con fondo liso o transparente. Con fondos complicados puede traer algo del fondo; la vista previa lo muestra antes de aceptar.
- Código nuevo: `Forma.kt`. Cambios en `Limpiador.kt` (estado de la forma, dibujo, un objeto no pasea solo, panel). La esfera sin forma funciona igual que antes.

## Versión 1.22: fichas iguales, vídeo con lista, miniaturas y panel simplificado
- Fichas de archivos y de carpetas: el nombre siempre reserva 2 líneas, así todas miden lo mismo.
- Reproductor de vídeo con lista de la carpeta: ⏮ / ⏭ cambian de vídeo, pasa solo al siguiente y los controles son propios (sin `MediaController`).
- Miniaturas de música (carátula), PDF (primera hoja) y APK (ícono) además de fotos y vídeos (`Thumbs.kt`).
- Más rápido: fecha y tamaño de cada archivo se calculan solo al dibujarlo; miniaturas con 4 hilos y las más recientes primero.
- Panel del amigo: se quitó el botón **Herramientas** (y `Herramientas.kt`, íconos `ic_tool_*`).
- Se quitó **Siempre activo** (`FriendService`, `FriendBackground` y sus permisos de notificación, servicio y batería).
- **Memoria** ahora está siempre encendida: ya no se activa ni se apaga. Ajustes solo la muestra como información.

## Versión 1.23: el amigo te sigue fuera de la app (`Seguir.kt`)
- Si sacas al amigo (no está guardado) y sales de la app, aparece una esfera flotante sobre las demás apps. Se arrastra y recuerda dónde la dejaste. Al volver a Archivero se esconde.
- Al tocarla salen 3 casillas pequeñas: **1** vacía (borrar caché, más adelante), **2** 🎵 mini reproductor (⏮ ⏯ ⏭ y una **✕** que cierra solo el panel; la música sigue), **3** vacía (notificaciones, más adelante). Tocar fuera cierra las casillas.
- Necesita el permiso "Mostrar sobre otras apps": en Ajustes hay una ficha **Seguirte fuera de la app** que lo pide. Mientras el amigo anda suelto corre un servicio con un aviso discreto (`FriendService`); si lo guardas, se detiene.
- Arreglo: al abrir la app, el amigo ya no aparece un instante en la esquina de arriba a la izquierda (se dibujaba antes de medir la pantalla).
- Pendiente: que evite tus zonas de toque en juegos y la casilla de notificaciones.

## Versión 1.24: el amigo flotante cobra vida y el mini reproductor tiene carpetas (`Seguir.kt`)
- **Animado fuera de la app**: la esfera ya no es un dibujo fijo. Tiene la misma cara que en la app (ojitos), se estira hacia donde va, respira, parpadea, mira a los lados, y si suena música baila y suelta notitas ♪ (`BubbleView`, bucle con `Choreographer` en `FriendOverlay.step`).
- **Se mueve sola**: pasea libre por toda la pantalla (camino curvo, paradas, ritmo distinto en cada paseo) o se queda en una esquina. Se puede agarrar y soltar en cualquier lado. Con un panel abierto se queda quieta al lado.
- **Al tocarla**: salen las 3 casillas de siempre; la 🎵 abre el mini reproductor.
- **Mini reproductor**: lista de carpetas de música (las mismas de la ficha Música) → tocas una carpeta → canciones → tocas una y suena. Arriba: título, barra de progreso, ⏮ ⏯ ⏭, botón 🫧/📌 (paseo libre / esquina) y **✕** que cierra solo el panel; la música sigue y el amigo sigue por la pantalla.
- La música ya no se corta con la pantalla apagada (`WAKE_LOCK`, `MusicPlayer.setWakeMode`).
- Las casillas 1 y 3 siguen vacías (borrar caché / notificaciones, para después).

## Versión 1.25: pantalla horizontal y amigo fijo (`Seguir.kt`)
- **Girar el teléfono**: el amigo flotante detecta la orientación (tamaño real de la pantalla). Si giras con un panel abierto, se rehace: en vertical va apilado; en horizontal los controles quedan a la izquierda y las carpetas/canciones a la derecha, y el panel se coloca al costado de la esfera si no cabe arriba/abajo. Vuelve a la carpeta que tenías abierta.
- **Doble toque** sobre el amigo: se queda **fijo** (aro rosa, no se mueve ni se deja arrastrar). Otro doble toque lo suelta. Se recuerda aunque se reinicie el servicio.
- Un toque simple abre las casillas tras un instante (el que tarda Android en distinguir un doble toque).

## Versión 1.26
- Lista de carpetas del mini reproductor: el nombre va arriba y debajo, en pequeño, "N canciones · almacenamiento" (antes se cortaba con "…" y no se veía si era la SD). Se quitó el 📁 repetido cuando la carpeta ya traía su propio emoji.

## Versión 1.27: corrección de errores, estabilidad, rendimiento y diseño
**Errores corregidos**
- Papelera: dos archivos con el mismo nombre eliminados a la vez (por ejemplo desde una búsqueda) podían pisarse y perderse; ahora cada uno recibe un nombre único (`Store.trashOne`).
- Papelera: si algo se eliminaba antes de que terminara de leerse la lista guardada, desaparecía de la lista (`Store.init`).
- Miniaturas de PDF: un PDF con contraseña o dañado dejaba abierto su descriptor de archivo; al listar muchos PDF se agotaban y la app fallaba (`Thumbs.pdfFirstPage`).
- Música: ahora respeta el foco de audio. Una llamada u otra app que reproduce sonido pausa la música, y se reanuda sola al terminar (`MusicPlayer`). Antes seguía sonando encima.
- Estabilidad: la actividad ya no se recrea al cambiar tamaño de letra, densidad, idioma o disposición de pantalla (`configChanges` en el manifiesto). Antes eso cerraba al amigo flotante, la música y perdía la carpeta abierta.

**Rendimiento y fluidez**
- Amigo (dentro de la app): ya no se recompone toda la capa en cada cuadro mientras se mueve; la posición se lee al medir (`CleanerLayer`). El lienzo de burbujitas de pantalla completa solo se repinta mientras hay burbujitas.
- Amigo flotante (fuera de la app): quieto, sin música y sin arrastre dibuja a la mitad de los cuadros (menos batería, mismo aspecto) (`FriendOverlay.frame`).
- Barra de fichas de Inicio: la forma y los degradados se arman una vez (`drawWithCache`) en vez de en cada cuadro del zoom.

**Diseño**
- Carpeta nueva (`FolderIcon`): fondo con pestaña redondeada, una hoja que asoma y tapa con degradado y brillo. Colores nuevos en `Pal.Folder*`.
- Ícono de archivo nuevo (`FileIcon`): hoja con esquinas suaves, esquina doblada con volumen y la extensión en una pastilla rosa.
- Panel lateral rehecho: cabecera con el resplandor de Inicio, secciones (Almacenamiento, Papelera, Candado), almacenamientos en tarjetas de vidrio con barrita, y opciones con el ícono dentro de una casilla redondeada. Los emojis del candado se cambiaron por íconos de línea (`LockIcon`, `KeyIcon`).
- Panel del amigo y Ajustes: mismo vidrio 3D que Inicio; el hueco para guardar al amigo ahora es rosa tenue.
- Tarjetas de carpeta en las fichas (`FolderTile`): degradado y canto con brillo.
- No se cambió la estructura del proyecto, los nombres de archivos ni el comportamiento de las pantallas.
