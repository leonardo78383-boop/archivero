package com.archivero

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import java.io.File
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ───────────── Enlace entre la app y el amigo flotante ─────────────

/**
 * Punto de encuentro entre la pantalla de la app y el servicio que dibuja al amigo sobre otras apps.
 * El amigo flotante solo aparece si: está suelto (no guardado), la app NO está en pantalla y se dio el permiso
 * "Mostrar sobre otras apps".
 */
object FriendLink {
    @Volatile var store: Store? = null          // para que el mini reproductor use la misma música de la app
    @Volatile var appVisible = true
    @Volatile var wantOut = false               // el amigo anda suelto
    var listener: (() -> Unit)? = null

    fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun setVisible(v: Boolean) {
        appVisible = v
        listener?.invoke()
    }

    /** Arranca el servicio si el amigo anda suelto y hay permiso; si no, lo detiene. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        if (wantOut && canDraw(app)) {
            try { app.startForegroundService(Intent(app, FriendService::class.java)) } catch (e: Exception) { }
        } else stop(app)
    }

    fun stop(ctx: Context) {
        try { ctx.applicationContext.stopService(Intent(ctx.applicationContext, FriendService::class.java)) } catch (e: Exception) { }
    }
}

/** Servicio en primer plano (con un aviso discreto) que mantiene viva la esfera flotante al salir de la app. */
class FriendService : Service() {
    private var overlay: FriendOverlay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = FriendOverlay(this)
        FriendLink.listener = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        refresh()
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (FriendLink.appVisible) overlay?.hide() else overlay?.show()
    }

    override fun onDestroy() {
        FriendLink.listener = null
        overlay?.hide()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Tu amigo te sigue", NotificationManager.IMPORTANCE_MIN))
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pi = if (launch != null) PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else null
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("Archivero")
            .setContentText("Tu amigo te sigue fuera de la app")
            .setOngoing(true)
        if (pi != null) b.setContentIntent(pi)
        return b.build()
    }

    companion object {
        private const val CHANNEL = "amigo_sigue"
        private const val NOTIF_ID = 8
    }
}

// ───────────── La esfera flotante y sus mini paneles ─────────────

/**
 * La esfera de gelatina del amigo, dibujada a mano (misma cara que la de la app) y animada:
 * se estira hacia donde va, respira, parpadea, mira a los lados y, si suena música, baila y suelta notitas.
 * Todos los valores los mueve [FriendOverlay] en cada cuadro; aquí solo se dibuja.
 */
private class BubbleView(ctx: Context) : View(ctx) {
    var stretch = 0f        // estiramiento (resorte)
    var angle = 0f          // hacia dónde va (radianes)
    var lookX = 0f          // hacia dónde mira (-1..1)
    var lookY = 0f
    var open = 1f           // 1 = ojos abiertos, ~0.1 = parpadeo
    var bob = 0f            // respiración (-0.5..0.5)
    var grow = 1f           // se agranda un poco al agarrarlo
    var playing = false     // suena música
    var noteT = 0f          // 0..1, notita que sube
    var frozen = false      // fijo: aro rosa

    private val dens = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * dens
        color = 0x99FFFFFF.toInt()
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val eyeHalo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x29FFFFFF }
    private val eye = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val note = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF0198.toInt(); textAlign = Paint.Align.CENTER }
    private val body = Path()
    private val box = RectF()
    private var baseRad = 1f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        baseRad = min(w, h) / 2f * 0.68f
        val r = baseRad
        fill.shader = RadialGradient(
            w / 2f - r * 0.32f, h / 2f - r * 0.40f, r * 1.7f,
            intArrayOf(0xEE3B3B44.toInt(), 0xE60E0E12.toInt(), 0xD6000000.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        note.textSize = min(w, h) * 0.22f
    }

    private fun buildBody(cx: Float, cy: Float, rad: Float) {
        val st = stretch.coerceIn(-0.4f, 0.4f)
        val breathe = bob * (if (playing) 0.10f else 0.05f)
        val sx = (1f + st) * (1f + breathe)
        val sy = (1f / (1f + st)) * (1f - breathe)
        val ripple = 0.012f + abs(st) * 0.07f
        val phase = bob * 6.2832f
        val ca = cos(angle)
        val sa = sin(angle)
        body.reset()
        val n = 48
        for (i in 0 until n) {
            val th = i * 2f * Math.PI.toFloat() / n
            val r = rad * (1f + ripple * sin(3f * th + phase))
            val x0 = r * cos(th)
            val y0 = r * sin(th)
            val xa = x0 * ca + y0 * sa
            val ya = -x0 * sa + y0 * ca
            val xs = xa * sx
            val ys = ya * sy
            val x = cx + xs * ca - ys * sa
            val y = cy + xs * sa + ys * ca
            if (i == 0) body.moveTo(x, y) else body.lineTo(x, y)
        }
        body.close()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = baseRad
        c.save()
        c.scale(grow, grow, cx, cy)
        buildBody(cx, cy, rad)
        c.drawPath(body, fill)
        rim.color = if (frozen) 0xFFFF0198.toInt() else 0x99FFFFFF.toInt()
        c.drawPath(body, rim)
        // brillo de gelatina arriba a la izquierda
        c.save()
        c.rotate(-30f, cx - rad * 0.38f, cy - rad * 0.52f)
        box.set(cx - rad * 0.70f, cy - rad * 0.69f, cx - rad * 0.06f, cy - rad * 0.35f)
        c.drawOval(box, glow)
        c.restore()
        c.drawCircle(cx - rad * 0.12f, cy - rad * 0.70f, rad * 0.055f, spark)

        // ojitos: dos píldoras blancas que miran hacia donde va
        val d = min(width, height).toFloat()
        val ew = d * 0.085f
        val eh = d * 0.22f * open
        val shx = cos(angle) * stretch * rad * 0.25f
        val shy = sin(angle) * stretch * rad * 0.25f
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * rad * 0.30f + lookX * rad * 0.20f + shx
            val ey = cy - rad * 0.02f + lookY * rad * 0.14f + shy
            c.save()
            c.rotate(s * 7f, ex, ey)
            box.set(ex - ew * 0.9f, ey - eh / 2f - ew * 0.4f, ex + ew * 0.9f, ey + eh / 2f + ew * 0.4f)
            c.drawRoundRect(box, ew, ew, eyeHalo)
            box.set(ex - ew / 2f, ey - eh / 2f, ex + ew / 2f, ey + eh / 2f)
            c.drawRoundRect(box, ew / 2f, ew / 2f, eye)
            c.restore()
        }
        c.restore()

        // notita que sube mientras suena la música
        if (playing) {
            note.alpha = ((1f - noteT) * 255).toInt().coerceIn(0, 255)
            c.drawText("♪", cx + rad * 0.78f, cy - rad * 0.55f - noteT * d * 0.16f, note)
        }
    }
}

/** Una fila de la lista del mini reproductor. kind: 0 = volver, 1 = carpeta, 2 = canción, 3 = aviso. */
private class MusicRow(val label: String, val sub: String?, val tag: String?, val kind: Int, val idx: Int = 0)

/**
 * Dibuja al amigo sobre las demás apps. Está siempre vivo: pasea libre por la pantalla (o se queda en una esquina),
 * se estira, parpadea y baila si suena música. Se arrastra con el dedo.
 * Al tocarlo salen 3 casillas pequeñas: 1) vacía  2) 🎵 mini reproductor  3) vacía.
 * El mini reproductor tiene las carpetas de música para elegir, controles y una ✕ que cierra solo el panel (la música sigue).
 */
class FriendOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val dens = ctx.resources.displayMetrics.density
    private val size = dp(72)

    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var slots: View? = null
    private var slotsLp: WindowManager.LayoutParams? = null
    private var music: View? = null
    private var musicLp: WindowManager.LayoutParams? = null
    private var musicTick: Runnable? = null
    private var slotsClosedAt = 0L
    private var musicFolders: List<CatFolder>? = null
    private var curFolder: File? = null               // carpeta abierta en el reproductor (sobrevive al girar el teléfono)
    private var curSongs: List<File> = emptyList()
    private var screenW = 0
    private var screenH = 0
    private var landscape = false
    private var lastTapAt = 0L
    private var pendingOpen: Runnable? = null

    // ── movimiento ──
    private var px = 0f
    private var py = 0f
    private var vx = 0f
    private var vy = 0f
    private var tx = 0f
    private var ty = 0f
    private var hasTarget = false
    private var idleUntil = 0L
    private var tripSpeed = 80f
    private var dirX = 1f
    private var dirY = 0f
    private var spd = 0f
    private var stretchVel = 0f
    private var dragging = false
    private var lastNs = 0L
    private var area = intArrayOf(0, 0, 0, 0)       // minX, minY, maxX, maxY de la esquina de arriba-izquierda del amigo
    private var areaFrames = 0
    private var gazeTx = 0f
    private var gazeTy = 0f
    private var gazeAt = 0L
    private var blinkAt = 0L
    private var blinkUntil = 0L
    private val rnd = java.util.Random()

    /** true = se queda quieto en una esquina; false = pasea libre. */
    private var parked: Boolean
        get() = prefs.getBoolean("park", false)
        set(v) { prefs.edit().putBoolean("park", v).apply() }
    /** true = fijo: no se mueve ni se deja arrastrar hasta que le des dos toques otra vez. */
    private var frozen: Boolean
        get() = prefs.getBoolean("frozen", false)
        set(v) { prefs.edit().putBoolean("frozen", v).apply() }
    private var corner: Int
        get() = prefs.getInt("corner", 3)
        set(v) { prefs.edit().putInt("corner", v).apply() }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun params(outside: Boolean, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (outside) WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH else 0),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun shape(color: Int, radius: Int, stroke: Int, dashed: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (dashed) setStroke(dp(1), stroke, dp(4).toFloat(), dp(3).toFloat()) else setStroke(dp(1), stroke)
    }

    private fun toast(s: String) { try { Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show() } catch (e: Exception) { } }

    // ── Pantalla utilizable ──

    private fun computeArea(): IntArray {
        return try {
            val m = wm.currentWindowMetrics
            val b = m.bounds
            val ins = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
            screenW = b.width(); screenH = b.height()
            intArrayOf(0, ins.top + dp(4), maxOf(0, b.width() - size), maxOf(ins.top + dp(4), b.height() - ins.bottom - size - dp(4)))
        } catch (e: Exception) {
            val d = ctx.resources.displayMetrics
            screenW = d.widthPixels; screenH = d.heightPixels
            intArrayOf(0, 0, maxOf(0, d.widthPixels - size), maxOf(0, d.heightPixels - size))
        }
    }

    private fun cornerX(i: Int): Float = (if (i and 1 == 0) area[0] + dp(6) else area[2] - dp(6)).toFloat()
    private fun cornerY(i: Int): Float = (if (i and 2 == 0) area[1] + dp(6) else area[3] - dp(6)).toFloat()

    private fun nearestCorner(): Int {
        val midX = (area[0] + area[2]) / 2f
        val midY = (area[1] + area[3]) / 2f
        return (if (px < midX) 0 else 1) or (if (py < midY) 0 else 2)
    }

    // ── Mostrar y ocultar ──

    fun show() {
        if (bubble != null || !Settings.canDrawOverlays(ctx)) return
        area = computeArea()
        areaFrames = 12
        landscape = screenW > screenH
        val v = BubbleView(ctx)
        val p = params(false, size, size)
        px = prefs.getInt("x", area[2] - dp(8)).coerceIn(area[0], area[2]).toFloat()
        py = prefs.getInt("y", (area[1] + area[3]) / 3).coerceIn(area[1], area[3]).toFloat()
        p.x = px.roundToInt()
        p.y = py.roundToInt()
        vx = 0f; vy = 0f; hasTarget = false; dragging = false; lastNs = 0L
        idleUntil = SystemClock.uptimeMillis() + 1200L

        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f; var moved = false; var slid = false
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = px; startY = py; moved = false; slid = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!moved && !slid && hypot(dx, dy) > slop) {
                        if (frozen) slid = true                 // fijo: no se deja arrastrar
                        else { moved = true; dragging = true; hasTarget = false }
                    }
                    if (moved) {
                        px = (startX + dx).coerceIn(area[0].toFloat(), area[2].toFloat())
                        py = (startY + dy).coerceIn(area[1].toFloat(), area[3].toFloat())
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) endDrag() else if (!slid) onTap()
                    moved = false; slid = false
                }
                MotionEvent.ACTION_CANCEL -> { if (moved) endDrag(); moved = false; slid = false }
            }
            true
        }
        try {
            wm.addView(v, p)
            bubble = v
            bubbleLp = p
            Choreographer.getInstance().postFrameCallback(frame)
        } catch (e: Exception) {
            // Sin permiso o Android no lo permite ahora: simplemente no se muestra.
        }
    }

    fun hide() {
        Choreographer.getInstance().removeFrameCallback(frame)
        pendingOpen?.let { ui.removeCallbacks(it) }
        pendingOpen = null
        closeSlots()
        closeMusic()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        bubbleLp = null
    }

    private fun endDrag() {
        dragging = false
        vx = 0f; vy = 0f
        idleUntil = SystemClock.uptimeMillis() + 2500L
        if (parked) corner = nearestCorner()
        saveSpot()
    }

    /**
     * Un toque abre las casillas (se espera un instante por si es doble toque).
     * Dos toques seguidos: el amigo se queda fijo; otros dos toques y vuelve a moverse.
     */
    private fun onTap() {
        val t = SystemClock.uptimeMillis()
        val dbl = ViewConfiguration.getDoubleTapTimeout().toLong()
        if (t - lastTapAt < dbl) {
            lastTapAt = 0L
            pendingOpen?.let { ui.removeCallbacks(it) }
            pendingOpen = null
            closeSlots()
            val nowFrozen = !frozen
            frozen = nowFrozen
            if (!nowFrozen) idleUntil = t + 800L
            toast(if (nowFrozen) "Quedé fijo · dos toques para soltarme" else "¡Libre otra vez!")
            return
        }
        lastTapAt = t
        if (slots != null) { closeSlots(); return }
        if (music != null) return                                   // el reproductor se cierra con su ✕
        if (t - slotsClosedAt < 300) return                         // el toque que cerró las casillas no las reabre
        val r = Runnable { pendingOpen = null; if (slots == null && music == null) openSlots() }
        pendingOpen = r
        ui.postDelayed(r, dbl)
    }

    /** El teléfono giró: los paneles abiertos se rehacen con la forma de la nueva orientación. */
    private fun onRotate() {
        if (music != null) { closeMusic(false); openMusic() }
        else if (slots != null) { closeSlots(); openSlots() }
    }

    private fun saveSpot() {
        prefs.edit().putInt("x", px.roundToInt()).putInt("y", py.roundToInt()).apply()
    }

    // ── El bucle de animación: un paso por cada cuadro de pantalla ──

    private var skipFrame = false

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val b = bubble ?: return
            val p = bubbleLp ?: return
            // Quieto, sin arrastre y sin música basta con la mitad de los cuadros: el amigo sigue vivo y gasta menos batería.
            val calm = !dragging && spd < 12f * dens && FriendLink.store?.music?.playing != true
            skipFrame = calm && !skipFrame
            if (!skipFrame) {
                try { step(b, p, frameTimeNanos) } catch (e: Exception) { }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    /** Camina hacia (tx, ty). Devuelve true si ya llegó. */
    private fun travel(dt: Float, now: Long, curvy: Boolean): Boolean {
        val dx0 = tx - px
        val dy0 = ty - py
        val dist = hypot(dx0, dy0)
        if (dist < 6f * dens) { vx = 0f; vy = 0f; return true }
        val maxSp = tripSpeed * dens
        val slow = (dist / (70f * dens)).coerceIn(0.25f, 1f)
        val k = (dt * 3f).coerceAtMost(1f)
        val bend = if (curvy) sin(now / 650f) * 0.7f * (dist / (160f * dens)).coerceIn(0f, 1f) else 0f
        val ux = dx0 / dist
        val uy = dy0 / dist
        val cb = cos(bend)
        val sb = sin(bend)
        val dx = ux * cb - uy * sb
        val dy = ux * sb + uy * cb
        vx += (dx * maxSp * slow - vx) * k
        vy += (dy * maxSp * slow - vy) * k
        px += vx * dt
        py += vy * dt
        return false
    }

    private fun step(b: BubbleView, p: WindowManager.LayoutParams, ns: Long) {
        val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastNs = ns
        val now = ns / 1_000_000L
        if (--areaFrames <= 0) {
            area = computeArea(); areaFrames = 12
            val land = screenW > screenH
            if (land != landscape) { landscape = land; onRotate() }
        }

        val ox = px
        val oy = py
        val busy = slots != null || music != null
        if (!dragging) {
            if (frozen) {
                hasTarget = false; vx = 0f; vy = 0f
            } else if (busy) {
                // Con un panel abierto se queda quietecito al lado.
                hasTarget = false; vx = 0f; vy = 0f
            } else if (parked) {
                tx = cornerX(corner); ty = cornerY(corner)
                tripSpeed = 170f
                if (travel(dt, now, false)) { px = tx; py = ty }
            } else if (now >= idleUntil) {
                if (!hasTarget) {
                    val mx = maxOf(1, area[2] - area[0])
                    val my = maxOf(1, area[3] - area[1])
                    var cx = 0f; var cy = 0f
                    for (i in 0 until 5) {
                        cx = area[0] + rnd.nextFloat() * mx
                        cy = area[1] + rnd.nextFloat() * my
                        if (hypot(cx - px, cy - py) > 140f * dens) break
                    }
                    tx = cx; ty = cy; hasTarget = true
                }
                if (travel(dt, now, true)) {
                    hasTarget = false
                    idleUntil = now + 1200L + rnd.nextInt(3200)
                    tripSpeed = 60f + rnd.nextFloat() * 90f
                    saveSpot()
                }
            }
        }
        px = px.coerceIn(area[0].toFloat(), area[2].toFloat())
        py = py.coerceIn(area[1].toFloat(), area[3].toFloat())

        // velocidad y dirección reales de este cuadro
        val mvx = px - ox
        val mvy = py - oy
        val len = hypot(mvx, mvy)
        spd += (len / dt - spd) * (dt * 12f).coerceAtMost(1f)
        if (len > 0.01f) {
            val kk = (dt * 10f).coerceAtMost(1f)
            dirX += (mvx / len - dirX) * kk
            dirY += (mvy / len - dirY) * kk
        }
        b.angle = atan2(dirY, dirX)

        // gelatina: estira al ir rápido y rebota al parar
        val tgt = (spd / dens / 900f).coerceIn(0f, 0.30f)
        stretchVel += ((tgt - b.stretch) * 220f - stretchVel * 13f) * dt
        b.stretch = (b.stretch + stretchVel * dt).coerceIn(-0.45f, 0.5f)

        // mirada: hacia donde va; quieto, curiosea
        val moving = spd > 12f * dens
        if (moving) {
            gazeTx = dirX * 0.9f; gazeTy = dirY * 0.7f; gazeAt = now + 600L
        } else if (now >= gazeAt) {
            gazeTx = (rnd.nextFloat() * 2f - 1f) * 0.9f
            gazeTy = (rnd.nextFloat() * 2f - 1f) * 0.5f
            gazeAt = now + 1400L + rnd.nextInt(2800)
        }
        val kg = (dt * 4.5f).coerceAtMost(1f)
        b.lookX += (gazeTx - b.lookX) * kg
        b.lookY += (gazeTy - b.lookY) * kg

        // parpadeo
        if (now >= blinkAt) { blinkUntil = now + 130L; blinkAt = now + 2500L + rnd.nextInt(3500) }
        b.open = if (now < blinkUntil) 0.12f else 1f

        // respiración, baile con la música y tamaño al agarrarlo
        val playing = FriendLink.store?.music?.playing == true
        b.playing = playing
        b.frozen = frozen
        b.bob = sin(now / (if (playing) 330.0 else 800.0)).toFloat() * 0.5f
        b.noteT = ((now % 1600L) / 1600f)
        b.grow += ((if (dragging) 1.12f else 1f) - b.grow) * (dt * 12f).coerceAtMost(1f)

        val ix = px.roundToInt()
        val iy = py.roundToInt()
        if (ix != p.x || iy != p.y) {
            p.x = ix; p.y = iy
            try { wm.updateViewLayout(b, p) } catch (e: Exception) { }
            if (busy) reposition()
        }
        b.invalidate()
    }

    // ── Colocar los paneles junto a la esfera (debajo si cabe, si no arriba) ──

    private fun position(v: View, p: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val sh = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels
        val wSpec = if (p.width > 0) View.MeasureSpec.makeMeasureSpec(p.width, View.MeasureSpec.EXACTLY)
                    else View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        v.measure(wSpec, View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val pw = v.measuredWidth
        val ph = v.measuredHeight
        val gap = dp(4)
        val below = b.y + size + gap + ph <= sh
        val above = b.y - gap - ph >= 0
        if (below || above) {
            p.x = (b.x + size / 2 - pw / 2).coerceIn(0, maxOf(0, sw - pw))
            p.y = if (below) b.y + size + gap else b.y - gap - ph
        } else {
            // pantalla horizontal: al costado de la esfera
            p.x = (if (b.x + size + gap + pw <= sw) b.x + size + gap else b.x - gap - pw).coerceIn(0, maxOf(0, sw - pw))
            p.y = (b.y + size / 2 - ph / 2).coerceIn(0, maxOf(0, sh - ph))
        }
    }

    private fun reposition() {
        slots?.let { v -> slotsLp?.let { p -> position(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
        music?.let { v -> musicLp?.let { p -> position(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
    }

    // ── Las 3 casillas ──

    private fun togglePanel() {
        if (music != null) return                       // el reproductor se cierra con su ✕
        if (slots != null) { closeSlots(); return }
        if (SystemClock.uptimeMillis() - slotsClosedAt < 300) return   // el toque que lo cerró fuera no lo reabre
        openSlots()
    }

    private fun slot(label: String?, onClick: (() -> Unit)?): TextView = TextView(ctx).apply {
        val s = dp(48)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(4), 0, dp(4), 0) }
        gravity = Gravity.CENTER
        textSize = 20f
        setTextColor(0xFFFFFFFF.toInt())
        if (label != null && onClick != null) {
            text = label
            background = shape(0xFF141414.toInt(), dp(10), 0xFF262626.toInt())
            setOnClickListener { onClick() }
        } else {
            background = shape(0x00000000, dp(10), 0xFF262626.toInt(), dashed = true)   // casilla vacía: para después
        }
    }

    private fun openSlots() {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(0xFF0B0B0B.toInt(), dp(14), 0xFF262626.toInt())
            addView(slot(null, null))                    // 1) borrar caché: más adelante
            addView(slot("🎵") { openMusic() })          // 2) música
            addView(slot(null, null))                    // 3) notificaciones: más adelante
            setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) { closeSlots() }
                false
            }
        }
        val p = params(true, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        position(row, p)
        try { wm.addView(row, p); slots = row; slotsLp = p } catch (e: Exception) { }
    }

    private fun closeSlots() {
        slots?.let { try { wm.removeView(it) } catch (e: Exception) { } ; slotsClosedAt = SystemClock.uptimeMillis() }
        slots = null
        slotsLp = null
    }

    // ── Mini reproductor con carpetas ──

    private fun musicBtn(label: String, sizeDp: Int = 44, onClick: () -> Unit): TextView = TextView(ctx).apply {
        val s = dp(sizeDp)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(3), 0, dp(3), 0) }
        gravity = Gravity.CENTER
        textSize = 18f
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        background = shape(0xFF141414.toInt(), dp(10), 0xFF262626.toInt())
        setOnClickListener { onClick() }
    }

    private fun openMusic() {
        closeSlots()
        val store = FriendLink.store
        fun player(): MusicPlayer? = store?.music

        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val sh = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels
        val land = sw > sh
        val panelW = if (land) min(dp(520), sw - dp(24)) else min(dp(272), sw - dp(16))
        val listH = if (land) min(dp(150), maxOf(dp(80), sh - dp(150))) else min(dp(190), maxOf(dp(80), sh - dp(300)))
        val rows = ArrayList<MusicRow>()
        var shownCurrent: String? = null

        // ── cabecera: título, paseo/esquina y ✕ ──
        val modeBtn = musicBtn(if (parked) "📌" else "🫧", 36) { }
        modeBtn.setOnClickListener {
            val nowParked = !parked
            parked = nowParked
            if (nowParked) corner = nearestCorner()
            modeBtn.text = if (nowParked) "📌" else "🫧"
            toast(if (nowParked) "Me quedo en la esquina" else "Paseo libre por la pantalla")
        }
        val closeBtn = musicBtn("✕", 36) { closeMusic() }      // quita solo el panel; la música sigue
        closeBtn.setTextColor(0xFFFF0198.toInt())
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(ctx).apply {
                text = "🎵 Música"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 14f
                setPadding(dp(4), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(modeBtn)
            addView(closeBtn)
        }

        // ── ahora suena ──
        val title = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }
        val progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(0xFFFF0198.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0xFF262626.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4))
        }
        val play = musicBtn("▶") { player()?.toggle() }
        val buttons = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
            addView(musicBtn("⏮") { player()?.prev() })
            addView(play)
            addView(musicBtn("⏭") { player()?.next() })
        }

        // ── carpetas y canciones ──
        val crumb = TextView(ctx).apply {
            setTextColor(0xFF9A9A9A.toInt())
            textSize = 12f
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val list = ListView(ctx)
        val adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
                val tv = (convert as? TextView) ?: TextView(ctx).apply {
                    textSize = 13f
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                }
                val r = rows[i]
                val playingNow = r.kind == 2 && r.tag == player()?.current?.path
                if (r.kind == 1) {
                    // Nombre arriba y, debajo en pequeño, cuántas canciones y en qué almacenamiento (ya no se corta).
                    val t1 = "▸  " + r.label
                    val t2 = r.sub
                    if (t2.isNullOrEmpty()) tv.text = t1 else {
                        val sp = SpannableString(t1 + "\n" + t2)
                        sp.setSpan(RelativeSizeSpan(0.82f), t1.length + 1, sp.length, 0)
                        sp.setSpan(ForegroundColorSpan(0xFF9A9A9A.toInt()), t1.length + 1, sp.length, 0)
                        tv.text = sp
                    }
                } else {
                    tv.text = if (r.kind == 2) (if (playingNow) "▶  " else "♪  ") + r.label else r.label
                }
                tv.setTextColor(if (playingNow) 0xFFFF0198.toInt() else if (r.kind == 3) 0xFF9A9A9A.toInt() else 0xFFFFFFFF.toInt())
                tv.background = if (r.kind == 1 || r.kind == 2) shape(0xFF141414.toInt(), dp(8), 0x00000000) else null
                return tv
            }
        }
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = dp(4)
        list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH)

        // Vertical: todo apilado. Horizontal: controles a la izquierda y carpetas/canciones a la derecha.
        val box = LinearLayout(ctx).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(0xFF0B0B0B.toInt(), dp(14), 0xFF262626.toInt())
            if (!land) {
                orientation = LinearLayout.VERTICAL
                addView(header)
                addView(title)
                addView(progress)
                addView(buttons)
                addView(crumb)
                addView(list)
            } else {
                orientation = LinearLayout.HORIZONTAL
                val left = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams((panelW * 0.42f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
                    addView(header)
                    addView(title)
                    addView(progress)
                    addView(buttons)
                }
                val right = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(10), 0, 0, 0) }
                    addView(crumb)
                    addView(list)
                }
                addView(left)
                addView(right)
            }
        }

        fun fillFolders(fs: List<CatFolder>) {
            rows.clear()
            if (fs.isEmpty()) rows.add(MusicRow("No encontré música en este equipo", null, null, 3))
            for (f in fs.sortedBy { it.dir.name.lowercase() }) {
                val n = f.files
                rows.add(MusicRow(f.dir.name, "$n " + (if (n == 1) "canción" else "canciones") + (if (f.vol.isNotEmpty()) " · " + f.vol else ""), f.dir.path, 1))
            }
            adapter.notifyDataSetChanged()
        }

        fun showFolders() {
            curFolder = null
            curSongs = emptyList()
            crumb.text = "Carpetas de música"
            val cached: List<CatFolder>? = (try { store?.catCache?.get(HomeTab.MUSIC)?.folders } catch (e: Exception) { null }) ?: musicFolders
            if (cached != null) {
                fillFolders(cached)
            } else {
                rows.clear(); rows.add(MusicRow("Buscando música…", null, null, 3)); adapter.notifyDataSetChanged()
                Thread {
                    val r: List<CatFolder> = try { if (store != null) mediaStoreTab(ctx, store.vols, HomeTab.MUSIC).folders else emptyList() } catch (e: Exception) { emptyList() }
                    ui.post {
                        musicFolders = r
                        if (music === box && curFolder == null) fillFolders(r)
                    }
                }.start()
            }
        }

        fun openFolder(dir: File) {
            curFolder = dir
            crumb.text = "‹  " + dir.name
            rows.clear(); rows.add(MusicRow("Cargando…", null, null, 3)); adapter.notifyDataSetChanged()
            Thread {
                val fs: List<File> = try {
                    (dir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.startsWith(".") && kindOf(it) == Kind.AUD }
                        .sortedBy { it.name.lowercase() }
                } catch (e: Exception) { emptyList() }
                ui.post {
                    if (music === box && curFolder == dir) {
                        curSongs = fs
                        rows.clear()
                        if (fs.isEmpty()) rows.add(MusicRow("Esta carpeta no tiene canciones", null, null, 3))
                        fs.forEachIndexed { i, f -> rows.add(MusicRow(f.nameWithoutExtension, null, f.path, 2, i)) }
                        adapter.notifyDataSetChanged()
                    }
                }
            }.start()
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            val r = rows.getOrNull(pos) ?: return@setOnItemClickListener
            when (r.kind) {
                1 -> r.tag?.let { openFolder(File(it)) }
                2 -> { player()?.start(curSongs, r.idx); adapter.notifyDataSetChanged() }
            }
        }
        crumb.setOnClickListener { if (curFolder != null) showFolders() }

        val tick = object : Runnable {
            override fun run() {
                val m = player()
                m?.tick()
                title.text = m?.current?.nameWithoutExtension ?: "Elige una carpeta y una canción"
                play.text = if (m != null && m.playing) "⏸" else "▶"
                progress.progress = if (m != null && m.duration > 0) (m.position * 1000L / m.duration).toInt() else 0
                val cur = m?.current?.path
                if (cur != shownCurrent) { shownCurrent = cur; adapter.notifyDataSetChanged() }
                ui.postDelayed(this, 300)
            }
        }
        val p = params(false, panelW, WindowManager.LayoutParams.WRAP_CONTENT)
        try {
            wm.addView(box, p)
            music = box
            musicLp = p
            musicTick = tick
        } catch (e: Exception) {
            return
        }
        // Al girar el teléfono el panel se rehace y vuelve a la carpeta que estaba abierta.
        val back = curFolder
        if (back != null) openFolder(back) else showFolders()
        tick.run()
        position(box, p)
        try { wm.updateViewLayout(box, p) } catch (e: Exception) { }
    }

    private fun closeMusic(reset: Boolean = true) {
        musicTick?.let { ui.removeCallbacks(it) }
        musicTick = null
        music?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        music = null
        musicLp = null
        if (reset) { curFolder = null; curSongs = emptyList() }
        idleUntil = SystemClock.uptimeMillis() + 800L        // al cerrar el panel, el amigo sigue con lo suyo
    }
}
