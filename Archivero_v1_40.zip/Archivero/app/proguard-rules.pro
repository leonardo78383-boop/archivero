# Archivero no usa reflexión propia; las reglas por defecto de Android y Compose alcanzan.

# PDFBox (lectura de texto de PDF): usa recursos y clases opcionales que no se incluyen.
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.harmony.** { *; }
-dontwarn com.tom_roush.**
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
-dontwarn javax.xml.**
-dontwarn java.awt.**
