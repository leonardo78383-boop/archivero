package com.archivero

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.ThumbnailUtils
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** Cola "el último en llegar sale primero": al desplazarse rápido, se cargan antes las miniaturas que están a la vista. */
private class LifoQueue : LinkedBlockingDeque<Runnable>() {
    override fun offer(e: Runnable): Boolean = offerFirst(e)
    override fun add(e: Runnable): Boolean { addFirst(e); return true }
}

/**
 * Miniaturas de fotos, vídeos, música (carátula), PDF (primera página) y APK (ícono de la app).
 * - Guarda las ya generadas en memoria, así volver a verlas es instantáneo.
 * - 4 a la vez y las más recientes primero, para que desplazarse rápido no sature el teléfono.
 * - Las que fallan se recuerdan: no se reintentan en cada desplazamiento.
 */
object Thumbs {
    private const val PX = 224

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val failed = HashSet<String>()
    private val pool = ThreadPoolExecutor(
        4, 4, 0L, TimeUnit.MILLISECONDS, LifoQueue(),
        { r -> Thread(r, "thumbs").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 } }
    ).asCoroutineDispatcher()

    /** ¿Este tipo de archivo puede tener miniatura? */
    fun supports(kind: Kind): Boolean =
        kind == Kind.IMG || kind == Kind.VID || kind == Kind.AUD || kind == Kind.PDF || kind == Kind.APK

    fun cached(path: String): Bitmap? = cache.get(path)

    fun hasFailed(path: String): Boolean = synchronized(failed) { path in failed }

    /** Memoria que ocupan las miniaturas guardadas (bytes). */
    fun sizeBytes(): Long = cache.size().toLong() * 1024L

    fun clear() {
        cache.evictAll()
        synchronized(failed) { failed.clear() }
    }

    suspend fun load(ctx: Context, f: File, kind: Kind): Bitmap? {
        cache.get(f.path)?.let { return it }
        if (hasFailed(f.path)) return null
        val app = ctx.applicationContext
        return withContext(pool) {
            val b = try {
                when (kind) {
                    Kind.VID -> ThumbnailUtils.createVideoThumbnail(f, Size(PX, PX), null)
                    Kind.IMG -> ThumbnailUtils.createImageThumbnail(f, Size(PX, PX), null)
                    Kind.AUD -> ThumbnailUtils.createAudioThumbnail(f, Size(PX, PX), null)
                    Kind.PDF -> pdfFirstPage(f)
                    Kind.APK -> apkIcon(app, f)
                    else -> null
                }
            } catch (e: Exception) {
                null   // archivo dañado, sin carátula o formato no soportado: se muestra el ícono normal
            } catch (e: OutOfMemoryError) {
                null
            }
            if (b != null) cache.put(f.path, b) else synchronized(failed) { failed.add(f.path) }
            b
        }
    }

    /** Primera página del PDF sobre fondo blanco. */
    private fun pdfFirstPage(f: File): Bitmap? {
        val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        // Un PDF con contraseña o dañado lanza error al abrirse: sin esto el descriptor quedaba abierto para siempre (se acababan al listar muchos PDF).
        val r = try { PdfRenderer(fd) } catch (e: Exception) {
            try { fd.close() } catch (ignored: Exception) { }
            throw e
        }
        try {
            if (r.pageCount == 0) return null
            val p = r.openPage(0)
            try {
                val w = PX
                val h = (PX * p.height.toFloat() / p.width.toFloat()).toInt().coerceIn(PX / 2, PX * 2)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                Canvas(bmp).drawColor(Color.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                p.close()
            }
        } finally {
            r.close()
        }
    }

    /** Ícono de la app que está dentro del APK (sin instalarlo). */
    private fun apkIcon(ctx: Context, f: File): Bitmap? {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(f.path, 0) ?: return null
        val ai = info.applicationInfo ?: return null
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        return ai.loadIcon(pm).toBitmap(PX, PX)
    }
}
