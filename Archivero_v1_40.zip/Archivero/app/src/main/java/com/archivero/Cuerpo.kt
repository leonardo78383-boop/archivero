package com.archivero

import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Cuerpo del amigo (Change shape):
 *  1) VOLUMEN: de la silueta de la foto se saca una "altura" (el centro sale hacia adelante y los bordes se curvan)
 *     y con ella se pinta luz y sombra sobre la propia foto. Todo se hace una sola vez, sin internet.
 *  2) ESQUELETO: la figura se parte en una malla de triángulos con huesos (cabeza, brazos, piernas) que se colocan
 *     solos según la silueta. Cada cuadro la malla se dobla con los huesos y la foto se deforma con ella.
 */

private fun smooth(a: Float, b: Float, x: Float): Float {
    if (b <= a) return if (x >= b) 1f else 0f
    val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/** Devuelve los mismos píxeles con luz y sombra (la forma se ve redonda, con masa). */
private fun shadePixels(px: IntArray, w: Int, h: Int): IntArray {
    val n = w * h
    val d = FloatArray(n)
    for (i in 0 until n) d[i] = if ((px[i] ushr 24) >= 128) 1e9f else 0f

    fun at(x: Int, y: Int): Float = if (x < 0 || y < 0 || x >= w || y >= h) 0f else d[y * w + x]

    // Distancia de cada píxel al borde de la figura (dos pasadas).
    for (y in 0 until h) for (x in 0 until w) {
        val i = y * w + x
        if (d[i] == 0f) continue
        var m = d[i]
        m = min(m, at(x - 1, y) + 1f)
        m = min(m, at(x, y - 1) + 1f)
        m = min(m, at(x - 1, y - 1) + 1.414f)
        m = min(m, at(x + 1, y - 1) + 1.414f)
        d[i] = m
    }
    for (y in h - 1 downTo 0) for (x in w - 1 downTo 0) {
        val i = y * w + x
        if (d[i] == 0f) continue
        var m = d[i]
        m = min(m, at(x + 1, y) + 1f)
        m = min(m, at(x, y + 1) + 1f)
        m = min(m, at(x + 1, y + 1) + 1.414f)
        m = min(m, at(x - 1, y + 1) + 1.414f)
        d[i] = m
    }
    var maxD = 0f
    for (v in d) if (v < 1e8f && v > maxD) maxD = v
    val r = max(4f, min(maxD, 0.12f * max(w, h)))

    // Altura: perfil redondo (circular) cerca del borde, plano en el centro.
    var hgt = FloatArray(n)
    for (i in 0 until n) {
        val t = min(1f, min(d[i], 1e8f) / r)
        hgt[i] = sqrt(max(0f, 1f - (1f - t) * (1f - t)))
    }
    // Se suaviza para que no se noten las marcas del cálculo.
    for (pass in 0 until 3) {
        val o = FloatArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue
                s += hgt[yy * w + xx]
                c++
            }
            o[y * w + x] = s / c
        }
        hgt = o
    }

    // Luz desde arriba a la izquierda.
    var lx = -0.42f
    var ly = -0.55f
    var lz = 0.72f
    val ll = sqrt(lx * lx + ly * ly + lz * lz)
    lx /= ll; ly /= ll; lz /= ll
    var hx = lx
    var hy = ly
    var hz = lz + 1f
    val hl = sqrt(hx * hx + hy * hy + hz * hz)
    hx /= hl; hy /= hl; hz /= hl

    val out = IntArray(n)
    for (y in 0 until h) for (x in 0 until w) {
        val i = y * w + x
        val p = px[i]
        val a = p ushr 24
        if (a == 0) { out[i] = p; continue }
        val xa = max(0, x - 1)
        val xb = min(w - 1, x + 1)
        val ya = max(0, y - 1)
        val yb = min(h - 1, y + 1)
        val gx = (hgt[y * w + xb] - hgt[y * w + xa]) / max(1, xb - xa).toFloat()
        val gy = (hgt[yb * w + x] - hgt[ya * w + x]) / max(1, yb - ya).toFloat()
        var nx = -gx * r * 0.9f
        var ny = -gy * r * 0.9f
        var nz = 1f
        val nl = sqrt(nx * nx + ny * ny + nz * nz)
        nx /= nl; ny /= nl; nz /= nl
        val lam = max(0f, nx * lx + ny * ly + nz * lz)
        var sp = max(0f, nx * hx + ny * hy + nz * hz)
        sp *= sp; sp *= sp; sp *= sp; sp *= sp; sp *= sp     // ^32: brillito suave
        sp *= 0.10f
        val t = min(1f, min(d[i], 1e8f) / r)
        val shade = (0.55f + 0.65f * lam) * (0.80f + 0.20f * sqrt(t))
        val rr = (((p shr 16) and 255) * shade + sp * 255f).toInt().coerceIn(0, 255)
        val gg = (((p shr 8) and 255) * shade + sp * 255f).toInt().coerceIn(0, 255)
        val bb = ((p and 255) * shade + sp * 255f).toInt().coerceIn(0, 255)
        out[i] = (a shl 24) or (rr shl 16) or (gg shl 8) or bb
    }
    return out
}

class SkinRig(val src: ImageBitmap, val body: BodyType) {
    val bmp: Bitmap
    val image: ImageBitmap
    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    val cols = 14
    val rows = 20
    private val nv = (cols + 1) * (rows + 1)
    val verts = FloatArray(nv * 2)
    private val vu = FloatArray(nv)
    private val vv = FloatArray(nv)
    private var nb = 0
    private var bw: Array<FloatArray> = emptyArray()
    private var pu = FloatArray(0)
    private var pv = FloatArray(0)
    private val hipV = 0.56f
    private val bc = FloatArray(8)
    private val bs = FloatArray(8)
    private val bt = FloatArray(8)
    private var drag = 0f

    init {
        for (i in 0 until nv) {
            vu[i] = (i % (cols + 1)).toFloat() / cols
            vv[i] = (i / (cols + 1)).toFloat() / rows
        }
        val flat = src.asAndroidBitmap()
        val w = flat.width
        val h = flat.height
        var px: IntArray? = null
        try {
            val a = IntArray(w * h)
            flat.getPixels(a, 0, w, 0, 0, w, h)
            px = a
        } catch (e: Exception) {
            px = null
        }
        if (px != null) {
            var made: Bitmap
            try {
                made = Bitmap.createBitmap(shadePixels(px, w, h), w, h, Bitmap.Config.ARGB_8888)
            } catch (e: Exception) {
                made = flat
            }
            bmp = made
            try { build(px, w, h) } catch (e: Exception) { nb = 0 }
        } else {
            bmp = flat
        }
        image = bmp.asImageBitmap()
    }

    /** Coloca los huesos mirando la silueta y calcula cuánto manda cada hueso en cada punto de la malla. */
    private fun build(px: IntArray, w: Int, h: Int) {
        fun al(x: Int, y: Int): Float = (px[y * w + x] ushr 24) / 255f
        fun colSums(v0: Float, v1: Float): FloatArray {
            val y0 = (v0 * (h - 1)).toInt().coerceIn(0, h - 1)
            val y1 = (v1 * (h - 1)).toInt().coerceIn(y0, h - 1)
            val cs = FloatArray(w)
            for (y in y0..y1) for (x in 0 until w) cs[x] += al(x, y)
            val rowsN = (y1 - y0 + 1).toFloat()
            for (x in 0 until w) cs[x] /= rowsN
            return cs
        }

        var sx = 0f
        var sa = 0f
        for (y in 0 until h) for (x in 0 until w) {
            val a = al(x, y)
            sx += a * x
            sa += a
        }
        val cx = if (sa > 0f) (sx / sa / w).coerceIn(0.3f, 0.7f) else 0.5f

        val raw: Array<FloatArray>
        if (body == BodyType.FOUR_LEGS) {
            val cs = colSums(0.88f, 0.97f)
            var mx = 0f
            for (c in cs) if (c > mx) mx = c
            val thr = max(0.15f, mx * 0.35f)
            val runs = ArrayList<FloatArray>()
            var st = -1
            val minW = max(2, (w * 0.02f).toInt())
            for (x in 0..w) {
                val on = x < w && cs[x] > thr
                if (on && st < 0) st = x
                if (!on && st >= 0) {
                    if (x - st >= minW) runs.add(floatArrayOf((st + x - 1) / 2f / w, (x - st).toFloat()))
                    st = -1
                }
            }
            val centers: List<Float> =
                if (runs.size >= 4) runs.sortedByDescending { it[1] }.take(4).map { it[0] }.sorted()
                else listOf(0.15f, 0.33f, 0.67f, 0.85f)
            nb = 4
            pu = FloatArray(4) { centers[it] }
            pv = FloatArray(4) { 0.60f }
            raw = Array(4) { FloatArray(nv) }
            for (i in 0 until nv) {
                val lv = smooth(0.52f, 0.68f, vv[i])
                for (b in 0 until 4) {
                    val z = (vu[i] - centers[b]) / 0.07f
                    raw[b][i] = lv * exp(-z * z)
                }
            }
        } else {
            // Dos patas: cabeza, brazo izq., brazo der., pierna izq., pierna der.
            val cs = colSums(0.85f, 0.97f)
            var split = cx
            var bestScore = 1e9f
            for (x in (w * 0.3f).toInt() until (w * 0.7f).toInt()) {
                val a = (cs[max(0, x - 1)] + cs[x] + cs[min(w - 1, x + 1)]) / 3f
                val u = x.toFloat() / w
                val sc = a + 0.4f * abs(u - cx)
                if (sc < bestScore) { bestScore = sc; split = u }
            }
            val csH = colSums(0.60f, 0.74f)
            var ls = 0f
            var lw = 0f
            var rs = 0f
            var rw = 0f
            val sx0 = (split * w).toInt()
            for (x in 0 until w) {
                if (x < sx0) { ls += csH[x] * x; lw += csH[x] } else { rs += csH[x] * x; rw += csH[x] }
            }
            val hipL = if (lw > 0.01f) ls / lw / w else split - 0.12f
            val hipR = if (rw > 0.01f) rs / rw / w else split + 0.12f

            val cE = colSums(0.30f, 0.40f)
            var e0 = -1
            var e1 = -1
            for (x in 0 until w) if (cE[x] > 0.25f) { if (e0 < 0) e0 = x; e1 = x }
            val halfExt = if (e1 > e0) ((e1 - e0) / 2f / w).coerceIn(0.18f, 0.5f) else 0.3f
            val off = (halfExt * 0.75f).coerceIn(0.10f, 0.30f)

            nb = 5
            pu = floatArrayOf(cx, cx - off, cx + off, hipL, hipR)
            pv = floatArrayOf(0.22f, 0.27f, 0.27f, hipV, hipV)
            raw = Array(5) { FloatArray(nv) }
            for (i in 0 until nv) {
                val u = vu[i]
                val v = vv[i]
                raw[0][i] = 1f - smooth(0.13f, 0.25f, v)
                val vwin = smooth(0.20f, 0.30f, v) * (1f - smooth(0.58f, 0.70f, v))
                val aw = smooth(halfExt * 0.55f, halfExt * 0.80f, abs(u - cx)) * vwin
                raw[1][i] = if (u < cx) aw else 0f
                raw[2][i] = if (u >= cx) aw else 0f
                val lv = smooth(0.50f, 0.64f, v)
                val sl = 1f - smooth(split - 0.05f, split + 0.05f, u)
                raw[3][i] = lv * sl
                raw[4][i] = lv * (1f - sl)
            }
        }
        // Que los pesos de un punto nunca sumen más de 1 (el resto lo manda el cuerpo).
        for (i in 0 until nv) {
            var s = 0f
            for (b in 0 until nb) s += raw[b][i]
            if (s > 1f) for (b in 0 until nb) raw[b][i] /= s
        }
        bw = raw
    }

    private fun setBone(i: Int, deg: Float, lift: Float) {
        val r = deg * (PI / 180.0).toFloat()
        bc[i] = cos(r)
        bs[i] = sin(r)
        bt[i] = lift
    }

    /**
     * Dobla la malla: piernas y brazos giran desde sus articulaciones al caminar, la cabeza se mece,
     * el pecho respira y, si lo agarras, estira brazos y piernas. Deja el resultado en [verts].
     */
    fun pose(left: Float, top: Float, w: Float, h: Float, gait: Float, ph: Float, bob: Float, dragging: Boolean) {
        val tau = 6.2831855f
        drag += ((if (dragging) 1f else 0f) - drag) * 0.2f
        val idle = (bob - 0.5f) * 2f              // -1..1, suave
        val breath = 0.014f * idle

        if (nb == 5) {
            val sL = sin(tau * ph)
            val cL = cos(tau * ph)
            val sR = sin(tau * (ph + 0.5f))
            val cR = cos(tau * (ph + 0.5f))
            setBone(0, 3f * sin(tau * ph * 2f) * gait + 1.5f * idle, 0f)
            setBone(1, -30f * sR * gait + 3f * idle + 35f * drag, 0f)
            setBone(2, -30f * sL * gait - 3f * idle - 35f * drag, 0f)
            setBone(3, -26f * sL * gait + 8f * drag, -max(0f, cL) * h * 0.04f * gait)
            setBone(4, -26f * sR * gait - 8f * drag, -max(0f, cR) * h * 0.04f * gait)
        } else if (nb == 4) {
            for (i in 0 until 4) {
                val o = when (i) { 0 -> 0f; 1 -> 0.5f; 2 -> 0.25f; else -> 0.75f }
                val s = sin(tau * (ph + o))
                val c = cos(tau * (ph + o))
                val side = if (i < 2) 1f else -1f
                setBone(i, -20f * s * gait + side * 6f * drag, -max(0f, c) * h * 0.03f * gait)
            }
        }

        val hipY = top + hipV * h
        for (i in 0 until nv) {
            val x0 = left + vu[i] * w
            val y0 = top + vv[i] * h
            var sw = 0f
            var ax = 0f
            var ay = 0f
            for (b in 0 until nb) {
                val wi = bw[b][i]
                if (wi <= 0.0005f) continue
                val px = left + pu[b] * w
                val py = top + pv[b] * h
                val dx = x0 - px
                val dy = y0 - py
                ax += wi * (px + dx * bc[b] - dy * bs[b])
                ay += wi * (py + dx * bs[b] + dy * bc[b] + bt[b])
                sw += wi
            }
            val rest = 1f - sw
            var by = y0 + (y0 - hipY) * breath * (1f - smooth(0.45f, 0.62f, vv[i]))
            if (nb == 4) by += sin(tau * ph * 2f - vu[i] * 3.1416f) * h * 0.008f * gait
            verts[2 * i] = ax + rest * x0
            verts[2 * i + 1] = ay + rest * by
        }
    }
}
