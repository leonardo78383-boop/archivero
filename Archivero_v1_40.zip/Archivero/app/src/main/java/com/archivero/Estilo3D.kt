package com.archivero

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tonos del "vidrio" oscuro: de arriba (más claro) a abajo (más oscuro) para dar volumen. */
object Glass {
    val Top = Color(0xFF2C2C34)
    val Mid = Color(0xFF18181D)
    val Bottom = Color(0xFF0D0D11)
    val Rim = Color(0x55FFFFFF)
}

/** Fondo de Inicio: degradado oscuro con un resplandor rosa muy tenue en la esquina superior. */
fun Modifier.fondoInicio(): Modifier = this
    .background(Brush.verticalGradient(listOf(Color(0xFF121218), Color(0xFF060608), Color.Black)))
    .drawBehind {
        drawRect(
            Brush.radialGradient(
                colors = listOf(Pal.Accent.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(size.width * 0.1f, 0f),
                radius = size.width * 0.95f
            )
        )
    }

/** Superficie elevada de vidrio: sombra, degradado vertical, brillo en el borde superior y canto fino. */
fun Modifier.vidrio3D(shape: Shape, elevation: Dp = 10.dp, glow: Boolean = false): Modifier = this
    .shadow(elevation, shape, ambientColor = Color.Black, spotColor = if (glow) Pal.Accent else Color.Black)
    .background(Brush.verticalGradient(listOf(Glass.Top, Glass.Mid, Glass.Bottom)), shape)
    .drawBehind {
        val y = 1.5.dp.toPx()
        drawLine(
            Brush.horizontalGradient(listOf(Color.Transparent, Color(0x66FFFFFF), Color.Transparent)),
            Offset(size.width * 0.12f, y), Offset(size.width * 0.88f, y),
            strokeWidth = 1.dp.toPx()
        )
    }
    .border(1.dp, Brush.verticalGradient(listOf(Glass.Rim, Color(0x14FFFFFF), Color(0x0AFFFFFF))), shape)

/** Título de sección: barrita de acento + texto pequeño en mayúsculas con letras espaciadas. */
@Composable
fun SectionTitle(text: String) {
    Row(Modifier.padding(start = 18.dp, top = 22.dp, end = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(14.dp).background(Pal.Accent))
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = Pal.Muted, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 2.sp)
    }
}
