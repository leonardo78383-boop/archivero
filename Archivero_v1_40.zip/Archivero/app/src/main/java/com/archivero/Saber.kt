package com.archivero

import android.content.Context
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

// ───────────── Qué carpetas puede tocar el amigo ─────────────

/**
 * Regla única de permiso: el amigo solo actúa dentro de una carpeta de la TARJETA SD cuyo nombre empieza con 🔓
 * pegado a la palabra (sin espacio), por ejemplo «🔓carpeta». Lo que está dentro de esa carpeta (subcarpetas) también cuenta.
 *  - ESCRIBIR: solo ahí (archivos de texto). Fuera de ahí no crea ni modifica nada. Nunca borra.
 *  - LEER PDF a demanda: los PDF que estén dentro de una carpeta 🔓 los lee todas las veces que quieras, mientras sigan ahí.
 */
object CarpetaLibre {
    const val MARCA = "🔓"

    /** Solo archivos de texto: nunca toca fotos, vídeos, APKs, PDFs, etc. */
    val TEXTO = setOf("txt", "md", "csv", "log", "json", "xml", "html")

    /** «🔓carpeta» sí; «🔓 carpeta» (con espacio) y «🔓» solo, no. */
    fun marcada(nombre: String): Boolean =
        nombre.length > MARCA.length && nombre.startsWith(MARCA) && !nombre[MARCA.length].isWhitespace()

    /** Nombre de archivo sin rutas ni caracteres raros; null si no sirve. */
    fun nombreSeguro(raw: String): String? {
        val n = raw.trim().trim('"', '«', '»', '\'')
        if (n.isEmpty() || n.length > 80) return null
        if (n.any { it in "/\\:*?\"<>|" || it.isISOControl() }) return null
        if (n.startsWith(".")) return null
        return n
    }
}

private class Voc(var n: Int, var ej: String, var fuentes: Int, var cuando: Long)

internal val STOP: Set<String> = (
    "para pero como esta este esto estos estas ese esa eso esos esas aquel aquella con por del las los una uno unos unas " +
    "que más mas muy sin sobre entre desde hasta hacia según segun también tambien cuando donde quien quienes cual cuales " +
    "cada otro otra otros otras todo toda todos todas ser son fue fueron sido era eran está están estan estaba estar tiene " +
    "tienen tener hay haber había han has hemos son nos les les mis tus sus mío tuyo suyo ante bajo tras así asi aun aún " +
    "pues porque sino sea sean puede pueden poder debe deben ella ellos ellas usted ustedes nosotros vosotros ahí ahi aquí aqui " +
    "the and for are but not you all any can had her was one our out has have that this with from they will would there their " +
    "what about which when your said each she how its who them then than into more some could other these those been being"
    ).split(" ").filter { it.isNotEmpty() }.toSet()

/** Resultado de buscar una palabra en lo aprendido. */
class PalabraSabida(val palabra: String, val veces: Int, val pdfs: Int, val ejemplo: String, val suele: List<String> = emptyList())

/** Resultado de buscar un PDF 🔓 por nombre: el archivo, o un aviso para el usuario. `coincide` = había candidatos (aunque sean varios). */
class BusquedaPdf(val archivo: File?, val aviso: String?, val coincide: Boolean)

/** Texto de un PDF por páginas, con la clave (ruta|tamaño|fecha) para saber si sigue siendo el mismo archivo. */
private class PdfTexto(val clave: String, val paginas: List<String>, val totalPaginas: Int)

/**
 * Lo que el amigo sabe hacer con archivos, con dos límites duros:
 *  1) ESCRIBIR: solo en carpetas 🔓 de la tarjeta SD, solo texto, nunca borra, y antes de cambiar algo guarda un .bak.
 *  2) LEER: solo PDF. Dos vías:
 *     a) los que tú le das con «Enseñar al amigo»: aprende sus palabras y las guarda en su memoria (Documents/Amigo/vocabulario.json);
 *     b) los que estén dentro de una carpeta 🔓 de la SD: los lee (leer, buscar una palabra, ver una página) todas las veces que
 *        quieras. El permiso se comprueba en CADA lectura: si sacas el PDF de la carpeta 🔓 (o le quitas el 🔓 a la carpeta, o le
 *        pones un espacio), deja de poder leerlo.
 *  Lo que lee, en ambos casos, lo guarda en su CEREBRO (una sola vez por PDF): vocabulario, frases enteras (su «literatura») y qué
 *  palabras suelen ir juntas. Cada PDF crea su propio archivo en Documents/Amigo/cerebro/ y nunca se borra ni se olvida nada: al abrir
 *  la app todos los archivos se suman en una sola memoria. (vocabulario.json y literatura.json de las versiones 1.33–1.35 se siguen
 *  leyendo como la base del cerebro.)
 */
class AmigoSaber(
    context: Context,
    private val volsProvider: () -> List<Vol>,
    private val memoryDir: () -> File
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private val vocab = HashMap<String, Voc>()
    private val leidos = LinkedHashMap<String, String>()          // clave del PDF -> nombre
    private val recientes = ArrayList<String>()                   // últimas palabras nuevas aprendidas
    private val frases = ArrayList<Pair<String, String>>()        // su «literatura»: frase entera -> nombre del PDF
    private val frasesVistas = HashSet<String>()                  // para no guardar dos veces la misma frase
    private val pendientes = ArrayList<Pair<String, String>>()    // archivos del cerebro (nombre, contenido) aún sin escribir en disco
    private val siguen = HashMap<String, HashMap<String, Int>>()  // palabra -> palabras que suelen ir justo después (con cuántas veces)
    private var loaded = false
    @Volatile private var dirty = false
    private var lastSync = 0L
    private val syncing = AtomicBoolean(false)
    private var pdfboxListo = false

    /** Cuántas palabras distintas sabe (se muestra en Ajustes). */
    var count by mutableIntStateOf(0)
        private set

    /** Cuántas frases enteras guarda de lo que ha leído (se muestra en Ajustes). */
    var frasesCount by mutableIntStateOf(0)
        private set

    /** Dónde dice lo que hace por su cuenta (el chat lo conecta). */
    @Volatile var onSay: ((String) -> Unit)? = null

    init { scope.launch { cargar() } }

    // ───────────── Permiso ─────────────

    private fun sdRoots(): List<File> {
        val internal = Environment.getExternalStorageDirectory().absolutePath
        return volsProvider().map { it.dir }.filter { it.absolutePath != internal }
    }

    private fun canon(f: File): File = try { f.canonicalFile } catch (e: Exception) { f.absoluteFile }

    /** ¿Se puede crear o modificar este archivo? Solo si está dentro de una carpeta 🔓 de la SD (se resuelven .. y accesos directos). */
    fun puedeEscribir(target: File): Boolean = dentroDeCarpetaLibre(target)

    /** ¿Puede leer este PDF a demanda? Solo si ahora mismo existe, es .pdf y está dentro de una carpeta 🔓 de la SD (o de una subcarpeta). */
    fun puedeLeer(pdf: File): Boolean =
        pdf.isFile && pdf.extension.equals("pdf", ignoreCase = true) && dentroDeCarpetaLibre(pdf)

    private fun dentroDeCarpetaLibre(target: File): Boolean {
        val t = canon(target)
        val root = sdRoots().map { canon(it) }.firstOrNull { t.path.startsWith(it.path + File.separator) } ?: return false
        var d: File? = t.parentFile
        while (d != null && d.path.length > root.path.length) {
            if (CarpetaLibre.marcada(d.name)) return true
            d = d.parentFile
        }
        return false
    }

    @Volatile private var cacheT = 0L
    @Volatile private var cacheL: List<File> = emptyList()

    /** Las carpetas 🔓 que hay ahora en la SD (se busca hasta 5 niveles; el resultado se recuerda 30 s). */
    fun carpetas(force: Boolean = false): List<File> {
        val now = System.currentTimeMillis()
        if (!force && now - cacheT < 30_000L) return cacheL
        val out = ArrayList<File>()
        var visitadas = 0
        fun recorrer(d: File, nivel: Int) {
            if (visitadas++ > 4000) return
            val hijos = d.listFiles() ?: return
            for (k in hijos) {
                if (!k.isDirectory) continue
                if (CarpetaLibre.marcada(k.name)) { out.add(k); continue }
                if (nivel < 4 && !k.name.startsWith(".") && k.name != "Android") recorrer(k, nivel + 1)
            }
        }
        for (r in sdRoots()) recorrer(r, 0)
        out.sortBy { it.path }
        cacheL = out
        cacheT = now
        return out
    }

    private val SIN_CARPETAS =
        "No tengo ninguna carpeta con ${CarpetaLibre.MARCA} en la tarjeta SD. Ponle ${CarpetaLibre.MARCA} pegado al nombre " +
            "(por ejemplo ${CarpetaLibre.MARCA}carpeta) y ahí sí puedo escribir."

    fun carpetasTexto(): String {
        val c = carpetas(true)
        return if (c.isEmpty()) SIN_CARPETAS
        else "Puedo escribir en: " + c.joinToString(", ") { "«" + it.name + "»" } +
            ". Solo archivos de texto y nunca borro nada. Los PDF que estén ahí los puedo leer cuando quieras."
    }

    // ───────────── Escribir (por orden tuya) ─────────────

    private fun elegirCarpeta(libres: List<File>, hint: String?): Pair<File?, String?> {
        if (hint != null) {
            val h = hint.trim().trim('"', '«', '»').removePrefix(CarpetaLibre.MARCA).lowercase()
            val f = libres.firstOrNull { it.name.removePrefix(CarpetaLibre.MARCA).lowercase() == h }
            return if (f != null) Pair(f, null)
            else Pair(null, "No encuentro esa carpeta 🔓. Tengo: " + libres.joinToString(", ") { "«" + it.name + "»" })
        }
        if (libres.size == 1) return Pair(libres[0], null)
        return Pair(null, "¿En cuál? Tengo: " + libres.joinToString(", ") { "«" + it.name + "»" } + ". Decime «… en nombre-de-carpeta …».")
    }

    private fun conExtension(nombre: String): String = if (nombre.contains('.')) nombre else "$nombre.txt"

    private fun esTexto(nombre: String) = nombre.substringAfterLast('.', "").lowercase() in CarpetaLibre.TEXTO

    fun crear(nombreRaw: String, carpetaHint: String?, texto: String): String {
        val libres = carpetas(true)
        if (libres.isEmpty()) return SIN_CARPETAS
        val n0 = CarpetaLibre.nombreSeguro(nombreRaw) ?: return "Ese nombre no me sirve (sin / \\ : * ? \" < > |, y que no empiece con punto)."
        val nombre = conExtension(n0)
        if (!esTexto(nombre)) return "Solo escribo archivos de texto (${CarpetaLibre.TEXTO.joinToString(", ")})."
        if (texto.length > 20_000) return "Ese texto es demasiado largo (máximo 20 000 caracteres)."
        val (dir, error) = elegirCarpeta(libres, carpetaHint)
        if (dir == null) return error ?: "No sé en qué carpeta."
        val f = File(dir, nombre)
        if (!puedeEscribir(f)) return "Ahí no puedo escribir."
        if (f.exists()) return "«$nombre» ya existe en «${dir.name}». Si querés, decime «agrega a $nombre: …»."
        return try {
            f.writeText(texto.trim() + "\n", Charsets.UTF_8)
            "Listo: creé «$nombre» en «${dir.name}»."
        } catch (e: Exception) {
            "No pude crear el archivo (sin espacio o sin permiso)."
        }
    }

    private fun buscarArchivo(nombreRaw: String): File? {
        val n0 = CarpetaLibre.nombreSeguro(nombreRaw) ?: return null
        val candidatos = listOf(n0, conExtension(n0)).distinct()
        for (c in carpetas(true)) {
            for (n in candidatos) {
                val directo = File(c, n)
                if (directo.isFile) return directo
                val f = c.walkTopDown().maxDepth(3).firstOrNull { it.isFile && it.name.equals(n, ignoreCase = true) }
                if (f != null) return f
            }
        }
        return null
    }

    fun agregar(nombreRaw: String, texto: String): String {
        if (carpetas(true).isEmpty()) return SIN_CARPETAS
        val f = buscarArchivo(nombreRaw) ?: return "No encuentro «${nombreRaw.trim()}» en mis carpetas 🔓."
        if (!puedeEscribir(f) || !esTexto(f.name)) return "Ese archivo no lo puedo modificar."
        if (texto.length > 20_000 || f.length() > 1_000_000L) return "Ese archivo o texto es demasiado grande para mí."
        return try {
            f.appendText("\n" + texto.trim() + "\n", Charsets.UTF_8)
            "Listo: agregué el texto al final de «${f.name}»."
        } catch (e: Exception) {
            "No pude escribir en «${f.name}»."
        }
    }

    fun cambiar(nombreRaw: String, viejo: String, nuevo: String): String {
        if (carpetas(true).isEmpty()) return SIN_CARPETAS
        val f = buscarArchivo(nombreRaw) ?: return "No encuentro «${nombreRaw.trim()}» en mis carpetas 🔓."
        if (!puedeEscribir(f) || !esTexto(f.name)) return "Ese archivo no lo puedo modificar."
        if (f.length() > 1_000_000L || viejo.isEmpty()) return "No pude hacer ese cambio."
        return try {
            val actual = f.readText(Charsets.UTF_8)
            if (!actual.contains(viejo)) return "No encontré ese texto en «${f.name}»."
            val bak = File(f.parentFile, f.name + ".bak")
            if (!puedeEscribir(bak)) return "Ahí no puedo escribir."
            bak.writeText(actual, Charsets.UTF_8)                       // copia de seguridad antes de tocar nada
            val veces = actual.split(viejo).size - 1
            f.writeText(actual.replace(viejo, nuevo), Charsets.UTF_8)
            "Listo: cambié $veces vez/veces en «${f.name}». Dejé la versión anterior en «${bak.name}»."
        } catch (e: Exception) {
            "No pude modificar «${f.name}»."
        }
    }

    // ───────────── Por su cuenta: diario y vocabulario en la carpeta 🔓 ─────────────

    private fun fechaHora(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es")).format(Date())

    /** Anota una línea en «Amigo - diario.txt» (lo crea si no existe). Devuelve el nombre de la carpeta o null. */
    private fun escribirDiario(linea: String): String? {
        val dir = carpetas(true).firstOrNull() ?: return null
        val f = File(dir, "Amigo - diario.txt")
        if (!puedeEscribir(f)) return null
        return try {
            if (!f.exists()) f.writeText("Diario de tu amigo. Lo escribe él solo, en esta carpeta 🔓.\n\n", Charsets.UTF_8)
            f.appendText(fechaHora() + "  " + linea + "\n", Charsets.UTF_8)
            dir.name
        } catch (e: Exception) {
            null
        }
    }

    /** Reescribe «Amigo - vocabulario.txt» (solo si es suyo: si ya existe con otro contenido, no lo pisa). */
    private fun escribirVocabulario(): Boolean {
        val dir = carpetas().firstOrNull() ?: return false
        val f = File(dir, "Amigo - vocabulario.txt")
        if (!puedeEscribir(f)) return false
        val sb = StringBuilder()
        synchronized(lock) {
            if (vocab.isEmpty()) return false
            sb.append("Vocabulario del amigo\n")
            sb.append("Actualizado: ").append(fechaHora()).append("\n")
            sb.append("Palabras que aprendió de los PDF que le diste: ").append(vocab.size).append("\n\n")
            val top = vocab.entries.sortedByDescending { it.value.n }.take(300)
            for ((w, v) in top) {
                sb.append(w).append(" (").append(v.n).append(")")
                if (v.ej.isNotEmpty()) sb.append(" — «").append(v.ej).append("»")
                sb.append("\n")
            }
        }
        return try {
            if (f.exists()) {
                val primera = f.bufferedReader(Charsets.UTF_8).use { it.readLine() } ?: ""
                if (!primera.startsWith("Vocabulario del amigo")) return false
            }
            f.writeText(sb.toString(), Charsets.UTF_8)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Lo llama el ciclo del amigo: si aprendió algo y hay carpeta 🔓, actualiza su vocabulario solo (como mucho cada 2 min). */
    fun autoSync() {
        if (!loaded) { scope.launch { cargar() }; return }
        if (!dirty) return
        val now = System.currentTimeMillis()
        if (now - lastSync < 120_000L) return
        if (!syncing.compareAndSet(false, true)) return
        scope.launch {
            try {
                lastSync = System.currentTimeMillis()
                if (carpetas().isNotEmpty() && escribirVocabulario()) dirty = false
            } finally {
                syncing.set(false)
            }
        }
    }

    // ───────────── Memoria de palabras ─────────────

    private fun archivoVocab() = File(memoryDir(), "vocabulario.json")

    private fun cargar() {
        synchronized(lock) {
            if (loaded) return
            if (volsProvider().isEmpty()) return          // aún no se leyeron los almacenamientos: se reintenta luego
            loaded = true
            cargarLiteratura()
            cargarBase()
            cargarCerebro()          // al final: suma cada archivo del cerebro encima de la base
            count = vocab.size
            frasesCount = frases.size
        }
    }

    /** Lo que guardaron las versiones 1.33 a 1.35 (vocabulario.json): se sigue usando como la base del cerebro, pero ya no se reescribe. */
    private fun cargarBase() {
        synchronized(lock) {
            val f = archivoVocab()
            if (!f.isFile) return
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                val p = o.optJSONObject("palabras")
                if (p != null) {
                    val ks = p.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val a = p.optJSONArray(k) ?: continue
                        vocab[k] = Voc(a.optInt(0, 1), a.optString(1, ""), a.optInt(2, 1), a.optLong(3, 0L))
                    }
                }
                val l = o.optJSONObject("pdfs")
                if (l != null) {
                    val ks = l.keys()
                    while (ks.hasNext()) { val k = ks.next(); leidos[k] = l.optString(k, k) }
                }
                val r = o.optJSONArray("recientes")
                if (r != null) for (i in 0 until r.length()) recientes.add(r.optString(i))
                count = vocab.size
            } catch (e: Exception) {
                // Archivo dañado: empieza de cero.
            }
        }
    }

    private fun archivoLiteratura() = File(memoryDir(), "literatura.json")

    private fun cargarLiteratura() {
        synchronized(lock) {
            val f = archivoLiteratura()
            if (!f.isFile) return
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                val fr = o.optJSONArray("frases")
                if (fr != null) for (i in 0 until fr.length()) {
                    val a = fr.optJSONArray(i) ?: continue
                    val txt = a.optString(0, "")
                    if (txt.isNotEmpty() && frasesVistas.add(txt)) frases.add(Pair(txt, a.optString(1, "")))
                }
                val sg = o.optJSONObject("siguen")
                if (sg != null) {
                    val ks = sg.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val arr = sg.optJSONArray(k) ?: continue
                        val m = HashMap<String, Int>()
                        for (i in 0 until arr.length()) {
                            val par = arr.optJSONArray(i) ?: continue
                            m[par.optString(0, "")] = par.optInt(1, 1)
                        }
                        siguen[k] = m
                    }
                }
                frasesCount = frases.size
            } catch (e: Exception) {
                // Archivo dañado: la literatura empieza de cero.
            }
        }
    }

    private val rxEspacios = Regex("\\s+")
    private val rxPalabra = Regex("\\p{L}{3,30}")
    private val rxGuion = Regex("-[ \\t]*\\r?\\n[ \\t]*")

    private fun ejemplo(t: String, r: IntRange): String {
        val a = maxOf(0, r.first - 32)
        val b = minOf(t.length, r.last + 33)
        return t.substring(a, b).replace(rxEspacios, " ").trim()
    }

    private fun sinAcentos(s: String): String =
        Normalizer.normalize(s.lowercase(Locale("es")), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    // ───────────── Leer un PDF y aprender sus palabras ─────────────

    /**
     * Lee UN PDF que tú le diste y guarda sus palabras en la memoria. Solo acepta archivos PDF de verdad (extensión y cabecera).
     * Devuelve un mensaje corto para mostrar; el detalle lo dice el amigo en el chat.
     */
    suspend fun aprender(pdf: File): String = withContext(Dispatchers.IO) {
        cargar()
        if (!loaded) return@withContext "Todavía no terminé de leer los almacenamientos. Probá de nuevo en unos segundos."
        if (!pdf.isFile || !pdf.extension.equals("pdf", ignoreCase = true)) return@withContext "Solo leo archivos PDF."
        if (pdf.length() > 40L * 1024 * 1024) return@withContext "Ese PDF pesa más de 40 MB: es demasiado para mí."
        val cabecera = try {
            pdf.inputStream().use { s -> val b = ByteArray(1024); val n = s.read(b); if (n > 0) String(b, 0, n, Charsets.ISO_8859_1) else "" }
        } catch (e: Exception) { "" }
        if (!cabecera.contains("%PDF-")) return@withContext "Ese archivo dice ser PDF pero no lo es."

        val clave = pdf.name + "|" + pdf.length() + "|" + pdf.lastModified()
        synchronized(lock) { if (leidos.containsKey(clave)) return@withContext "Ya leí «${pdf.name}»." }

        val sb = StringBuilder()
        var conClave = false
        var doc: PDDocument? = null
        try {
            if (!pdfboxListo) { PDFBoxResourceLoader.init(ctx); pdfboxListo = true }
            doc = PDDocument.load(pdf)
            if (doc.isEncrypted) {
                conClave = true
            } else {
                val ultima = minOf(doc.numberOfPages, 300)
                val st = PDFTextStripper()
                var p = 1
                while (p <= ultima) {
                    st.startPage = p
                    st.endPage = minOf(p + 19, ultima)
                    sb.append(st.getText(doc)).append('\n')
                    if (sb.length > 3_000_000) break
                    p += 20
                }
            }
        } catch (e: Throwable) {
            return@withContext "No pude leer ese PDF (dañado, con contraseña o demasiado pesado)."
        } finally {
            try { doc?.close() } catch (ignored: Throwable) { }
        }
        if (conClave) return@withContext "Ese PDF tiene contraseña: no lo puedo leer."
        val texto = sb.toString().replace(rxGuion, "")
        if (texto.isBlank()) return@withContext "Ese PDF no tiene texto que pueda leer (¿es un escaneo?)."

        val a = absorber(pdf.name, clave, texto) ?: return@withContext "No encontré palabras que aprender en ese PDF."
        onSay?.invoke(a.dicho)
        "Aprendí ${a.nuevas} palabras nuevas de «${pdf.name}»"
    }

    // ───────────── El cerebro: un archivo por cada PDF que lee, todos sumados en una sola memoria ─────────────
    //
    // Cada PDF nuevo crea su propio archivo pequeño en Documents/Amigo/cerebro/ (000001_nombre.json) con sus palabras, frases y
    // palabras que van juntas. NADA se borra ni se olvida: al abrir la app, el amigo suma todos los archivos (los de antes y los
    // nuevos) en una sola memoria. Se puede crear tantos como se quiera; escribir uno nuevo no toca los anteriores.

    private val rxFrases = Regex("(?<=[.!?…])\\s+")

    /** Lo que quedó guardado de un PDF: números y el texto largo para el chat. */
    private class Aprendido(val nuevas: Int, val frases: Int, val dicho: String)

    private fun dirCerebro() = File(memoryDir(), "cerebro")

    /** Frases enteras y legibles, repartidas a lo largo del PDF (hasta 100 por PDF). Sin tablas ni números sueltos. */
    private fun elegirFrases(texto: String): List<String> {
        val cands = ArrayList<String>()
        for (f in texto.replace(rxEspacios, " ").split(rxFrases)) {
            val s = f.trim()
            if (s.length < 35 || s.length > 220) continue
            if (!(s[0].isLetter() || s[0] in "¿¡«\"")) continue
            if (s.count { it.isLetter() } < s.length * 0.75) continue
            if (s.count { it == ' ' } < 4) continue
            cands.add(s)
        }
        if (cands.size <= 100) return cands
        val paso = cands.size.toDouble() / 100
        return (0 until 100).map { cands[(it * paso).toInt()] }
    }

    /** Se queda con las `n` palabras más frecuentes (en la memoria viva; los archivos del cerebro conservan todo). */
    private fun podar(m: HashMap<String, Int>, n: Int) {
        val tope = m.entries.sortedByDescending { it.value }.take(n).map { Pair(it.key, it.value) }
        m.clear()
        for (par in tope) m[par.first] = par.second
    }

    /**
     * Suma UN archivo del cerebro a la memoria viva. Se usa igual al abrir la app (para cada archivo guardado) que justo después
     * de aprender un PDF: así lo que sabe ahora es exactamente lo mismo que sabrá la próxima vez que abra la app.
     */
    private fun fusionar(o: JSONObject) {
        val pdfs = o.optJSONObject("pdfs")
        if (pdfs != null) {
            val ks = pdfs.keys()
            while (ks.hasNext()) { val k = ks.next(); leidos[k] = pdfs.optString(k, k) }
        }
        val p = o.optJSONObject("palabras")
        if (p != null) {
            val ks = p.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val a = p.optJSONArray(k) ?: continue
                val n = a.optInt(0, 1)
                val ej = a.optString(1, "")
                val v = vocab[k]
                if (v == null) vocab[k] = Voc(n, ej, a.optInt(2, 1), a.optLong(3, 0L))
                else { v.n += n; v.fuentes += a.optInt(2, 1); if (v.ej.isEmpty() && ej.isNotEmpty()) v.ej = ej }
            }
        }
        val fr = o.optJSONArray("frases")
        if (fr != null) for (i in 0 until fr.length()) {
            val a = fr.optJSONArray(i) ?: continue
            val txt = a.optString(0, "")
            if (txt.isNotEmpty() && frasesVistas.add(txt)) frases.add(Pair(txt, a.optString(1, "")))
        }
        val sg = o.optJSONObject("siguen")
        if (sg != null) {
            val ks = sg.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val arr = sg.optJSONArray(k) ?: continue
                val mapa = siguen.getOrPut(k) { HashMap() }
                for (i in 0 until arr.length()) {
                    val par = arr.optJSONArray(i) ?: continue
                    val b = par.optString(0, "")
                    if (b.isNotEmpty()) mapa[b] = (mapa[b] ?: 0) + par.optInt(1, 1)
                }
                if (mapa.size > 20) podar(mapa, 20)
            }
        }
        val nu = o.optJSONArray("nuevas")
        if (nu != null) for (i in nu.length() - 1 downTo 0) {
            val w = nu.optString(i, "")
            if (w.isNotEmpty()) { recientes.remove(w); recientes.add(0, w) }
        }
        while (recientes.size > 30) recientes.removeAt(recientes.size - 1)
    }

    /** Lee todos los archivos del cerebro, en orden, y los suma en una sola memoria. Un archivo dañado se salta y los demás siguen. */
    private fun cargarCerebro() {
        val archivos = dirCerebro().listFiles()?.filter { it.isFile && it.name.endsWith(".json") }?.sortedBy { it.name } ?: return
        for (f in archivos) {
            try {
                fusionar(JSONObject(f.readText(Charsets.UTF_8)))
            } catch (e: Exception) {
                // Archivo dañado: se salta.
            }
        }
    }

    private fun slug(nombre: String): String {
        val base = sinAcentos(nombre.substringBeforeLast('.')).replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40)
        return base.ifEmpty { "pdf" }
    }

    /** Escribe el archivo nuevo del cerebro (y los que quedaran pendientes). Nunca toca los anteriores; si falla, se reintenta luego. */
    private fun guardarCerebro(slug: String, json: String) {
        synchronized(lock) { pendientes.add(Pair(slug, json)) }
        val lista = synchronized(lock) { ArrayList(pendientes) }
        try {
            val d = dirCerebro()
            d.mkdirs()
            for (par in lista) {
                // El número sale de lo que ya hay en la carpeta: un archivo nuevo nunca pisa a uno anterior.
                val max = d.listFiles()?.mapNotNull { it.name.substringBefore('_').toIntOrNull() }?.maxOrNull() ?: 0
                val nombre = String.format(Locale.US, "%06d_%s.json", max + 1, par.first)
                val dest = File(d, nombre)
                val tmp = File(d, "$nombre.tmp")
                tmp.writeText(par.second, Charsets.UTF_8)
                if (!tmp.renameTo(dest)) { dest.writeText(par.second, Charsets.UTF_8); tmp.delete() }
                synchronized(lock) { pendientes.remove(par) }
            }
        } catch (e: Exception) {
            // Sin permiso o sin espacio: se queda pendiente y se intenta con el próximo PDF.
        }
    }

    /**
     * Aprende de un texto y lo guarda en el cerebro: suma sus palabras al vocabulario, guarda frases suyas y anota qué palabras
     * suelen ir juntas. Una sola vez por PDF (la clave es nombre|tamaño|fecha): si ya lo leyó, devuelve null y no cuenta dos veces.
     * También devuelve null si no hay palabras que aprender.
     */
    private fun absorber(nombre: String, clave: String, texto: String): Aprendido? {
        synchronized(lock) { if (leidos.containsKey(clave)) return null }
        val loc = Locale("es")
        val cont = HashMap<String, Int>()
        val ejs = HashMap<String, String>()
        val pares = HashMap<String, Int>()          // «palabra siguiente» -> veces, en este PDF
        var total = 0
        var previa: String? = null
        var finPrevia = -1
        for (m in rxPalabra.findAll(texto)) {
            val w = m.value.lowercase(loc)
            total++
            val vacia = w in STOP
            if (!vacia) {
                val c = cont[w]
                cont[w] = (c ?: 0) + 1
                if (c == null) ejs[w] = ejemplo(texto, m.range)
                val pv = previa
                if (pv != null && m.range.first - finPrevia - 1 in 0..2 && texto.substring(finPrevia + 1, m.range.first).isBlank()) {
                    val k = pv + " " + w
                    if (pares.size < 150_000 || pares.containsKey(k)) pares[k] = (pares[k] ?: 0) + 1
                }
            }
            previa = if (vacia) null else w
            finPrevia = m.range.last
        }
        if (cont.isEmpty()) return null
        val frasesPdf = elegirFrases(texto)

        val nuevas = ArrayList<Pair<String, Int>>()
        var guardadas = 0
        val json: String
        synchronized(lock) {
            val ahora = System.currentTimeMillis()
            for ((w, c) in cont) if (!vocab.containsKey(w)) nuevas.add(Pair(w, c))
            nuevas.sortByDescending { it.second }
            val esNueva = HashSet<String>()
            for (par in nuevas) esNueva.add(par.first)

            // El archivo de este PDF. El ejemplo solo se guarda para las palabras nuevas (así ocupa menos).
            val palabras = JSONObject()
            for ((w, c) in cont) palabras.put(w, JSONArray().put(c).put(if (w in esNueva) (ejs[w] ?: "") else "").put(1).put(ahora))
            val minimo = if (pares.size > 5_000) 2 else 1
            val elegidos = pares.entries.filter { it.value >= minimo }.sortedByDescending { it.value }.take(30_000)
            val porPalabra = HashMap<String, JSONArray>()
            for ((k, c) in elegidos) {
                val i = k.indexOf(' ')
                porPalabra.getOrPut(k.substring(0, i)) { JSONArray() }.put(JSONArray().put(k.substring(i + 1)).put(c))
            }
            val sg = JSONObject()
            for ((a, arr) in porPalabra) sg.put(a, arr)
            val fr = JSONArray()
            for (f in frasesPdf) if (!frasesVistas.contains(f)) { fr.put(JSONArray().put(f).put(nombre)); guardadas++ }
            val rec = JSONArray()
            for (par in nuevas.take(10)) rec.put(par.first)
            val o = JSONObject()
            o.put("version", 1)
            o.put("creado", ahora)
            o.put("pdfs", JSONObject().put(clave, nombre))
            o.put("palabras", palabras)
            o.put("frases", fr)
            o.put("siguen", sg)
            o.put("nuevas", rec)

            fusionar(o)                       // lo suma a la memoria viva, igual que hará al abrir la app
            count = vocab.size
            frasesCount = frases.size
            dirty = true
            json = o.toString()
        }
        guardarCerebro(slug(nombre), json)

        val destacadas = nuevas.take(6).joinToString(", ") { "«" + it.first + "»" }
        val donde = escribirDiario(
            "Leí «$nombre»: ${cont.size} palabras distintas, ${nuevas.size} nuevas para mí, $guardadas frases guardadas." +
                (if (destacadas.isNotEmpty()) " Entre las nuevas: $destacadas." else "")
        )
        if (donde != null && escribirVocabulario()) dirty = false
        val dicho = buildString {
            append("Leí «").append(nombre).append("»: ").append(total).append(" palabras en total, ")
            append(cont.size).append(" distintas y ").append(nuevas.size).append(" nuevas para mí.")
            if (destacadas.isNotEmpty()) append(" Las nuevas que más aparecen: ").append(destacadas).append(".")
            if (guardadas > 0) append(" Guardé ").append(guardadas).append(" frases suyas para aprender cómo se arman.")
            append(" Lo sumé a mi cerebro (Documents/Amigo/cerebro).")
            if (donde != null) append(" Lo anoté en mi diario de «").append(donde).append("».")
            else append(" No escribí ningún archivo en la SD porque no tengo carpeta ${CarpetaLibre.MARCA}.")
        }
        return Aprendido(nuevas.size, guardadas, dicho)
    }

    /** Primera vez que lee esta versión de un PDF 🔓: lo suma al cerebro. Devuelve un aviso corto para añadir a la respuesta ("" si ya lo tenía). */
    private fun alimentarMemoria(pdf: File, t: PdfTexto): String {
        cargar()
        if (!loaded) return ""
        val clave = pdf.name + "|" + pdf.length() + "|" + pdf.lastModified()
        val a = absorber(pdf.name, clave, t.paginas.joinToString("\n")) ?: return ""
        return " Además lo sumé a mi cerebro: ${a.nuevas} palabras nuevas y ${a.frases} frases."
    }

    // ───────────── Leer PDF a demanda: solo los que están dentro de una carpeta 🔓 ─────────────

    private val SIN_CARPETAS_LEER =
        "No tengo ninguna carpeta con ${CarpetaLibre.MARCA} en la tarjeta SD. Ponele ${CarpetaLibre.MARCA} pegado al nombre " +
            "(por ejemplo ${CarpetaLibre.MARCA}carpeta), metí ahí tus PDF y los leo todas las veces que quieras."

    private val SIN_PDFS =
        "No hay ningún PDF dentro de mis carpetas ${CarpetaLibre.MARCA}. Poné uno ahí (o en una subcarpeta) y lo leo todas las veces que quieras."

    private val YA_NO_ESTA =
        "Ese PDF ya no está dentro de una carpeta ${CarpetaLibre.MARCA}, así que no lo puedo leer."

    private val lockPdf = Any()
    private var cachePdf: PdfTexto? = null

    private fun normNombre(s: String): String =
        sinAcentos(s.trim()).trim('"', '«', '»', '\'', '.', ',', '?', '!', '¿', '¡', ' ').removeSuffix(".pdf").trim()

    private fun plural(n: Int, uno: String, varios: String) = if (n == 1) uno else varios

    /**
     * Los PDF que hay AHORA en carpetas 🔓 de la SD (y sus subcarpetas, hasta 6 niveles). Se mira el disco cada vez y cada archivo
     * pasa por [puedeLeer]: si lo sacas de ahí, o le quitas el 🔓 a la carpeta, deja de aparecer.
     */
    fun pdfsLibres(): List<File> {
        val out = ArrayList<File>()
        for (c in carpetas(true)) {
            val hallados = c.walkTopDown().maxDepth(6)
                .onEnter { !it.name.startsWith(".") }
                .filter { it.isFile && it.extension.equals("pdf", ignoreCase = true) && puedeLeer(it) }
                .take(500)
                .toList()
            out.addAll(hallados)
        }
        return out.distinctBy { canon(it).path }.sortedBy { it.name.lowercase(Locale("es")) }
    }

    /** Lista corta de lo que puede leer (para el chat). */
    fun pdfsTexto(): String {
        if (carpetas(true).isEmpty()) return SIN_CARPETAS_LEER
        val l = pdfsLibres()
        if (l.isEmpty()) return SIN_PDFS
        val nombres = l.take(15).joinToString(", ") { "«" + it.name + "»" }
        return "Puedo leer " + l.size + " PDF de mis carpetas ${CarpetaLibre.MARCA}: " + nombres +
            (if (l.size > 15) " y más" else "") + ". Los leo todas las veces que quieras mientras sigan ahí."
    }

    /** Busca un PDF 🔓 por nombre (con o sin «.pdf», sin importar mayúsculas ni acentos; vale un trozo del nombre). */
    fun pdfPorNombre(raw: String): BusquedaPdf {
        val q = normNombre(raw)
        if (q.isEmpty()) return BusquedaPdf(null, null, false)
        if (carpetas(true).isEmpty()) return BusquedaPdf(null, SIN_CARPETAS_LEER, false)
        val todos = pdfsLibres()
        if (todos.isEmpty()) return BusquedaPdf(null, SIN_PDFS, false)
        val exactos = todos.filter { normNombre(it.name) == q }
        // Un trozo del nombre sirve solo si tiene al menos 3 letras: así «lee el» no elige un PDF cualquiera.
        val cand = when {
            exactos.isNotEmpty() -> exactos
            q.length >= 3 -> todos.filter { normNombre(it.name).contains(q) }
            else -> emptyList()
        }
        return when {
            cand.size == 1 -> BusquedaPdf(cand[0], null, true)
            cand.isEmpty() -> BusquedaPdf(
                null,
                "No encuentro «${raw.trim()}» entre los PDF de mis carpetas ${CarpetaLibre.MARCA}. Si lo sacaste de ahí, ya no lo puedo leer.",
                false
            )
            else -> BusquedaPdf(
                null,
                "¿Cuál? Tengo: " + cand.take(6).joinToString(", ") { "«" + it.name + "» (en «" + (it.parentFile?.name ?: "") + "»)" } + ".",
                true
            )
        }
    }

    /** Texto de un PDF 🔓 por páginas (hasta 300). Recuerda el último para no volver a procesarlo en cada pregunta. */
    private fun textoPaginas(pdf: File): Pair<PdfTexto?, String?> = synchronized(lockPdf) { cargarTextoPaginas(pdf) }

    private fun cargarTextoPaginas(pdf: File): Pair<PdfTexto?, String?> {
        // El permiso se comprueba en cada lectura, también si el texto estaba guardado en la caché.
        if (!puedeLeer(pdf)) { cachePdf = null; return Pair(null, YA_NO_ESTA) }
        if (pdf.length() > 40L * 1024 * 1024) return Pair(null, "Ese PDF pesa más de 40 MB: es demasiado para mí.")
        val clave = canon(pdf).path + "|" + pdf.length() + "|" + pdf.lastModified()
        val previo = cachePdf
        if (previo != null && previo.clave == clave) return Pair(previo, null)

        val cabecera = try {
            pdf.inputStream().use { s -> val b = ByteArray(1024); val n = s.read(b); if (n > 0) String(b, 0, n, Charsets.ISO_8859_1) else "" }
        } catch (e: Exception) { "" }
        if (!cabecera.contains("%PDF-")) return Pair(null, "Ese archivo dice ser PDF pero no lo es.")

        val paginas = ArrayList<String>()
        var numPaginas = 0
        var doc: PDDocument? = null
        try {
            if (!pdfboxListo) { PDFBoxResourceLoader.init(ctx); pdfboxListo = true }
            doc = PDDocument.load(pdf)
            if (doc.isEncrypted) return Pair(null, "Ese PDF tiene contraseña: no lo puedo leer.")
            numPaginas = doc.numberOfPages
            val ultima = minOf(numPaginas, 300)
            val st = PDFTextStripper()
            var total = 0
            for (p in 1..ultima) {
                st.startPage = p
                st.endPage = p
                val tx = st.getText(doc).replace(rxGuion, "")
                paginas.add(tx)
                total += tx.length
                if (total > 3_000_000) break
            }
        } catch (e: Throwable) {
            return Pair(null, "No pude leer ese PDF (dañado, con contraseña o demasiado pesado).")
        } finally {
            try { doc?.close() } catch (ignored: Throwable) { }
        }
        if (paginas.all { it.isBlank() }) return Pair(null, "Ese PDF no tiene texto que pueda leer (¿es un escaneo?).")
        val r = PdfTexto(clave, paginas, numPaginas)
        cachePdf = r
        return Pair(r, null)
    }

    /** «Lee <pdf>»: cuántas páginas tiene y cómo empieza. Se puede pedir las veces que quieras. */
    fun leerPdf(pdf: File): String {
        val (t, err) = textoPaginas(pdf)
        if (t == null) return err ?: "No pude leer ese PDF."
        val inicio = (t.paginas.firstOrNull { it.isNotBlank() } ?: "").replace(rxEspacios, " ").trim()
        val corto = if (inicio.length > 600) inicio.substring(0, 600).trimEnd() + "…" else inicio
        val nombre = pdf.name.removeSuffix(".pdf").removeSuffix(".PDF")
        val extra = alimentarMemoria(pdf, t)
        return "«${pdf.name}» tiene ${t.totalPaginas} ${plural(t.totalPaginas, "página", "páginas")}" +
            (if (t.paginas.size < t.totalPaginas) " (leo las primeras ${t.paginas.size})" else "") +
            ". Empieza así: «$corto». Pedime «lee página 2 de $nombre» o «busca una palabra en $nombre»." + extra
    }

    /** «Lee página N de <pdf>». */
    fun leerPagina(pdf: File, n: Int): String {
        val (t, err) = textoPaginas(pdf)
        if (t == null) return err ?: "No pude leer ese PDF."
        if (n < 1 || n > t.totalPaginas) return "«${pdf.name}» tiene ${t.totalPaginas} ${plural(t.totalPaginas, "página", "páginas")}: la $n no existe."
        if (n > t.paginas.size) return "Solo leo las primeras ${t.paginas.size} páginas de un PDF."
        val tx = t.paginas[n - 1].replace(rxEspacios, " ").trim()
        if (tx.isEmpty()) return "La página $n de «${pdf.name}» no tiene texto que pueda leer."
        val corto = if (tx.length > 1500) tx.substring(0, 1500).trimEnd() + "…" else tx
        return "Página $n de «${pdf.name}»: $corto" + alimentarMemoria(pdf, t)
    }

    /** «Busca <texto> en <pdf>»: cuántas veces aparece, en qué páginas y unas frases de ejemplo. */
    fun buscarEnPdf(pdf: File, consulta: String): String {
        val (t, err) = textoPaginas(pdf)
        if (t == null) return err ?: "No pude leer ese PDF."
        val orig = consulta.trim().trim('"', '«', '»', '?', '¿', '.', '!').trim()
        val q = sinAcentos(orig).replace(rxEspacios, " ")
        if (q.length < 2) return "¿Qué palabra o frase busco en «${pdf.name}»?"
        var veces = 0
        var paginasCon = 0
        val ejs = ArrayList<String>()
        for ((i, pg) in t.paginas.withIndex()) {
            // Cada espacio en blanco (salto de línea, tabulador…) pasa a ser un espacio, sin cambiar el largo del texto.
            val pgc = String(CharArray(pg.length) { if (pg[it].isWhitespace()) ' ' else pg[it] })
            val ps = sinAcentos(pgc)
            var pos = ps.indexOf(q)
            if (pos < 0) continue
            paginasCon++
            var primera = true
            while (pos >= 0) {
                veces++
                if (primera && ejs.size < 5) {
                    val base = if (ps.length == pgc.length) pgc else ps
                    ejs.add("p. ${i + 1}: «" + ejemplo(base, pos..(pos + q.length - 1)) + "»")
                }
                primera = false
                pos = ps.indexOf(q, pos + q.length)
            }
        }
        val nota = if (t.paginas.size < t.totalPaginas) " (solo miré las primeras ${t.paginas.size} páginas)" else ""
        val extra = alimentarMemoria(pdf, t)
        if (veces == 0) return "No encontré «$orig» en «${pdf.name}»$nota." + extra
        return "Encontré «$orig» $veces ${plural(veces, "vez", "veces")} en $paginasCon ${plural(paginasCon, "página", "páginas")} de «${pdf.name}»$nota. " +
            ejs.joinToString(" · ") + extra
    }

    // ───────────── Consultas del chat ─────────────

    fun resumenTexto(): String = synchronized(lock) {
        cargar()
        if (vocab.isEmpty()) {
            "Todavía no aprendí palabras. Abrí el menú ⋮ de un PDF y tocá «Enseñar al amigo»."
        } else {
            val rec = recientes.take(8).joinToString(", ") { "«$it»" }
            "En mi cerebro tengo ${vocab.size} palabras y ${frases.size} frases de ${leidos.size} PDF." + (if (rec.isNotEmpty()) " Las últimas que aprendí: $rec." else "") +
                " No entiendo su significado como una persona: sé cuántas veces las vi y en qué frase."
        }
    }

    /** Las palabras que más suelen ir justo después de esta (las 3 primeras). */
    private fun suele(w: String): List<String> =
        siguen[w]?.entries?.sortedByDescending { it.value }?.take(3)?.map { it.key } ?: emptyList()

    /** Una frase guardada que contenga esta palabra (o null). */
    fun fraseCon(palabra: String): String? {
        cargar()
        val q = sinAcentos(palabra.trim())
        if (q.length < 3) return null
        synchronized(lock) {
            val par = frases.filter { sinAcentos(it.first).contains(q) }.randomOrNull() ?: return null
            return par.first
        }
    }

    /** Una frase al azar de lo que ha leído, con el PDF del que salió. */
    fun fraseAlAzar(): String? {
        cargar()
        synchronized(lock) {
            val par = frases.randomOrNull() ?: return null
            return "«" + par.first + "» (de «" + par.second + "»)"
        }
    }

    fun buscar(raw: String): PalabraSabida? {
        cargar()
        val q = raw.trim().trim('"', '«', '»', '?', '¿', '.', '!').lowercase(Locale("es"))
        if (q.isEmpty()) return null
        synchronized(lock) {
            vocab[q]?.let { return PalabraSabida(q, it.n, it.fuentes, it.ej, suele(q)) }
            val qs = sinAcentos(q)
            for ((k, v) in vocab) if (sinAcentos(k) == qs) return PalabraSabida(k, v.n, v.fuentes, v.ej, suele(k))
        }
        return null
    }

    // ───────────── Descansar: paseos por las carpetas 🔓 ─────────────

    /** Lo que vio el amigo en un paseo por una carpeta 🔓. */
    class Paseo(val carpeta: String, val subcarpetas: Int, val archivos: Int, val pdfLeido: String?, val palabrasNuevas: Int)

    private var paseoIdx = 0
    private val sinTexto = HashSet<String>()          // PDF que no dieron texto (escaneos, con clave…): no se reintentan

    /**
     * Un paso del «descansar»: entra a la siguiente carpeta 🔓 de la SD (una por una, dando la vuelta), mira qué hay y, si encuentra
     * un PDF que todavía no leyó, lo lee y lo suma a su cerebro. Solo lee dentro de carpetas 🔓 y solo escribe su diario ahí:
     * las mismas reglas de siempre. Null si no hay carpetas 🔓 o aún no cargó su memoria.
     */
    fun pasear(): Paseo? {
        cargar()
        if (!loaded) return null
        val libres = carpetas(true)
        if (libres.isEmpty()) return null
        val dir = libres[paseoIdx++ % libres.size]
        if (!dir.isDirectory) return null
        val hijos = dir.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
        var leido: String? = null
        var nuevas = 0
        val pend = pdfsLibres().firstOrNull { f ->
            val k = f.name + "|" + f.length() + "|" + f.lastModified()
            k !in sinTexto && synchronized(lock) { !leidos.containsKey(k) }
        }
        if (pend != null) {
            val k = pend.name + "|" + pend.length() + "|" + pend.lastModified()
            val (t, _) = textoPaginas(pend)
            if (t == null) sinTexto.add(k)
            else {
                val a = absorber(pend.name, k, t.paginas.joinToString("\n"))
                if (a == null) sinTexto.add(k) else { leido = pend.name; nuevas = a.nuevas }
            }
        }
        return Paseo(dir.name, hijos.count { it.isDirectory }, hijos.count { it.isFile }, leido, nuevas)
    }

    /** Anota una línea en su diario (carpeta 🔓). Devuelve el nombre de la carpeta o null. */
    fun diario(linea: String): String? = escribirDiario(linea)

    /** ¿Ya conoce esta palabra por los PDF? (lo usa el lector de pantalla para no llamar «nueva» a lo que ya sabe). */
    fun sabe(w: String): Boolean = synchronized(lock) { vocab.containsKey(w) }

    /** Una palabra al azar de las recientes, para comentarla por iniciativa propia. */
    fun palabraReciente(): PalabraSabida? {
        synchronized(lock) {
            val w = recientes.randomOrNull() ?: return null
            val v = vocab[w] ?: return null
            return PalabraSabida(w, v.n, v.fuentes, v.ej)
        }
    }
}
