package com.archivero

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────── Memoria: lo que el amigo aprende, en texto, en Documents de la SD ─────────────

/**
 * Guarda en Documents/Amigo (de la tarjeta SD si hay; si no, del almacenamiento interno) dos archivos:
 *  - memoria.txt: resumen legible de lo que ha aprendido (carpetas, tipos de archivo y fichas que más usas, hora más activa).
 *  - memoria.json: los contadores, para seguir aprendiendo la próxima vez.
 * Solo se cuenta qué carpetas/tipos se abren; nunca el contenido de los archivos.
 */
class FriendMemory(context: Context, private val volsProvider: () -> List<Vol>) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private val folders = HashMap<String, Int>()
    private val kinds = HashMap<String, Int>()
    private val tabs = HashMap<String, Int>()
    private val hours = IntArray(24)
    private var opens = 0
    private var loaded = false
    private var flushJob: Job? = null

    /** La memoria está siempre encendida (ya no se puede apagar). */
    val enabled: Boolean get() = true

    /** Cuántas cosas ha visto en total (para mostrarlo en Ajustes). */
    var count by mutableIntStateOf(0)
        private set

    init {
        scope.launch { load(); count = opens }
    }

    /** Carpeta donde se guarda la memoria. */
    fun memoryDir(): File {
        val internal = Environment.getExternalStorageDirectory().absolutePath
        val sd = volsProvider().firstOrNull { it.dir.absolutePath != internal }
        val base = sd?.dir ?: Environment.getExternalStorageDirectory()
        return File(base, "Documents/Amigo")
    }

    /** Texto para mostrar dónde se guarda. */
    fun whereText(): String {
        val internal = Environment.getExternalStorageDirectory().absolutePath
        val hasSd = volsProvider().any { it.dir.absolutePath != internal }
        return (if (hasSd) "Tarjeta SD" else "Almacenamiento") + " · Documents/Amigo"
    }

    private fun hourNow(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun bump(m: HashMap<String, Int>, key: String) {
        synchronized(lock) {
            m[key] = (m[key] ?: 0) + 1
            opens++
            hours[hourNow()]++
            count = opens
        }
        schedule()
    }

    /** Nombre de la carpeta que más se abre (null si aún no hay datos o la memoria está apagada). */
    fun topFolderName(): String? = synchronized(lock) { folders.maxByOrNull { it.value }?.key }?.let { File(it).name }

    /** Tipo de archivo que más se abre. */
    fun topKindLabel(): String? = synchronized(lock) { kinds.maxByOrNull { it.value }?.key }

    /** Ficha de Inicio que más se usa. */
    fun topTabLabel(): String? = synchronized(lock) { tabs.maxByOrNull { it.value }?.key }

    /** Se entró a una carpeta. */
    fun visitFolder(dir: File) {
        bump(folders, dir.path)
    }

    /** Se abrió un archivo de este tipo. */
    fun openFile(kind: Kind) {
        bump(kinds, kind.label)
    }

    /** Se entró a una ficha de Inicio. */
    fun visitTab(tab: HomeTab) {
        bump(tabs, tab.label)
    }

    private fun schedule() {
        if (flushJob?.isActive == true) return
        flushJob = scope.launch {
            delay(10_000L)
            flush()
        }
    }

    /** Guarda ya (por ejemplo al salir de la app). */
    fun flushNow() {
        scope.launch { flush() }
    }

    private fun merge(into: HashMap<String, Int>, o: JSONObject?) {
        if (o == null) return
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            into[k] = (into[k] ?: 0) + o.optInt(k, 0)
        }
    }

    private fun load() {
        synchronized(lock) {
            if (loaded) return
            // Si aún no se leyeron los almacenamientos (o no hay permiso), se reintenta después: así nunca se pisa lo guardado.
            if (volsProvider().isEmpty()) return
            loaded = true
            val f = File(memoryDir(), "memoria.json")
            if (!f.isFile) return
            try {
                val o = JSONObject(f.readText())
                opens += o.optInt("opens", 0)
                merge(folders, o.optJSONObject("folders"))
                merge(kinds, o.optJSONObject("kinds"))
                merge(tabs, o.optJSONObject("tabs"))
                val h = o.optJSONArray("hours")
                if (h != null) {
                    for (i in 0 until minOf(24, h.length())) hours[i] += h.optInt(i, 0)
                }
            } catch (e: Exception) {
                // Archivo dañado: se empieza de cero.
            }
        }
    }

    private fun top(m: Map<String, Int>, n: Int): List<Pair<String, Int>> =
        m.entries.sortedByDescending { it.value }.take(n).map { Pair(it.key, it.value) }

    private fun flush() {
        load()
        if (!loaded) return
        count = synchronized(lock) { opens }
        val json: String
        val text: String
        synchronized(lock) {
            val o = JSONObject()
            o.put("opens", opens)
            o.put("folders", JSONObject(HashMap(folders) as Map<*, *>))
            o.put("kinds", JSONObject(HashMap(kinds) as Map<*, *>))
            o.put("tabs", JSONObject(HashMap(tabs) as Map<*, *>))
            val h = JSONArray()
            for (x in hours) h.put(x)
            o.put("hours", h)
            json = o.toString()

            val sb = StringBuilder()
            sb.append("MEMORIA DE TU AMIGO\n")
            sb.append("Actualizada: ").append(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es")).format(Date())).append("\n")
            sb.append("Esto es lo que voy aprendiendo de cómo usas Archivero. Solo guardo qué abres. Del contenido, únicamente lo de los PDF que leo (sus palabras y frases van a la carpeta cerebro, un archivo por PDF, y nada se olvida).\n\n")
            sb.append("Cosas que he visto en total: ").append(opens).append("\n\n")
            sb.append("Carpetas que más visitas:\n")
            val tf = top(folders, 8)
            if (tf.isEmpty()) sb.append("  (todavía nada)\n")
            for ((i, p) in tf.withIndex()) sb.append("  ").append(i + 1).append(". ").append(p.first).append("  (").append(p.second).append(" veces)\n")
            sb.append("\nTipos de archivo que más abres:\n")
            val tk = top(kinds, 6)
            if (tk.isEmpty()) sb.append("  (todavía nada)\n")
            for (p in tk) sb.append("  - ").append(p.first).append(": ").append(p.second).append("\n")
            sb.append("\nFichas de Inicio que más usas:\n")
            val tt = top(tabs, 5)
            if (tt.isEmpty()) sb.append("  (todavía nada)\n")
            for (p in tt) sb.append("  - ").append(p.first).append(": ").append(p.second).append("\n")
            val bestHour = hours.indices.maxByOrNull { hours[it] }
            if (bestHour != null && hours[bestHour] > 0) {
                sb.append("\nLa hora en la que más usas el explorador: ").append(bestHour).append(" h\n")
            }
            text = sb.toString()
        }
        try {
            val d = memoryDir()
            d.mkdirs()
            File(d, "memoria.json").writeText(json)
            File(d, "memoria.txt").writeText(text)
        } catch (e: Exception) {
            // Sin permiso o sin espacio: se intenta de nuevo en el próximo guardado.
        }
    }
}

// ───────────── Íconos de Ajustes (línea fina) ─────────────

/** Esfera con un puntito rosa (ícono de "seguirte"). */
@Composable
fun BubbleIcon(w: Dp = 38.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        drawCircle(color.copy(alpha = 0.92f), s * 0.34f, Offset(s * 0.5f, s * 0.5f), style = Stroke(1.6.dp.toPx()))
        drawCircle(Pal.Accent, s * 0.06f, Offset(s * 0.62f, s * 0.6f))
    }
}

/** Chip de memoria: cuerpo con esquinas cortadas, patitas y un núcleo rosa. */
@Composable
fun ChipIcon(w: Dp = 38.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = color.copy(alpha = 0.92f)
        val body = Path().apply {
            moveTo(s * 0.3f, s * 0.22f); lineTo(s * 0.7f, s * 0.22f); lineTo(s * 0.78f, s * 0.3f)
            lineTo(s * 0.78f, s * 0.7f); lineTo(s * 0.7f, s * 0.78f); lineTo(s * 0.3f, s * 0.78f)
            lineTo(s * 0.22f, s * 0.7f); lineTo(s * 0.22f, s * 0.3f); close()
        }
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        drawRect(Pal.Accent, Offset(s * 0.4f, s * 0.4f), Size(s * 0.2f, s * 0.2f), style = Stroke(sw))
        for (i in 0..2) {
            val p = s * (0.36f + 0.14f * i)
            drawLine(line, Offset(p, s * 0.08f), Offset(p, s * 0.22f), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(line, Offset(p, s * 0.78f), Offset(p, s * 0.92f), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(line, Offset(s * 0.08f, p), Offset(s * 0.22f, p), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(line, Offset(s * 0.78f, p), Offset(s * 0.92f, p), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Lupa con un puntito rosa (ícono de "aprender de la pantalla"). */
@Composable
fun LupaIcon(w: Dp = 38.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.6.dp.toPx()
        val line = color.copy(alpha = 0.92f)
        drawCircle(line, s * 0.26f, Offset(s * 0.44f, s * 0.44f), style = Stroke(sw))
        drawLine(line, Offset(s * 0.63f, s * 0.63f), Offset(s * 0.82f, s * 0.82f), strokeWidth = sw, cap = StrokeCap.Round)
        drawCircle(Pal.Accent, s * 0.06f, Offset(s * 0.44f, s * 0.44f))
    }
}

/** Marco de escaneo con una línea rosa (ícono de «Leer imágenes y juegos», el OCR). */
@Composable
fun OcrIcon(w: Dp = 38.dp, color: Color = Pal.White) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.6.dp.toPx()
        val line = color.copy(alpha = 0.92f)
        val a = s * 0.16f                 // borde de arriba/izquierda
        val b = s * 0.84f                 // borde de abajo/derecha
        val l = s * 0.24f                 // largo de cada esquina
        drawLine(line, Offset(a, a), Offset(a + l, a), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(a, a), Offset(a, a + l), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(b, a), Offset(b - l, a), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(b, a), Offset(b, a + l), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(a, b), Offset(a + l, b), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(a, b), Offset(a, b - l), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(b, b), Offset(b - l, b), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(b, b), Offset(b, b - l), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(Pal.Accent, Offset(a + l * 0.5f, s * 0.5f), Offset(b - l * 0.5f, s * 0.5f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

// ───────────── Pantalla de Ajustes del amigo ─────────────

/** Casilla de Ajustes: ícono, título, estado y (opcional) una acción pequeña debajo. */
@Composable
private fun SettingTile(
    modifier: Modifier,
    title: String,
    status: String,
    on: Boolean,
    locked: Boolean,
    icon: @Composable () -> Unit,
    action: String? = null,
    onAction: () -> Unit = {},
    onClick: (() -> Unit)? = null
) {
    val shape = ChamferShape(12.dp)
    Column(
        modifier
            .height(148.dp)
            .clip(shape)
            .background(if (on) Pal.Sel else Pal.Card)
            .border(1.dp, if (on) Pal.Accent else Pal.Line, shape)
            .then(if (locked || onClick == null) Modifier else Modifier.clickable(onClick = onClick))
            .padding(12.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
    ) {
        Box(Modifier.alpha(if (locked) 0.45f else 1f)) { icon() }
        Column {
            Text(title, color = if (locked) Pal.Muted else Pal.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(status, color = if (on) Pal.White else Pal.Muted, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2)
            if (action != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    action, color = Pal.Pink, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(onClick = onAction)
                )
            }
        }
    }
}

/** El "papel grande" de Ajustes: por ahora solo informa de la Memoria, que siempre está activa. */
@Composable
fun AjustesSheet(store: Store, onClose: () -> Unit) {
    val mem = store.memory
    val ctx = LocalContext.current
    var canDraw by remember { mutableStateOf(FriendLink.canDraw(ctx)) }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        canDraw = FriendLink.canDraw(ctx)
        FriendLink.sync(ctx)          // si ya estaba suelto, empieza a seguirte
    }
    // Aprender de la pantalla: interruptor propio (PalabrasPantalla.activo) + servicio encendido en Accesibilidad.
    var servicioOn by remember { mutableStateOf(PalabrasPantalla.servicioEnSistema(ctx)) }
    var capturaOk by remember { mutableStateOf(PalabrasPantalla.capturaPermitida(ctx)) }
    val accesibilidadLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        servicioOn = PalabrasPantalla.servicioEnSistema(ctx)
        capturaOk = PalabrasPantalla.capturaPermitida(ctx)
    }
    fun abrirAccesibilidad() {
        try {
            accesibilidadLauncher.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast(ctx, "Buscá «Archivero: aprender de la pantalla» y activalo")
        } catch (e: Exception) {
            toast(ctx, "No se pudo abrir Accesibilidad")
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.74f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
    ) {
        val shape = ChamferShape(18.dp)
        Column(
            Modifier
                .align(Alignment.Center)
                .padding(16.dp)
                .fillMaxWidth()
                .vidrio3D(shape, 18.dp)
                .clip(shape)
                .pointerInput(Unit) { detectTapGestures { } }       // tocar dentro no cierra
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AJUSTES", color = Pal.Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(2.dp))
                    Text("Tu amigo", color = Pal.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                }
                Text(
                    "Cerrar", color = Pal.Muted, fontSize = 13.sp,
                    modifier = Modifier.clickable(onClick = onClose).padding(8.dp)
                )
            }
            Spacer(Modifier.height(14.dp))

            SettingTile(
                Modifier.fillMaxWidth(), "Memoria",
                "Siempre activa · " + mem.whereText() + " · " + mem.count + " recuerdos",
                on = true, locked = false,
                icon = { ChipIcon() }
            )
            Spacer(Modifier.height(10.dp))
            SettingTile(
                Modifier.fillMaxWidth(), "Aprender y escribir",
                store.saber.count.toString() + " palabras y " + store.saber.frasesCount + " frases aprendidas · lee y escribe solo en carpetas con " + CarpetaLibre.MARCA + " (SD)",
                on = store.saber.count > 0, locked = false,
                icon = { ChipIcon() }
            )
            Spacer(Modifier.height(10.dp))
            SettingTile(
                Modifier.fillMaxWidth(), "Seguirte fuera de la app",
                if (canDraw) "Activo · si lo sacas y sales de la app, te sigue" else "Falta el permiso · toca para darlo",
                on = canDraw, locked = false,
                icon = { BubbleIcon() },
                onClick = if (canDraw) null else ({
                    try {
                        overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                    } catch (e: Exception) {
                        toast(ctx, "No se pudo abrir el permiso")
                    }
                })
            )
            Spacer(Modifier.height(10.dp))
            val pOn = PalabrasPantalla.activo
            SettingTile(
                Modifier.fillMaxWidth(), "Aprender de la pantalla",
                when {
                    !pOn -> "Apagado · toca para encenderlo. Lee el texto que ves para aprender palabras nuevas"
                    !servicioOn -> "Falta activar el servicio en Accesibilidad · toca para abrirla"
                    PalabrasPantalla.descansando -> "El amigo está descansando · no leo nada · toca para llamarlo"
                    PalabrasPantalla.noLectura -> "En «No lectura» (casilla del amigo) · no leo nada"
                    else -> "Activo · " + PalabrasPantalla.total + " palabras · toca para apagarlo"
                },
                on = servicioOn && PalabrasPantalla.puedeLeer, locked = false,
                icon = { LupaIcon() },
                onClick = {
                    if (!pOn) {
                        PalabrasPantalla.setActivo(ctx, true)
                        servicioOn = PalabrasPantalla.servicioEnSistema(ctx)
                        if (!servicioOn) abrirAccesibilidad()
                    } else if (!servicioOn) abrirAccesibilidad()
                    else if (PalabrasPantalla.descansando) PalabrasPantalla.setDescansando(ctx, false)     // llamarlo desde la app
                    else PalabrasPantalla.setActivo(ctx, false)
                }
            )
            Spacer(Modifier.height(10.dp))
            // OCR: interruptor APARTE y apagado por defecto. Solo funciona si «Aprender de la pantalla» también está encendido.
            val oOn = PalabrasPantalla.ocrActivo
            val faltaServicio = oOn && pOn && (!servicioOn || !capturaOk)
            SettingTile(
                Modifier.fillMaxWidth(), "Leer imágenes y juegos (OCR)",
                when {
                    !oOn -> "Apagado · toca para encenderlo. Para juegos e imágenes sin texto accesible"
                    !pOn -> "Encendido, pero necesita «Aprender de la pantalla» activo · toca para apagarlo"
                    !servicioOn -> "Falta activar el servicio en Accesibilidad"
                    !capturaOk -> "Falta el permiso de capturas: reactiva el servicio en Accesibilidad"
                    PalabrasPantalla.descansando -> "El amigo está descansando · no leo nada"
                    PalabrasPantalla.noLectura -> "En «No lectura» · no leo nada"
                    else -> "Activo · solo como respaldo · 1 captura cada 10 s como mucho · toca para apagarlo"
                },
                on = oOn && servicioOn && capturaOk && PalabrasPantalla.puedeOcr, locked = false,
                icon = { OcrIcon() },
                action = if (faltaServicio) "Abrir Accesibilidad" else null,
                onAction = { abrirAccesibilidad() },
                onClick = {
                    if (!oOn) {
                        PalabrasPantalla.setOcrActivo(ctx, true)
                        capturaOk = PalabrasPantalla.capturaPermitida(ctx)
                        if (!pOn) toast(ctx, "El OCR solo funciona con «Aprender de la pantalla» encendido")
                    } else PalabrasPantalla.setOcrActivo(ctx, false)
                }
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Ojo con el OCR: si una app no muestra su texto (juegos, imágenes, algunos vídeos), el amigo captura la pantalla ENTERA " +
                    "y la lee con reconocimiento de texto dentro del teléfono, sin internet. La captura nunca se guarda: se usa en el momento " +
                    "y se descarta. Solo entra cuando la lectura normal no encuentra texto, como mucho una vez cada 10 segundos y nunca con la " +
                    "pantalla apagada. Se tapan el teclado, tus campos de texto y de contraseña, los avisos y las otras ventanas, y no se usa en " +
                    "apps de bancos, billeteras o contraseñas. Gasta más batería. Para esto el servicio de Accesibilidad pide también el permiso " +
                    "de «hacer capturas de pantalla».",
                color = Pal.Muted, fontSize = 11.sp, lineHeight = 15.sp
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "El amigo limpia los residuos de la app cuando lo tocas. La memoria anota qué carpetas y tipos de archivo abres, y guarda tus charlas con él en conversaciones.txt. De los PDF que lee (los que le das y los de carpetas ${CarpetaLibre.MARCA}) suma palabras y frases a su cerebro (nada se olvida); del resto de tus archivos nunca guarda el contenido. Con «Aprender de la pantalla» encendido lee el texto visible (nunca contraseñas, lo que escribes tú, bancos ni la propia app) y guarda solo palabras nuevas con un trozo de contexto en Documents/Amigo/pantalla. El OCR (capturas de pantalla) es un interruptor aparte y viene apagado.",
                color = Pal.Muted, fontSize = 11.sp, lineHeight = 15.sp
            )
        }
    }
}
