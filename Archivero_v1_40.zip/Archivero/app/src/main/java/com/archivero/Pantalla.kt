package com.archivero

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

// ───────────── El amigo aprende de lo que ves en la pantalla ─────────────
//
// Dos piezas:
//  1) LeerPantallaService: servicio de accesibilidad de Android. SOLO lee cuando el interruptor «Aprender de la pantalla»
//     (Ajustes del amigo) está encendido Y el usuario activó el servicio en Ajustes del sistema > Accesibilidad.
//  2) PalabrasPantalla: de ese texto saca las palabras que el amigo todavía no conoce (jerga, términos técnicos, formas nuevas
//     de escribir, hashtags, abreviaturas) y las guarda en Documents/Amigo/pantalla/ con: la palabra, una frase de contexto,
//     cuántas veces apareció, cuándo la vio por primera y última vez y en qué app.
//
// Qué NUNCA lee ni guarda: campos de contraseña, lo que TÚ escribes (campos editables), la propia app, el teclado, la barra
// de estado/notificaciones, apps de bancos/billeteras/contraseñas (lista aproximada), direcciones web, correos, @usuarios ni
// números largos (teléfonos, tarjetas, códigos). No guarda capturas de pantalla ni el texto completo: solo palabras sueltas
// y un trozo corto alrededor de cada una.
//
// OCR de respaldo (1.39, interruptor aparte y apagado por defecto): para apps que no exponen su texto (juegos, imágenes, algunos
// vídeos), cuando la lectura normal da poco o nada, el servicio hace una captura de pantalla EN MEMORIA, tapa lo privado,
// reconoce el texto con ML Kit (modelo local, sin internet), lo pasa por la misma limpieza y descarta la imagen. Nunca se guarda.

/** Una palabra (o expresión) que el amigo vio en la pantalla. */
class PalabraVista(
    val palabra: String,
    val veces: Int,
    val app: String,
    val contexto: String,
    val primera: Long,
    val ultima: Long,
    val tipo: String,
    val esExpresion: Boolean = false
) {
    /** «hashtag», «jerga alargada»… en palabras para el chat. */
    fun etiqueta(): String = PalabrasPantalla.etiqueta(tipo)
    fun cuandoPrimera(): String = PalabrasPantalla.fecha(primera)
}

object PalabrasPantalla {
    private class Cot(var veces: Int, var contexto: String, var app: String, val primera: Long, var ultima: Long, val tipo: String)

    private const val MAX_PALABRAS = 20_000
    private const val MAX_EXPRESIONES = 3_000
    private const val ANTI_REPETIR_MS = 60_000L        // la misma palabra en la misma pantalla no cuenta dos veces seguidas
    private const val GUARDAR_CADA_S = 30L

    private val ES = Locale("es")
    private val lock = Any()
    private val palabras = HashMap<String, Cot>()
    private val expresiones = HashMap<String, Cot>()
    private val recientes = ArrayList<String>()          // últimas palabras nuevas, la más nueva primero
    private val contadoEn = HashMap<String, Long>()      // clave -> última vez que se contó
    private val bigramas = HashMap<String, Int>()        // pares candidatos a expresión (solo en RAM hasta que se repiten)
    private val io = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "amigo-pantalla").apply { isDaemon = true } }
    private val guardadoPendiente = AtomicBoolean(false)

    @Volatile private var app: Context? = null
    @Volatile private var cargado = false
    @Volatile private var sucio = false

    /** Cuántas palabras de la pantalla sabe (se muestra en Ajustes). */
    var total by mutableIntStateOf(0)
        private set

    /** Interruptor del usuario: apagado = el servicio ignora todo. */
    var activo by mutableStateOf(false)
        private set

    /** Casilla «No lectura» del amigo flotante: encendida (rosa) = no lee la pantalla. Se recuerda. */
    var noLectura by mutableStateOf(false)
        private set

    /** Casilla «Descansar»: el amigo se fue a pasear por la SD y no lee nada hasta que lo llamen. Se recuerda. */
    var descansando by mutableStateOf(false)
        private set

    /** Solo se lee si está encendido, no está en «No lectura» y no está descansando. */
    val puedeLeer: Boolean get() = activo && !noLectura && !descansando

    /** Interruptor aparte del OCR (capturas de pantalla + reconocimiento de texto). Apagado por defecto. */
    var ocrActivo by mutableStateOf(false)
        private set

    /** El OCR solo corre si el usuario lo encendió Y la lectura normal está permitida (así respeta «No lectura» y el descanso). */
    val puedeOcr: Boolean get() = puedeLeer && ocrActivo

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("amigo_pantalla", Context.MODE_PRIVATE)

    fun setNoLectura(ctx: Context, v: Boolean) {
        noLectura = v
        prefs(ctx).edit().putBoolean("no_lectura", v).apply()
        if (v) guardarYa()
    }

    fun setDescansando(ctx: Context, v: Boolean) {
        descansando = v
        prefs(ctx).edit().putBoolean("descansando", v).apply()
        if (v) guardarYa()
    }

    fun setOcrActivo(ctx: Context, v: Boolean) {
        ocrActivo = v
        prefs(ctx).edit().putBoolean("ocr_activo", v).apply()
    }

    // ───────────── Arranque y permisos ─────────────

    /** Llamar al crear la Store y al conectar el servicio: lee el interruptor y carga lo guardado (en segundo plano). */
    fun iniciar(ctx: Context) {
        val c = ctx.applicationContext
        app = c
        val pr = prefs(c)
        activo = pr.getBoolean("activo", false)
        noLectura = pr.getBoolean("no_lectura", false)
        descansando = pr.getBoolean("descansando", false)
        ocrActivo = pr.getBoolean("ocr_activo", false)
        if (!cargado) io.execute { try { cargar() } catch (e: Throwable) { } }
    }

    fun setActivo(ctx: Context, v: Boolean) {
        activo = v
        ctx.applicationContext.getSharedPreferences("amigo_pantalla", Context.MODE_PRIVATE).edit().putBoolean("activo", v).apply()
        if (!v) guardarYa()
    }

    /** ¿Está encendido el servicio en Ajustes del sistema > Accesibilidad? */
    fun servicioEnSistema(ctx: Context): Boolean {
        val s = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        } catch (e: Exception) { null } ?: return false
        val yo = ComponentName(ctx, LeerPantallaService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == yo }
    }

    /**
     * ¿El servicio que está encendido en Accesibilidad tiene el permiso de hacer capturas? Si la app se actualizó con el servicio
     * ya activo, puede hacer falta apagarlo y volver a encenderlo. Si no se puede saber, se asume que sí.
     */
    fun capturaPermitida(ctx: Context): Boolean = try {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val yo = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).firstOrNull {
            it.resolveInfo.serviceInfo.packageName == ctx.packageName &&
                it.resolveInfo.serviceInfo.name == LeerPantallaService::class.java.name
        }
        yo == null || (yo.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_TAKE_SCREENSHOT) != 0
    } catch (e: Throwable) {
        true
    }

    /** Carpeta de la memoria: igual que `FriendMemory.memoryDir` (SD si hay) + «pantalla». Null si no hay permiso de archivos. */
    private fun carpeta(ctx: Context): File? = carpetaAmigo(ctx)?.let { File(it, "pantalla") }

    /** Documents/Amigo (en la SD si hay). Null si falta el permiso de archivos. */
    fun carpetaAmigo(ctx: Context): File? {
        if (!Environment.isExternalStorageManager()) return null
        val internal = Environment.getExternalStorageDirectory().absolutePath
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val sd = sm.storageVolumes
            .filter { it.state == Environment.MEDIA_MOUNTED }
            .mapNotNull { it.directory }
            .firstOrNull { it.absolutePath != internal }
        return File(sd ?: Environment.getExternalStorageDirectory(), "Documents/Amigo")
    }

    // ───────────── Qué apps se ignoran ─────────────

    private val OMITIR_EXACTOS = setOf(
        "com.archivero", "com.android.systemui", "android", "com.android.settings", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.android.packageinstaller", "com.google.android.packageinstaller"
    )
    private val OMITIR_TROZOS = listOf(
        "inputmethod", "keyboard", "honeyboard", "swiftkey", "launcher", "lockscreen",
        "bank", "banco", "wallet", "authenticator", "password", "passwd", "keepass", "bitwarden", "lastpass", "1password", "keeper",
        "paypal", "mercadopago", "pago", "billetera", "vpn", "dialer", "contacts"
    )

    /** Apps de las que el amigo NO lee nada (la lista es aproximada: no puede conocer todos los bancos del mundo). */
    fun debeOmitir(pkg: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        return p in OMITIR_EXACTOS || OMITIR_TROZOS.any { p.contains(it) }
    }

    // ───────────── Qué palabras se ignoran ─────────────

    /** Palabras de botones y menús que aparecen en cualquier app: no son «nuevas», son interfaz. */
    private val INTERFAZ: Set<String> = (
        "aceptar cancelar guardar buscar enviar ajustes configuración configuracion menú menu inicio atrás atras siguiente anterior " +
        "compartir abrir cerrar editar borrar eliminar copiar pegar cortar volver listo hecho ayuda opciones perfil cuenta notificaciones " +
        "mensaje mensajes chat llamada llamadas contactos favoritos historial descargas archivos carpeta fotos vídeos videos música musica " +
        "más mas todo todos todas nuevo nueva ver más ver mas mostrar ocultar activar desactivar permitir denegar continuar omitir " +
        "descansar llamar lectura cargando error reintentar actualizar actualización actualizacion instalar desinstalar iniciar sesión sesion cerrar sesión registrarse " +
        "ok cancel settings search send home back next share like comment save open close edit delete copy paste done help options profile " +
        "account notifications message messages call calls contacts history downloads files folder photos videos music more all new view " +
        "show hide enable disable allow deny continue skip loading error retry update install login logout sign"
        ).split(" ").filter { it.isNotEmpty() }.toSet()

    // ───────────── Limpieza del texto (privacidad) ─────────────

    private val RX_URL = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)
    private val RX_MAIL = Regex("\\S+@\\S+\\.\\S+")
    private val RX_USUARIO = Regex("@\\w+")
    private val RX_NUM = Regex("\\d[\\d .\\-/]{5,}\\d")
    private val RX_ESP = Regex("\\s+")
    private val RX_TOKEN = Regex("#?\\p{L}[\\p{L}\\p{N}_']{1,29}")
    private val RX_ALARGADA = Regex("(\\p{L})\\1{2,}")
    private val RX_RISA = Regex("^(\\p{L}{1,2})\\1{2,}$")
    private val RX_CAMEL = Regex("\\p{Ll}\\p{Lu}")

    private fun limpiar(s: String): String =
        s.replace(RX_URL, " ").replace(RX_MAIL, " ").replace(RX_USUARIO, " ").replace(RX_NUM, " ")

    private fun trozo(t: String, r: IntRange): String {
        val a = maxOf(0, r.first - 45)
        val b = minOf(t.length, r.last + 46)
        return t.substring(a, b).replace(RX_ESP, " ").trim()
    }

    private fun sinAcentos(s: String): String =
        Normalizer.normalize(s.lowercase(ES), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    /** Qué clase de palabra nueva es (para que el amigo la comente con más gracia). */
    private fun tipoDe(orig: String, w: String): String = when {
        orig.startsWith("#") -> "hashtag"
        RX_ALARGADA.containsMatchIn(w) || RX_RISA.containsMatchIn(w) -> "alargada"
        w.any { it.isDigit() } -> "tecnica"
        RX_CAMEL.containsMatchIn(orig) -> "marca"
        w.length <= 4 && w.none { it in "aeiouáéíóúü" } -> "abreviatura"
        else -> "palabra"
    }

    fun etiqueta(tipo: String): String = when (tipo) {
        "hashtag" -> "un hashtag"
        "alargada" -> "una forma de escribir alargada"
        "tecnica" -> "un término técnico o con números"
        "marca" -> "un nombre propio o de marca"
        "abreviatura" -> "una abreviatura"
        "expresion" -> "una expresión"
        else -> "una palabra"
    }

    private val FECHA = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es"))
    fun fecha(ms: Long): String = synchronized(FECHA) { FECHA.format(Date(ms)) }

    // ───────────── Aprender de un texto de pantalla ─────────────

    /** Lo llama el servicio con los textos visibles. Se procesa en un hilo aparte: nunca frena la pantalla. */
    fun procesar(appNombre: String, textos: List<String>) {
        io.execute { try { procesarInterno(appNombre, textos) } catch (e: Throwable) { } }
    }

    private fun procesarInterno(appNombre: String, textos: List<String>) {
        if (!puedeLeer) return
        if (!cargar()) return
        val ahora = System.currentTimeMillis()
        val cerebro = FriendLink.store?.saber          // lo que ya sabe de los PDF (si la app está abierta)
        val vistas = HashSet<String>()
        var cambio = false
        synchronized(lock) {
            if (contadoEn.size > 6_000) contadoEn.clear()
            if (bigramas.size > 30_000) bigramas.clear()
            for (raw in textos) {
                val t = limpiar(raw)
                if (t.length < 3) continue
                var previa: String? = null
                var finPrevia = -1
                for (m in RX_TOKEN.findAll(t)) {
                    val orig = m.value
                    val w = orig.lowercase(ES).trim('\'', '_')
                    val letras = w.count { it.isLetter() }
                    if (w.length < 3 || letras < 2 || w.count { it.isDigit() } * 2 > w.length ||
                        w in STOP || w in INTERFAZ || w.removePrefix("#") in STOP) {
                        previa = null
                        continue
                    }
                    val adyacente = previa != null && m.range.first - finPrevia - 1 in 0..2 &&
                        t.substring(finPrevia + 1, m.range.first).isBlank()

                    // 1) La palabra.
                    var cot = palabras[w]
                    if (cot == null && cerebro?.sabe(w) != true) {
                        if (palabras.size >= MAX_PALABRAS) podar()
                        cot = Cot(0, trozo(t, m.range), appNombre, ahora, ahora, tipoDe(orig, w))
                        palabras[w] = cot
                        recientes.remove(w); recientes.add(0, w)
                        while (recientes.size > 40) recientes.removeAt(recientes.size - 1)
                        cambio = true
                    }
                    if (cot != null && vistas.add(w)) {
                        val ult = contadoEn[w]
                        if (ult == null || ahora - ult >= ANTI_REPETIR_MS) {
                            cot.veces++
                            cot.ultima = ahora
                            if (cot.contexto.isEmpty()) cot.contexto = trozo(t, m.range)
                            contadoEn[w] = ahora
                            cambio = true
                        }
                    }

                    // 2) Expresión: dos palabras seguidas, de las cuales al menos una es nueva para el amigo, que se repiten.
                    val pv = previa
                    if (adyacente && pv != null && (palabras.containsKey(pv) || palabras.containsKey(w))) {
                        val par = "$pv $w"
                        if (vistas.add("¶$par")) {
                            val ult = contadoEn["¶$par"]
                            if (ult == null || ahora - ult >= ANTI_REPETIR_MS) {
                                contadoEn["¶$par"] = ahora
                                val ex = expresiones[par]
                                if (ex != null) {
                                    ex.veces++; ex.ultima = ahora; cambio = true
                                } else {
                                    val n = (bigramas[par] ?: 0) + 1
                                    if (n >= 3 && expresiones.size < MAX_EXPRESIONES) {
                                        bigramas.remove(par)
                                        expresiones[par] = Cot(n, trozo(t, maxOf(0, finPrevia - pv.length + 1)..m.range.last), appNombre, ahora, ahora, "expresion")
                                        cambio = true
                                    } else bigramas[par] = n
                                }
                            }
                        }
                    }
                    previa = w
                    finPrevia = m.range.last
                }
            }
            if (cambio) { total = palabras.size; sucio = true }
        }
        if (cambio) programarGuardado()
    }

    /** Al llegar al tope, se olvidan las palabras vistas una sola vez hace más tiempo (las repetidas se conservan). */
    private fun podar() {
        val fuera = palabras.entries.filter { it.value.veces <= 1 }.sortedBy { it.value.ultima }.take(2_000).map { it.key }
        for (k in fuera) palabras.remove(k)
        recientes.removeAll(fuera.toSet())
    }

    // ───────────── Guardar y cargar (Documents/Amigo/pantalla) ─────────────

    private fun cargar(): Boolean {
        if (cargado) return true
        val ctx = app ?: return false
        val d = carpeta(ctx) ?: return false
        synchronized(lock) {
            if (cargado) return true
            val f = File(d, "palabras.json")
            if (f.isFile) {
                try {
                    val o = JSONObject(f.readText(Charsets.UTF_8))
                    leerMapa(o.optJSONObject("palabras"), palabras)
                    leerMapa(o.optJSONObject("expresiones"), expresiones)
                    val r = o.optJSONArray("recientes")
                    if (r != null) for (i in 0 until r.length()) { val w = r.optString(i); if (palabras.containsKey(w)) recientes.add(w) }
                } catch (e: Exception) {
                    // Archivo dañado: se guarda una copia aparte y se sigue de cero (nunca se pisa sin respaldo).
                    try { f.copyTo(File(d, "palabras.dañado.json"), overwrite = true) } catch (ignored: Exception) { }
                    palabras.clear(); expresiones.clear(); recientes.clear()
                }
            }
            cargado = true
            total = palabras.size
        }
        return true
    }

    private fun leerMapa(o: JSONObject?, into: HashMap<String, Cot>) {
        if (o == null) return
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            val a = o.optJSONArray(k) ?: continue
            into[k] = Cot(a.optInt(0, 1), a.optString(1, ""), a.optString(2, ""), a.optLong(3, 0L), a.optLong(4, 0L), a.optString(5, "palabra"))
        }
    }

    private fun escribirMapa(m: HashMap<String, Cot>): JSONObject {
        val o = JSONObject()
        for ((k, c) in m) o.put(k, JSONArray().put(c.veces).put(c.contexto).put(c.app).put(c.primera).put(c.ultima).put(c.tipo))
        return o
    }

    private fun programarGuardado() {
        if (!guardadoPendiente.compareAndSet(false, true)) return
        io.schedule(Runnable {
            guardadoPendiente.set(false)
            try { guardar() } catch (e: Throwable) { }
        }, GUARDAR_CADA_S, TimeUnit.SECONDS)
    }

    /** Guarda ya (al apagar el interruptor o al cerrarse el servicio). */
    fun guardarYa() {
        io.execute { try { guardar() } catch (e: Throwable) { } }
    }

    private fun guardar() {
        if (!sucio || !cargado) return
        val ctx = app ?: return
        val d = carpeta(ctx) ?: return
        val json: String
        val txt: String
        synchronized(lock) {
            val o = JSONObject()
            o.put("version", 1)
            o.put("palabras", escribirMapa(palabras))
            o.put("expresiones", escribirMapa(expresiones))
            o.put("recientes", JSONArray(recientes))
            json = o.toString()

            val sb = StringBuilder()
            sb.append("Lo que mi amigo aprendió de la pantalla\n")
            sb.append("Actualizado: ").append(fecha(System.currentTimeMillis())).append("\n")
            sb.append("Palabras distintas: ").append(palabras.size).append(" · Expresiones: ").append(expresiones.size).append("\n")
            sb.append("Solo guardo palabras sueltas y un trozo corto alrededor. Nunca contraseñas, lo que escribes tú, correos, webs ni números.\n\n")
            sb.append("Las más vistas (palabra · veces · tipo · app · primera vez — contexto):\n")
            for ((w, c) in palabras.entries.sortedByDescending { it.value.veces }.take(300)) {
                sb.append(w).append(" · ").append(c.veces).append(" · ").append(c.tipo).append(" · ").append(c.app)
                    .append(" · ").append(fecha(c.primera)).append(" — «").append(c.contexto).append("»\n")
            }
            if (expresiones.isNotEmpty()) {
                sb.append("\nExpresiones que se repiten:\n")
                for ((w, c) in expresiones.entries.sortedByDescending { it.value.veces }.take(100)) {
                    sb.append(w).append(" · ").append(c.veces).append(" · ").append(c.app).append(" — «").append(c.contexto).append("»\n")
                }
            }
            txt = sb.toString()
            sucio = false
        }
        try {
            d.mkdirs()
            escribirAtomico(File(d, "palabras.json"), json)
            escribirAtomico(File(d, "palabras.txt"), txt)
        } catch (e: Exception) {
            sucio = true            // sin permiso o sin espacio: se reintenta en el próximo guardado
        }
    }

    private fun escribirAtomico(dest: File, contenido: String) {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.writeText(contenido, Charsets.UTF_8)
        if (!tmp.renameTo(dest)) { dest.writeText(contenido, Charsets.UTF_8); tmp.delete() }
    }

    // ───────────── Lo que el chat usa ─────────────

    private fun vista(k: String, c: Cot, exp: Boolean = false) =
        PalabraVista(k, c.veces, c.app, c.contexto, c.primera, c.ultima, c.tipo, exp)

    /** «qué sabes de <palabra>»: busca entre lo visto en pantalla (sin importar acentos ni mayúsculas). */
    fun buscar(raw: String): PalabraVista? {
        val q = raw.trim().trim('"', '«', '»', '?', '¿', '.', '!').lowercase(ES)
        if (q.isEmpty()) return null
        synchronized(lock) {
            palabras[q]?.let { return vista(q, it) }
            expresiones[q]?.let { return vista(q, it, true) }
            val qs = sinAcentos(q)
            for ((k, c) in palabras) if (sinAcentos(k) == qs) return vista(k, c)
        }
        return null
    }

    /** Si lo que escribiste lleva una palabra que el amigo aprendió de la pantalla (vista al menos 2 veces), la devuelve. */
    fun mencionada(texto: String): PalabraVista? {
        if (total == 0) return null
        val toks = RX_TOKEN.findAll(texto).map { it.value.lowercase(ES) }.take(60).toList()
        synchronized(lock) {
            var mejor: Pair<String, Cot>? = null
            for (w in toks) {
                val c = palabras[w] ?: continue
                if (c.veces >= 2 && (mejor == null || c.veces > mejor.second.veces)) mejor = Pair(w, c)
            }
            return mejor?.let { vista(it.first, it.second) }
        }
    }

    /** Una palabra o expresión de las últimas que aprendió (para sacarla en una charla). */
    fun alAzar(): PalabraVista? {
        synchronized(lock) {
            val w = recientes.take(15).randomOrNull() ?: return null
            val c = palabras[w] ?: return null
            if (c.contexto.isEmpty()) return null
            return vista(w, c)
        }
    }

    /** «qué palabras nuevas viste»: un resumen corto con dónde las encontró. */
    fun resumenTexto(): String {
        synchronized(lock) {
            if (palabras.isEmpty()) {
                return if (!activo) "Todavía no leo la pantalla. Activá «Aprender de la pantalla» en Ajustes (y el servicio en Accesibilidad)."
                else "Todavía no vi palabras nuevas en la pantalla. Usá el teléfono un rato y después me preguntás."
            }
            val rec = recientes.take(6).mapNotNull { w -> palabras[w]?.let { "«$w» (${it.app})" } }
            val top = palabras.entries.filter { it.value.veces >= 2 }.sortedByDescending { it.value.veces }.take(5).map { "«${it.key}» ×${it.value.veces}" }
            return "De la pantalla aprendí ${palabras.size} palabras y ${expresiones.size} expresiones." +
                (if (rec.isNotEmpty()) " Las últimas: " + rec.joinToString(", ") + "." else "") +
                (if (top.isNotEmpty()) " Las que más se repiten: " + top.joinToString(", ") + "." else "") +
                " Todo está en Documents/Amigo/pantalla."
        }
    }
}

// ───────────── El servicio de accesibilidad ─────────────

/**
 * Lee el texto visible de la ventana activa de vez en cuando (no en cada evento) y se lo pasa a [PalabrasPantalla].
 * Se activa en Ajustes del sistema > Accesibilidad > Archivero; además hay un interruptor propio en los Ajustes del amigo.
 *
 * OCR de respaldo (1.39): si el usuario encendió su interruptor aparte y la lectura normal de nodos da poco o nada de texto
 * (juegos, imágenes, algunos vídeos), hace una captura EN MEMORIA, tapa lo privado, reconoce el texto con ML Kit y descarta la imagen.
 * Como mucho una captura cada 10 s, nunca con la pantalla apagada, y nunca se guarda nada de la imagen.
 */
class LeerPantallaService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var programado = false
    private var ultimaLectura = 0L
    private var ultimaFirma = 0
    private val nombres = HashMap<String, String>()

    // ── OCR de respaldo ──
    private val ocrEnCurso = AtomicBoolean(false)
    private var ultimaOcr = 0L                           // reloj de la última captura pedida (0 = ninguna todavía)
    @Volatile private var firmaOcr = 0                   // para no repetir el mismo texto leído dos veces seguidas
    private val lockOcr = Any()
    private var reconocedor: TextRecognizer? = null      // se crea al primer uso y se cierra tras 1 minuto sin usarse
    private val cerrarReposo = Runnable { if (!ocrEnCurso.get()) cerrarReconocedor() }

    /** Qué se conserva de una captura: la ventana de la app activa, menos los rectángulos que hay que tapar. */
    private class PlanOcr(val conservar: Rect, val tapar: List<Rect>)

    private companion object {
        const val OCR_CADA_MS = 10_000L                  // como mucho una captura cada 10 s
        const val OCR_ATASCADO_MS = 60_000L              // si una captura no terminó en 1 minuto, se da por perdida
        const val OCR_REPOSO_MS = 60_000L                // sin usarse 1 minuto: se suelta el modelo de la memoria
        const val OCR_SI_MENOS_DE = 60                   // «poco texto»: menos de 60 caracteres leídos por accesibilidad
        val RX_BLANCOS = Regex("\\s+")

        /** Hilo aparte (prioridad baja) para convertir la captura y recibir el resultado: nada de esto toca el hilo principal. */
        val OCR_HILO = Executors.newSingleThreadExecutor { r ->
            Thread({
                try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (e: Throwable) { }
                r.run()
            }, "amigo-ocr").apply { isDaemon = true }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        PalabrasPantalla.iniciar(this)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || programado || !PalabrasPantalla.puedeLeer) return
        val pkg = e.packageName?.toString() ?: return
        if (PalabrasPantalla.debeOmitir(pkg)) return
        programado = true
        // Como mucho una lectura cada ~2,5 s: el contenido cambia muchas veces por segundo y no hace falta leerlo todo.
        val espera = maxOf(900L, 2500L - (SystemClock.uptimeMillis() - ultimaLectura))
        h.postDelayed({ programado = false; leer() }, espera)
    }

    override fun onInterrupt() {
        PalabrasPantalla.guardarYa()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        cerrarReconocedor()
        PalabrasPantalla.guardarYa()
        super.onDestroy()
    }

    private fun leer() {
        ultimaLectura = SystemClock.uptimeMillis()
        if (!PalabrasPantalla.puedeLeer) return
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm != null && !pm.isInteractive) return           // pantalla apagada: no se lee nada
        val root = try { rootInActiveWindow } catch (e: Throwable) { null } ?: return
        try {
            val pkg = root.packageName?.toString() ?: return
            if (PalabrasPantalla.debeOmitir(pkg)) return
            val textos = LinkedHashSet<String>()
            val campos = ArrayList<Rect>()                     // contraseñas y campos editables: se tapan si hay OCR
            val cont = IntArray(3)
            recorrer(root, 0, textos, cont, campos)
            if (textos.isNotEmpty()) {
                val firma = pkg.hashCode() * 31 + textos.hashCode()
                if (firma != ultimaFirma) {                    // si nada cambió desde la última lectura, no se repite
                    ultimaFirma = firma
                    PalabrasPantalla.procesar(nombreDe(pkg), ArrayList(textos))
                }
            }
            // Respaldo: solo si la lectura normal dio poco o nada y el usuario encendió el OCR.
            if (cont[1] < OCR_SI_MENOS_DE && PalabrasPantalla.puedeOcr) pedirOcr(pkg, campos, cont[2] == 1)
        } finally {
            reciclar(root)
        }
    }

    /**
     * Recorre los nodos visibles. cont[0] = nodos vistos, cont[1] = letras juntadas (topes para no gastar batería),
     * cont[2] = 1 si se llegó a un tope sin terminar de recorrer. Los campos de contraseña y los editables se anotan en [campos]
     * (su rectángulo) para taparlos si luego se hace OCR.
     */
    private fun recorrer(n: AccessibilityNodeInfo, prof: Int, out: MutableSet<String>, cont: IntArray, campos: MutableList<Rect>) {
        if (prof > 40 || cont[0] > 700 || cont[1] > 30_000) { cont[2] = 1; return }
        cont[0]++
        if (!n.isVisibleToUser) return
        if (n.isPassword || n.isEditable) {
            if (campos.size >= 100) cont[2] = 1
            else {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (!r.isEmpty) campos.add(r)
            }
        }
        if (n.isPassword) return
        if (!n.isEditable) {                                    // lo que escribe el usuario (campos editables) no se lee
            val t = n.text
            if (!t.isNullOrBlank() && t.length <= 4000) { out.add(t.toString()); cont[1] += t.length }
        }
        for (i in 0 until n.childCount) {
            val c = try { n.getChild(i) } catch (e: Throwable) { null } ?: continue
            try { recorrer(c, prof + 1, out, cont, campos) } finally { reciclar(c) }
        }
    }

    // ───────────── OCR de respaldo ─────────────

    /**
     * Pide una captura de pantalla (en memoria) para leerla con OCR. Se llama desde el hilo principal y no hace nada pesado:
     * la captura, la conversión y el reconocimiento ocurren en otros hilos. No pide nada si: el límite de 10 s no pasó, ya hay una
     * en curso, la pantalla está apagada, no se pudo recorrer toda la pantalla (no se podría tapar con seguridad) o no se sabe
     * con certeza qué ventanas hay.
     */
    private fun pedirOcr(pkg: String, campos: List<Rect>, incompleto: Boolean) {
        if (incompleto) return
        val ahora = SystemClock.elapsedRealtime()
        if (ultimaOcr != 0L && ahora - ultimaOcr < OCR_CADA_MS) return
        if (ocrEnCurso.get() && ahora - ultimaOcr < OCR_ATASCADO_MS) return
        if (!pantallaEncendida()) return
        val plan = planOcr(campos) ?: return
        val nombre = nombreDe(pkg)                            // aquí, en el hilo principal: `nombres` no es seguro entre hilos
        ocrEnCurso.set(true)
        ultimaOcr = ahora
        h.removeCallbacks(cerrarReposo)
        h.postDelayed(cerrarReposo, OCR_REPOSO_MS)
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, OCR_HILO, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                    atenderCaptura(screenshot, pkg, nombre, plan)
                }

                override fun onFailure(errorCode: Int) {
                    ocrEnCurso.set(false)                     // sin permiso, ventana protegida, demasiado seguido…: se intentará más tarde
                }
            })
        } catch (e: Throwable) {
            ocrEnCurso.set(false)
        }
    }

    /**
     * Decide qué parte de la captura se puede mirar. Solo la ventana de la app activa; se tapan: los campos de contraseña y los
     * editables, y toda ventana que esté POR ENCIMA de la app (teclado, avisos emergentes, burbujas, otras capas). Null (= no hacer
     * OCR) si no se puede asegurar qué hay en pantalla: sin lista de ventanas, sin ventana activa o si la activa no es una app.
     */
    private fun planOcr(campos: List<Rect>): PlanOcr? {
        val ventanas = try { windows } catch (e: Throwable) { null } ?: return null
        try {
            val activa = ventanas.firstOrNull { it.isActive } ?: return null
            if (activa.type != AccessibilityWindowInfo.TYPE_APPLICATION) return null
            val area = Rect()
            activa.getBoundsInScreen(area)
            if (area.isEmpty) return null
            val tapar = ArrayList<Rect>(campos)
            val capaActiva = activa.layer
            for (v in ventanas) {
                if (v === activa || v.layer <= capaActiva) continue
                val r = Rect()
                v.getBoundsInScreen(r)
                if (!r.isEmpty) tapar.add(r)
            }
            return PlanOcr(area, tapar)
        } finally {
            for (v in ventanas) reciclarVentana(v)
        }
    }

    /** Corre en el hilo del OCR. Convierte la captura, tapa lo privado y lanza el reconocimiento; la imagen se descarta siempre. */
    private fun atenderCaptura(captura: AccessibilityService.ScreenshotResult, pkg: String, nombre: String, plan: PlanOcr) {
        val bmp = copiaEnMemoria(captura)
        if (bmp == null) { ocrEnCurso.set(false); return }
        var enMarcha = false
        try {
            // La pantalla pudo apagarse, el usuario apagar el OCR o cambiar de app mientras se capturaba: se vuelve a comprobar.
            if (!PalabrasPantalla.puedeOcr || !pantallaEncendida() || !mismaAppAdelante(pkg)) return
            taparZonas(bmp, plan)
            val tarea = obtenerReconocedor().process(InputImage.fromBitmap(bmp, 0))
            tarea.addOnCompleteListener(OCR_HILO) { t ->
                try {
                    bmp.recycle()                              // la captura se descarta pase lo que pase: nunca se guarda
                    if (t.isSuccessful) entregar(pkg, nombre, t.result)
                } catch (e: Throwable) {
                } finally {
                    ocrEnCurso.set(false)
                }
            }
            enMarcha = true
        } catch (e: Throwable) {
        } finally {
            if (!enMarcha) {
                try { bmp.recycle() } catch (e: Throwable) { }
                ocrEnCurso.set(false)
            }
        }
    }

    /** Pasa la captura (memoria gráfica) a una imagen normal en RAM y cierra la memoria gráfica original. */
    private fun copiaEnMemoria(captura: AccessibilityService.ScreenshotResult): Bitmap? {
        val buffer = captura.hardwareBuffer
        try {
            val dura = Bitmap.wrapHardwareBuffer(buffer, captura.colorSpace) ?: return null
            return try { dura.copy(Bitmap.Config.ARGB_8888, true) } finally { dura.recycle() }
        } catch (e: Throwable) {
            return null
        } finally {
            try { buffer.close() } catch (e: Throwable) { }
        }
    }

    /** Pinta de negro todo lo que no se debe leer: lo que queda fuera de la app activa y los rectángulos del plan. */
    private fun taparZonas(bmp: Bitmap, plan: PlanOcr) {
        val w = bmp.width.toFloat()
        val alto = bmp.height.toFloat()
        // Por si la captura no tiene el mismo tamaño que la pantalla: se escalan los rectángulos.
        var sx = 1f
        var sy = 1f
        try {
            val pantalla = (getSystemService(Context.WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
            if (pantalla.width() > 0 && pantalla.height() > 0) { sx = w / pantalla.width(); sy = alto / pantalla.height() }
        } catch (e: Throwable) { }
        val negro = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
        val c = Canvas(bmp)
        val k = RectF(plan.conservar.left * sx, plan.conservar.top * sy, plan.conservar.right * sx, plan.conservar.bottom * sy)
        c.drawRect(0f, 0f, w, k.top, negro)                    // arriba (barra de estado…)
        c.drawRect(0f, k.bottom, w, alto, negro)               // abajo (barra de navegación…)
        c.drawRect(0f, k.top, k.left, k.bottom, negro)         // izquierda
        c.drawRect(k.right, k.top, w, k.bottom, negro)         // derecha (otra app en pantalla dividida…)
        for (r in plan.tapar) c.drawRect(RectF(r.left * sx, r.top * sy, r.right * sx, r.bottom * sy), negro)
    }

    /** Corre en el hilo del OCR: arma los textos del resultado y los pasa por [PalabrasPantalla.procesar] (que hace la limpieza). */
    private fun entregar(pkg: String, nombre: String, texto: Text) {
        if (!PalabrasPantalla.puedeOcr || !pantallaEncendida()) return
        val partes = LinkedHashSet<String>()
        var letras = 0
        for (b in texto.textBlocks) {
            // Un bloque en una sola línea: así «procesar» limpia números largos y direcciones aunque el OCR los haya partido en renglones.
            val t = b.text.replace(RX_BLANCOS, " ").trim()
            if (t.length < 3 || t.length > 4000) continue
            partes.add(t)
            letras += t.length
            if (letras > 30_000) break
        }
        if (partes.isEmpty()) return
        val firma = pkg.hashCode() * 31 + partes.hashCode()
        if (firma == firmaOcr) return                          // la misma pantalla de antes: no se cuenta otra vez
        firmaOcr = firma
        PalabrasPantalla.procesar(nombre, ArrayList(partes))
    }

    private fun pantallaEncendida(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        return pm != null && pm.isInteractive                  // para el OCR, si no se sabe, se asume apagada
    }

    /** ¿Sigue al frente la misma app que se comprobó antes de capturar? */
    private fun mismaAppAdelante(pkg: String): Boolean {
        val r = try { rootInActiveWindow } catch (e: Throwable) { null } ?: return false
        try {
            val ahora = r.packageName?.toString() ?: return false
            return ahora == pkg && !PalabrasPantalla.debeOmitir(ahora)
        } finally {
            reciclar(r)
        }
    }

    private fun obtenerReconocedor(): TextRecognizer = synchronized(lockOcr) {
        reconocedor ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also { reconocedor = it }
    }

    private fun cerrarReconocedor() {
        synchronized(lockOcr) {
            try { reconocedor?.close() } catch (e: Throwable) { }
            reconocedor = null
        }
    }

    @Suppress("DEPRECATION")
    private fun reciclar(n: AccessibilityNodeInfo) {
        if (Build.VERSION.SDK_INT < 33) try { n.recycle() } catch (e: Throwable) { }
    }

    @Suppress("DEPRECATION")
    private fun reciclarVentana(w: AccessibilityWindowInfo) {
        if (Build.VERSION.SDK_INT < 33) try { w.recycle() } catch (e: Throwable) { }
    }

    /** «com.whatsapp» → «WhatsApp» (si Android deja ver la app); si no, «whatsapp». */
    private fun nombreDe(pkg: String): String = nombres.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.')
        }
    }
}
