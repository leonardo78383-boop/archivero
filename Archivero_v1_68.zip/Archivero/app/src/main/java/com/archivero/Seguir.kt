package com.archivero

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.StateListAnimator
import android.graphics.drawable.RippleDrawable
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Rect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.ViewConfiguration
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.LruCache
import androidx.core.graphics.PathParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ───────────── Enlace entre la app y el amigo flotante ─────────────

/**
 * Punto de encuentro entre la pantalla de la app y el servicio que dibuja al amigo sobre otras apps.
 * El amigo flotante solo aparece si: está suelto (no guardado), la app NO está en pantalla y se dio el permiso
 * "Mostrar sobre otras apps".
 */
object FriendLink {
    @Volatile var store: Store? = null          // para que el mini reproductor use la misma música de la app
    @Volatile var appVisible = true
    @Volatile var wantOut = false               // el amigo anda suelto
    var listener: (() -> Unit)? = null

    fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun setVisible(v: Boolean) {
        appVisible = v
        listener?.invoke()
    }

    /** Arranca el servicio si el amigo anda suelto y hay permiso; si no, lo detiene. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        if (wantOut && canDraw(app)) {
            try { app.startForegroundService(Intent(app, FriendService::class.java)) } catch (e: Exception) { }
        } else {
            stop(app)
        }
    }

    fun stop(ctx: Context) {
        try { ctx.applicationContext.stopService(Intent(ctx.applicationContext, FriendService::class.java)) } catch (e: Exception) { }
    }
}

/** Servicio en primer plano (con un aviso discreto) que mantiene viva la esfera flotante al salir de la app. */
class FriendService : Service() {
    private var overlay: FriendOverlay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = FriendOverlay(this)
        FriendLink.listener = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        refresh()
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (FriendLink.appVisible) overlay?.hide() else overlay?.show()
    }

    override fun onDestroy() {
        FriendLink.listener = null
        overlay?.shutdown()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Tu amigo te sigue", NotificationManager.IMPORTANCE_MIN))
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pi = if (launch != null) PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else null
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("Archivero")
            .setContentText("Tu amigo te sigue fuera de la app")
            .setOngoing(true)
        if (pi != null) b.setContentIntent(pi)
        return b.build()
    }

    companion object {
        private const val CHANNEL = "amigo_sigue"
        private const val NOTIF_ID = 8
    }
}

// ───────────── La esfera flotante y sus mini paneles ─────────────

/**
 * La esfera de gelatina del amigo, dibujada a mano (misma cara que la de la app) y animada:
 * se estira hacia donde va, respira, parpadea, mira a los lados y, si suena música, baila y suelta notitas.
 * Todos los valores los mueve [FriendOverlay] en cada cuadro; aquí solo se dibuja.
 */
private class BubbleView(ctx: Context) : View(ctx) {
    var stretch = 0f        // estiramiento (resorte)
    var angle = 0f          // hacia dónde va (radianes)
    var lookX = 0f          // hacia dónde mira (-1..1)
    var lookY = 0f
    var open = 1f           // 1 = ojo abierto, ~0.1 = parpadeo
    var bob = 0f            // respiración (-0.5..0.5)
    var grow = 1f           // se agranda un poco al agarrarlo
    var playing = false     // suena música
    var noteT = 0f          // 0..1, notita que sube
    var frozen = false      // fijo: aro plateado
    val pose = Pose()       // lo que pide la animación del momento (ver Gestos.kt)

    private val art = AmigoArte(ctx.resources.displayMetrics.density)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        art.size(w, h)
    }

    override fun onDraw(c: Canvas) {
        art.draw(c, width, height, pose, stretch, angle, lookX, lookY, open, bob, grow, playing, noteT, frozen)
    }
}

/**
 * Casilla del amigo flotante: ícono dibujado a mano + nombre debajo. `active` = rosa (encendida).
 * kind: 0 = luna (Descansar), 1 = nota (Música), 2 = ojo tachado (No lectura).
 */
/** Mezcla un color con blanco (f = 0..1). */
private fun fMix(c: Int, f: Float): Int {
    val r = (c shr 16 and 0xFF); val g = (c shr 8 and 0xFF); val b = (c and 0xFF)
    val rr = (r + (255 - r) * f).toInt(); val gg = (g + (255 - g) * f).toInt(); val bb = (b + (255 - b) * f).toInt()
    return (c and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
}

/** Fondo con las esquinas superior izquierda e inferior derecha cortadas en diagonal, degradado suave y canto fino (el mismo estilo que la app). */
internal class CutBg(private val color: Int, private val stroke: Int, private val cut: Float, private val sw: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw }
    private val path = Path()
    private val grad = LinearGradient(0f, 0f, 0f, 1f, fMix(color, 0.08f), color, Shader.TileMode.CLAMP)
    private val gm = Matrix()
    init { fill.shader = grad }
    override fun onBoundsChange(b: Rect) {
        val i = sw / 2f
        val l = b.left + i; val t = b.top + i; val r = b.right - i; val bt = b.bottom - i
        val k = minOf(cut, (r - l) / 2f, (bt - t) / 2f).coerceAtLeast(0f)
        path.reset()
        path.moveTo(l + k, t); path.lineTo(r, t); path.lineTo(r, bt - k)
        path.lineTo(r - k, bt); path.lineTo(l, bt); path.lineTo(l, t + k); path.close()
        gm.setScale(1f, maxOf(1f, b.height().toFloat()))             // el mismo degradado, estirado: sin crear objetos al estirar el panel
        gm.postTranslate(0f, b.top.toFloat())
        grad.setLocalMatrix(gm)
        edge.color = stroke
    }
    override fun draw(c: Canvas) { c.drawPath(path, fill); c.drawPath(path, edge) }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Casilla ancha del amigo flotante, con el estilo del explorador: cuadrito con el ícono a la izquierda, nombre en mayúsculas
 * y una línea pequeña debajo; esquinas cortadas (arriba-izquierda y abajo-derecha) y puntitos en las esquinas libres.
 * Encendida (haciendo algo) = plata brillante con texto oscuro. kind: 0 = música, 1 = optimizar, 2 = teclado.
 */
private class ActionSlotView(ctx: Context, private val kind: Int, private val label: String, private val subDefault: String) : View(ctx) {
    var active = false
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Texto pequeño que sustituye al de siempre mientras trabaja o al terminar («380 MB libres»). null = el de siempre. */
    var status: String? = null
        set(v) { if (field != v) { field = v; invalidate() } }

    private val dens = ctx.resources.displayMetrics.density
    private val fillBg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * dens }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cellFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cellEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * dens }
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f * dens; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f * dens; typeface = Typeface.DEFAULT }
    private val box = RectF()
    private val cell = RectF()
    private val a = Path()

    private fun fit(p: Paint, s: String, avail: Float): String {
        val n = p.breakText(s, true, avail, null)
        return if (n >= s.length) s else s.substring(0, maxOf(0, n - 1)) + "…"
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val dark = 0xFF0B0C0E.toInt()
        val tint = if (active) dark else 0xFFFFFFFF.toInt()
        box.set(dens * 0.5f, dens * 0.5f, w - dens * 0.5f, h - dens * 0.5f)
        val k = 10f * dens
        a.reset()
        a.moveTo(box.left + k, box.top); a.lineTo(box.right, box.top); a.lineTo(box.right, box.bottom - k)
        a.lineTo(box.right - k, box.bottom); a.lineTo(box.left, box.bottom); a.lineTo(box.left, box.top + k); a.close()
        fillBg.shader = LinearGradient(
            0f, 0f, 0f, h,
            if (active) 0xFFFFFFFF.toInt() else 0xFF2A2D33.toInt(), if (active) 0xFFC3C8D0.toInt() else 0xFF14161A.toInt(),
            Shader.TileMode.CLAMP
        )
        edge.color = if (active) 0xFFFFFFFF.toInt() else 0xFF3A3F47.toInt()
        c.drawPath(a, fillBg)
        c.drawPath(a, edge)
        // Puntitos de las esquinas libres.
        ink.color = (tint and 0xFFFFFF) or 0x66000000
        c.drawCircle(dens * 5f, h - dens * 5f, dens * 1.2f, ink)
        c.drawCircle(w - dens * 5f, dens * 5f, dens * 1.2f, ink)

        // Cuadrito del ícono (como el cuadrado de la maqueta).
        val pad = 7f * dens
        val side = h - pad * 2f
        cell.set(pad, pad, pad + side, pad + side)
        cellFill.color = if (active) 0x22000000 else 0x1AFFFFFF
        cellEdge.color = (tint and 0xFFFFFF) or 0x55000000
        c.drawRect(cell, cellFill)
        c.drawRect(cell, cellEdge)
        ink.color = tint
        val d = when (kind) { 0 -> FIco.NOTE; 1 -> FIco.BOLT; else -> FIco.KEYBOARD }
        val s = side * 0.58f
        FIco.draw(c, d, cell.left + (side - s) / 2f, cell.top + (side - s) / 2f, s, ink)

        // Nombre y línea pequeña.
        val tx = cell.right + 9f * dens
        val avail = w - tx - 9f * dens
        title.color = tint
        small.color = if (active) 0xFF3A3F47.toInt() else 0xFF8D939C.toInt()
        c.drawText(fit(title, label.uppercase(), avail), tx, h * 0.46f, title)
        c.drawText(fit(small, status ?: subDefault, avail), tx, h * 0.72f, small)
    }
}

/**
 * Contenedor de las 3 casillas: dibuja, debajo de ellas, las líneas finas que salen de la esfera hacia cada una
 * (como en la maqueta). originX/originY = punto de la esfera (en píxeles de esta ventana).
 */
private class SlotsRoot(ctx: Context, private val sphereLeft: Boolean) : LinearLayout(ctx) {
    var originX = 0f
    var originY = 0f
    var column: LinearLayout? = null
    private val dens = ctx.resources.displayMetrics.density
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * dens; color = 0xFFB4BAC4.toInt() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD5D9E0.toInt() }

    override fun dispatchDraw(c: Canvas) {
        val col = column
        if (col != null && col.height > 0) {
            val endX = if (sphereLeft) col.left.toFloat() else col.right.toFloat()
            for (i in 0 until col.childCount) {
                val ch = col.getChildAt(i)
                val y = col.top + ch.top + ch.height / 2f
                c.drawLine(originX, originY, endX, y, ln)
                c.drawCircle(endX, y, 2f * dens, dot)
            }
            c.drawCircle(originX, originY, 2.5f * dens, dot)
        }
        super.dispatchDraw(c)
    }
}

private val COVER_NAMES = setOf("cover", "folder", "front", "album", "albumart", "artwork")

/** Una fila de la lista del mini reproductor. kind: 0 = volver, 1 = carpeta, 2 = canción, 3 = aviso. */
private class MusicRow(val label: String, val sub: String?, val tag: String?, val kind: Int, val idx: Int = 0)

/** Una fila del panel «Apps» (pkg vacío = aviso, no se puede tocar). */
private class AppRow(val label: String, val pkg: String)

/**
 * Modo «moldear» del panel de apps (como el recuadro de recorte de un editor de fotos): borde, rejilla de 3×3, esquinas gruesas
 * y asas en el medio de cada borde. Solo dibuja; los arrastres los maneja `openApps`.
 */
private class ShapeEditor(ctx: Context) : View(ctx) {
    private val dens = ctx.resources.displayMetrics.density
    // El editor ocupa toda la ventana y dibuja el recuadro él mismo: mover o estirar el panel solo repinta esta vista (sin re-medir nada).
    private var rl = 0
    private var rt = 0
    private var rr = 0
    private var rb = 0

    fun setRect(l: Int, t: Int, r: Int, b: Int) {
        if (l == rl && t == rt && r == rr && b == rb) return
        rl = l; rt = t; rr = r; rb = b
        invalidate()
    }

    private val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x12FFFFFF }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * dens; color = 0xFFFFFFFF.toInt() }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * dens; color = 0x66FFFFFF }
    private val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3.5f * dens; strokeCap = Paint.Cap.SQUARE; color = 0xFFFFFFFF.toInt() }

    override fun onDraw(c: Canvas) {
        val w = (rr - rl).toFloat()
        val h = (rb - rt).toFloat()
        if (w <= 0f || h <= 0f) return
        val save = c.save()
        c.translate(rl.toFloat(), rt.toFloat())
        drawFrame(c, w, h)
        c.restoreToCount(save)
    }

    private fun drawFrame(c: Canvas, w: Float, h: Float) {
        val i = dens * 1.5f
        c.drawRect(i, i, w - i, h - i, tint)
        c.drawRect(i, i, w - i, h - i, edge)
        for (k in 1..2) {
            c.drawLine(w * k / 3f, i, w * k / 3f, h - i, grid)
            c.drawLine(i, h * k / 3f, w - i, h * k / 3f, grid)
        }
        val l = minOf(16f * dens, minOf(w, h) / 4f)
        c.drawLine(i, i, i + l, i, bold); c.drawLine(i, i, i, i + l, bold)
        c.drawLine(w - i, i, w - i - l, i, bold); c.drawLine(w - i, i, w - i, i + l, bold)
        c.drawLine(i, h - i, i + l, h - i, bold); c.drawLine(i, h - i, i, h - i - l, bold)
        c.drawLine(w - i, h - i, w - i - l, h - i, bold); c.drawLine(w - i, h - i, w - i, h - i - l, bold)
        val m = minOf(10f * dens, minOf(w, h) / 6f)
        c.drawLine(w / 2f - m, i, w / 2f + m, i, bold); c.drawLine(w / 2f - m, h - i, w / 2f + m, h - i, bold)
        c.drawLine(i, h / 2f - m, i, h / 2f + m, bold); c.drawLine(w - i, h / 2f - m, w - i, h / 2f + m, bold)
    }
}

/** Íconos vectoriales (trazos Material de 24×24): no dependen de emojis ni de fuentes, se ven igual en cualquier teléfono. */
internal object FIco {
    const val PLAY = "M8 5v14l11-7z"
    const val PAUSE = "M6 19h4V5H6v14zm8-14v14h4V5h-4z"
    const val PREV = "M6 6L8 6L8 18L6 18Z M9.5 12L18 6L18 18Z"
    const val NEXT = "M6 6L14.5 12L6 18Z M16 6L18 6L18 18L16 18Z"
    const val REPEAT = "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"
    const val REPEAT_ONE = "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4-2V9h-1l-2 1v1h1.5v4H13z"
    const val NOTE = "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"
    const val BOLT = "M7 2v11h3v9l7-12h-4l4-7z"
    const val TRASH = "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
    const val APPS = "M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"
    const val RESIZE = "M19 12h-2v3h-3v2h5v-5zM7 9h3V7H5v5h2V9zm14-6H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"
    const val KEYBOARD = "M20 5H4c-1.1 0-1.99.9-1.99 2L2 17c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm-9 3h2v2h-2V8zm0 3h2v2h-2v-2zM8 8h2v2H8V8zm0 3h2v2H8v-2zm-1 2H5v-2h2v2zm0-3H5V8h2v2zm9 7H8v-2h8v2zm0-4h-2v-2h2v2zm0-3h-2V8h2v2zm3 3h-2v-2h2v2zm0-3h-2V8h2v2z"
    const val SHIFT = "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
    const val BACKSPACE = "M22 3H7c-.69 0-1.23.35-1.59.88L0 12l5.41 8.11c.36.53.9.89 1.59.89h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-3 12.59L17.59 17 14 13.41 10.41 17 9 15.59 12.59 12 9 8.41 10.41 7 14 10.59 17.59 7 19 8.41 15.41 12 19 15.59z"
    const val ENTER = "M19 7v4H5.83l3.58-3.59L8 6l-6 6 6 6 1.41-1.41L5.83 13H21V7z"
    const val FOLDER = "M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"

    private val cache = HashMap<String, Path>()
    private fun path(d: String): Path = cache.getOrPut(d) { PathParser.createPathFromPathData(d) }

    fun draw(c: Canvas, d: String, left: Float, top: Float, size: Float, paint: Paint) {
        val p = Path(path(d))
        val m = Matrix()
        m.setScale(size / 24f, size / 24f)
        m.postTranslate(left, top)
        p.transform(m)
        c.drawPath(p, paint)
    }
}

/** Botón-ícono: dibuja un trazo vectorial del color pedido. */
internal class FloatIconView(ctx: Context, private var d: String, private var tint: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun icon(newD: String, newTint: Int) {
        if (newD != d || newTint != tint) { d = newD; tint = newTint; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        paint.color = tint
        val s = min(width, height) * 0.56f
        FIco.draw(c, d, (width - s) / 2f, (height - s) / 2f, s, paint)
    }
}

/** Miniatura cuadrada con esquinas redondas: carátula si existe; si no, un ícono de nota o de carpeta. */
internal class FloatThumbView(ctx: Context) : View(ctx) {
    var key: String? = null
    var placeholder: String = FIco.NOTE
    var playing: Boolean = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private var bmp: Bitmap? = null
    private var shader: BitmapShader? = null
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22252A.toInt() }
    private val img = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ico = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val shp = Path()

    fun setBitmap(b: Bitmap?) {
        bmp = b
        shader = if (b != null) BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) else null
        img.shader = shader
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = 7f * resources.displayMetrics.density
        rect.set(0f, 0f, w, h)
        shp.reset()
        shp.moveTo(k, 0f); shp.lineTo(w, 0f); shp.lineTo(w, h - k); shp.lineTo(w - k, h); shp.lineTo(0f, h); shp.lineTo(0f, k); shp.close()
        c.drawPath(shp, bg)
        val b = bmp
        val sh = shader
        if (b != null && sh != null) {
            val sc = maxOf(w / b.width, h / b.height)          // recorte centrado: llena el cuadro sin deformar
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate((w - b.width * sc) / 2f, (h - b.height * sc) / 2f)
            sh.setLocalMatrix(m)
            c.drawPath(shp, img)
        } else {
            ico.color = 0xFF8D939C.toInt()
            val s = w * 0.5f
            FIco.draw(c, placeholder, (w - s) / 2f, (h - s) / 2f, s, ico)
        }
        if (playing) {                                        // la que suena: velo oscuro + ▶ rosa
            ico.color = 0x99000000.toInt()
            c.drawPath(shp, ico)
            ico.color = 0xFFD5D9E0.toInt()
            val s = w * 0.5f
            FIco.draw(c, FIco.PLAY, (w - s) / 2f, (h - s) / 2f, s, ico)
        }
    }
}

/**
 * Dibuja al amigo sobre las demás apps. Está siempre vivo: pasea libre por la pantalla (o se queda en una esquina),
 * se estira, parpadea y baila si suena música. Se arrastra con el dedo.
 * Al tocarlo sale la casilla «Música» (mini reproductor).
 * El mini reproductor tiene las carpetas (con miniaturas), controles vectoriales, un botón de repetir canción y una ✕ que cierra solo el panel (la música sigue).
 */
class FriendOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val dens = ctx.resources.displayMetrics.density
    private val size = dp(96)

    private var bubble: BubbleView? = null
    private val gestos = Gestos()                 // las 60+ animaciones del amigo (Gestos.kt)
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var slots: View? = null
    private var slotsLp: WindowManager.LayoutParams? = null
    private var music: View? = null
    private var apps: View? = null                    // panel «Apps»
    // Íconos de apps: caché por tamaño (16 MB) y 2 hilos de fondo con una sola cola. Lo que se ve va primero; el resto se prepara antes de abrir el panel.
    private val appIcons = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val iconQueue = java.util.ArrayDeque<String>()
    private val iconQueued = HashSet<String>()
    private val iconLock = java.lang.Object()
    private var iconWorkers = 0
    @Volatile private var iconsOn = true
    private val iconNotify = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var appRows: List<AppRow>? = null          // última lista de apps (ya ordenada): el panel la muestra al instante
    private var onIconsReady: (() -> Unit)? = null
    private var appsStop: (() -> Unit)? = null                   // limpia lo que el panel «Apps» dejó pendiente al cerrarse

    private fun startIconWorkers() {
        synchronized(iconLock) {
            if (iconWorkers > 0) return
            iconWorkers = 2
        }
        repeat(2) {
            Thread {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                while (iconsOn) {
                    var pkg: String? = null
                    synchronized(iconLock) {
                        while (iconQueue.isEmpty() && iconsOn) { try { iconLock.wait() } catch (e: InterruptedException) { iconsOn = false } }
                        if (iconsOn) { pkg = iconQueue.pollFirst(); pkg?.let { iconQueued.remove(it) } }
                    }
                    val k = pkg ?: continue
                    if (appIcons.get(k) != null) continue
                    val bm = loadAppIcon(k) ?: continue
                    appIcons.put(k, bm)
                    if (iconNotify.compareAndSet(false, true)) ui.postDelayed({ iconNotify.set(false); onIconsReady?.invoke() }, 90L)
                }
            }.apply { isDaemon = true }.start()
        }
    }

    private fun requestIcon(pkg: String, front: Boolean) {
        synchronized(iconLock) {
            if (iconQueued.add(pkg)) { if (front) iconQueue.addFirst(pkg) else iconQueue.addLast(pkg) }
            else if (front) { iconQueue.remove(pkg); iconQueue.addFirst(pkg) }
            iconLock.notifyAll()
        }
    }

    private fun queryAppRows(): List<AppRow> = try {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(main, 0)
            .map { AppRow(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    } catch (e: Exception) { emptyList() }

    /** Prepara en segundo plano la lista de apps y pone sus íconos en cola. [done] se llama en el hilo principal. */
    private fun warmApps(done: ((List<AppRow>) -> Unit)? = null) {
        startIconWorkers()
        Thread {
            val out = queryAppRows()
            if (out.isNotEmpty()) { appRows = out; out.forEach { requestIcon(it.pkg, false) } }
            if (done != null) ui.post { done(out) }
        }.apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 }.start()
    }

    private var musicLp: WindowManager.LayoutParams? = null
    private var musicTick: Runnable? = null
    private var slotsClosedAt = 0L
    private var appsLp: WindowManager.LayoutParams? = null
    private var slotsSphereLeft = true                // la esfera queda a la izquierda de las casillas (ellas a la derecha)
    private var working = false                       // optimizando o borrando caché: un toque a la vez
    private var musicFolders: List<CatFolder>? = null
    private var curFolder: File? = null               // carpeta abierta en el reproductor (sobrevive al girar el teléfono)
    private var curSongs: List<File> = emptyList()
    private var screenW = 0
    private var screenH = 0
    private var landscape = false
    private var lastTapAt = 0L
    private var pendingOpen: Runnable? = null
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)     // carga de miniaturas del panel de música
    private val folderThumbs = LruCache<String, Bitmap>(24)
    private val noCover = HashSet<String>()

    // ── movimiento ──
    private var px = 0f
    private var py = 0f
    private var vx = 0f
    private var vy = 0f
    private var tx = 0f
    private var ty = 0f
    private var hasTarget = false
    private var idleUntil = 0L
    private var tripSpeed = 80f
    private var dirX = 1f
    private var dirY = 0f
    private var spd = 0f
    private var stretchVel = 0f
    private var dragging = false
    private var pressed = false        // dedo encima: se queda quieto para que el toque no se le escape
    private var lastNs = 0L
    private var area = intArrayOf(0, 0, 0, 0)       // minX, minY, maxX, maxY de la esquina de arriba-izquierda del amigo
    private var areaFrames = 0
    private var gazeTx = 0f
    private var gazeTy = 0f
    private var gazeAt = 0L
    private var blinkAt = 0L
    private var blinkUntil = 0L
    private val rnd = java.util.Random()

    /** true = se queda quieto en una esquina; false = pasea libre. */
    private var parked: Boolean
        get() = prefs.getBoolean("park", false)
        set(v) { prefs.edit().putBoolean("park", v).apply() }
    /** true = fijo: no se mueve ni se deja arrastrar hasta que le des dos toques otra vez. */
    private var frozen: Boolean
        get() = prefs.getBoolean("frozen", false)
        set(v) { prefs.edit().putBoolean("frozen", v).apply() }
    private var corner: Int
        get() = prefs.getInt("corner", 3)
        set(v) { prefs.edit().putInt("corner", v).apply() }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun params(outside: Boolean, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (outside) WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH else 0),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun shape(color: Int, radius: Int, stroke: Int, dashed: Boolean = false): Drawable =
        CutBg(color, stroke, radius * 0.8f, dp(1).toFloat())

    /** Fondo con onda al tocar: da respuesta inmediata en los botones de las barras de los paneles flotantes. */
    private fun pressable(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), content, CutBg(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), dp(10) * 0.8f, dp(1).toFloat()))

    /** Al pulsar, el botón se encoge un poco y vuelve al soltar. */
    private fun pressFx(v: View) {
        v.stateListAnimator = StateListAnimator().apply {
            val down = AnimatorSet().apply {
                playTogether(ObjectAnimator.ofFloat(v, View.SCALE_X, 0.9f), ObjectAnimator.ofFloat(v, View.SCALE_Y, 0.9f))
                duration = 80L
            }
            val up = AnimatorSet().apply {
                playTogether(ObjectAnimator.ofFloat(v, View.SCALE_X, 1f), ObjectAnimator.ofFloat(v, View.SCALE_Y, 1f))
                duration = 120L
            }
            addState(intArrayOf(android.R.attr.state_pressed), down)
            addState(intArrayOf(), up)
        }
    }

    // ── Avisos propios ──
    // El Toast del sistema no se puede estilizar desde un servicio (Android 11+) y salía gris translúcido sobre cualquier app.
    // Este aviso es una ventana propia: fondo oscuro casi opaco, borde claro y sombra, siempre del lado contrario al panel abierto.

    private var toastView: View? = null
    private var toastHide: Runnable? = null
    private var avoidCenterY = -1            // centro vertical del panel «Apps» (para no taparlo con el aviso)

    private fun panelCenterY(): Int =
        if (apps != null && avoidCenterY >= 0) avoidCenterY else (musicLp?.let { it.y + it.height / 2 } ?: -1)

    private fun removeToast() {
        toastHide?.let { ui.removeCallbacks(it) }
        toastHide = null
        toastView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        toastView = null
    }

    private fun toast(s: String, largo: Boolean = false) {
        try {
            removeToast()
            val dm = ctx.resources.displayMetrics
            val sw = if (screenW > 0) screenW else dm.widthPixels
            val sh = if (screenH > 0) screenH else dm.heightPixels
            var insTop = 0
            var insBottom = 0
            try {
                val ins = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
                insTop = ins.top; insBottom = ins.bottom
            } catch (e: Exception) { }
            val pad = dp(14)
            val tv = TextView(ctx).apply {
                text = s
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                maxWidth = maxOf(dp(160), sw - dp(56))
                setPadding(dp(16), dp(11), dp(16), dp(11))
                background = GradientDrawable().apply {
                    setColor(0xFA0B0C0E.toInt())                       // casi opaco: no se confunde con la app de atrás
                    cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), 0x99FFFFFF.toInt())
                }
                elevation = dp(8).toFloat()
                alpha = 0f
            }
            val box = FrameLayout(ctx).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(pad, pad, pad, pad)
                addView(tv)
            }
            val cy = panelCenterY()
            val atBottom = cy in 0 until sh / 2                       // panel arriba → aviso abajo; en cualquier otro caso, arriba
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = (if (atBottom) Gravity.BOTTOM else Gravity.TOP) or Gravity.CENTER_HORIZONTAL
            p.y = if (atBottom) insBottom + dp(16) else insTop + dp(4)
            wm.addView(box, p)
            toastView = box
            tv.animate().alpha(1f).setDuration(140L).start()
            val hide = Runnable {
                tv.animate().alpha(0f).setDuration(160L).withEndAction { if (toastView === box) removeToast() }.start()
            }
            toastHide = hide
            ui.postDelayed(hide, if (largo) 4200L else 2400L)
        } catch (e: Exception) { }
    }

    // ── Pantalla utilizable ──

    private fun computeArea(): IntArray {
        return try {
            val m = wm.currentWindowMetrics
            val b = m.bounds
            val ins = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
            screenW = b.width(); screenH = b.height()
            intArrayOf(0, ins.top + dp(4), maxOf(0, b.width() - size), maxOf(ins.top + dp(4), b.height() - ins.bottom - size - dp(4)))
        } catch (e: Exception) {
            val d = ctx.resources.displayMetrics
            screenW = d.widthPixels; screenH = d.heightPixels
            intArrayOf(0, 0, maxOf(0, d.widthPixels - size), maxOf(0, d.heightPixels - size))
        }
    }

    private fun cornerX(i: Int): Float = (if (i and 1 == 0) area[0] + dp(6) else area[2] - dp(6)).toFloat()
    private fun cornerY(i: Int): Float = (if (i and 2 == 0) area[1] + dp(6) else area[3] - dp(6)).toFloat()

    private fun nearestCorner(): Int {
        val midX = (area[0] + area[2]) / 2f
        val midY = (area[1] + area[3]) / 2f
        return (if (px < midX) 0 else 1) or (if (py < midY) 0 else 2)
    }

    // ── Mostrar y ocultar ──

    fun show() {
        if (!Settings.canDrawOverlays(ctx)) return
        if (bubble != null) return
        area = computeArea()
        areaFrames = 12
        landscape = screenW > screenH
        val v = BubbleView(ctx)
        val p = params(false, size, size)
        px = prefs.getInt("x", area[2] - dp(8)).coerceIn(area[0], area[2]).toFloat()
        py = prefs.getInt("y", (area[1] + area[3]) / 3).coerceIn(area[1], area[3]).toFloat()
        p.x = px.roundToInt()
        p.y = py.roundToInt()
        vx = 0f; vy = 0f; hasTarget = false; dragging = false; pressed = false; lastNs = 0L
        idleUntil = SystemClock.uptimeMillis() + 1200L

        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f; var moved = false; var slid = false
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pressed = true; vx = 0f; vy = 0f; hasTarget = false      // deja de caminar al instante
                    downX = ev.rawX; downY = ev.rawY; startX = px; startY = py; moved = false; slid = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!moved && !slid && hypot(dx, dy) > slop) {
                        if (frozen) slid = true                 // fijo: no se deja arrastrar
                        else { moved = true; dragging = true; hasTarget = false }
                    }
                    if (moved) {
                        px = (startX + dx).coerceIn(area[0].toFloat(), area[2].toFloat())
                        py = (startY + dy).coerceIn(area[1].toFloat(), area[3].toFloat())
                    }
                }
                MotionEvent.ACTION_UP -> {
                    pressed = false
                    if (moved) endDrag() else if (!slid) onTap()
                    moved = false; slid = false
                }
                MotionEvent.ACTION_CANCEL -> { pressed = false; if (moved) endDrag(); moved = false; slid = false }
            }
            true
        }
        try {
            wm.addView(v, p)
            bubble = v
            bubbleLp = p
            Choreographer.getInstance().postFrameCallback(frame)
        } catch (e: Exception) {
            // Sin permiso o Android no lo permite ahora: simplemente no se muestra.
        }
    }

    fun hide() {
        quitarEsfera()
    }

    /** El servicio se apaga del todo. */
    fun shutdown() {
        removeToast()
        hide()
        job.cancel()
        iconsOn = false
        synchronized(iconLock) { iconLock.notifyAll() }
    }

    private fun quitarEsfera() {
        Choreographer.getInstance().removeFrameCallback(frame)
        pendingOpen?.let { ui.removeCallbacks(it) }
        pendingOpen = null
        closeSlots()
        closeMusic()
        closeApps()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        bubbleLp = null
    }

    /** Los almacenamientos montados, sin depender de la app: lo usa el mini reproductor cuando la actividad no existe. */
    private fun volumenesPropios(): List<Vol> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        return sm.storageVolumes
            .filter { it.state == Environment.MEDIA_MOUNTED }
            .mapNotNull { v -> v.directory?.let { Vol(if (v.isPrimary) "Almacenamiento primordial" else "Tarjeta SD", it, 1L, 0L) } }
    }

    private fun endDrag() {
        dragging = false
        vx = 0f; vy = 0f
        idleUntil = SystemClock.uptimeMillis() + 2500L
        if (parked) corner = nearestCorner()
        saveSpot()
    }

    /**
     * Un toque abre las casillas (se espera un instante por si es doble toque).
     * Dos toques seguidos: el amigo se queda fijo; otros dos toques y vuelve a moverse.
     */
    private fun onTap() {
        val t = SystemClock.uptimeMillis()
        val dbl = ViewConfiguration.getDoubleTapTimeout().toLong()
        if (t - lastTapAt < dbl) {
            lastTapAt = 0L
            pendingOpen?.let { ui.removeCallbacks(it) }
            pendingOpen = null
            closeSlots()
            val nowFrozen = !frozen
            frozen = nowFrozen
            if (!nowFrozen) idleUntil = t + 800L
            toast(if (nowFrozen) "Quedé fijo · dos toques para soltarme" else "¡Libre otra vez!")
            return
        }
        lastTapAt = t
        if (slots != null) { closeSlots(); return }
        if (music != null || apps != null) return                   // el reproductor y el panel de apps se cierran con su ✕
        if (t - slotsClosedAt < 300) return                         // el toque que cerró las casillas no las reabre
        val r = Runnable { pendingOpen = null; if (slots == null && music == null && apps == null) openSlots() }
        pendingOpen = r
        ui.postDelayed(r, dbl)
    }

    /** El teléfono giró: los paneles abiertos se rehacen con la forma de la nueva orientación. */
    private fun onRotate() {
        if (music != null) { closeMusic(false); openMusic() }
        else if (apps != null) { closeApps(); openApps() }
        else if (slots != null) { closeSlots(); openSlots() }
    }

    private fun saveSpot() {
        prefs.edit().putInt("x", px.roundToInt()).putInt("y", py.roundToInt()).apply()
    }

    // ── El bucle de animación: un paso por cada cuadro de pantalla ──

    private var skipFrame = false

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val b = bubble ?: return
            val p = bubbleLp ?: return
            // Quieto, sin arrastre y sin música basta con la mitad de los cuadros: el amigo sigue vivo y gasta menos batería.
            val calm = !dragging && spd < 12f * dens && Musica.actual()?.playing != true
            skipFrame = calm && !skipFrame
            if (!skipFrame) {
                try { step(b, p, frameTimeNanos) } catch (e: Exception) { }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    /** Camina hacia (tx, ty). Devuelve true si ya llegó. */
    private fun travel(dt: Float, now: Long, curvy: Boolean): Boolean {
        val dx0 = tx - px
        val dy0 = ty - py
        val dist = hypot(dx0, dy0)
        if (dist < 6f * dens) { vx = 0f; vy = 0f; return true }
        val maxSp = tripSpeed * dens
        val slow = (dist / (70f * dens)).coerceIn(0.25f, 1f)
        val k = (dt * 3f).coerceAtMost(1f)
        val bend = if (curvy) sin(now / 650f) * 0.7f * (dist / (160f * dens)).coerceIn(0f, 1f) else 0f
        val ux = dx0 / dist
        val uy = dy0 / dist
        val cb = cos(bend)
        val sb = sin(bend)
        val dx = ux * cb - uy * sb
        val dy = ux * sb + uy * cb
        vx += (dx * maxSp * slow - vx) * k
        vy += (dy * maxSp * slow - vy) * k
        px += vx * dt
        py += vy * dt
        return false
    }

    private fun step(b: BubbleView, p: WindowManager.LayoutParams, ns: Long) {
        val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastNs = ns
        val now = ns / 1_000_000L
        if (--areaFrames <= 0) {
            area = computeArea(); areaFrames = 12
            val land = screenW > screenH
            if (land != landscape) { landscape = land; onRotate() }
        }

        val ox = px
        val oy = py
        val busy = slots != null || music != null || apps != null
        if (!dragging && !pressed) {
            if (frozen) {
                hasTarget = false; vx = 0f; vy = 0f
            } else if (busy) {
                // Con un panel abierto se queda quietecito al lado.
                hasTarget = false; vx = 0f; vy = 0f
            } else if (parked) {
                tx = cornerX(corner); ty = cornerY(corner)
                tripSpeed = 170f
                if (travel(dt, now, false)) { px = tx; py = ty }
            } else if (now >= idleUntil) {
                if (!hasTarget) {
                    val mx = maxOf(1, area[2] - area[0])
                    val my = maxOf(1, area[3] - area[1])
                    var cx = 0f; var cy = 0f
                    for (i in 0 until 5) {
                        cx = area[0] + rnd.nextFloat() * mx
                        cy = area[1] + rnd.nextFloat() * my
                        if (hypot(cx - px, cy - py) > 140f * dens) break
                    }
                    tx = cx; ty = cy; hasTarget = true
                }
                if (travel(dt, now, true)) {
                    hasTarget = false
                    idleUntil = now + 1200L + rnd.nextInt(3200)
                    tripSpeed = 60f + rnd.nextFloat() * 90f
                    saveSpot()
                }
            }
        }
        px = px.coerceIn(area[0].toFloat(), area[2].toFloat())
        py = py.coerceIn(area[1].toFloat(), area[3].toFloat())

        // velocidad y dirección reales de este cuadro
        val mvx = px - ox
        val mvy = py - oy
        val len = hypot(mvx, mvy)
        spd += (len / dt - spd) * (dt * 12f).coerceAtMost(1f)
        if (len > 0.01f) {
            val kk = (dt * 10f).coerceAtMost(1f)
            dirX += (mvx / len - dirX) * kk
            dirY += (mvy / len - dirY) * kk
        }
        b.angle = atan2(dirY, dirX)

        // gelatina: estira al ir rápido y rebota al parar
        val tgt = (spd / dens / 900f).coerceIn(0f, 0.30f)
        stretchVel += ((tgt - b.stretch) * 220f - stretchVel * 13f) * dt
        b.stretch = (b.stretch + stretchVel * dt).coerceIn(-0.45f, 0.5f)

        // mirada: hacia donde va; quieto, curiosea
        val moving = spd > 12f * dens
        if (moving) {
            gazeTx = dirX * 0.9f; gazeTy = dirY * 0.7f; gazeAt = now + 600L
        } else if (now >= gazeAt) {
            gazeTx = (rnd.nextFloat() * 2f - 1f) * 0.9f
            gazeTy = (rnd.nextFloat() * 2f - 1f) * 0.5f
            gazeAt = now + 1400L + rnd.nextInt(2800)
        }
        val kg = (dt * 4.5f).coerceAtMost(1f)
        b.lookX += (gazeTx - b.lookX) * kg
        b.lookY += (gazeTy - b.lookY) * kg

        // parpadeo
        if (now >= blinkAt) { blinkUntil = now + 130L; blinkAt = now + 2500L + rnd.nextInt(3500) }
        b.open = if (now < blinkUntil) 0.12f else 1f

        // respiración, baile con la música y tamaño al agarrarlo
        val playing = Musica.actual()?.playing == true
        b.playing = playing
        b.frozen = frozen
        b.bob = sin(now / (if (playing) 330.0 else 800.0)).toFloat() * 0.5f
        b.noteT = ((now % 1600L) / 1600f)
        // animación del momento: agarrado (3) > suena música (2) > andando (1) > quieto (0)
        gestos.update(b.pose, now, if (dragging || pressed) 3 else if (playing) 2 else if (moving) 1 else 0)
        b.grow += ((if (dragging) 1.12f else 1f) - b.grow) * (dt * 12f).coerceAtMost(1f)

        val ix = px.roundToInt()
        val iy = py.roundToInt()
        if (ix != p.x || iy != p.y) {
            p.x = ix; p.y = iy
            try { wm.updateViewLayout(b, p) } catch (e: Exception) { }
            if (busy) reposition()
        }
        b.invalidate()
    }

    // ── Colocar los paneles junto a la esfera (debajo si cabe, si no arriba) ──

    private fun position(v: View, p: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val sh = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels
        val wSpec = if (p.width > 0) View.MeasureSpec.makeMeasureSpec(p.width, View.MeasureSpec.EXACTLY)
                    else View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        v.measure(wSpec, View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val pw = v.measuredWidth
        val ph = v.measuredHeight
        val gap = dp(4)
        val below = b.y + size + gap + ph <= sh
        val above = b.y - gap - ph >= 0
        if (below || above) {
            p.x = (b.x + size / 2 - pw / 2).coerceIn(0, maxOf(0, sw - pw))
            p.y = if (below) b.y + size + gap else b.y - gap - ph
        } else {
            // pantalla horizontal: al costado de la esfera
            p.x = (if (b.x + size + gap + pw <= sw) b.x + size + gap else b.x - gap - pw).coerceIn(0, maxOf(0, sw - pw))
            p.y = (b.y + size / 2 - ph / 2).coerceIn(0, maxOf(0, sh - ph))
        }
    }

    private fun reposition() {
        (slots as? SlotsRoot)?.let { v -> slotsLp?.let { p -> positionSlots(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
        music?.let { v -> musicLp?.let { p -> position(v, p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } } }
    }

    // ── La casilla ──

    private fun togglePanel() {
        if (music != null || apps != null) return       // el reproductor y el panel de apps se cierran con su ✕
        if (slots != null) { closeSlots(); return }
        if (SystemClock.uptimeMillis() - slotsClosedAt < 300) return   // el toque que lo cerró fuera no lo reabre
        openSlots()
    }

    /**
     * Casilla «Teclado»: el teclado propio solo puede sustituir al del teléfono si el sistema lo permite, así que se guía en dos pasos:
     * 1) encenderlo en la lista de teclados; 2) elegirlo en el selector (el mismo selector sirve luego para volver al de siempre).
     */
    private fun tecladoCasilla(v: ActionSlotView) {
        closeSlots()
        try {
            if (!Teclado.habilitado(ctx)) {
                toast("Enciende «Teclado Archivero» en la lista y vuelve a tocar la casilla", true)
                Teclado.abrirAjustes(ctx)
            } else {
                toast(if (Teclado.activo(ctx)) "Elige tu teclado de siempre para salir del de Archivero" else "Elige «Teclado Archivero»", true)
                Teclado.elegir(ctx)
            }
        } catch (e: Exception) { toast("No pude abrir los ajustes del teclado") }
    }

    private fun slot(kind: Int, label: String, sub: String, onClick: (ActionSlotView) -> Unit): ActionSlotView = ActionSlotView(ctx, kind, label, sub).apply {
        layoutParams = LinearLayout.LayoutParams(dp(140), dp(46)).apply { setMargins(0, dp(5), 0, dp(5)) }
        setOnClickListener { onClick(this) }
    }

    /** Las casillas van a un lado de la esfera (el lado con más sitio), en columna y unidas a ella por líneas finas. */
    private fun positionSlots(root: SlotsRoot, p: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val sh = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels
        root.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val pw = root.measuredWidth
        val ph = root.measuredHeight
        val cy = b.y + size / 2
        val left = slotsSphereLeft
        p.x = (if (left) b.x + size - dp(6) else b.x - pw + dp(6)).coerceIn(0, maxOf(0, sw - pw))
        p.y = (cy - ph / 2).coerceIn(0, maxOf(0, sh - ph))
        root.originX = ((if (left) b.x + size - dp(5) else b.x + dp(5)) - p.x).toFloat()
        root.originY = (cy - p.y).toFloat()
        root.invalidate()
    }

    private fun openSlots() {
        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val bx = bubbleLp?.x ?: 0
        slotsSphereLeft = (sw - (bx + size)) >= bx          // hay más sitio a la derecha de la esfera
        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(slot(0, "Música", "reproductor") { openMusic() })                       // mini reproductor
            addView(slot(1, "Optimizar", "liberar memoria") { v -> optimizarTelefono(v) })   // cierra apps de fondo
            addView(slot(2, "Teclado", "escribir y corregir") { v -> tecladoCasilla(v) }.also {   // teclado propio con corrector
                it.active = Teclado.activo(ctx)
                if (it.active) it.status = "activo · toca para cambiar"
            })
        }
        val gutter = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(dp(26), 1) }
        val row = SlotsRoot(ctx, slotsSphereLeft).apply {
            orientation = LinearLayout.HORIZONTAL
            this.column = column
            if (slotsSphereLeft) { addView(gutter); addView(column) } else { addView(column); addView(gutter) }
            setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) { closeSlots() }
                false
            }
        }
        val p = params(true, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        positionSlots(row, p)
        try { wm.addView(row, p); slots = row; slotsLp = p } catch (e: Exception) { }
    }

    /** Casilla «Optimizar»: cierra las apps que están en segundo plano y dice cuánta memoria (RAM) quedó libre. */
    private fun optimizarTelefono(v: ActionSlotView) {
        if (working) return
        working = true
        scope.launch {
            try {
                v.active = true
                v.status = "optimizando…"
                val r = Optimizador.optimizar(ctx)
                v.status = when {
                    r.apps == 0 -> "nada que cerrar"
                    r.liberada > 0L -> "${fmtSize(r.liberada)} de RAM libres"
                    else -> "${r.apps} apps cerradas"
                }
                delay(3200)
            } finally {
                working = false
                v.active = false
                v.status = null
            }
        }
    }

    private fun closeSlots() {
        slots?.let { try { wm.removeView(it) } catch (e: Exception) { } ; slotsClosedAt = SystemClock.uptimeMillis() }
        slots = null
        slotsLp = null
    }

    // ── Mini reproductor con carpetas ──

    private fun iconBtn(d: String, tint: Int, sizeDp: Int = 44, onClick: () -> Unit): FloatIconView = FloatIconView(ctx, d, tint).apply {
        val s = dp(sizeDp)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(3), 0, dp(3), 0) }
        background = pressable(shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt()))
        pressFx(this)
        setOnClickListener { onClick() }
    }

    /** Alterna entre pasear libre por la pantalla y quedarse en la esquina (antes era el botón 📌/🫧; ahora: mantener pulsado "Música"). */
    private fun toggleMode() {
        val nowParked = !parked
        parked = nowParked
        if (nowParked) corner = nearestCorner()
        toast(if (nowParked) "Me quedo en la esquina" else "Paseo libre por la pantalla")
    }

    /** Portada de una carpeta: imagen típica (cover/folder…) o, si no hay, la carátula de la primera canción que tenga. */
    private suspend fun folderCover(dir: File): Bitmap? {
        folderThumbs.get(dir.path)?.let { return it }
        if (dir.path in noCover) return null
        val b: Bitmap? = withContext(Dispatchers.IO) {
            val files = (dir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.startsWith(".") }
            var bmp: Bitmap? = null
            val img = files.firstOrNull { kindOf(it) == Kind.IMG && it.nameWithoutExtension.lowercase() in COVER_NAMES }
            if (img != null) bmp = Thumbs.load(ctx, img, Kind.IMG)
            if (bmp == null) {
                for (f in files.filter { kindOf(it) == Kind.AUD }.sortedBy { it.name.lowercase() }.take(6)) {
                    bmp = Thumbs.load(ctx, f, Kind.AUD)
                    if (bmp != null) break
                }
            }
            bmp
        }
        if (b != null) folderThumbs.put(dir.path, b) else noCover.add(dir.path)
        return b
    }

    private fun musicBtn(label: String, sizeDp: Int = 44, onClick: () -> Unit): TextView = TextView(ctx).apply {
        val s = dp(sizeDp)
        layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(3), 0, dp(3), 0) }
        gravity = Gravity.CENTER
        textSize = 18f
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        background = pressable(shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt()))
        pressFx(this)
        setOnClickListener { onClick() }
    }

    private fun openMusic() {
        closeSlots()
        val store = FriendLink.store
        fun player(): MusicPlayer? = Musica.get(ctx)      // el mismo reproductor de la app: funciona aunque la actividad ya no exista

        val sw = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
        val sh = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels
        val land = sw > sh
        val panelW = if (land) min(dp(520), sw - dp(24)) else min(dp(272), sw - dp(16))
        val listH = if (land) min(dp(150), maxOf(dp(80), sh - dp(150))) else min(dp(190), maxOf(dp(80), sh - dp(300)))
        val rows = ArrayList<MusicRow>()
        var shownCurrent: String? = null

        // ── cabecera: título, paseo/esquina y ✕ ──
        // Repetir: con un toque, la canción que suena se repite sin parar; otro toque y la música sigue normal.
        val repBtn = iconBtn(FIco.REPEAT, 0xFFB0B0B0.toInt(), 36) { }
        var repShown: Boolean? = null
        fun paintRepeat() {
            val on = player()?.repeatOne == true
            if (repShown == on) return                       // solo se redibuja si cambió (se llama cada 300 ms)
            repShown = on
            repBtn.icon(if (on) FIco.REPEAT_ONE else FIco.REPEAT, if (on) 0xFFD5D9E0.toInt() else 0xFFB0B0B0.toInt())
            repBtn.background = if (on) shape(0xFF2A2D33.toInt(), dp(10), 0xFFD5D9E0.toInt()) else shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt())
        }
        repBtn.setOnClickListener {
            val m = player()
            if (m == null) {
                toast("Primero elige una canción")
            } else {
                m.setRepeat(!m.repeatOne)
                paintRepeat()
                toast(if (m.repeatOne) "Repetir canción: activado" else "Repetir canción: desactivado")
            }
        }
        val closeBtn = musicBtn("✕", 36) { closeMusic() }      // quita solo el panel; la música sigue
        closeBtn.setTextColor(0xFFD5D9E0.toInt())
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(View(ctx).apply {
                setBackgroundColor(0xFFD5D9E0.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(3), dp(14)).apply { setMargins(dp(4), 0, dp(8), 0) }
            })
            addView(TextView(ctx).apply {
                text = "MÚSICA"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.14f
                setOnLongClickListener { toggleMode(); true }      // mantener pulsado: pasear libre / quedarse en la esquina
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(repBtn)
            addView(closeBtn)
        }

        // ── ahora suena ──
        val title = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }
        val progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(0xFFD5D9E0.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0xFF2A2D33.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4))
        }
        val play = iconBtn(FIco.PLAY, 0xFFD5D9E0.toInt()) { player()?.toggle() }
        val buttons = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
            addView(iconBtn(FIco.PREV, 0xFFFFFFFF.toInt()) { player()?.prev() })
            addView(play)
            addView(iconBtn(FIco.NEXT, 0xFFFFFFFF.toInt()) { player()?.next() })
        }

        // ── carpetas y canciones ──
        val crumb = TextView(ctx).apply {
            setTextColor(0xFF8D939C.toInt())
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val list = ListView(ctx)
        val adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
                val row = (convert as? LinearLayout) ?: LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val th = FloatThumbView(ctx).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) }
                    }
                    val tv = TextView(ctx).apply {
                        textSize = 13f
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    addView(th)
                    addView(tv)
                }
                val th = row.getChildAt(0) as FloatThumbView
                val tv = row.getChildAt(1) as TextView
                val r = rows[i]
                val playingNow = r.kind == 2 && r.tag == player()?.current?.path
                val withThumb = r.kind == 1 || r.kind == 2
                row.setPadding(if (withThumb) dp(6) else dp(10), if (withThumb) dp(6) else dp(9), dp(10), if (withThumb) dp(6) else dp(9))
                th.visibility = if (withThumb) View.VISIBLE else View.GONE
                if (r.kind == 1) {
                    // Nombre arriba y, debajo en pequeño, cuántas canciones y en qué almacenamiento (ya no se corta).
                    val t1 = r.label
                    val t2 = r.sub
                    if (t2.isNullOrEmpty()) tv.text = t1 else {
                        val sp = SpannableString(t1 + "\n" + t2)
                        sp.setSpan(RelativeSizeSpan(0.82f), t1.length + 1, sp.length, 0)
                        sp.setSpan(ForegroundColorSpan(0xFF8D939C.toInt()), t1.length + 1, sp.length, 0)
                        tv.text = sp
                    }
                } else {
                    tv.text = r.label
                }
                tv.setTextColor(if (playingNow) 0xFF0B0C0E.toInt() else if (r.kind == 3) 0xFF8D939C.toInt() else 0xFFFFFFFF.toInt())
                row.background = if (!withThumb) null
                    else if (playingNow) shape(0xFFD5D9E0.toInt(), dp(10), 0xFFFFFFFF.toInt())
                    else shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt())
                if (withThumb) {
                    val path = r.tag ?: ""
                    th.placeholder = if (r.kind == 1) FIco.FOLDER else FIco.NOTE
                    th.playing = playingNow
                    if (th.key != path) {
                        th.key = path
                        th.setBitmap(null)
                        val hit: Bitmap? = if (r.kind == 2) Thumbs.cached(path) else folderThumbs.get(path)
                        if (hit != null) {
                            th.setBitmap(hit)
                        } else if (!(r.kind == 2 && Thumbs.hasFailed(path)) && !(r.kind == 1 && path in noCover)) {
                            val isSong = r.kind == 2
                            scope.launch {
                                val bm: Bitmap? = if (isSong) Thumbs.load(ctx, File(path), Kind.AUD) else folderCover(File(path))
                                if (bm != null && th.key == path) th.setBitmap(bm)      // si la fila ya se reutilizó para otra, no se pisa
                            }
                        }
                    }
                }
                return row
            }
        }
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = dp(4)
        list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH)

        // Vertical: todo apilado. Horizontal: controles a la izquierda y carpetas/canciones a la derecha.
        val box = LinearLayout(ctx).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(0xFF0E1013.toInt(), dp(14), 0xFF2A2D33.toInt())
            if (!land) {
                orientation = LinearLayout.VERTICAL
                addView(header)
                addView(title)
                addView(progress)
                addView(buttons)
                addView(crumb)
                addView(list)
            } else {
                orientation = LinearLayout.HORIZONTAL
                val left = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams((panelW * 0.42f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
                    addView(header)
                    addView(title)
                    addView(progress)
                    addView(buttons)
                }
                val right = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(10), 0, 0, 0) }
                    addView(crumb)
                    addView(list)
                }
                addView(left)
                addView(right)
            }
        }

        fun fillFolders(fs: List<CatFolder>) {
            rows.clear()
            if (fs.isEmpty()) rows.add(MusicRow("No encontré música en este equipo", null, null, 3))
            for (f in fs.sortedBy { it.dir.name.lowercase() }) {
                val n = f.files
                rows.add(MusicRow(f.dir.name, "$n " + (if (n == 1) "canción" else "canciones") + (if (f.vol.isNotEmpty()) " · " + f.vol else ""), f.dir.path, 1))
            }
            adapter.notifyDataSetChanged()
        }

        fun showFolders() {
            curFolder = null
            curSongs = emptyList()
            crumb.text = "CARPETAS DE MÚSICA"
            val cached: List<CatFolder>? = (try { store?.catCache?.get(HomeTab.MUSIC)?.folders } catch (e: Exception) { null }) ?: musicFolders
            if (cached != null) {
                fillFolders(cached)
            } else {
                rows.clear(); rows.add(MusicRow("Buscando música…", null, null, 3)); adapter.notifyDataSetChanged()
                Thread {
                    val r: List<CatFolder> = try { mediaStoreTab(ctx, store?.vols ?: volumenesPropios(), HomeTab.MUSIC).folders } catch (e: Exception) { emptyList() }
                    ui.post {
                        musicFolders = r
                        if (music === box && curFolder == null) fillFolders(r)
                    }
                }.start()
            }
        }

        fun openFolder(dir: File) {
            curFolder = dir
            crumb.text = "‹  " + dir.name.uppercase()
            rows.clear(); rows.add(MusicRow("Cargando…", null, null, 3)); adapter.notifyDataSetChanged()
            Thread {
                val fs: List<File> = try {
                    (dir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.startsWith(".") && kindOf(it) == Kind.AUD }
                        .sortedBy { it.name.lowercase() }
                } catch (e: Exception) { emptyList() }
                ui.post {
                    if (music === box && curFolder == dir) {
                        curSongs = fs
                        rows.clear()
                        if (fs.isEmpty()) rows.add(MusicRow("Esta carpeta no tiene canciones", null, null, 3))
                        fs.forEachIndexed { i, f -> rows.add(MusicRow(f.nameWithoutExtension, null, f.path, 2, i)) }
                        adapter.notifyDataSetChanged()
                    }
                }
            }.start()
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            val r = rows.getOrNull(pos) ?: return@setOnItemClickListener
            when (r.kind) {
                1 -> r.tag?.let { openFolder(File(it)) }
                2 -> { player()?.start(curSongs, r.idx); adapter.notifyDataSetChanged() }
            }
        }
        crumb.setOnClickListener { if (curFolder != null) showFolders() }

        val tick = object : Runnable {
            override fun run() {
                val m = player()
                m?.tick()
                title.text = m?.current?.nameWithoutExtension ?: "Elige una carpeta y una canción"
                play.icon(if (m != null && m.playing) FIco.PAUSE else FIco.PLAY, 0xFFD5D9E0.toInt())
                paintRepeat()
                progress.progress = if (m != null && m.duration > 0) (m.position * 1000L / m.duration).toInt() else 0
                val cur = m?.current?.path
                if (cur != shownCurrent) { shownCurrent = cur; adapter.notifyDataSetChanged() }
                ui.postDelayed(this, 300)
            }
        }
        val p = params(false, panelW, WindowManager.LayoutParams.WRAP_CONTENT)
        try {
            wm.addView(box, p)
            music = box
            musicLp = p
            musicTick = tick
        } catch (e: Exception) {
            return
        }
        // Al girar el teléfono el panel se rehace y vuelve a la carpeta que estaba abierta.
        val back = curFolder
        if (back != null) openFolder(back) else showFolders()
        tick.run()
        position(box, p)
        try { wm.updateViewLayout(box, p) } catch (e: Exception) { }
    }

    // ── Panel «Apps»: todas las apps del teléfono. Al tocar una se abre en una ventana del tamaño del panel ──

    private fun scrW() = if (screenW > 0) screenW else ctx.resources.displayMetrics.widthPixels
    private fun scrH() = if (screenH > 0) screenH else ctx.resources.displayMetrics.heightPixels

    private fun loadAppIcon(pkg: String): Bitmap? = try {
        val d = ctx.packageManager.getApplicationIcon(pkg)
        val s = dp(40)
        val bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(bm))
        bm
    } catch (e: Exception) { null }

    /** Coloca una ventana de tamaño ya fijado junto a la esfera: debajo si cabe, si no arriba, si no al costado. */
    private fun placeBox(p: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val sw = scrW()
        val sh = scrH()
        val gap = dp(4)
        val pw = p.width
        val ph = p.height
        val below = b.y + size + gap + ph <= sh
        val above = b.y - gap - ph >= 0
        if (below || above) {
            p.x = (b.x + size / 2 - pw / 2).coerceIn(0, maxOf(0, sw - pw))
            p.y = if (below) b.y + size + gap else b.y - gap - ph
        } else {
            p.x = (if (b.x + size + gap + pw <= sw) b.x + size + gap else b.x - gap - pw).coerceIn(0, maxOf(0, sw - pw))
            p.y = (b.y + size / 2 - ph / 2).coerceIn(0, maxOf(0, sh - ph))
        }
    }

    /** ¿El teléfono puede abrir apps en ventanas flotantes (lo único que deja meter una app dentro del mini panel)? */
    private fun freeformReady(): Boolean = try {
        ctx.packageManager.hasSystemFeature("android.software.freeform_window_management") ||
            Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1
    } catch (e: Exception) { false }

    /** Si una vez se concedió el permiso WRITE_SECURE_SETTINGS (por adb), las ventanas flotantes se activan solas; si no, devuelve false. */
    private fun tryEnableFreeform(): Boolean = try {
        val cr = ctx.contentResolver
        Settings.Global.putInt(cr, "enable_freeform_support", 1)
        Settings.Global.putInt(cr, "force_resizable_activities", 1)
        true
    } catch (e: Throwable) { false }

    private fun openApps() {
        closeSlots()
        val sw = scrW()
        val sh = scrH()
        val land = sw > sh
        val minW = dp(48)
        val minH = dp(48)
        // Tamaño de partida = el del panel de música; después se recuerda el que dejes.
        val defW = if (land) min(dp(520), sw - dp(24)) else min(dp(272), sw - dp(16))
        val defH = if (land) min(dp(240), sh - dp(60)) else min(dp(370), sh - dp(120))
        // (rx, ry, rw, rh) = dónde está el panel en la pantalla.
        // Fijo: la ventana mide justo eso. Moldeando: la ventana ocupa TODA la pantalla y no cambia mientras arrastras;
        // solo se mueve/estira el panel dentro de ella (antes se cambiaba el tamaño de la ventana en cada cuadro y eso temblaba).
        var rw = prefs.getInt("appsW", defW).coerceIn(minW, maxOf(minW, sw))
        var rh = prefs.getInt("appsH", defH).coerceIn(minH, maxOf(minH, sh))
        var rx = 0
        var ry = 0
        var compact = false                 // true = solo la barra de arriba (el panel «se hace chiquito» para ver la app)
        var editing = false                 // true = moldeando el panel; false = fijo
        var dragging = false
        var curPkg: String? = null
        var curName: String? = null
        var styledEditing: Boolean? = null
        val rows = ArrayList<AppRow>()
        val p = params(false, rw, rh)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        placeBox(p)
        rx = p.x
        ry = p.y

        // ── lista de apps ──
        val list = ListView(ctx)
        val adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
                val row = (convert as? LinearLayout) ?: LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(6), dp(6), dp(10), dp(6))
                    addView(ImageView(ctx).apply { layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) } })
                    addView(TextView(ctx).apply {
                        textSize = 13f
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    })
                }
                val iv = row.getChildAt(0) as ImageView
                val tv = row.getChildAt(1) as TextView
                val r = rows[i]
                // El fondo se crea una vez por fila (antes se rehacía en cada desplazamiento).
                if (r.pkg.isEmpty()) { if (row.background != null) row.background = null }
                else if (row.background == null) row.background = pressable(shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt()))
                tv.text = r.label
                tv.setTextColor(if (r.pkg.isEmpty()) 0xFF8D939C.toInt() else 0xFFFFFFFF.toInt())
                iv.tag = r.pkg
                val hit = if (r.pkg.isEmpty()) null else appIcons.get(r.pkg)
                if (hit != null) {
                    iv.setImageBitmap(hit)
                } else {
                    iv.setImageDrawable(null)
                    if (r.pkg.isNotEmpty()) requestIcon(r.pkg, true)       // lo que se ve ahora se carga primero
                }
                return row
            }
        }
        list.adapter = adapter
        list.divider = null
        list.dividerHeight = dp(4)
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.isScrollingCacheEnabled = false
        list.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

        /** Cuando llega un ícono, solo se pone en la fila que lo espera: sin re-medir ni rehacer la lista. */
        fun refreshIcons() {
            for (k in 0 until list.childCount) {
                val row = list.getChildAt(k) as? LinearLayout ?: continue
                val iv = row.getChildAt(0) as? ImageView ?: continue
                val pkg = iv.tag as? String ?: continue
                if (pkg.isNotEmpty() && iv.drawable == null) appIcons.get(pkg)?.let { iv.setImageBitmap(it) }
            }
        }

        // ── cabecera: título, moldear, volver a la lista y ✕ ──
        val title = TextView(ctx).apply {
            text = "APPS"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.14f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val shapeBtn = iconBtn(FIco.RESIZE, 0xFFD5D9E0.toInt(), 36) { }
        val backBtn = iconBtn(FIco.APPS, 0xFFD5D9E0.toInt(), 36) { }
        backBtn.visibility = View.GONE
        val closeBtn = musicBtn("✕", 36) { closeApps() }
        closeBtn.setTextColor(0xFFD5D9E0.toInt())
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(View(ctx).apply {
                setBackgroundColor(0xFFD5D9E0.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(3), dp(14)).apply { setMargins(dp(4), 0, dp(8), 0) }
            })
            addView(title)
            addView(shapeBtn)
            addView(backBtn)
            addView(closeBtn)
        }
        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(0xFF0E1013.toInt(), dp(14), 0xFF2A2D33.toInt())
            addView(header)
            addView(list)
        }
        val editor = ShapeEditor(ctx)
        editor.visibility = View.GONE
        val panel = FrameLayout(ctx).apply {
            addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            pivotX = 0f                                                     // las transformaciones del arrastre parten de la esquina de arriba a la izquierda
            pivotY = 0f
        }
        val panelLp = FrameLayout.LayoutParams(rw, rh).apply { gravity = Gravity.TOP or Gravity.START }
        // El editor va encima del panel y ocupa toda la ventana: dibuja el recuadro por su cuenta.
        val host = FrameLayout(ctx).apply {                                  // lo que se agrega al WindowManager
            addView(panel, panelLp)
            addView(editor, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        fun curH() = if (compact && !editing) dp(56) else rh
        fun saveSize() { prefs.edit().putInt("appsW", rw).putInt("appsH", rh).apply() }
        fun clampRect() {
            rx = rx.coerceIn(0, maxOf(0, sw - rw))
            ry = ry.coerceIn(0, maxOf(0, sh - curH()))
        }
        /** Forma del panel dentro de la ventana (moldeando: su sitio en la pantalla; fijo: ocupa toda la ventana). */
        fun syncPanel() {
            panelLp.leftMargin = if (editing) rx else 0
            panelLp.topMargin = if (editing) ry else 0
            panelLp.width = rw
            panelLp.height = curH()
            panel.layoutParams = panelLp
            editor.setRect(rx, ry, rx + rw, ry + curH())
            avoidCenterY = ry + curH() / 2
        }
        /** Tamaño y sitio de la ventana: solo cambia al cambiar de modo, nunca mientras arrastras. */
        fun syncWindow() {
            if (editing) {
                p.x = 0; p.y = 0; p.width = sw; p.height = sh
            } else {
                p.x = rx; p.y = ry; p.width = rw; p.height = curH()
            }
            try { wm.updateViewLayout(host, p) } catch (e: Exception) { }
        }

        /** Aplica el modo (lista completa, solo la barra, moldeando o fijo) a la ventana y a los botones. */
        fun refit() {
            clampRect()
            list.visibility = if (compact) View.GONE else View.VISIBLE
            backBtn.visibility = if (compact && !editing) View.VISIBLE else View.GONE
            // El título dice siempre en qué modo está el panel: «MOLDEANDO» (libre para estirar) o fijo.
            title.text = if (editing) "MOLDEANDO" else if (compact) (curName ?: "APPS").uppercase() else "APPS"
            editor.visibility = if (editing) View.VISIBLE else View.GONE
            panel.alpha = if (editing && compact) 0.5f else 1f        // moldeando con una app abierta: se ve lo de atrás
            if (styledEditing != editing) {                          // el estilo del botón solo se rehace cuando cambia el modo
                styledEditing = editing
                shapeBtn.icon(FIco.RESIZE, if (editing) 0xFF0B0C0E.toInt() else 0xFFD5D9E0.toInt())
                shapeBtn.background = pressable(
                    if (editing) shape(0xFFD5D9E0.toInt(), dp(10), 0xFFFFFFFF.toInt()) else shape(0xFF16181C.toInt(), dp(10), 0xFF2A2D33.toInt())
                )
            }
            syncPanel()
            syncWindow()
        }

        /**
         * Cambio entre moldear y fijo. La ventana del sistema cambia de tamaño y de sitio, y el panel cambia su margen dentro de ella;
         * esas dos cosas las pinta el sistema en momentos distintos, y en ese cuadro el panel se veía saltar a la esquina.
         * Arreglo: 1) el panel se oculta ANTES de tocar la ventana y se espera a que ese cuadro ya esté pintado;
         * 2) se cambia la ventana y el margen; 3) se espera a que la ventana tenga de verdad su tamaño nuevo (más un par de cuadros)
         * y solo entonces el panel reaparece con un fundido corto.
         */
        var switchToken = 0
        fun fadeInPanel(token: Int) {
            if (token != switchToken || apps !== host) return
            panel.animate().cancel()
            panel.animate().alpha(if (editing && compact) 0.5f else 1f).setStartDelay(0L).setDuration(140L).start()
        }
        fun switchMode() {
            val token = ++switchToken
            panel.animate().cancel()
            panel.scaleX = 1f; panel.scaleY = 1f; panel.pivotX = 0f; panel.pivotY = 0f
            panel.alpha = 0f
            val ch = Choreographer.getInstance()
            ch.postFrameCallback { ch.postFrameCallback {
                if (token != switchToken || apps !== host) return@postFrameCallback
                var done = false
                fun finish(listener: ViewTreeObserver.OnGlobalLayoutListener?) {
                    if (done) return
                    done = true
                    if (listener != null) {
                        val vto = host.viewTreeObserver
                        if (vto.isAlive) vto.removeOnGlobalLayoutListener(listener)
                    }
                    ch.postFrameCallback { ch.postFrameCallback { fadeInPanel(token) } }
                }
                val ew = if (editing) sw else rw
                val eh = if (editing) sh else curH()
                var listener: ViewTreeObserver.OnGlobalLayoutListener? = null
                listener = ViewTreeObserver.OnGlobalLayoutListener {
                    if (host.width == ew && host.height == eh && panel.width == rw) finish(listener)
                }
                host.viewTreeObserver.addOnGlobalLayoutListener(listener!!)
                refit()
                panel.alpha = 0f                                   // refit() pone la opacidad normal: se mantiene oculto hasta que todo esté en su sitio
                // Por si la ventana ya tenía ese tamaño (no habría nuevo diseño) o el sistema tarda: nunca se queda oculto.
                host.postDelayed({ finish(listener) }, 300L)
            } }
        }

        // Durante un arrastre, como mucho UNA actualización por cuadro de pantalla.
        var framePosted = false
        // Moldeando: el panel NO se vuelve a medir mientras el dedo está abajo. Se queda con el tamaño con que empezó el gesto y solo se
        // le aplica una transformación (traslación + escala, que la GPU hace sin recalcular el diseño, con el panel en una capa de hardware).
        // El diseño definitivo (la lista con su nuevo tamaño) se aplica una sola vez, al soltar el dedo.
        var transforming = false
        var baseX = 0
        var baseY = 0
        var baseW = 1
        var baseH = 1
        val frameCb = Choreographer.FrameCallback {
            framePosted = false
            if (editing) {
                if (transforming) {
                    panel.translationX = (rx - baseX).toFloat()
                    panel.translationY = (ry - baseY).toFloat()
                    panel.scaleX = rw.toFloat() / baseW
                    panel.scaleY = rh.toFloat() / baseH
                    editor.setRect(rx, ry, rx + rw, ry + rh)
                    avoidCenterY = ry + rh / 2
                }
            } else {
                p.x = rx; p.y = ry
                avoidCenterY = ry + curH() / 2
                try { wm.updateViewLayout(host, p) } catch (e: Exception) { }
            }
        }
        fun pushFrame() { if (!framePosted) { framePosted = true; Choreographer.getInstance().postFrameCallback(frameCb) } }
        /** Al soltar: quita la transformación y aplica el tamaño final de una sola vez. */
        fun commitDrag() {
            if (!transforming) return
            transforming = false
            if (framePosted) { Choreographer.getInstance().removeFrameCallback(frameCb); framePosted = false }
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.translationX = 0f
            panel.translationY = 0f
            panel.scaleX = 1f
            panel.scaleY = 1f
            syncPanel()
        }

        /** Abre la app pidiendo una ventana del tamaño del panel (solo la respetan los teléfonos con ventanas flotantes). */
        fun launch(pkg: String) {
            val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) { toast("No puedo abrir esa app"); return }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                val opt = android.app.ActivityOptions.makeBasic()
                // La app ocupa el panel justo debajo de su barra (si el panel es muy bajito, ocupa todo).
                val barH = dp(56)
                val top = if (rh > barH + dp(96)) ry + barH else ry
                opt.setLaunchBounds(Rect(rx, top, rx + rw, ry + rh))
                // Pide explícitamente ventana flotante (5 = freeform); si el sistema no deja usar este método, se ignora.
                try { android.app.ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(opt, 5) } catch (e: Throwable) { }
                ctx.startActivity(intent, opt.toBundle())
            } catch (e: Exception) { toast("No pude abrir esa app") }
        }

        // El botón de moldear: un toque = moldear; otro toque = el panel queda fijo con esa forma (se puede mover desde la cabecera).
        shapeBtn.setOnClickListener {
            commitDrag()
            editing = !editing
            if (!editing) saveSize()
            switchMode()
            if (editing) toast("Agarra una esquina o un borde para moldear el panel") else toast("Panel fijo")
            if (!editing && compact) curPkg?.let { launch(it) }
        }
        backBtn.setOnClickListener {
            compact = false; curPkg = null; curName = null
            refit()
            list.animate().cancel()
            list.alpha = 0f
            list.animate().alpha(1f).setDuration(170L).start()          // la lista vuelve con un fundido en vez de aparecer de golpe
        }

        // Moldear: esquina = cambia ancho y alto; borde = solo ese lado; centro = mueve el panel. Sin límites de forma (hasta muy delgado).
        var zone = 0                 // bits: 1 izquierda, 2 arriba, 4 derecha, 8 abajo; 16 = mover
        var startRawX = 0f
        var startRawY = 0f
        var sL = 0
        var sT = 0
        var sR = 0
        var sB = 0
        var editorButtonPressed = false
        editor.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val loc = IntArray(2)
                    shapeBtn.getLocationOnScreen(loc)
                    val onBtn = ev.rawX >= loc[0] && ev.rawX <= loc[0] + shapeBtn.width && ev.rawY >= loc[1] && ev.rawY <= loc[1] + shapeBtn.height
                    // El editor está por encima del panel y ocupa toda la ventana. Capturamos aquí
                    // el botón para fijar: devolver false no garantiza que el toque llegue al botón
                    // que está debajo en todas las versiones de Android.
                    if (onBtn) {
                        editorButtonPressed = true
                        true
                    } else {
                    // El editor ocupa toda la ventana; el recuadro es el del panel (con un margen de 14 dp afuera para agarrar mejor el borde).
                    val tol = dp(14)
                    val inside = ev.x >= rx - tol && ev.x <= rx + rw + tol && ev.y >= ry - tol && ev.y <= ry + rh + tol
                    if (!inside) {
                        false                                  // fuera del panel, el toque puede continuar hacia otras vistas
                    } else {
                        val w = rw.toFloat()
                        val h = rh.toFloat()
                        val sl = min(dp(32).toFloat(), min(w, h) / 3f)
                        var z = 0
                        if (ev.x < rx + sl) z = z or 1
                        if (ev.y < ry + sl) z = z or 2
                        if (ev.x > rx + w - sl) z = z or 4
                        if (ev.y > ry + h - sl) z = z or 8
                        zone = if (z == 0) 16 else z
                        startRawX = ev.rawX
                        startRawY = ev.rawY
                        sL = rx; sT = ry; sR = rx + rw; sB = ry + rh
                        baseX = rx; baseY = ry; baseW = maxOf(1, rw); baseH = maxOf(1, rh)
                        transforming = true
                        panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)      // el panel se pinta una vez y la GPU lo mueve/estira
                        dragging = true
                        true
                    }
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!transforming) return@setOnTouchListener true
                    val ddx = (ev.rawX - startRawX).toInt()
                    val ddy = (ev.rawY - startRawY).toInt()
                    var l = sL
                    var t = sT
                    var r = sR
                    var b = sB
                    if (zone == 16) {
                        val w = sR - sL
                        val h = sB - sT
                        l = (sL + ddx).coerceIn(0, maxOf(0, sw - w))
                        t = (sT + ddy).coerceIn(0, maxOf(0, sh - h))
                        r = l + w
                        b = t + h
                    } else {
                        if (zone and 1 != 0) l = (sL + ddx).coerceIn(0, maxOf(0, sR - minW))
                        if (zone and 4 != 0) r = (sR + ddx).coerceIn(minOf(sw, sL + minW), sw)
                        if (zone and 2 != 0) t = (sT + ddy).coerceIn(0, maxOf(0, sB - minH))
                        if (zone and 8 != 0) b = (sB + ddy).coerceIn(minOf(sh, sT + minH), sh)
                    }
                    rx = l
                    ry = t
                    rw = r - l
                    rh = b - t
                    pushFrame()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (editorButtonPressed) {
                        editorButtonPressed = false
                        shapeBtn.performClick()                // alterna moldear/fijo de forma fiable
                    } else {
                        dragging = false
                        commitDrag()
                        saveSize()
                        refreshIcons()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    editorButtonPressed = false
                    dragging = false
                    commitDrag()
                    true
                }
                else -> true
            }
        }

        // Panel fijo: se mueve agarrándolo de la cabecera (título / barrita), sin cambiar su forma.
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var hx = 0f
        var hy = 0f
        var hl = 0
        var ht = 0
        var hMoved = false
        header.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { hx = ev.rawX; hy = ev.rawY; hl = rx; ht = ry; hMoved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - hx
                    val dy = ev.rawY - hy
                    if (!hMoved && (abs(dx) > slop || abs(dy) > slop)) hMoved = true     // un toque suelto no lo mueve
                    if (hMoved) {
                        rx = (hl + dx.toInt()).coerceIn(0, maxOf(0, sw - rw))
                        ry = (ht + dy.toInt()).coerceIn(0, maxOf(0, sh - curH()))
                        pushFrame()
                    }
                    true
                }
                else -> true
            }
        }

        var setupShown = false
        list.setOnItemClickListener { _, _, pos, _ ->
            val r = rows.getOrNull(pos) ?: return@setOnItemClickListener
            if (r.pkg.isEmpty()) return@setOnItemClickListener
            // Para abrir la app DENTRO del panel el teléfono necesita ventanas flotantes. Si no están, se intenta activarlas solas;
            // si tampoco se puede, la primera vez se explica y se lleva a Opciones de desarrollador (el segundo toque abre la app normal).
            if (!freeformReady() && !tryEnableFreeform() && !setupShown) {
                setupShown = true
                toast("Para abrir la app dentro del panel activa «Ventanas de forma libre» en Opciones de desarrollador", true)
                try {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
                return@setOnItemClickListener
            }
            curPkg = r.pkg
            curName = r.label
            launch(r.pkg)                                   // primero se pide la app: empieza a abrirse mientras el panel se anima
            list.animate().cancel()
            list.animate().alpha(0f).setDuration(110L).withEndAction {
                if (apps !== host || curPkg != r.pkg) return@withEndAction
                compact = true                               // el panel se hace una barrita
                refit()
                list.alpha = 1f
                header.animate().cancel()
                header.alpha = 0f
                header.animate().alpha(1f).setDuration(150L).start()
            }.start()
        }

        // La lista de la vez anterior (o la que se preparó al abrir las casillas) sale al instante; después se revisa en segundo plano.
        val cached = appRows
        if (cached != null && cached.isNotEmpty()) rows.addAll(cached) else rows.add(AppRow("Buscando apps…", ""))
        try {
            wm.addView(host, p)
            apps = host
            appsLp = p
        } catch (e: Exception) {
            return
        }
        // Entrada suave: el panel aparece con un fundido y un leve crecimiento (sin mover la ventana).
        panel.alpha = 0f
        panel.scaleX = 0.94f
        panel.scaleY = 0.94f
        panel.pivotX = rw / 2f
        panel.pivotY = curH() / 2f
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170L)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
            .withEndAction { panel.pivotX = 0f; panel.pivotY = 0f }.start()
        onIconsReady = { if (apps === host && !dragging) refreshIcons() }
        appsStop = {
            Choreographer.getInstance().removeFrameCallback(frameCb)
            onIconsReady = null
        }
        warmApps { out ->
            if (apps === host) {
                val same = out.isNotEmpty() && out.size == rows.size && out.indices.all { rows[it].pkg == out[it].pkg }
                if (!same) {
                    rows.clear()
                    if (out.isEmpty()) rows.add(AppRow("No encontré apps", "")) else rows.addAll(out)
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun closeApps() {
        appsStop?.invoke(); appsStop = null
        apps?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        apps = null
        appsLp = null
        avoidCenterY = -1
        idleUntil = SystemClock.uptimeMillis() + 800L        // al cerrar el panel, el amigo sigue con lo suyo
    }

    private fun closeMusic(reset: Boolean = true) {
        job.cancelChildren()                                  // deja de cargar miniaturas que ya no se ven
        musicTick?.let { ui.removeCallbacks(it) }
        musicTick = null
        music?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        music = null
        musicLp = null
        if (reset) { curFolder = null; curSongs = emptyList() }
        idleUntil = SystemClock.uptimeMillis() + 800L        // al cerrar el panel, el amigo sigue con lo suyo
    }
}
