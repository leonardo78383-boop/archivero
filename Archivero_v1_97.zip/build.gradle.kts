plugins {
    id("com.android.application") version "8.7.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}

// Hace que `gradle assembleRelease` funcione desde la raíz
tasks.register("assembleRelease") {
    dependsOn(":app:assembleRelease")
    group = "build"
    description = "Compila el APK release del módulo app"
}
