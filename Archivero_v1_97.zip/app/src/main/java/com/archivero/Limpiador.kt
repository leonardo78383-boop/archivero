package com.archivero

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class CleanPhase { IDLE, CLEANING, DONE }

/**
 * Limpiador de residuos de la propia app (sin mascota ni animaciones):
 *  - archivos temporales en la caché (interna y externa) de Archivero,
 *  - miniaturas y carpetas leídas que la app guarda en memoria para ir más rápido.
 * NO toca tus archivos, ni la papelera, ni otras apps.
 * Vive en el mini panel de las 3 rayitas.
 */
class CleanerState(context: Context, private val store: Store) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("limpiador", Context.MODE_PRIVATE)

    /** true = la burbuja flotante puede mostrarse fuera de la app (si hay permiso). */
    var out by mutableStateOf(prefs.getBoolean("out", false))
    var junk by mutableLongStateOf(-1L)           // -1 = midiendo
    var phase by mutableStateOf(CleanPhase.IDLE)
    var say by mutableStateOf<String?>(null)
    var sayId by mutableIntStateOf(0)
    var settingsOpen by mutableStateOf(false)     // pantalla de Ajustes abierta
    var hint by mutableStateOf("")                // título de la pantalla actual (lo pone App)
    var sayMs = 2800L                             // cuánto dura el mensaje

    fun save() { prefs.edit().putBoolean("out", out).apply() }
    fun talk(msg: String?, ms: Long = 2800L) { say = msg; sayMs = ms; sayId++ }

    private fun sizeOf(f: File?): Long =
        if (f == null || !f.exists()) 0L else if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun wipe(d: File?) {
        d?.listFiles()?.forEach { runCatching { if (it.isDirectory) it.deleteRecursively() else it.delete() } }
    }

    /** Residuos actuales en bytes: caché en disco + miniaturas en memoria. */
    suspend fun measure(): Long = withContext(Dispatchers.IO) {
        sizeOf(ctx.cacheDir) + sizeOf(ctx.externalCacheDir) + Thumbs.sizeBytes()
    }

    suspend fun refresh() { junk = measure() }

    suspend fun clean() {
        if (phase == CleanPhase.CLEANING) return
        phase = CleanPhase.CLEANING
        try {
            talk("Limpiando…")
            val before = measure()
            withContext(Dispatchers.IO) { wipe(ctx.cacheDir); wipe(ctx.externalCacheDir) }
            store.clearMemoryCaches()
            val after = measure()
            junk = after
            val freed = (before - after).coerceAtLeast(0L)
            phase = CleanPhase.DONE
            talk(if (freed > 0) "¡Listo! ${fmtSize(freed)} liberados" else "Todo estaba limpio")
            delay(1200)
        } finally {
            phase = CleanPhase.IDLE
        }
    }
}

// ───────────── Capa sobre toda la app: mini panel y mensajes ─────────────

@Composable
fun CleanerLayer(c: CleanerState, store: Store, panelOpen: Boolean, onClosePanel: () -> Unit) {
    LaunchedEffect(panelOpen) { c.refresh() }
    LaunchedEffect(c.sayId) {
        if (c.say != null) { delay(c.sayMs); c.say = null }
    }

    Box(Modifier.fillMaxSize()) {
        if (panelOpen) {
            CleanerPanel(
                c,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 66.dp, end = 8.dp),
                onSettings = { c.settingsOpen = true; onClosePanel() }
            )
        }
        val msg = c.say
        if (msg != null) {
            val shape = ChamferShape(8.dp)
            Text(
                msg, color = Pal.White, fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 96.dp)
                    .clip(shape).background(Pal.Ink).border(1.dp, Pal.Line, shape)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
        // El "papel grande" de Ajustes, por encima de todo.
        if (c.settingsOpen) AjustesSheet(store) { c.settingsOpen = false }
    }
}

// ───────────── Mini panel ─────────────

@Composable
private fun CleanerPanel(c: CleanerState, modifier: Modifier, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shape = ChamferShape(14.dp)
    Column(
        modifier
            .width(224.dp)
            .vidrio3D(shape, 16.dp, glow = true)
            .esquinasLuz()
            .clip(shape)
            .pointerInput(Unit) { detectTapGestures { } }       // que los toques no pasen a lo de abajo
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(12.dp).background(Pal.Accent))
            Spacer(Modifier.width(8.dp))
            Text("LIMPIEZA", color = Pal.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Residuos", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(if (c.junk < 0) "…" else fmtSize(c.junk), color = Pal.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(6.dp))
        SegBar((c.junk.coerceAtLeast(0L) / (30f * 1024 * 1024)).coerceIn(0f, 1f), Modifier.fillMaxWidth(), segments = 20, height = 3.dp)
        Spacer(Modifier.height(10.dp))
        Text(
            if (c.phase == CleanPhase.CLEANING) "Limpiando…" else "Limpiar residuos",
            color = Pal.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(ChamferShape(6.dp))
                .border(1.dp, Pal.Accent, ChamferShape(6.dp))
                .clickable { scope.launch { c.clean() } }
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Burbuja flotante", color = Pal.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = c.out,
                onCheckedChange = {
                    c.out = it
                    c.save()
                    if (it && !FriendLink.canDraw(ctx)) c.talk("Falta el permiso: actívalo en Ajustes", 3500L)
                }
            )
        }
        Text(
            "Ajustes", color = Pal.Muted, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(ChamferShape(6.dp)).clickable(onClick = onSettings).padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}
