package com.archivero

import androidx.compose.foundation.background
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tonos de las superficies (nombre heredado de "vidrio"): ahora planos y limpios. */
object Glass {
    val Top: Color get() = Pal.Card
    val Mid: Color get() = Pal.Card
    val Bottom: Color get() = Pal.Card
    val Rim: Color get() = Pal.Line
    val Rim2: Color get() = Pal.Line
    val Rim3: Color get() = Pal.Line
}

/** Fondo de Inicio: liso (blanco en el tema claro, negro suave en el oscuro). */
fun Modifier.fondoInicio(): Modifier = this.background(Pal.Black)

/** Superficie elevada: tarjeta lisa con esquinas redondeadas, canto fino y una sombra muy suave (sin degradados ni brillos). */
fun Modifier.vidrio3D(shape: Shape, elevation: Dp = 10.dp, glow: Boolean = false): Modifier = this
    .shadow(minOf(elevation, 3.dp), shape, ambientColor = Color(0x22000000), spotColor = Color(0x22000000))
    .background(Pal.Card, shape)
    .border(1.dp, if (glow) Pal.Accent else Pal.Line, shape)

/** Antes dibujaba "esquinas de luz"; el diseño elegante no las usa. Se deja como no-op para no tocar a quien la llama. */
fun Modifier.esquinasLuz(color: Color = Pal.Accent, largo: Dp = 12.dp, alpha: Float = 0.85f, topIzq: Boolean = true, topDer: Boolean = false): Modifier = this

/** Título de sección: barrita amarilla y texto limpio en negrita. */
@Composable
fun SectionTitle(text: String) {
    Row(Modifier.padding(start = 20.dp, top = 22.dp, end = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).background(Pal.Accent, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Pal.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
