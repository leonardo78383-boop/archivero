package com.archivero

import androidx.compose.animation.core.LinearEasing
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil

/** Antes: esquina cortada en diagonal. Ahora: esquinas redondeadas con el radio indicado (mismo nombre para no tocar a quien la usa). */
class ChamferShape(private val cut: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = (with(density) { cut.toPx() } * 1.3f).coerceAtMost(minOf(size.width, size.height) / 2f)
        return Outline.Rounded(androidx.compose.ui.geometry.RoundRect(0f, 0f, size.width, size.height, CornerRadius(r, r)))
    }
}

/** Antes: cada esquina cortada en diagonal. Ahora: esquinas redondeadas; el radio es el mayor de los indicados (un poco más suave). */
class CutShape(
    private val tl: Dp = 0.dp, private val tr: Dp = 0.dp,
    private val br: Dp = 0.dp, private val bl: Dp = 0.dp
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val m = minOf(size.width, size.height) / 2f
        val r = (with(density) { maxOf(maxOf(tl, tr), maxOf(br, bl)).toPx() } * 1.3f).coerceAtMost(m)
        return Outline.Rounded(androidx.compose.ui.geometry.RoundRect(0f, 0f, size.width, size.height, CornerRadius(r, r)))
    }
}

/** Ruedita de carga: un arco fino que gira sobre un aro tenue. */
@Composable
fun ThinSpinner(d: Dp = 32.dp, color: Color = Pal.White) {
    val t = rememberInfiniteTransition(label = "spin")
    val angleS = t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart), label = "angle"
    )
    Canvas(Modifier.size(d)) {
        val angle = angleS.value          // se lee al dibujar: girar no recompone la pantalla
        val sw = 2.dp.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(Pal.Line, 0f, 360f, false, tl, sz, style = Stroke(sw))
        drawArc(color, angle - 90f, 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
    }
}

/** Línea de carga fina (indeterminada). */
@Composable
fun ThinLoading(modifier: Modifier = Modifier.fillMaxWidth()) {
    LinearProgressIndicator(modifier = modifier.height(2.dp), color = Pal.White, trackColor = Pal.Line)
}

/** Barra de progreso lisa y redondeada, rellena de amarillo hasta [frac] (0..1). [segments] se ignora (nombre heredado). */
@Composable
fun SegBar(frac: Float, modifier: Modifier = Modifier, segments: Int = 14, height: Dp = 4.dp) {
    val shown = remember { Animatable(0f) }
    LaunchedEffect(frac) {
        shown.animateTo(frac.coerceIn(0f, 1f), tween(Anim.ms(350), easing = FastOutSlowInEasing))
    }
    Canvas(modifier.height(maxOf(height, 5.dp))) {
        val r = CornerRadius(size.height / 2f, size.height / 2f)
        drawRoundRect(color = Pal.Line, size = size, cornerRadius = r)
        val w = size.width * shown.value
        if (w > 0f) drawRoundRect(color = Pal.Accent, size = Size(maxOf(w, size.height), size.height), cornerRadius = r)
    }
}

/**
 * Carpeta moderna: pestaña y cuerpo en ámbar, hoja blanca que **sale** al pulsar (animación fluida tipo referencia).
 * Capas (de atrás a adelante): fondo + pestaña → hoja (se eleva y asoma) → tapa frontal (baja un poco al abrir).
 * Resorte táctil: responde al instante y vuelve con un rebote suave. Nítida desde 26 dp hasta 60 dp.
 */
@Composable
fun FolderIcon(w: Dp = 44.dp, pressed: Boolean = false) {
    // Resorte con un toque de rebote para que se sienta "vivo" al abrir y al cerrar.
    val open by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(
            dampingRatio = 0.58f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "folderOpen"
    )
    Canvas(Modifier.size(w, w * 0.82f)) {
        val t = open
        val W = size.width
        val H = size.height
        val r = CornerRadius(W * 0.13f, W * 0.13f)
        val rs = CornerRadius(W * 0.08f, W * 0.08f)

        // --- 1) Fondo + pestaña (siempre fijos) ---
        // Pestaña
        drawRoundRect(Color(0xFFE5A300), Offset(0f, 0f), Size(W * 0.46f, H * 0.36f), r)
        // Cuerpo trasero
        drawRoundRect(Color(0xFFE5A300), Offset(0f, H * 0.14f), Size(W, H * 0.86f), r)

        // --- 2) Hoja blanca: sale hacia arriba de forma marcada ---
        // En reposo asoma un poco; al pulsar sube ~38 % de la altura y se hace más alta.
        val paperLift = H * (0.06f + 0.32f * t)          // de 6 % a 38 %
        val paperH = H * (0.42f + 0.12f * t)             // un poco más alta al salir
        val paperY = H * 0.22f - paperLift
        val paperX = W * 0.10f
        val paperW = W * 0.80f
        // Sombra suave detrás de la hoja (solo cuando se abre)
        if (t > 0.05f) {
            drawRoundRect(
                Color(0x22000000),
                Offset(paperX + W * 0.02f, paperY + H * 0.03f),
                Size(paperW, paperH),
                rs
            )
        }
        // Hoja
        drawRoundRect(Color(0xFFFFFDF8), Offset(paperX, paperY), Size(paperW, paperH), rs)
        // Borde muy fino
        drawRoundRect(
            Color(0xFFE8E4D8),
            Offset(paperX, paperY),
            Size(paperW, paperH),
            rs,
            style = Stroke((W * 0.015f).coerceAtLeast(0.8f))
        )
        // Líneas de "documento" sutiles (solo cuando ya asomó bastante)
        if (t > 0.35f) {
            val lineAlpha = ((t - 0.35f) / 0.65f).coerceIn(0f, 0.55f)
            val lineC = Color(0xFFD0CBB8).copy(alpha = lineAlpha)
            val lx = paperX + paperW * 0.12f
            val lw = paperW * 0.76f
            for (i in 0..2) {
                val ly = paperY + paperH * (0.28f + i * 0.18f)
                drawLine(lineC, Offset(lx, ly), Offset(lx + lw, ly), strokeWidth = (W * 0.012f).coerceAtLeast(0.7f), cap = StrokeCap.Round)
            }
        }

        // --- 3) Tapa frontal: baja un poco al abrir (efecto de "abrir la carpeta") ---
        val flapDrop = H * 0.06f * t
        val flapTop = H * 0.30f + flapDrop
        drawRoundRect(
            Brush.verticalGradient(
                listOf(Color(0xFFFFD84D), Color(0xFFFFC400)),
                startY = flapTop,
                endY = H
            ),
            Offset(0f, flapTop),
            Size(W, H - flapTop),
            r
        )
        // Filo de luz en el borde superior de la tapa
        drawLine(
            Color(0xAAFFFFFF),
            Offset(W * 0.08f, flapTop + 1.5f),
            Offset(W * 0.92f, flapTop + 1.5f),
            strokeWidth = (W * 0.028f).coerceAtLeast(1.2f),
            cap = StrokeCap.Round
        )
        // Sombra interior sutil bajo el filo (profundidad)
        drawLine(
            Color(0x18000000),
            Offset(W * 0.10f, flapTop + (W * 0.04f)),
            Offset(W * 0.90f, flapTop + (W * 0.04f)),
            strokeWidth = (W * 0.02f).coerceAtLeast(1f),
            cap = StrokeCap.Round
        )
    }
}

/**
 * Archivo moderno: hoja blanca con esquinas suaves y la esquina doblada, un símbolo según el tipo en negro con un toque amarillo
 * y la extensión en una pastilla negra con letras amarillas.
 */
@Composable
fun FileIcon(isDir: Boolean, kind: Kind, ext: String, pressed: Boolean = false) {
    if (isDir) { FolderIcon(42.dp, pressed); return }
    Box(Modifier.size(34.dp, 42.dp), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 1.dp.toPx()
            val l = sw / 2; val t = sw / 2
            val r = size.width - sw / 2; val b = size.height - sw / 2
            val c = size.width * 0.30f           // esquina doblada
            val k = size.width * 0.14f           // redondeo
            val sheet = Path().apply {
                moveTo(l + k, t); lineTo(r - c, t); lineTo(r, t + c); lineTo(r, b - k)
                quadraticBezierTo(r, b, r - k, b); lineTo(l + k, b)
                quadraticBezierTo(l, b, l, b - k); lineTo(l, t + k)
                quadraticBezierTo(l, t, l + k, t); close()
            }
            val face = if (Pal.light) Color(0xFFFFFFFF) else Color(0xFF2B2B2B)
            val edge = if (Pal.light) Color(0xFFD7D7CF) else Color(0xFF444444)
            val fold = if (Pal.light) Color(0xFFEDEDE6) else Color(0xFF3C3C3C)
            drawPath(sheet, face)
            drawPath(sheet, edge, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            // Esquina doblada
            val f = Path().apply {
                moveTo(r - c, t); lineTo(r - c, t + c - k * 0.7f)
                quadraticBezierTo(r - c, t + c, r - c + k * 0.7f, t + c); lineTo(r, t + c); close()
            }
            drawPath(f, fold)
            drawPath(f, edge, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            glyph(kind, size.width / 2f, size.height * 0.42f, size.width * 0.15f, Pal.White, Pal.Accent, Stroke(1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (ext.isNotEmpty()) {
            val pill = RoundedCornerShape(50)
            Text(
                ext.take(4).uppercase(), color = Pal.AccentHi, fontSize = 7.sp, lineHeight = 9.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp, maxLines = 1,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .background(Color(0xFF111111), pill)
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            )
        }
    }
}

private fun poly(p: List<Offset>, close: Boolean = false) = Path().apply {
    moveTo(p[0].x, p[0].y)
    for (i in 1 until p.size) lineTo(p[i].x, p[i].y)
    if (close) close()
}

/** Símbolo de cada tipo: trazo redondeado en [ink] y un detalle relleno en [acc]; [u] es la unidad de medida (el dibujo mide unas 4,5 u de ancho). */
private fun DrawScope.glyph(kind: Kind, cx: Float, cy: Float, u: Float, ink: Color, acc: Color, st: Stroke) {
    fun o(x: Float, y: Float) = Offset(cx + x * u, cy + y * u)
    when (kind) {
        Kind.IMG -> {
            drawPath(poly(listOf(o(-2.2f, 1.6f), o(-0.7f, -0.4f), o(0.4f, 0.8f), o(1.2f, -0.1f), o(2.2f, 1.6f))), ink, style = st)
            drawCircle(acc, u * 0.62f, o(1.2f, -1.7f))
        }
        Kind.VID -> {
            drawCircle(ink, u * 2.1f, o(0f, 0f), style = st)
            drawPath(poly(listOf(o(-0.7f, -1.1f), o(1.2f, 0f), o(-0.7f, 1.1f)), close = true), acc)
        }
        Kind.AUD -> {
            drawLine(ink, o(0.9f, 1.1f), o(0.9f, -1.9f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawCircle(ink, u * 0.95f, o(-0.2f, 1.3f))
            drawLine(acc, o(0.9f, -1.9f), o(2.1f, -1.1f), strokeWidth = st.width * 1.3f, cap = StrokeCap.Round)
        }
        Kind.APK -> {
            drawPath(poly(listOf(o(0f, -1.9f), o(1.7f, -0.95f), o(1.7f, 0.95f), o(0f, 1.9f), o(-1.7f, 0.95f), o(-1.7f, -0.95f)), close = true), ink, style = st)
            drawLine(acc, o(0f, 0f), o(0f, 1.9f), strokeWidth = st.width * 1.3f, cap = StrokeCap.Round)
            drawPath(poly(listOf(o(-1.7f, -0.95f), o(0f, 0f), o(1.7f, -0.95f))), ink, style = st)
        }
        else -> {
            drawLine(ink, o(-1.8f, -1.2f), o(1.8f, -1.2f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(ink, o(-1.8f, 0f), o(1.8f, 0f), strokeWidth = st.width, cap = StrokeCap.Round)
            drawLine(acc, o(-1.8f, 1.2f), o(0.6f, 1.2f), strokeWidth = st.width * 1.3f, cap = StrokeCap.Round)
        }
    }
}


// ───────────── Íconos del panel lateral (línea fina, esquinas cortadas, un toque rosa) ─────────────

/** Casita: techo en ángulo, esquinas cortadas y la puerta en rosa. */
@Composable
fun HomeIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val body = Path().apply {
            moveTo(s * 0.5f, s * 0.08f)
            lineTo(s * 0.94f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.48f)
            lineTo(s * 0.82f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.92f)
            lineTo(s * 0.18f, s * 0.48f)
            lineTo(s * 0.06f, s * 0.48f)
            close()
        }
        drawPath(body, Pal.Sel)
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        val door = Path().apply {
            moveTo(s * 0.42f, s * 0.92f); lineTo(s * 0.42f, s * 0.64f); lineTo(s * 0.58f, s * 0.64f); lineTo(s * 0.58f, s * 0.92f)
        }
        drawPath(door, Pal.Accent, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Papelera de reciclaje: tres flechas formando un triángulo (rosa) sobre línea blanca. */
@Composable
fun RecycleIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val cx = s * 0.5f
        val cy = s * 0.56f
        val r = s * 0.4f
        val pts = listOf(
            Offset(cx, cy - r),
            Offset(cx + r * 0.866f, cy + r * 0.5f),
            Offset(cx - r * 0.866f, cy + r * 0.5f)
        )
        for (i in 0 until 3) {
            val a = pts[i]
            val b = pts[(i + 1) % 3]
            val p0 = Offset(a.x + (b.x - a.x) * 0.16f, a.y + (b.y - a.y) * 0.16f)
            val p1 = Offset(a.x + (b.x - a.x) * 0.7f, a.y + (b.y - a.y) * 0.7f)
            drawLine(line, p0, p1, strokeWidth = sw, cap = StrokeCap.Round)
            // Punta de flecha: la dirección girada +150° y -150°.
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len = kotlin.math.sqrt(dx * dx + dy * dy)
            val ux = dx / len
            val uy = dy / len
            val h = s * 0.15f
            val lx = ux * (-0.866f) - uy * 0.5f
            val ly = ux * 0.5f + uy * (-0.866f)
            val rx = ux * (-0.866f) + uy * 0.5f
            val ry = -ux * 0.5f + uy * (-0.866f)
            drawLine(Pal.Accent, p1, Offset(p1.x + lx * h, p1.y + ly * h), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(Pal.Accent, p1, Offset(p1.x + rx * h, p1.y + ry * h), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Tacho de basura: tapa con asa, cuerpo con esquinas inferiores cortadas y rayitas en rosa. */
@Composable
fun TrashIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        drawLine(line, Offset(s * 0.12f, s * 0.26f), Offset(s * 0.88f, s * 0.26f), strokeWidth = sw, cap = StrokeCap.Round)
        val handle = Path().apply {
            moveTo(s * 0.38f, s * 0.26f); lineTo(s * 0.38f, s * 0.1f); lineTo(s * 0.62f, s * 0.1f); lineTo(s * 0.62f, s * 0.26f)
        }
        drawPath(handle, line, style = Stroke(sw, join = StrokeJoin.Round))
        val body = Path().apply {
            moveTo(s * 0.2f, s * 0.26f); lineTo(s * 0.2f, s * 0.82f); lineTo(s * 0.3f, s * 0.92f)
            lineTo(s * 0.7f, s * 0.92f); lineTo(s * 0.8f, s * 0.82f); lineTo(s * 0.8f, s * 0.26f)
        }
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        for (x in listOf(0.4f, 0.5f, 0.6f)) {
            drawLine(Pal.Accent, Offset(s * x, s * 0.42f), Offset(s * x, s * 0.78f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Candado de línea fina: cerrado o abierto, con el ojo de la cerradura en rosa. */
@Composable
fun LockIcon(open: Boolean = false, w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        val shackle = Path().apply {
            if (open) {
                moveTo(s * 0.34f, s * 0.46f); lineTo(s * 0.34f, s * 0.28f)
                quadraticBezierTo(s * 0.34f, s * 0.1f, s * 0.52f, s * 0.1f)
                quadraticBezierTo(s * 0.68f, s * 0.1f, s * 0.7f, s * 0.24f)
            } else {
                moveTo(s * 0.32f, s * 0.46f); lineTo(s * 0.32f, s * 0.3f)
                quadraticBezierTo(s * 0.32f, s * 0.1f, s * 0.5f, s * 0.1f)
                quadraticBezierTo(s * 0.68f, s * 0.1f, s * 0.68f, s * 0.3f); lineTo(s * 0.68f, s * 0.46f)
            }
        }
        drawPath(shackle, line, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val body = Path().apply {
            moveTo(s * 0.2f, s * 0.46f); lineTo(s * 0.8f, s * 0.46f); lineTo(s * 0.8f, s * 0.84f)
            lineTo(s * 0.72f, s * 0.92f); lineTo(s * 0.28f, s * 0.92f); lineTo(s * 0.2f, s * 0.84f); close()
        }
        drawPath(body, Pal.Sel)
        drawPath(body, line, style = Stroke(sw, join = StrokeJoin.Round))
        drawCircle(Pal.Accent, s * 0.055f, Offset(s * 0.5f, s * 0.64f))
        drawLine(Pal.Accent, Offset(s * 0.5f, s * 0.64f), Offset(s * 0.5f, s * 0.76f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

/** Llave de línea fina: argolla con el centro rosa y dientes. */
@Composable
fun KeyIcon(w: Dp = 26.dp) {
    Canvas(Modifier.size(w, w)) {
        val s = size.width
        val sw = 1.5.dp.toPx()
        val line = Pal.White.copy(alpha = 0.92f)
        drawCircle(line, s * 0.19f, Offset(s * 0.29f, s * 0.35f), style = Stroke(sw))
        drawCircle(Pal.Accent, s * 0.05f, Offset(s * 0.29f, s * 0.35f))
        drawLine(line, Offset(s * 0.42f, s * 0.48f), Offset(s * 0.9f, s * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(s * 0.7f, s * 0.71f), Offset(s * 0.58f, s * 0.84f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(line, Offset(s * 0.82f, s * 0.82f), Offset(s * 0.72f, s * 0.93f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}


/** Almacenamiento interno: cajita redondeada con la franja de disco y una luz amarilla. */
@Composable
fun DriveIcon(w: Dp = 28.dp) {
    Canvas(Modifier.size(w, w * 0.8f)) {
        val W = size.width
        val H = size.height
        val r = CornerRadius(W * 0.16f, W * 0.16f)
        drawRoundRect(Pal.White, Offset(0f, 0f), Size(W, H), r)
        drawRoundRect(Pal.Accent, Offset(W * 0.14f, H * 0.66f), Size(W * 0.34f, H * 0.12f), CornerRadius(H * 0.06f, H * 0.06f))
        drawCircle(Pal.Accent, H * 0.09f, Offset(W * 0.82f, H * 0.72f))
        drawRoundRect(Pal.Black.copy(alpha = 0.25f), Offset(W * 0.14f, H * 0.2f), Size(W * 0.72f, H * 0.1f), CornerRadius(H * 0.05f, H * 0.05f))
    }
}
