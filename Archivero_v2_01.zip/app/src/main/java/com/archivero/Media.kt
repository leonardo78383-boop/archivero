package com.archivero

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.basicMarquee
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.math.abs
import kotlin.random.Random
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Qué se está viendo a pantalla completa. */
sealed interface Viewer {
    class Images(val files: List<File>, val index: Int) : Viewer
    class Video(val files: List<File>, val index: Int) : Viewer
}

/** Abre un archivo con el visor/reproductor interno si es foto, vídeo o música; si no, con otra app. */
fun openEntry(store: Store, ctx: Context, e: Entry, siblings: List<Entry>) {
    when (e.kind) {
        Kind.IMG -> {
            val imgs = siblings.filter { !it.isDir && it.kind == Kind.IMG }.map { it.file }
            val i = imgs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.viewer = Viewer.Images(imgs, i) else openFile(ctx, e.file)
        }
        Kind.VID -> {
            val vids = siblings.filter { !it.isDir && it.kind == Kind.VID }.map { it.file }
            val i = vids.indexOfFirst { it.path == e.file.path }
            store.viewer = if (i >= 0) Viewer.Video(vids, i) else Viewer.Video(listOf(e.file), 0)
        }
        Kind.AUD -> {
            val songs = siblings.filter { !it.isDir && it.kind == Kind.AUD }.map { it.file }
            val i = songs.indexOfFirst { it.path == e.file.path }
            if (i >= 0) store.music.start(songs, i) else openFile(ctx, e.file)
        }
        else -> openFile(ctx, e.file)
    }
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ───────────────────────── Capa a pantalla completa ─────────────────────────

@Composable
fun MediaOverlay(v: Viewer, onClose: () -> Unit) {
    // El pointerInput vacío hace que los toques no "atraviesen" hacia la pantalla de abajo.
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }) {
        when (v) {
            is Viewer.Images -> ImageViewer(v, onClose)
            is Viewer.Video -> VideoViewer(v, onClose)
        }
    }
}

@Composable
private fun TopBar(title: String, onClose: () -> Unit, extra: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onClose) { Text("✕", color = Color.White, fontSize = 20.sp) }
        Text(title, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        extra()
    }
}

// ───────────────────────── Visor de imágenes ─────────────────────────

/** Lee la imagen reducida (máx. ~2048 px) y ya girada según su orientación. */
suspend fun loadBitmap(f: File, maxDim: Int = if (Mem.low) 1536 else 2048): Bitmap? = withContext(Dispatchers.IO) {
    try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { decoder, info, _ ->
            val s = maxOf(info.size.width, info.size.height) / maxDim
            if (s > 1) decoder.setTargetSampleSize(s)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }
}

@Composable
fun ImageViewer(v: Viewer.Images, onClose: () -> Unit) {
    BackHandler { onClose() }
    val pager = rememberPagerState(initialPage = v.index, pageCount = { v.files.size })
    var zoomed by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = !zoomed,
            beyondViewportPageCount = 1,   // la foto siguiente/anterior ya está cargada al deslizar
            key = { v.files[it].path }
        ) { page ->
            ImagePage(v.files[page]) { zoomed = it }
        }
        val cur = pager.currentPage.coerceIn(0, v.files.size - 1)
        TopBar("${cur + 1}/${v.files.size}  ${v.files[cur].name}", onClose)
    }
}

@Composable
private fun ImagePage(f: File, onZoom: (Boolean) -> Unit) {
    val res by produceState(false to (null as ImageBitmap?), f) {
        value = true to loadBitmap(f)?.asImageBitmap()
    }
    val (done, img) = res
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            !done -> {
                // Mientras se decodifica la foto grande se muestra al instante la miniatura que ya estaba en memoria (si la hay),
                // en vez de una ruedita sobre negro: abrir una foto se siente inmediato y luego se afina.
                val t = remember(f.path) { Thumbs.cached(f.path) }
                if (t != null) Image(bitmap = t.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                else ThinSpinner()
            }
            img == null -> Text("No se pudo mostrar esta imagen", color = Color.White, textAlign = TextAlign.Center)
            else -> ZoomImage(img, onZoom)
        }
    }
}

/** Zoom con dos dedos, arrastrar cuando está ampliada y doble toque para ampliar o volver. */
@Composable
private fun ZoomImage(img: ImageBitmap, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                    } else {
                        scale = 2.5f
                    }
                    onZoom(scale > 1f)
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val fingers = ev.changes.count { it.pressed }
                        // Con un dedo y sin zoom no se toca nada: así el deslizar pasa a la foto siguiente.
                        if (fingers >= 2 || scale > 1f) {
                            val ns = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                            val mx = box.width * (ns - 1f) / 2f
                            val my = box.height * (ns - 1f) / 2f
                            val o = if (ns > 1f) offset + ev.calculatePan() else Offset.Zero
                            offset = Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
                            scale = ns
                            onZoom(ns > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        Image(
            bitmap = img,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )
    }
}

// ───────────────────────── Reproductor de vídeo ─────────────────────────

@Composable
fun VideoViewer(v: Viewer.Video, onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = LocalContext.current
    val vv = remember { VideoView(ctx) }
    var idx by remember { mutableIntStateOf(v.index.coerceIn(0, v.files.size - 1)) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showUi by remember { mutableStateOf(true) }
    var landscape by remember { mutableStateOf(false) }
    val file = v.files[idx]

    DisposableEffect(vv) {
        onDispose {
            vv.stopPlayback()
            ctx.findActivity()?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Cada vez que cambia el vídeo (⏮ ⏭ o fin del anterior) se carga el nuevo en el mismo reproductor.
    LaunchedEffect(idx) {
        pos = 0
        dur = 0
        playing = false
        vv.setVideoURI(Uri.fromFile(v.files[idx]))
    }

    // Barra de progreso propia (sin MediaController): se actualiza cada 300 ms mientras reproduce.
    LaunchedEffect(playing, idx) {
        while (playing) {
            if (drag == null) pos = try { vv.currentPosition } catch (e: Exception) { pos }
            delay(300)
        }
    }

    // Los controles se esconden solos a los 4 segundos mientras reproduce.
    LaunchedEffect(showUi, playing, idx, drag) {
        if (showUi && playing && drag == null) {
            delay(4000)
            showUi = false
        }
    }

    fun next() { if (idx + 1 < v.files.size) idx++ }
    fun prev() { if (pos > 3000 || idx == 0) { vv.seekTo(0); pos = 0 } else idx-- }
    fun toggle() {
        if (vv.isPlaying) { vv.pause(); playing = false } else { vv.start(); playing = true }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                vv.apply {
                    setOnPreparedListener { mp ->
                        dur = mp.duration
                        start()
                        playing = true
                    }
                    setOnCompletionListener {
                        if (idx + 1 < v.files.size) idx++ else { playing = false; showUi = true }
                    }
                    setOnErrorListener { _, _, _ ->
                        playing = false
                        showUi = true
                        toast(ctx, "No se puede reproducir este vídeo")
                        true
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        // Capa transparente: un toque muestra u oculta los controles.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showUi = !showUi } }
        )
        if (showUi) {
            Box(Modifier.align(Alignment.TopCenter)) {
                TopBar("${idx + 1}/${v.files.size}  ${file.name}", onClose) {
                    TextButton(onClick = {
                        landscape = !landscape
                        ctx.findActivity()?.requestedOrientation =
                            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }) { Text("⟳ Girar", color = Color.White) }
                }
            }
            val max = maxOf(1, dur).toFloat()
            val shown = (drag ?: pos.toFloat()).coerceIn(0f, max)
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Slider(
                    value = shown,
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let { vv.seekTo(it.toInt()); pos = it.toInt() }
                        drag = null
                    },
                    valueRange = 0f..max
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        fmtTime(shown.toInt()) + " / " + fmtTime(dur),
                        Modifier.padding(start = 8.dp).weight(1f),
                        color = Color.White, style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { prev() }) { Text("⏮", fontSize = 22.sp) }
                    TextButton(onClick = { toggle() }) { Text(if (playing) "⏸" else "▶", fontSize = 22.sp) }
                    TextButton(onClick = { next() }, enabled = idx + 1 < v.files.size) { Text("⏭", fontSize = 22.sp) }
                }
            }
        }
    }
}

// ───────────────────────── Reproductor de música ─────────────────────────

/** Presets del ecualizador (milibeles por banda, 5 bandas típicas; se recortan/rellenan según el hardware). */
private val EQ_PRESETS: Map<String, ShortArray> = mapOf(
    "Plano" to shortArrayOf(0, 0, 0, 0, 0),
    "Acústico" to shortArrayOf(300, 200, 0, 150, 200),
    "Bajos+" to shortArrayOf(600, 400, 100, 0, 0),
    "Bajos−" to shortArrayOf(-400, -250, 0, 50, 100),
    "Clásico" to shortArrayOf(300, 150, -100, 200, 350),
    "Profundo" to shortArrayOf(500, 300, 0, -100, -150),
    "Electrónica" to shortArrayOf(400, 200, 0, 200, 400),
    "Hip-Hop" to shortArrayOf(500, 350, 100, -50, 150),
    "Jazz" to shortArrayOf(250, 150, 0, 150, 250),
    "Latina" to shortArrayOf(400, 250, 0, 100, 200),
    "Loudness" to shortArrayOf(450, 200, -150, 100, 300),
    "Lounge" to shortArrayOf(200, 100, 0, 100, 200),
    "Piano" to shortArrayOf(150, 100, 50, 150, 250),
    "Pop" to shortArrayOf(250, 150, 0, 150, 250),
    "R&B" to shortArrayOf(400, 250, 50, 100, 200),
    "Rock" to shortArrayOf(400, 250, -50, 150, 350),
    "Altavoces chicos" to shortArrayOf(400, 300, 150, 250, 350),
    "Agudos+" to shortArrayOf(0, 0, 100, 350, 500),
    "Agudos−" to shortArrayOf(100, 50, 0, -250, -400),
)

class MusicPlayer(private val appCtx: Context? = null) {
    private var mp: MediaPlayer? = null

    // Foco de audio: si entra una llamada o suena otra app, la música se pausa sola (y sigue cuando se libera).
    private val audioManager: android.media.AudioManager? = appCtx?.getSystemService(android.media.AudioManager::class.java)
    private var focusReq: android.media.AudioFocusRequest? = null
    private var resumeOnFocus = false
    private val audioAttrs: android.media.AudioAttributes = android.media.AudioAttributes.Builder()
        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private val focusListener = android.media.AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            android.media.AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                if (playing) toggle()
            }
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (playing) { resumeOnFocus = true; toggle() }
            }
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Un aviso corto (navegador, notificación): la música baja de volumen y sigue, no se pausa.
                duck = 0.25f
                ensureTick()
            }
            android.media.AudioManager.AUDIOFOCUS_GAIN -> {
                duck = 1f
                ensureTick()
                if (resumeOnFocus) { resumeOnFocus = false; if (!playing) toggle() }
            }
        }
    }

    private fun requestFocus() {
        val am = audioManager ?: return
        try {
            val req = focusReq ?: android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(audioAttrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build().also { focusReq = it }
            am.requestAudioFocus(req)
        } catch (ignored: Exception) { }
    }

    private fun abandonFocus() {
        resumeOnFocus = false
        try { focusReq?.let { audioManager?.abandonAudioFocusRequest(it) } } catch (ignored: Exception) { }
    }

    var queue by mutableStateOf<List<File>>(emptyList())
    var index by mutableIntStateOf(0)
    var playing by mutableStateOf(false)
    var position by mutableIntStateOf(0)
    var duration by mutableIntStateOf(0)

    val current: File? get() = queue.getOrNull(index)
    val active: Boolean get() = queue.isNotEmpty()

    // ── Sonido suave + efectos 8D / 9D ──
    // Siempre (con o sin efecto): la música entra y sale con un fundido corto (sin golpes al empezar, pausar o cambiar de canción)
    // y un limitador suave domina los picos fuertes (DynamicsProcessing, si el teléfono lo soporta).
    // 8D: el sonido rodea tu cabeza despacio (11 s por vuelta), con un ambiente muy leve, y los agudos se apagan un poco
    //     cuando "pasa por detrás" (así se siente delante / detrás, no solo izquierda / derecha).
    // 9D: lo mismo más lento (15 s), más ancho (virtualizador) y con una sala cálida y larga de cola oscura (reverberación suave).
    // Solo uno a la vez; tocar el mismo otra vez lo apaga. Se mantiene al cambiar de canción y al salir de la app (es el mismo
    // reproductor). Todo es opcional: si el teléfono no soporta algún efecto, se omite y el resto sigue funcionando.
    // Se nota más con audífonos.
    var fx by mutableIntStateOf(0)
        private set

    // Parámetros del efecto que elige el usuario (se recuerdan): velocidad del giro (×0,5 a ×2) e intensidad (30 % a 100 %:
    // cuánto se desplaza el sonido entre los dos oídos y cuánta amplitud da el virtualizador).
    private val fxPrefs = appCtx?.getSharedPreferences("archivero", Context.MODE_PRIVATE)
    var fxSpeed by mutableFloatStateOf((fxPrefs?.getFloat("fx_speed", 1f) ?: 1f).coerceIn(0.5f, 2f))
        private set
    var fxDepth by mutableFloatStateOf((fxPrefs?.getFloat("fx_depth", 1f) ?: 1f).coerceIn(0.3f, 1f))
        private set
    private var duck = 1f                        // 1 = normal; menos = otra app habla encima (la música baja)

    // ── Ecualizador de usuario (se combina con 8D/9D) ──
    // Niveles por banda en milibeles (típicamente -1500..1500). Se recuerdan.
    // presetName: nombre del preset activo ("Plano", "Bajos+", … o "Personalizado").
    var eqEnabled by mutableStateOf(fxPrefs?.getBoolean("eq_on", false) ?: false)
        private set
    var eqPreset by mutableStateOf(fxPrefs?.getString("eq_preset", "Plano") ?: "Plano")
        private set
    // Hasta 10 bandas (el hardware decide cuántas hay realmente).
    private val eqUserLevels = ShortArray(10) { i ->
        (fxPrefs?.getInt("eq_b$i", 0) ?: 0).toShort()
    }
    /** Copia pública de los niveles actuales (para la UI). */
    var eqBands by mutableStateOf(eqUserLevels.copyOf())
        private set
    var eqBandFreqs by mutableStateOf(FloatArray(0))   // Hz de cada banda (se rellena al crear el Equalizer)
        private set
    var eqBandMin by mutableIntStateOf(-1500)
        private set
    var eqBandMax by mutableIntStateOf(1500)
        private set

    /** Cambia velocidad y/o intensidad del efecto 8D/9D. Se aplica al instante y se recuerda. */
    fun ajustarFx(speed: Float? = null, depth: Float? = null) {
        if (speed != null) fxSpeed = speed.coerceIn(0.5f, 2f)
        if (depth != null) fxDepth = depth.coerceIn(0.3f, 1f)
        fxPrefs?.edit()?.putFloat("fx_speed", fxSpeed)?.putFloat("fx_depth", fxDepth)?.apply()
        if (depth != null) {
            try {
                virt?.let { v -> if (v.strengthSupported) v.setStrength(virtStrength(fx).toShort()) }
            } catch (ignored: Exception) { }
        }
        ensureTick()
    }

    private fun virtStrength(mode: Int): Int = ((if (mode == 8) 350 else 550) * fxDepth).toInt().coerceIn(0, 1000)
    private var eq: android.media.audiofx.Equalizer? = null
    private var virt: android.media.audiofx.Virtualizer? = null
    private var env: android.media.audiofx.EnvironmentalReverb? = null
    private var dyn: android.media.audiofx.DynamicsProcessing? = null
    private var eqFreq = FloatArray(0)
    private var eqCur = ShortArray(0)
    private var eqMin = -1500
    private var eqMax = 1500
    private var eqClock = 0L
    private val fxHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val tickRun = object : Runnable {
        override fun run() { tickSound() }
    }
    private var tickOn = false
    private var lastTick = 0L
    private var phase = 0f                       // vuelta del sonido (0..1), sigue donde iba al pausar
    private var gain = 1f                        // fundido: 0..1 (se aplica al cuadrado, que se oye más natural)
    private var gainTarget = 1f
    private var gainPerMs = 0f
    private var onFaded: (() -> Unit)? = null    // qué hacer cuando el fundido de salida llega a cero

    private fun ensureTick() {
        if (tickOn) return
        tickOn = true
        lastTick = android.os.SystemClock.uptimeMillis()
        fxHandler.post(tickRun)
    }

    private fun fadeTo(target: Float, ms: Int) {
        gainTarget = target
        gainPerMs = kotlin.math.abs(target - gain) / ms.coerceAtLeast(1).toFloat()
        ensureTick()
    }

    private fun fadeOutThen(ms: Int, action: () -> Unit) {
        onFaded = action
        fadeTo(0f, ms)
    }

    /** Se ejecuta cada 20 ms mientras hay fundido o efecto: mueve el fundido, el giro, el volumen por canal y (cada 100 ms) los agudos. */
    private fun tickSound() {
        val m = mp
        if (m == null) { tickOn = false; return }
        val now = android.os.SystemClock.uptimeMillis()
        val dt = (now - lastTick).coerceIn(0L, 100L).toFloat()
        lastTick = now
        if (gain != gainTarget) {
            val d = gainPerMs * dt
            gain = if (gain < gainTarget) kotlin.math.min(gainTarget, gain + d) else kotlin.math.max(gainTarget, gain - d)
        }
        var l = 1f
        var r = 1f
        val mode = fx
        if (mode != 0) {
            val period = (if (mode == 8) 11000f else 15000f) / fxSpeed
            val depth = (if (mode == 8) 0.85f else 0.90f) * fxDepth     // nunca se apaga del todo un oído: se siente más natural
            if (playing) {
                phase += dt / period
                if (phase >= 1f) phase -= 1f
            }
            val a = phase * 6.2831855f
            val ang = (kotlin.math.sin(a) * depth + 1f) * 0.7853982f
            val back = 0.93f + 0.07f * kotlin.math.cos(a)      // un poco más bajo al pasar por detrás
            l = (kotlin.math.cos(ang) * 1.4142135f * back).coerceIn(0f, 1f)
            r = (kotlin.math.sin(ang) * 1.4142135f * back).coerceIn(0f, 1f)
            if (now - eqClock >= 100L) {
                eqClock = now
                updateEq(mode, (1f - kotlin.math.cos(a)) * 0.5f)
            }
        }
        val g = gain * gain * duck
        try { m.setVolume(l * g, r * g) } catch (ignored: Exception) { }
        if (gain <= 0.001f && gainTarget <= 0.001f) {
            val act = onFaded
            onFaded = null
            if (act != null) act()
        }
        if (gain != gainTarget || (fx != 0 && playing) || onFaded != null) fxHandler.postDelayed(tickRun, 20) else tickOn = false
    }

    /** Ecualizador: combina los niveles del usuario + curva suave de 8D/9D (graves un poco más llenos, agudos más dulces, y los agudos se apagan más cuando el sonido va por detrás). */
    private fun updateEq(mode: Int, behind: Float) {
        val e = eq ?: return
        val warmHigh = if (mode == 8) 120f else if (mode == 9) 200f else 0f
        val behindDepth = if (mode == 8) 350f else if (mode == 9) 450f else 0f
        val userOn = eqEnabled
        try {
            for (i in eqFreq.indices) {
                val f = eqFreq[i]
                val w = ((f - 2500f) / 6000f).coerceIn(0f, 1f)
                val lw = ((200f - f) / 150f).coerceIn(0f, 1f)
                val fxPart = if (mode != 0) (100f * lw - warmHigh * w - behindDepth * w * behind) else 0f
                val userPart = if (userOn && i < eqUserLevels.size) eqUserLevels[i].toFloat() else 0f
                val target = (fxPart + userPart).toInt().coerceIn(eqMin, eqMax)
                if (kotlin.math.abs(target - eqCur[i].toInt()) >= 12) {
                    e.setBandLevel(i.toShort(), target.toShort())
                    eqCur[i] = target.toShort()
                }
            }
        } catch (ignored: Exception) { }
    }

    /** Activa/desactiva el ecualizador de usuario. */
    fun alternarEqActivo(on: Boolean) {
        eqEnabled = on
        fxPrefs?.edit()?.putBoolean("eq_on", on)?.apply()
        applyFx()
    }

    /** Aplica un preset por nombre. "Personalizado" no cambia los niveles. */
    fun aplicarEqPreset(name: String) {
        eqPreset = name
        val levels = EQ_PRESETS[name]
        if (levels != null) {
            for (i in eqUserLevels.indices) {
                eqUserLevels[i] = if (i < levels.size) levels[i] else 0
            }
            eqBands = eqUserLevels.copyOf()
            saveEqBands()
        }
        applyUserEqNow()
        fxPrefs?.edit()?.putString("eq_preset", name)?.apply()
    }

    /** Cambia el nivel de una banda (milibeles). Marca el preset como Personalizado. */
    fun setEqBand(index: Int, level: Int) {
        if (index !in eqUserLevels.indices) return
        eqUserLevels[index] = level.coerceIn(eqBandMin, eqBandMax).toShort()
        eqBands = eqUserLevels.copyOf()
        eqPreset = "Personalizado"
        saveEqBands()
        fxPrefs?.edit()?.putString("eq_preset", "Personalizado")?.apply()
        applyUserEqNow()
    }

    private fun saveEqBands() {
        val ed = fxPrefs?.edit() ?: return
        for (i in eqUserLevels.indices) ed.putInt("eq_b$i", eqUserLevels[i].toInt())
        ed.apply()
    }

    /** Aplica de inmediato los niveles de usuario (sin recrear el Equalizer). */
    private fun applyUserEqNow() {
        val e = eq ?: return
        val mode = fx
        val behind = if (mode != 0) {
            val a = phase * 6.2831855f
            ((1f - kotlin.math.cos(a)) * 0.5f).coerceIn(0f, 1f)
        } else 0f
        updateEq(mode, behind)
    }

    private fun releaseFx() {
        if (env != null) {
            try { mp?.setAuxEffectSendLevel(0f) } catch (ignored: Exception) { }
            try { mp?.attachAuxEffect(0) } catch (ignored: Exception) { }
        }
        try { env?.release() } catch (ignored: Exception) { }
        try { eq?.release() } catch (ignored: Exception) { }
        try { virt?.release() } catch (ignored: Exception) { }
        env = null; eq = null; virt = null
        eqFreq = FloatArray(0)
        eqCur = ShortArray(0)
    }

    private fun releaseSoft() {
        try { dyn?.release() } catch (ignored: Exception) { }
        dyn = null
    }

    /** Limitador suave (solo con 8D/9D): ataque rápido, salida lenta y umbral alto (-1 dB), para no apagar la dinámica. */
    private fun applySoft() {
        releaseSoft()
        val m = mp ?: return
        try {
            val cfg = android.media.audiofx.DynamicsProcessing.Config.Builder(
                android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2, false, 0, false, 0, false, 0, true
            ).build()
            val d = android.media.audiofx.DynamicsProcessing(0, m.audioSessionId, cfg)
            val lim = android.media.audiofx.DynamicsProcessing.Limiter(true, true, 0, 3f, 160f, 12f, -1f, 0f)
            d.setLimiterAllChannelsTo(lim)
            d.setEnabled(true)
            dyn = d
        } catch (ignored: Exception) { }
    }

    private fun applyFx() {
        releaseFx()
        val m = mp ?: return
        val mode = fx
        val needEq = mode != 0 || eqEnabled
        // Limitador solo cuando hay 8D/9D (el EQ de usuario solo no suele saturar).
        if (mode != 0) applySoft() else releaseSoft()
        if (needEq || mode != 0) {
            val sid = try { m.audioSessionId } catch (e: Exception) { 0 }
            if (needEq) {
                try {
                    val e = android.media.audiofx.Equalizer(0, sid)
                    eq = e
                    val n = e.numberOfBands.toInt()
                    val range = e.bandLevelRange
                    eqMin = range[0].toInt()
                    eqMax = range[1].toInt()
                    eqBandMin = eqMin
                    eqBandMax = eqMax
                    eqFreq = FloatArray(n) { i -> e.getCenterFreq(i.toShort()) / 1000f }
                    eqBandFreqs = FloatArray(n) { i -> e.getCenterFreq(i.toShort()) / 1000f }
                    eqCur = ShortArray(n) { i -> e.getBandLevel(i.toShort()) }
                    e.setEnabled(true)
                    eqClock = 0L
                    // Aplica de una los niveles de usuario (+ curva 8D/9D si hay).
                    updateEq(mode, 0f)
                } catch (ignored: Exception) { }
            }
            if (mode != 0) {
                try {
                    val v = android.media.audiofx.Virtualizer(0, sid)
                    virt = v
                    if (v.strengthSupported) v.setStrength(virtStrength(mode).toShort())
                    v.setEnabled(true)
                } catch (ignored: Exception) { }
                try {
                    // Reverberación como efecto auxiliar: mezcla (send) muy baja en 8D y media en 9D; cola cálida (los agudos se apagan).
                    val rv = android.media.audiofx.EnvironmentalReverb(0, 0)
                    env = rv
                    if (mode == 8) {
                        rv.setRoomLevel((-600).toShort()); rv.setRoomHFLevel((-900).toShort())
                        rv.setDecayTime(1100); rv.setDecayHFRatio(500.toShort())
                        rv.setReflectionsLevel((-1400).toShort()); rv.setReflectionsDelay(18)
                        rv.setReverbLevel((-900).toShort()); rv.setReverbDelay(30)
                        rv.setDiffusion(900.toShort()); rv.setDensity(1000.toShort())
                    } else {
                        rv.setRoomLevel((-400).toShort()); rv.setRoomHFLevel((-1100).toShort())
                        rv.setDecayTime(2600); rv.setDecayHFRatio(450.toShort())
                        rv.setReflectionsLevel((-1200).toShort()); rv.setReflectionsDelay(25)
                        rv.setReverbLevel((-600).toShort()); rv.setReverbDelay(40)
                        rv.setDiffusion(1000.toShort()); rv.setDensity(1000.toShort())
                    }
                    rv.setEnabled(true)
                    m.attachAuxEffect(rv.id)
                    m.setAuxEffectSendLevel(if (mode == 8) 0.22f else 0.40f)
                } catch (ignored: Exception) { }
            }
        }
        ensureTick()        // aplica el volumen (o lo devuelve a normal si se apagó el efecto)
    }

    /** Activa 8 o 9 (3D). Si ya estaba activo ese mismo, lo apaga. */
    fun alternarFx(mode: Int) {
        if (mode != 8 && mode != 9) return
        val next = if (fx == mode) 0 else mode
        // Cambio suave: baja el volumen un momento, aplica el nuevo efecto y vuelve a subir (evita el golpe al pasar de 8D ↔ 9D ↔ off).
        fadeOutThen(180) {
            fx = next
            applyFx()
            fadeTo(1f, 280)
        }
    }

    /** true = la canción que suena se repite sin parar al terminar; false = sigue con la siguiente como siempre. */
    var repeatOne by mutableStateOf(false)
        private set

    /** true = al terminar una canción pasa a otra al azar de la lista. */
    var shuffle by mutableStateOf(false)
        private set

    fun toggleShuffle() { shuffle = !shuffle }

    /** true mientras la canción se está preparando (todavía no se sabe cuánto dura). */
    val loading: Boolean get() = active && duration == 0

    fun setRepeat(on: Boolean) {
        repeatOne = on
        try { mp?.isLooping = on } catch (ignored: Exception) { }
    }

    fun start(files: List<File>, i: Int) {
        queue = files
        play(i)
    }

    private fun play(i: Int) {
        if (i !in queue.indices) return
        index = i
        position = 0
        duration = 0
        releasePlayer()
        val m = MediaPlayer()
        try {
            // Con la pantalla apagada o fuera de la app, que la música no se corte.
            appCtx?.let { m.setWakeMode(it, android.os.PowerManager.PARTIAL_WAKE_LOCK) }
            m.setAudioAttributes(audioAttrs)
            m.setDataSource(queue[i].path)
            m.isLooping = repeatOne            // si "repetir" está activo, también se repite la canción que se elija después
            m.setOnPreparedListener {
                gain = 0f
                gainTarget = 0f
                try { it.setVolume(0f, 0f) } catch (ignored: Exception) { }
                it.start()
                duration = it.duration
                playing = true
                applyFx()                          // sin efecto: sonido limpio y directo (alta fidelidad); con 8D/9D: efecto + limitador de seguridad
                try { startVisualizer(it.audioSessionId) } catch (ignored: Exception) { }
                fadeTo(1f, 900)                    // entra con un fundido suave
            }
            m.setOnCompletionListener { advance(false) }
            m.setOnErrorListener { _, _, _ ->
                playing = false
                true
            }
            mp = m
            requestFocus()
            m.prepareAsync()
        } catch (e: Exception) {
            mp = null
            try { m.release() } catch (ignored: Exception) { }
            playing = false
        }
    }

    fun toggle() {
        val m = mp ?: return
        try {
            if (playing) {
                playing = false                                                  // la pantalla ya muestra pausa
                fadeOutThen(300) { try { mp?.pause() } catch (ignored: Exception) { } }
            } else {
                onFaded = null                                                   // si estaba bajando para pausar, se cancela
                m.start()
                playing = true
                fadeTo(1f, 500)                                                  // vuelve con un fundido suave
            }
        } catch (e: Exception) {
            playing = false
        }
    }

    fun next() = advance(true)

    /** Pasa a la siguiente; [soft] = baja el volumen un instante antes de cambiar (no si la canción ya terminó sola). */
    private fun advance(soft: Boolean) {
        if (shuffle && queue.size > 1) {
            var j = index
            while (j == index) j = kotlin.random.Random.nextInt(queue.size)
            switchTo(j, soft)
        } else if (index + 1 < queue.size) switchTo(index + 1, soft) else { playing = false; position = 0; abandonFocus() }
    }

    private fun switchTo(i: Int, soft: Boolean) {
        if (soft && mp != null && playing) fadeOutThen(220) { play(i) } else play(i)
    }

    fun prev() {
        if (position > 3000 || index == 0) seek(0) else switchTo(index - 1, true)
    }

    fun seek(ms: Int) {
        try { mp?.seekTo(ms) } catch (ignored: Exception) { }
        position = ms
    }

    /** Lo llama la pantalla cada medio segundo para mover la barra de progreso. */
    fun tick() {
        val m = mp ?: return
        try { if (m.isPlaying) position = m.currentPosition } catch (ignored: Exception) { }
    }

    // ── Visualizador de audio (barras reactivas a la canción) ──
    private var visualizer: android.media.audiofx.Visualizer? = null
    /** Niveles 0..1 por barra; la UI los lee y anima. */
    var vizBars by mutableStateOf(FloatArray(32) { 0.08f })
        private set
    private val vizSmooth = FloatArray(32) { 0.08f }

    private fun startVisualizer(sessionId: Int) {
        stopVisualizer()
        if (sessionId == 0) return
        try {
            val v = android.media.audiofx.Visualizer(sessionId)
            val range = android.media.audiofx.Visualizer.getCaptureSizeRange()
            val size = range[1].coerceAtMost(512).coerceAtLeast(range[0])
            v.captureSize = size
            v.setDataCaptureListener(object : android.media.audiofx.Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: android.media.audiofx.Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(visualizer: android.media.audiofx.Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft == null || fft.size < 4) return
                    val n = vizSmooth.size
                    val step = ((fft.size / 2) - 1).coerceAtLeast(1) / n.toFloat()
                    for (i in 0 until n) {
                        val idx = (1 + i * step).toInt().coerceIn(1, fft.size / 2 - 1) * 2
                        val re = fft[idx].toInt()
                        val im = if (idx + 1 < fft.size) fft[idx + 1].toInt() else 0
                        val mag = kotlin.math.sqrt((re * re + im * im).toFloat()) / 180f
                        // Suavizado: sube rápido, baja lento
                        val target = mag.coerceIn(0f, 1f)
                        vizSmooth[i] = if (target > vizSmooth[i]) {
                            vizSmooth[i] * 0.35f + target * 0.65f
                        } else {
                            vizSmooth[i] * 0.82f + target * 0.18f
                        }
                    }
                    vizBars = vizSmooth.copyOf()
                }
            }, android.media.audiofx.Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            visualizer = v
        } catch (ignored: Exception) {
            visualizer = null
        }
    }

    private fun stopVisualizer() {
        try { visualizer?.enabled = false } catch (ignored: Exception) { }
        try { visualizer?.release() } catch (ignored: Exception) { }
        visualizer = null
        for (i in vizSmooth.indices) vizSmooth[i] = 0.08f
        vizBars = vizSmooth.copyOf()
    }

    private fun releasePlayer() {
        fxHandler.removeCallbacks(tickRun)
        tickOn = false
        onFaded = null
        stopVisualizer()
        releaseFx()
        releaseSoft()
        mp?.let { try { it.release() } catch (ignored: Exception) { } }
        mp = null
    }

    fun stop() {
        val old = mp
        mp = null                                  // el estado queda limpio ya; el sonido viejo baja solo y se libera
        fxHandler.removeCallbacks(tickRun)
        tickOn = false
        onFaded = null
        stopVisualizer()
        releaseFx()
        releaseSoft()
        abandonFocus()
        queue = emptyList()
        playing = false
        position = 0
        duration = 0
        if (old != null) {
            var v = if (gain < 0.2f) 0.2f else gain
            val h = fxHandler
            val r = object : Runnable {
                override fun run() {
                    v -= 0.1f
                    if (v <= 0f) {
                        try { old.release() } catch (ignored: Exception) { }
                    } else {
                        try {
                            old.setVolume(v * v, v * v)
                            h.postDelayed(this, 20)
                        } catch (e: Exception) {
                            try { old.release() } catch (ignored: Exception) { }
                        }
                    }
                }
            }
            h.post(r)
        }
    }

    fun release() = releasePlayer()
}

fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

// ── Íconos vectoriales del reproductor (no son emojis: se dibujan igual en cualquier teléfono) ──
private object PIco {
    const val PLAY = "M8 5v14l11-7z"
    const val PAUSE = "M6 19h4V5H6v14zm8-14v14h4V5h-4z"
    const val PREV = "M6 6L8 6L8 18L6 18Z M9.5 12L18 6L18 18Z"
    const val NEXT = "M6 6L14.5 12L6 18Z M16 6L18 6L18 18L16 18Z"
    const val CLOSE = "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
    const val STOP = "M6 6h12v12H6z"
    const val SHUFFLE = "M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z"
    const val REPEAT = "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"
    const val BACK = "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"
    const val SHARE = "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"
    const val EQ = "M10 20h4V4h-4v16zm-6 0h4v-8H4v8zM16 9v11h4V9h-4z"
    const val NOTE = "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"
    private val cache = HashMap<String, androidx.compose.ui.graphics.Path>()
    fun path(d: String): androidx.compose.ui.graphics.Path =
        cache.getOrPut(d) { androidx.compose.ui.graphics.vector.PathParser().parsePathString(d).toPath() }
}

@Composable
private fun PIcon(d: String, tint: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(Modifier.size(size)) {
        val k = this.size.width / 24f
        withTransform({ scale(k, k, androidx.compose.ui.geometry.Offset.Zero) }) {
            drawPath(PIco.path(d), tint)
        }
    }
}

/** Botón redondo con ícono. [filled] = círculo plateado (el de reproducir/pausa). */
@Composable
private fun PBtn(d: String, size: androidx.compose.ui.unit.Dp, icon: androidx.compose.ui.unit.Dp, filled: Boolean = false, tint: androidx.compose.ui.graphics.Color = Pal.White, onClick: () -> Unit) {
    val bg = if (filled) Modifier.background(
        androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Pal.AccentHi, Pal.Pink)),
        androidx.compose.foundation.shape.CircleShape
    ) else Modifier
    Box(
        Modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape).then(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { PIcon(d, if (filled) Pal.AccentOn else tint, icon) }
}

/** Carátula de la canción (o una nota si no tiene). */
@Composable
private fun PCover(f: java.io.File, size: androidx.compose.ui.unit.Dp, radius: androidx.compose.ui.unit.Dp, elev: androidx.compose.ui.unit.Dp = 8.dp) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<Bitmap?>(Thumbs.cached(f.path), f.path) {
        value = Thumbs.cached(f.path) ?: Thumbs.load(ctx, f, Kind.AUD)
    }
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(radius)
    Box(
        Modifier.size(size).shadow(elev, shape).clip(shape).background(Pal.Sel),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        else PIcon(PIco.NOTE, Pal.Muted, size * 0.45f)
    }
}

/**
 * Panel del ecualizador (botón ⋮≡ del reproductor grande).
 * Estilo cercano al de la captura: gráfico de bandas, presets horizontales, 8D/9D combinables.
 */
@Composable
private fun EqPanel(m: MusicPlayer, dim: Color, white: Color) {
    val freqs = m.eqBandFreqs
    val bands = m.eqBands
    val n = freqs.size.coerceAtMost(bands.size).coerceAtMost(8)
    val minL = m.eqBandMin.toFloat()
    val maxL = m.eqBandMax.toFloat()
    val presetNames = remember {
        listOf(
            "Plano", "Acústico", "Bajos+", "Bajos−", "Clásico", "Profundo",
            "Electrónica", "Hip-Hop", "Jazz", "Latina", "Loudness", "Lounge",
            "Piano", "Pop", "R&B", "Rock", "Altavoces chicos", "Agudos+", "Agudos−", "Personalizado"
        )
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .background(Color(0xF0121218))
            .padding(14.dp)
    ) {
        // Encabezado: interruptor EQ + 8D / 9D
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Ecualizador", color = white, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = m.eqEnabled,
                onCheckedChange = { m.alternarEqActivo(it) },
                colors = SwitchDefaults.colors(checkedTrackColor = Pal.Accent, checkedThumbColor = Pal.AccentOn)
            )
        }
        Spacer(Modifier.height(8.dp))

        // 8D / 9D (combinables con el EQ)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            FxTile("8D", m.fx == 8, 44.dp) { m.alternarFx(8) }
            Spacer(Modifier.width(10.dp))
            FxTile("9D", m.fx == 9, 44.dp) { m.alternarFx(9) }
        }
        Spacer(Modifier.height(4.dp))
        Text(fxCaption(m.fx), color = dim, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (m.fx != 0) {
            Spacer(Modifier.height(4.dp))
            FxSliders(m)
        }

        if (n > 0) {
            Spacer(Modifier.height(10.dp))
            // Gráfico de bandas (sliders verticales)
            Row(
                Modifier.fillMaxWidth().height(140.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                for (i in 0 until n) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        val level = if (i < bands.size) bands[i].toFloat() else 0f
                        // Slider vertical: usamos un Slider normal rotado
                        Box(
                            Modifier
                                .height(110.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Slider(
                                value = level.coerceIn(minL, maxL),
                                onValueChange = { m.setEqBand(i, it.toInt()) },
                                valueRange = minL..maxL,
                                enabled = m.eqEnabled,
                                modifier = Modifier
                                    .requiredWidth(110.dp)
                                    .graphicsLayer { rotationZ = -90f },
                                colors = SliderDefaults.colors(
                                    thumbColor = Pal.Accent,
                                    activeTrackColor = Pal.Accent,
                                    inactiveTrackColor = Color(0x44FFFFFF)
                                )
                            )
                        }
                        val label = when {
                            freqs[i] >= 1000f -> "${(freqs[i] / 1000f).toInt()}k"
                            else -> "${freqs[i].toInt()}"
                        }
                        Text(label, color = dim, fontSize = 10.sp)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            // Presets horizontales
            val scroll = rememberScrollState()
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scroll),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                presetNames.forEach { name ->
                    val selected = m.eqPreset == name
                    Text(
                        name,
                        color = if (selected) Pal.AccentOn else white,
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                            .background(if (selected) Pal.Accent else Color(0x33FFFFFF))
                            .clickable {
                                if (name != "Personalizado") m.aplicarEqPreset(name)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        } else {
            Spacer(Modifier.height(6.dp))
            Text(
                if (m.eqEnabled) "Activá el EQ y esperá un momento…" else "Activá el interruptor para usar el ecualizador",
                color = dim, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

/** Casilla cuadrada de efecto (8D / 9D): esquinas cortadas como las del explorador; encendida = plata con texto oscuro. */
@Composable
private fun FxTile(label: String, on: Boolean, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    val shape = CutShape(tl = 8.dp, br = 8.dp)
    val L = Pal.light
    val bg = if (on) Brush.verticalGradient(listOf(Pal.AccentHi, Pal.Accent))
             else Brush.verticalGradient(listOf(Pal.Card, Pal.Card))
    val ink = if (on) Pal.AccentOn else Pal.White
    Box(
        Modifier.size(size).clip(shape).background(bg)
            .border(1.dp, if (on) Pal.Accent else Pal.Line, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = ink, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 0.5.sp, maxLines = 1, softWrap = false)
    }
}

private fun fxCaption(fx: Int): String = when (fx) {
    8 -> "8D · el sonido te rodea, suave y despacio"
    9 -> "9D · giro lento + sala cálida y envolvente"
    else -> "Sonido 3D apagado · mejor con audífonos"
}

/** Velocidad e intensidad del efecto 8D/9D (solo se ven mientras hay un efecto encendido). */
@Composable
private fun FxSliders(m: MusicPlayer) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Velocidad", color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.width(72.dp))
        Slider(value = m.fxSpeed, onValueChange = { m.ajustarFx(speed = it) }, valueRange = 0.5f..2f, modifier = Modifier.weight(1f))
        Text("×%.1f".format(m.fxSpeed), color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.width(34.dp))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Intensidad", color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.width(72.dp))
        Slider(value = m.fxDepth, onValueChange = { m.ajustarFx(depth = it) }, valueRange = 0.3f..1f, modifier = Modifier.weight(1f))
        Text("%d%%".format((m.fxDepth * 100).toInt()), color = Pal.Muted, fontSize = 11.sp, modifier = Modifier.width(34.dp))
    }
}

// ───────────────────────── Reproductor estilo «Gestor de archivos» ─────────────────────────
// Abajo: una barra baja con la carátula, el título que se desliza, el artista, ▶/⏸ y ■ (tocarla abre el reproductor grande).
// Reproductor grande: la carátula ocupa toda la pantalla, arriba «1 de 11», ecualizador y compartir; abajo título, artista,
// barra de tiempo y ⇄ ⏮ ⏸ ⏭ ↻. Arrastrar el dedo de lado sobre la carátula salta en la canción y muestra la hora grande.

private class MusicMeta(val title: String?, val artist: String?)

@Composable
private fun rememberMeta(f: java.io.File): MusicMeta? =
    produceState<MusicMeta?>(null, f.path) {
        value = withContext(Dispatchers.IO) {
            try {
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(f.path)
                    val t = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim()?.takeIf { it.isNotEmpty() }
                    val a = (r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        ?: r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST))?.trim()?.takeIf { it.isNotEmpty() }
                    MusicMeta(t, a)
                } finally { try { r.release() } catch (ignored: Exception) { } }
            } catch (e: Exception) { MusicMeta(null, null) }
        }
    }.value

/** Carátula grande (la que trae la canción, reducida a ~1024 px); si no tiene, la miniatura que ya usa la app. */
private suspend fun loadCoverBig(ctx: Context, f: java.io.File): Bitmap? {
    val own = withContext(Dispatchers.IO) {
        try {
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(f.path)
                val bytes = r.embeddedPicture
                if (bytes == null) null else {
                    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var k = 1
                    while (maxOf(o.outWidth, o.outHeight) / k > 1024) k *= 2
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, android.graphics.BitmapFactory.Options().apply { inSampleSize = k })
                }
            } finally { try { r.release() } catch (ignored: Exception) { } }
        } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
    }
    return own ?: Thumbs.cached(f.path) ?: Thumbs.load(ctx, f, Kind.AUD)
}

/** Barra de tiempo del reproductor grande: pista fina clara, relleno blanco y una perilla pequeña. */
@Composable
private fun PSeek(shown: Float, max: Float, onDrag: (Float) -> Unit, onDone: () -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val frac = (shown / max).coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().height(32.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(max) { detectTapGestures { o -> onDrag((o.x / w).coerceIn(0f, 1f) * max); onDone() } }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> onDrag((o.x / w).coerceIn(0f, 1f) * max) },
                    onDragEnd = { onDone() },
                    onDragCancel = { onDone() },
                    onHorizontalDrag = { ch, _ -> onDrag((ch.position.x / w).coerceIn(0f, 1f) * max) }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(32.dp)) {
            val h = 2.dp.toPx()
            val cy = size.height / 2f
            drawRect(Color(0x55FFFFFF), androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(size.width, h))
            val x = size.width * frac
            drawRect(Color.White, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(x, h))
            drawCircle(Color.White, 6.dp.toPx(), androidx.compose.ui.geometry.Offset(x.coerceIn(6.dp.toPx(), size.width - 6.dp.toPx()), cy))
        }
    }
}

/** La barra baja: carátula, título que se desliza, artista, ▶/⏸ y ■. Tocarla abre el reproductor grande. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MiniPlayer(m: MusicPlayer, onOpen: () -> Unit) {
    val f = m.current ?: return
    LaunchedEffect(m.playing, m.index) {
        while (m.playing) {
            m.tick()
            delay(500)
        }
    }
    val meta = rememberMeta(f)
    val max = maxOf(1, m.duration).toFloat()
    val frac = (m.position / max).coerceIn(0f, 1f)
    Column(
        Modifier.fillMaxWidth()
            .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Glass.Top, Glass.Mid, Glass.Bottom)))
            .navigationBarsPadding()
    ) {
        // Línea fina de progreso arriba de la barra.
        Box(Modifier.fillMaxWidth().height(2.dp).background(Pal.Line)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Pal.Accent))
        }
        Row(Modifier.fillMaxWidth().height(56.dp).clickable(onClick = onOpen), verticalAlignment = Alignment.CenterVertically) {
            PCover(f, 56.dp, 0.dp, elev = 0.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    meta?.title ?: f.nameWithoutExtension, maxLines = 1, softWrap = false,
                    fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Pal.White,
                    modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                )
                Text(
                    meta?.artist ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp, color = Pal.Muted
                )
            }
            PBtn(if (m.playing) PIco.PAUSE else PIco.PLAY, 44.dp, 24.dp) { m.toggle() }
            PBtn(PIco.STOP, 44.dp, 20.dp) { m.stop() }
            Spacer(Modifier.width(4.dp))
        }
    }
}

private fun Modifier.fillMaxHeight(): Modifier = this.then(Modifier.fillMaxHeight())

/**
 * Reproductor grande rediseñado:
 * - Fondo negro (sin portada a pantalla completa).
 * - Tres portadas en el centro: anterior · actual · siguiente (deslizar para cambiar de canción).
 * - Visualizador de barras (“bits”) animado detrás de las portadas, reacciona mientras suena.
 * - Controles y barra de tiempo abajo; ecualizador y compartir arriba.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MusicFull(m: MusicPlayer, onClose: () -> Unit) {
    val f = m.current ?: return
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler { onClose() }
    LaunchedEffect(m.playing, m.index) {
        while (m.playing) {
            m.tick()
            delay(250)
        }
    }
    val meta = rememberMeta(f)
    var drag by remember { mutableStateOf<Float?>(null) }
    var fxOpen by remember { mutableStateOf(false) }
    val max = maxOf(1, m.duration).toFloat()
    val shown = (drag ?: m.position.toFloat()).coerceIn(0f, max)
    val white = Color.White
    val dim = Color(0xB3FFFFFF)
    val accent = Pal.Accent

    // Índices de las tres tarjetas: prev / actual / next (con wrap si hay cola).
    val q = m.queue
    val idx = m.index
    val prevFile = if (q.isNotEmpty()) q[(idx - 1 + q.size) % q.size] else null
    val nextFile = if (q.isNotEmpty()) q[(idx + 1) % q.size] else null
    val prevCover by produceState<Bitmap?>(null, prevFile?.path) {
        value = prevFile?.let { loadCoverBig(ctx, it) }
    }
    val curCover by produceState<Bitmap?>(null, f.path) {
        value = loadCoverBig(ctx, f)
    }
    val nextCover by produceState<Bitmap?>(null, nextFile?.path) {
        value = nextFile?.let { loadCoverBig(ctx, it) }
    }

    // Visualizador: usa el FFT real del MediaPlayer; si no hay datos, un fallback suave.
    val barCount = 32
    var bars by remember { mutableStateOf(FloatArray(barCount) { 0.08f }) }
    LaunchedEffect(m.playing, m.index) {
        val rnd = Random(System.nanoTime())
        while (true) {
            val real = m.vizBars
            val hasReal = real.any { it > 0.12f }
            if (hasReal && m.playing) {
                bars = real.copyOf(barCount)
            } else {
                val base = if (m.playing) 0.22f else 0.06f
                val energy = if (m.playing) 0.45f else 0.08f
                val t = System.currentTimeMillis() / 1000f
                bars = FloatArray(barCount) { i ->
                    val wave = (sin(t * 3.2f + i * 0.55f) * 0.5f + 0.5f)
                    val pulse = (sin(t * 7.1f + i * 1.3f) * 0.5f + 0.5f)
                    val noise = rnd.nextFloat()
                    (base + energy * (0.45f * wave + 0.35f * pulse + 0.2f * noise)).coerceIn(0.04f, 1f)
                }
            }
            delay(if (m.playing) 40 else 120)
        }
    }

    // Pager centrado en la canción actual (página del medio = actual).
    // Usamos 3 páginas fijas (0=prev, 1=cur, 2=next) y al terminar el swipe cambiamos de pista.
    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 3 })
    LaunchedEffect(m.index) {
        // Al cambiar de canción desde los botones, recentrar el pager.
        if (pagerState.currentPage != 1) pagerState.scrollToPage(1)
    }
    LaunchedEffect(pagerState.settledPage) {
        when (pagerState.settledPage) {
            0 -> {
                m.prev()
                pagerState.scrollToPage(1)
            }
            2 -> {
                m.next()
                pagerState.scrollToPage(1)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Visualizador de bits detrás de las portadas
        Canvas(Modifier.fillMaxSize().padding(top = 80.dp, bottom = 200.dp)) {
            val w = size.width
            val h = size.height
            val gap = 3.dp.toPx()
            val barW = ((w - gap * (barCount - 1)) / barCount).coerceAtLeast(2f)
            val maxH = h * 0.85f
            val accentCol = accent.copy(alpha = 0.85f)
            val glowCol = accent.copy(alpha = 0.25f)
            for (i in 0 until barCount) {
                val bh = maxH * bars[i]
                val x = i * (barW + gap)
                val y = (h - bh) / 2f
                // Resplandor suave detrás
                drawRoundRect(
                    color = glowCol,
                    topLeft = Offset(x - 2f, y - 4f),
                    size = Size(barW + 4f, bh + 8f),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
                drawRoundRect(
                    color = accentCol,
                    topLeft = Offset(x, y),
                    size = Size(barW, bh),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // Arriba: atrás, «1 de N», ecualizador y compartir
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                PBtn(PIco.BACK, 48.dp, 24.dp, tint = white) { onClose() }
                Text(
                    "${m.index + 1} de ${m.queue.size}",
                    color = white, fontSize = 18.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f).padding(start = 6.dp)
                )
                PBtn(PIco.EQ, 48.dp, 22.dp, tint = if (fxOpen || m.fx != 0 || m.eqEnabled) white else dim) { fxOpen = !fxOpen }
                PBtn(PIco.SHARE, 48.dp, 22.dp, tint = white) { shareFile(ctx, f) }
            }
            if (fxOpen) {
                EqPanel(m, dim, white)
            }

            // Zona central: tres portadas (deslizar para cambiar)
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth().height(280.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 56.dp),
                    pageSpacing = 12.dp
                ) { page ->
                    val file = when (page) {
                        0 -> prevFile
                        2 -> nextFile
                        else -> f
                    }
                    val cover = when (page) {
                        0 -> prevCover
                        2 -> nextCover
                        else -> curCover
                    }
                    val isCenter = page == 1
                    CoverCard(
                        file = file,
                        cover = cover,
                        isCenter = isCenter,
                        accent = accent,
                        dim = dim
                    )
                }
            }

            // Título y artista
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                val title = meta?.title
                Text(
                    title ?: f.nameWithoutExtension,
                    color = white, fontSize = 20.sp, fontWeight = FontWeight.Medium,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 26.sp,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    textAlign = TextAlign.Center
                )
                Text(
                    if (m.loading) "Cargando" else (meta?.artist ?: ""),
                    color = dim, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(14.dp))

            // Barra de tiempo
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(fmtTime(shown.toInt()), color = white, fontSize = 13.sp)
                Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    PSeek(shown, max, { drag = it }, { drag?.let { m.seek(it.toInt()) }; drag = null })
                }
                Text(fmtTime(m.duration), color = white, fontSize = 13.sp)
            }

            // Controles
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PBtn(PIco.SHUFFLE, 48.dp, 22.dp, tint = if (m.shuffle) white else Color(0x66FFFFFF)) { m.toggleShuffle() }
                PBtn(PIco.PREV, 56.dp, 30.dp, tint = white) {
                    scope.launch { pagerState.animateScrollToPage(0) }
                }
                PBtn(if (m.playing) PIco.PAUSE else PIco.PLAY, 72.dp, 44.dp, tint = white) { m.toggle() }
                PBtn(PIco.NEXT, 56.dp, 30.dp, tint = white) {
                    scope.launch { pagerState.animateScrollToPage(2) }
                }
                PBtn(PIco.REPEAT, 48.dp, 22.dp, tint = if (m.repeatOne) white else Color(0x66FFFFFF)) { m.setRepeat(!m.repeatOne) }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/** Tarjeta de portada (anterior / actual / siguiente) para el carrusel del reproductor. */
@Composable
private fun CoverCard(
    file: java.io.File?,
    cover: Bitmap?,
    isCenter: Boolean,
    accent: Color,
    dim: Color
) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
    val scale = if (isCenter) 1f else 0.88f
    val alpha = if (isCenter) 1f else 0.7f
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                this.alpha = alpha
            }
            .shadow(if (isCenter) 16.dp else 4.dp, shape)
            .clip(shape)
            .background(Color(0xFF121212))
            .border(1.dp, if (isCenter) accent.copy(alpha = 0.6f) else Color(0x33FFFFFF), shape),
        contentAlignment = Alignment.Center
    ) {
        if (cover != null) {
            Image(
                cover.asImageBitmap(),
                contentDescription = file?.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            PIcon(PIco.NOTE, dim, 64.dp)
        }
        // Viñeta inferior para que se lea el nombre si se quiere en el futuro
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(48.dp)
                .background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))
                )
        )
    }
}

private fun Modifier.statusBarsPadding(): Modifier = this.then(Modifier.statusBarsPadding())
